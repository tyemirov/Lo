"""Preserve the bounded echo reproductions without copying guest filesystems."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd().resolve()
WORK = ROOT / '_scratch/i011-20261020/completion-20261022/http-echo-repro'
OUTPUT = ROOT / 'docs/evidence/i011-qualification-20261022/http-echo-reproduction'
PHASES = ('', 'configured', 'cpu', 'canonical-short')
BINARY_NAMES = {'native', 'repro', 'runner'}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def checked(path: Path) -> Path:
    resolved = path.resolve(strict=True)
    if not resolved.is_relative_to(ROOT):
        raise ValueError(f'path leaves Lo: {path}')
    return resolved


def main() -> None:
    if OUTPUT.exists():
        raise ValueError('evidence output already exists')
    selected: set[Path] = set()
    binaries: list[dict[str, object]] = []
    for phase in PHASES:
        directory = WORK / phase
        for path in directory.iterdir():
            if not path.is_file():
                continue
            path = checked(path)
            if path.name in BINARY_NAMES:
                data = path.read_bytes()
                binaries.append({'path': str(path.relative_to(ROOT)),
                                 'bytes': len(data), 'sha256': digest(data)})
            else:
                selected.add(path)
        for report_path in directory.glob('guest*/report.json'):
            report = json.loads(checked(report_path).read_text())
            selected.add(checked(report_path))
            selected.add(checked(ROOT / report['export']))
            for path in report_path.parent.iterdir():
                if path.is_file() and (path.name in {'serial.log', 'qemu.stderr'}
                                      or path.name.startswith('0.')):
                    selected.add(checked(path))
    OUTPUT.mkdir()
    records: list[dict[str, object]] = []
    for path in sorted(selected):
        data = path.read_bytes()
        relative = path.relative_to(WORK)
        target = OUTPUT / 'files' / (str(relative) + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.compress(data, mtime=0))
        if gzip.decompress(target.read_bytes()) != data:
            raise ValueError(f'archive mismatch: {path}')
        records.append({'path': str(path.relative_to(ROOT)), 'bytes': len(data),
                        'sha256': digest(data), 'archive': str(target.relative_to(OUTPUT)),
                        'archive_sha256': digest(target.read_bytes())})
    prior = checked(ROOT / 'docs/evidence/i011-qualification-20261022/storage-nonpass/manifest.json')
    manifest = {'scope': 'Focused Linux echo diagnostics; not qualification.',
                'semantic_source_sha256': 'f26d0b99e160cc84ecfdb3f511d2a13930c7a9794eca16130573620427d878ca',
                'production_changes': False, 'qualification_rerun': False,
                'i011_complete': False, 'thresholds_changed': False,
                'records': records, 'binary_identities': binaries,
                'prior_campaign': {'path': str(prior.relative_to(ROOT)),
                                   'sha256': digest(prior.read_bytes())},
                'limits': ['Binary identities do not contain binary payloads.',
                           'Guest filesystems and images are derived outputs and are not archived.',
                           'CPU totals include each server lifetime, not only request processing.',
                           'The initial option test used the guest default GOMAXPROCS=2.',
                           'The configured option test, CPU test, and canonical short test use GOMAXPROCS=1.',
                           'No diagnostic replaces the original inconclusive campaign.']}
    (OUTPUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'archives_verified': len(records), 'binary_identities': len(binaries),
                      'manifest_sha256': digest((OUTPUT / 'manifest.json').read_bytes())}))


if __name__ == '__main__':
    main()
