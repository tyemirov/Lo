from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import statistics
ROOT=Path.cwd().resolve()
WORK=ROOT/'_scratch/i011-20261020/completion-20261022/http-echo-repro/canonical-short'
GO='/opt/homebrew/Cellar/go/1.27.1/libexec/bin/go'


def identity(path):
 path=Path(path);assert path.resolve().is_relative_to(ROOT)
 return {'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}


def stage(name,argv,env,timeout):
 result=subprocess.run([str(x) for x in argv],cwd=ROOT,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout)
 for stream in ['stdout','stderr']:(WORK/(name+'.'+stream)).write_bytes(getattr(result,stream))
 (WORK/(name+'.json')).write_text(json.dumps({'command':[str(x) for x in argv],'status':result.returncode,'stdout':identity(WORK/(name+'.stdout')),'stderr':identity(WORK/(name+'.stderr'))},indent=2)+'\n')
 return result


if (WORK/'build.json').exists():raise ValueError('no replacement/retry')
env=dict(os.environ,CI='1',PYTHONDONTWRITEBYTECODE='1')
r=stage('build',[GO,'build','-trimpath','-o',WORK/'runner',WORK/'main.go'],dict(env,GOOS='linux',GOARCH='arm64',GOARM64='v8.0',CGO_ENABLED='0'),600)
if r.returncode:raise SystemExit(r.returncode)
(WORK/'working').mkdir()
config={'samples':10,'warmup':3,'compiler':'/compiler/bin/lo','output':'/result/performance.json','execution':[],'process':[],'http':[{'name':'echo','source':'/input/echo.lo','expected':'fixed varied payload 123','source_sha256':identity(WORK/'echo.lo')['sha256'],'reference':'','native':'','allocation':'','artifact':'/work/repro/program','work':'/work/repro'}],'build':[]}
(WORK/'config.json').write_text(json.dumps(config,indent=2)+'\n')
manifest={'files':[{'source':str(WORK/'runner'),'path':'/input/runner'},{'source':str(WORK/'echo.lo'),'path':'/input/echo.lo'},{'source':str(WORK/'config.json'),'path':'/input/config.json'},{'source':str(WORK/'working'),'path':'/work/repro'}],'cases':[{'id':'canonical-echo-short-cpu','argv':['/input/runner','--config','/input/config.json'],'cwd':'/work/repro','environment':{},'stdin':'','timeout_seconds':240,'outputs':['/result/performance.json']}]}
(WORK/'batch.json').write_text(json.dumps(manifest,indent=2)+'\n')
(WORK/'artifacts.json').write_text(json.dumps({'runner':identity(WORK/'runner'),'source':identity(WORK/'main.go'),'canonical':identity(ROOT/'tools/loqualification/performance-runner/main.go'),'config':identity(WORK/'config.json')},indent=2)+'\n')
r=stage('guest',[sys.executable,'-B',ROOT/'tools/loqualification/batch.py','--preparation',ROOT/'_scratch/native-runtime','--package',ROOT/'bin/distributions-i011-storage-20261023/lo-linux-arm64-software','--manifest',WORK/'batch.json','--work',WORK/'guest','--accelerator','hvf'],env,300)
report=json.loads((WORK/'guest/report.json').read_text());case=report['cases'][0]
sys.path.insert(0,str(ROOT/'tools/loqualification'));import batch
actual=batch.receive(ROOT/report['export'],(case['id'],),(1,))[0]
assert actual.status==case['status'] and actual.elapsed_ns==case['elapsed_ns']
assert actual.stdout==(WORK/'guest/0.stdout').read_bytes() and actual.stderr==(WORK/'guest/0.stderr').read_bytes()
assert len(actual.files)==1 and actual.files[0]==(WORK/'guest/0.file0').read_bytes()
value=json.loads(actual.files[0]);(WORK/'result.json').write_text(json.dumps({'guest_status':actual.status,'outer_status':r.returncode,'raw_report':identity(WORK/'guest/report.json'),'result':value},indent=2)+'\n')
print(json.dumps({'status':actual.status,'report_keys':list(value)}))
if actual.status!=0:raise SystemExit('canonical diagnostic failed; raw preserved, no retry')
http=value['http'];assert len(http)==1
row=http[0];assert row['name']=='echo' and len(row['samples'])==10 and row['requests_per_sample']==200 and row['both_servers_alive']
cpu=row['server_lifetime_cpu'];assert set(cpu)=={'native','interpreter'}
pairs=[(pair['native']['elapsed_ns']-pair['interpreter']['elapsed_ns'])/200 for pair in row['samples']]
summary={'state':'complete_canonical_short_cpu_diagnostic','canonical_timing_loop_unchanged':True,'requests_per_backend_including_warmup':2600,'server_lifetime_cpu':cpu,'native_minus_go_total_cpu_ns':cpu['native']['total_cpu_ns']-cpu['interpreter']['total_cpu_ns'],'measured_native_minus_go_ns_per_request':pairs,'median_measured_native_minus_go_ns_per_request':statistics.median(pairs),'result':identity(WORK/'result.json'),'limits':['Whole processCPU includes startup,warmups,idle,shutdown; not exactrequestCPU.','Canonicalloop has backgroundrequestcontext and3warm10measuredpairs unchanged.','This diagnostic is not qualification and changes no product source.']}
(WORK/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
