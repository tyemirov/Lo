i011-http-echo-repro-canonical-short: | tool-state
	CI=1 PYTHONDONTWRITEBYTECODE=1 python3 -B _scratch/i011-20261020/completion-20261022/http-echo-repro/canonical-short/run.py </dev/null
