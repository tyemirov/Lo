from pathlib import Path
import hashlib
import json
import statistics
import sys
ROOT=Path.cwd().resolve()
WORK=ROOT/'_scratch/i011-20261020/completion-20261022/http-echo-repro/canonical-short'
sys.path.insert(0,str(ROOT/'tools/loqualification'))
import batch


def identity(path):
 path=Path(path);assert path.resolve().is_relative_to(ROOT)
 return {'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}


assert not (WORK/'result.json').exists()
report=json.loads((WORK/'guest/report.json').read_text());case=report['cases'][0]
actual=batch.receive(ROOT/report['export'],(case['id'],),(1,))[0]
assert actual.status==case['status']==0 and actual.elapsed_ns==case['elapsed_ns']
assert actual.stdout==(WORK/'guest/0.stdout').read_bytes() and actual.stderr==(WORK/'guest/0.stderr').read_bytes()
assert len(actual.outputs)==1 and actual.outputs[0]==(WORK/'guest/0.file0').read_bytes()
value=json.loads(actual.outputs[0]);(WORK/'result.json').write_text(json.dumps({'guest_status':actual.status,'raw_report':identity(WORK/'guest/report.json'),'result':value},indent=2)+'\n')
assert value['measurement_complete'] and value['samples']==10 and value['warmup']==3
assert len(value['http'])==1
row=value['http'][0];assert row['name']=='echo' and len(row['samples'])==10 and row['requests_per_sample']==200 and row['both_servers_alive']
cpu=row['server_lifetime_cpu'];assert set(cpu)=={'native','interpreter'}
for pair in row['samples']:
 assert len(pair['native']['samples_ns'])==len(pair['interpreter']['samples_ns'])==200
pairs=[(pair['native']['elapsed_ns']-pair['interpreter']['elapsed_ns'])/200 for pair in row['samples']]
summary={'state':'complete_canonical_short_cpu_diagnostic','canonical_timing_loop_unchanged':True,'requests_per_backend_including_warmup':2600,'server_lifetime_cpu':cpu,'native_minus_go_total_cpu_ns':cpu['native']['total_cpu_ns']-cpu['interpreter']['total_cpu_ns'],'measured_native_minus_go_ns_per_request':pairs,'median_measured_native_minus_go_ns_per_request':statistics.median(pairs),'result':identity(WORK/'result.json'),'configuration':'Canonical main retains BOTH runtime.GOMAXPROCS(1) and os.Setenv GOMAXPROCS1; runner and Go child use1.','postprocess_correction':'Original run.py used nonexistent batch.Result.files; actual schema is outputs. Measurement and all original files unchanged; this parser consumes the same raw export.','limits':['Whole server lifetime CPU includes startup,2600requests,warmups,idle,shutdown; not exactrequestCPU.','Exact canonical HTTPclient loop uses backgroundcontext and3warm10measuredpairs unchanged.','No packet/socket/compiler/runtime settings changed. No production or qualification edits.']}
(WORK/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
