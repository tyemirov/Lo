from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess
import sys
ROOT=Path.cwd().resolve()
WORK=ROOT/'_scratch/i011-20261020/completion-20261022/http-echo-repro/configured'


def identity(path):
 path=Path(path);assert path.resolve().is_relative_to(ROOT)
 return {'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}


if (WORK/'guest-run').exists():raise ValueError('no replacement/retry')
original=json.loads((WORK/'batch.json').read_text())
assert original['cases'][0]['environment']=={'GOMAXPROCS':'1'}
original['cases'][0]['environment']={}
(WORK/'batch-admitted.json').write_text(json.dumps(original,indent=2)+'\n')
correction={'cause':'Maintained batch owns GOMAXPROCS=2 and rejects case overrides. The compiled diagnostic explicitly sets runtime.GOMAXPROCS(1) and os.Setenv GOMAXPROCS1 before setup; Go child inherits1.','rejected_manifest':identity(WORK/'batch.json'),'rejected_admission':identity(WORK/'guest.json'),'admitted_manifest':identity(WORK/'batch-admitted.json'),'unchanged_diagnostic':identity(WORK/'repro'),'unchanged_source':identity(WORK/'repro.go'),'same_native':identity(WORK.parent/'native'),'no_prior_corrected_guest_measurement':True}
(WORK/'admission-correction.json').write_text(json.dumps(correction,indent=2)+'\n')
command=[sys.executable,'-B',str(ROOT/'tools/loqualification/batch.py'),'--preparation',str(ROOT/'_scratch/native-runtime'),'--package',str(ROOT/'bin/distributions-i011-storage-20261023/lo-linux-arm64-software'),'--manifest',str(WORK/'batch-admitted.json'),'--work',str(WORK/'guest-run'),'--accelerator','hvf']
r=subprocess.run(command,cwd=ROOT,env=dict(os.environ,CI='1',PYTHONDONTWRITEBYTECODE='1'),stdin=subprocess.DEVNULL,capture_output=True,timeout=240)
(WORK/'admitted-guest.stdout').write_bytes(r.stdout);(WORK/'admitted-guest.stderr').write_bytes(r.stderr)
(WORK/'admitted-guest.json').write_text(json.dumps({'command':command,'status':r.returncode,'stdout':identity(WORK/'admitted-guest.stdout'),'stderr':identity(WORK/'admitted-guest.stderr')},indent=2)+'\n')
report=json.loads((WORK/'guest-run/report.json').read_text());case=report['cases'][0]
sys.path.insert(0,str(ROOT/'tools/loqualification'));import batch
actual=batch.receive(ROOT/report['export'],(case['id'],),(0,))[0]
assert actual.status==case['status'] and actual.elapsed_ns==case['elapsed_ns']
assert actual.stdout==(WORK/'guest-run/0.stdout').read_bytes() and actual.stderr==(WORK/'guest-run/0.stderr').read_bytes()
value=json.loads(actual.stdout)
assert value['gomaxprocs']==1 and value['gomaxprocs_environment']=='1'
(WORK/'result.json').write_text(json.dumps({'guest_status':actual.status,'outer_status':r.returncode,'raw_report':identity(WORK/'guest-run/report.json'),'result':value},indent=2)+'\n')
print(json.dumps({'guest_status':actual.status,'state':value['state'],'error':value.get('error')}))
if value['state']=='complete':
 rows=value['observations'];savings=[];controls=[]
 for pair in range(10):
  chosen=[row for row in rows if not row['warmup'] and row['pair']==pair]
  assert len(chosen)==4 and all(len(row['samples_ns'])==200 and not row.get('error') for row in chosen)
  native={row['native_nodelay']:row for row in chosen if row['backend']=='native'}
  go={row['native_nodelay']:row for row in chosen if row['backend']=='interpreter'}
  savings.append((native[0]['elapsed_ns']-native[1]['elapsed_ns'])/200)
  controls.append((go[0]['elapsed_ns']-go[1]['elapsed_ns'])/200)
 summary={'state':'complete_configured_diagnostic_not_qualification','paired_native_saved_ns_per_request':savings,'median_native_saved_ns_per_request':statistics.median(savings),'paired_go_control_difference_ns_per_request':controls,'median_go_control_difference_ns_per_request':statistics.median(controls),'original_native_options':value['native_original_options'],'original_go_options':value['go_original_options'],'restored_native_options':value['restored_native_options'],'socket_identity':value['socket_identity'],'gomaxprocs':value['gomaxprocs'],'gomaxprocs_environment':value['gomaxprocs_environment'],'cleanup':value['cleanup'],'raw':identity(WORK/'result.json'),'limits':['Exact bodybytes/status everyrequest; no packettrace or fullheaderbyte claim.','Observed socketoption intervention only; no runtime/server/client code changes.','Initial default2vCPU run retained independently; rejected batchenvironment setup retained before this sole corrected guest run.']}
 (WORK/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
