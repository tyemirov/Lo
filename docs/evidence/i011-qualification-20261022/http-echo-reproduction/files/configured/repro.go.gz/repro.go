package main

import (
 "bufio"
 "bytes"
 "context"
 "encoding/json"
 "fmt"
 "io"
 "net"
 "net/http"
 "os"
 "os/exec"
 "strconv"
 "sort"
 "runtime"
 "strings"
 "sync"
 "syscall"
 "time"
 "golang.org/x/sys/unix"
)

type capture struct { sync.Mutex; data []byte; overflow bool }
func (c *capture) Write(p []byte)(int,error){c.Lock();defer c.Unlock();n:=len(p);if n>65536-len(c.data){n=65536-len(c.data);c.overflow=true};c.data=append(c.data,p[:n]...);return len(p),nil}
func (c *capture) text()string{c.Lock();defer c.Unlock();return string(c.data)}
type server struct { cmd *exec.Cmd; reader *bufio.Reader; stderr *capture; address string; client *http.Client; local string; dials int; transport *http.Transport; inode string; targetFDs []int; confirmedLocal string; confirmedPeer string }
type options struct { NoDelay int `json:"nodelay"`; Nonblocking bool `json:"nonblocking"`; ReadTimeoutUS int64 `json:"read_timeout_us"`; WriteTimeoutUS int64 `json:"write_timeout_us"` }
type observation struct { Backend string `json:"backend"`; Option int `json:"native_nodelay"`; Warmup bool `json:"warmup"`; Pair int `json:"pair"`; Samples []int64 `json:"samples_ns"`; Elapsed int64 `json:"elapsed_ns"`; Error string `json:"error,omitempty"` }
func start(ctx context.Context,argv []string)(*server,error){
 c:=exec.Command(argv[0],argv[1:]...);c.Stdin=nil;c.SysProcAttr=&syscall.SysProcAttr{Setpgid:true};errlog:=&capture{};c.Stderr=errlog;out,e:=c.StdoutPipe();if e!=nil{return nil,e};if e=c.Start();e!=nil{return nil,e}
 s:=&server{cmd:c,reader:bufio.NewReader(out),stderr:errlog};line:=make(chan []byte,1);go func(){v,_:=s.reader.ReadBytes('\n');line<-v}()
 select{case raw:=<-line:var v struct{Status string;Servers []struct{Address string}};if e=json.Unmarshal(raw,&v);e!=nil||v.Status!="ready"||len(v.Servers)!=1{_ = s.close();return nil,fmt.Errorf("readiness %q: %v",raw,e)};s.address=v.Servers[0].Address
 case <-time.After(10*time.Second):_ = s.close();return nil,fmt.Errorf("readiness deadline")}
 s.transport=&http.Transport{Proxy:nil,MaxIdleConnsPerHost:1,ForceAttemptHTTP2:false,DialContext:func(ctx context.Context,network,address string)(net.Conn,error){var d net.Dialer;conn,e:=d.DialContext(ctx,network,address);if e==nil{s.local=conn.LocalAddr().String();s.dials++};return conn,e}}
 s.client=&http.Client{Transport:s.transport,Timeout:5*time.Second};return s,nil
}
func(s *server)close()error{if s.transport!=nil{s.transport.CloseIdleConnections()};if s.cmd==nil||s.cmd.Process==nil{return nil};_ = s.cmd.Process.Signal(syscall.SIGTERM);done:=make(chan error,1);go func(){done<-s.cmd.Wait()}();var e error;select{case e=<-done:case<-time.After(10*time.Second):_ = syscall.Kill(-s.cmd.Process.Pid,syscall.SIGKILL);e=<-done;return fmt.Errorf("shutdown deadline: %v",e)};if e!=nil||s.stderr.text()!=""||s.stderr.overflow{return fmt.Errorf("shutdown %v stderr=%q",e,s.stderr.text())};return nil}
func(s *server)request(ctx context.Context)error{request,e:=http.NewRequestWithContext(ctx,"POST","http://"+s.address+"/benchmark",strings.NewReader("fixed varied payload 123"));if e!=nil{return e};request.Header.Set("Content-Type","application/octet-stream");response,e:=s.client.Do(request);if e!=nil{return e};body,e:=io.ReadAll(io.LimitReader(response.Body,1025));closeError:=response.Body.Close();if e!=nil||closeError!=nil||response.StatusCode!=200||!bytes.Equal(body,[]byte("fixed varied payload 123")){return fmt.Errorf("response status=%d body=%q read=%v close=%v",response.StatusCode,body,e,closeError)};if s.dials!=1{return fmt.Errorf("persistent connection changed: %d",s.dials)};return nil}
func endpoint(address string)(string,error){h,p,e:=net.SplitHostPort(address);if e!=nil{return "",e};ip:=net.ParseIP(h).To4();if ip==nil{return "",fmt.Errorf("IPv4 endpoint required: %s",address)};port,e:=strconv.Atoi(p);return fmt.Sprintf("%02X%02X%02X%02X:%04X",ip[3],ip[2],ip[1],ip[0],port),e}
func duplicate(s *server)(fd,pidfd int,e error){
 local,e:=endpoint(s.address);if e!=nil{return -1,-1,e};remote,e:=endpoint(s.local);if e!=nil{return -1,-1,e};raw,e:=os.ReadFile("/proc/net/tcp");if e!=nil{return -1,-1,e};inode:="";for _,line:=range strings.Split(string(raw),"\n"){f:=strings.Fields(line);if len(f)>9&&f[1]==local&&f[2]==remote&&f[3]=="01"{if inode!=""{return -1,-1,fmt.Errorf("duplicate endpoint match")};inode=f[9]}};if inode==""{return -1,-1,fmt.Errorf("established endpoint match missing %s/%s",local,remote)}
 entries,e:=os.ReadDir(fmt.Sprintf("/proc/%d/fd",s.cmd.Process.Pid));if e!=nil{return -1,-1,e};targets:=[]int{};for _,entry:=range entries{link,e:=os.Readlink(fmt.Sprintf("/proc/%d/fd/%s",s.cmd.Process.Pid,entry.Name()));if e==nil&&link=="socket:["+inode+"]"{n,_:=strconv.Atoi(entry.Name());targets=append(targets,n)}};if len(targets)==0{return -1,-1,fmt.Errorf("accepted FD not found")};sort.Ints(targets);target:=targets[0];s.inode=inode;s.targetFDs=targets;pidfd,e=unix.PidfdOpen(s.cmd.Process.Pid,0);if e!=nil{return -1,-1,fmt.Errorf("pidfd_open: %w",e)};fd,e=unix.PidfdGetfd(pidfd,target,0);if e!=nil{unix.Close(pidfd);return -1,-1,fmt.Errorf("pidfd_getfd: %w",e)}
 own,e:=unix.Getsockname(fd);if e!=nil{unix.Close(fd);unix.Close(pidfd);return -1,-1,e};peer,e:=unix.Getpeername(fd);if e!=nil{unix.Close(fd);unix.Close(pidfd);return -1,-1,e}
 ownText,e:=socketAddress(own);if e!=nil{unix.Close(fd);unix.Close(pidfd);return -1,-1,e};peerText,e:=socketAddress(peer);if e!=nil{unix.Close(fd);unix.Close(pidfd);return -1,-1,e}
 if ownText!=s.address||peerText!=s.local{unix.Close(fd);unix.Close(pidfd);return -1,-1,fmt.Errorf("duplicated socket endpoints differ: %s/%s expected %s/%s",ownText,peerText,s.address,s.local)}
 s.confirmedLocal=ownText;s.confirmedPeer=peerText;return fd,pidfd,nil
}
func socketAddress(address unix.Sockaddr)(string,error){v,ok:=address.(*unix.SockaddrInet4);if !ok{return "",fmt.Errorf("duplicated socket is not IPv4")};return net.JoinHostPort(net.IP(v.Addr[:]).String(),strconv.Itoa(v.Port)),nil}
func snapshot(fd int)(options,error){v,e:=unix.GetsockoptInt(fd,unix.IPPROTO_TCP,unix.TCP_NODELAY);if e!=nil{return options{},e};flags,e:=unix.FcntlInt(uintptr(fd),unix.F_GETFL,0);if e!=nil{return options{},e};r,e:=unix.GetsockoptTimeval(fd,unix.SOL_SOCKET,unix.SO_RCVTIMEO);if e!=nil{return options{},e};w,e:=unix.GetsockoptTimeval(fd,unix.SOL_SOCKET,unix.SO_SNDTIMEO);if e!=nil{return options{},e};return options{v,flags&unix.O_NONBLOCK!=0,r.Sec*1000000+r.Usec,w.Sec*1000000+w.Usec},nil}
func run()(result map[string]any,returned error){
 result=map[string]any{"diagnostic_only":true,"state":"setup","gomaxprocs":runtime.GOMAXPROCS(0),"gomaxprocs_environment":os.Getenv("GOMAXPROCS"),"warmup_pairs":3,"measured_pairs":10,"requests_per_batch":200,"request_body":"fixed varied payload 123","raw_response_rule":"status200/exact24Bbody","option_changes":"Only native accepted TCP_NODELAY; timeouts/nonblocking/client/Go unchanged"}
 ctx,cancel:=context.WithTimeout(context.Background(),165*time.Second);defer cancel();servers:=map[string]*server{};fds:=map[string]int{};pids:=map[string]int{};original:=options{};originalKnown:=false
 defer func(){if fd,ok:=fds["native"];ok&&originalKnown{e:=unix.SetsockoptInt(fd,unix.IPPROTO_TCP,unix.TCP_NODELAY,original.NoDelay);state,se:=snapshot(fd);result["restored_native_options"]=state;if e!=nil||se!=nil||state!=original{restoreError:=fmt.Errorf("restore option failed: %v %v",e,se);result["restore_error"]=restoreError.Error();if returned==nil{returned=restoreError}else{result["primary_error"]=returned.Error()}}};for _,name:=range []string{"native","interpreter"}{if fd,ok:=fds[name];ok{unix.Close(fd)};if fd,ok:=pids[name];ok{unix.Close(fd)}};cleanup:=map[string]string{};for _,name:=range []string{"native","interpreter"}{if s:=servers[name];s!=nil{if e:=s.close();e!=nil{cleanup[name]=e.Error();if returned==nil{returned=e}}else{cleanup[name]="exit0_empty_stderr"}}};result["cleanup"]=cleanup;if returned!=nil{result["error"]=returned.Error()}}()
 for _,name:=range []string{"native","interpreter"}{argv:=[]string{os.Args[1],"serve","--listen","0","--format","json"};if name=="interpreter"{argv=[]string{os.Args[2],"serve",os.Args[3],"--listen","0","--format","json"}};s,e:=start(ctx,argv);if e!=nil{return result,e};servers[name]=s;if e=s.request(ctx);e!=nil{return result,e};fd,pid,e:=duplicate(s);if e!=nil{result["state"]="socket_duplication_unavailable";return result,e};fds[name]=fd;pids[name]=pid}
 native,e:=snapshot(fds["native"]);if e!=nil{return result,e};reference,e:=snapshot(fds["interpreter"]);if e!=nil{return result,e};original=native;originalKnown=true;result["socket_identity"]=map[string]any{"native_inode":servers["native"].inode,"native_matching_fds":servers["native"].targetFDs,"go_inode":servers["interpreter"].inode,"go_matching_fds":servers["interpreter"].targetFDs,"native_duplicate_local":servers["native"].confirmedLocal,"native_duplicate_peer":servers["native"].confirmedPeer,"go_duplicate_local":servers["interpreter"].confirmedLocal,"go_duplicate_peer":servers["interpreter"].confirmedPeer};result["native_original_options"]=native;result["go_original_options"]=reference;result["endpoints"]=map[string]any{"native_server":servers["native"].address,"native_client":servers["native"].local,"go_server":servers["interpreter"].address,"go_client":servers["interpreter"].local}
 if native.NoDelay==1{result["state"]="missing_nodelay_hypothesis_falsified_already_enabled";return result,nil};if native.NoDelay!=0{return result,fmt.Errorf("unexpected native NODELAY %d",native.NoDelay)}
 observations:=make([]observation,0,52);transitions:=[]options{}
 for pair:=0;pair<13;pair++{order:=[]int{0,1};if pair%2==1{order=[]int{1,0}};for _,option:=range order{if e=unix.SetsockoptInt(fds["native"],unix.IPPROTO_TCP,unix.TCP_NODELAY,option);e!=nil{return result,e};observed,e:=snapshot(fds["native"]);if e!=nil{return result,e};expected:=original;expected.NoDelay=option;if observed!=expected{return result,fmt.Errorf("unexpected native option transition %+v",observed)};observedGo,e:=snapshot(fds["interpreter"]);if e!=nil||observedGo!=reference{return result,fmt.Errorf("Go option changed %+v %v",observedGo,e)};transitions=append(transitions,observed);result["transitions"]=transitions
 for _,name:=range []string{"native","interpreter"}{o:=observation{Backend:name,Option:option,Warmup:pair<3,Pair:pair-3,Samples:make([]int64,0,200)};started:=time.Now();for request:=0;request<200;request++{before:=time.Now();e=servers[name].request(ctx);elapsed:=time.Since(before).Nanoseconds();o.Samples=append(o.Samples,elapsed);if e!=nil{o.Error=e.Error();break}};o.Elapsed=time.Since(started).Nanoseconds();observations=append(observations,o);result["observations"]=observations;if e!=nil{return result,e}}
 }}
 result["state"]="complete";return result,nil
}
func main(){runtime.GOMAXPROCS(1);if e:=os.Setenv("GOMAXPROCS","1");e!=nil{panic(e)};if len(os.Args)!=4{fmt.Fprintln(os.Stderr,"usage: repro NATIVE GO_COMPILER SOURCE");os.Exit(2)};result,e:=run();status:=0;if e!=nil{status=2;result["error"]=e.Error()};result["status"]=status;encoded,err:=json.Marshal(result);if err!=nil{fmt.Fprintln(os.Stderr,err);os.Exit(3)};fmt.Println(string(encoded));os.Exit(status)}
