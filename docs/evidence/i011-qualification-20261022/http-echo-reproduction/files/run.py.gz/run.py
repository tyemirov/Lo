from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
ROOT=Path.cwd().resolve()
WORK=ROOT/'_scratch/i011-20261020/completion-20261022/http-echo-repro'
PACKAGE=ROOT/'bin/distributions-i011-storage-20261023/lo-linux-arm64-software'
HOST=ROOT/'bin/distributions-i011-storage-20261023/lo-darwin-arm64-software'
GO='/opt/homebrew/Cellar/go/1.27.1/libexec/bin/go'


def identity(path):
 path=Path(path);assert path.resolve().is_relative_to(ROOT)
 return {'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}


def stage(name,argv,env,timeout):
 result=subprocess.run([str(x) for x in argv],cwd=ROOT,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout)
 for stream in ['stdout','stderr']:(WORK/(name+'.'+stream)).write_bytes(getattr(result,stream))
 record={'command':[str(x) for x in argv],'status':result.returncode,'timeout_seconds':timeout,'stdout':identity(WORK/(name+'.stdout')),'stderr':identity(WORK/(name+'.stderr'))}
 (WORK/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 return result


if (WORK/'native-build.json').exists():raise ValueError('no replacement/retry')
env=dict(os.environ,CI='1',PYTHONDONTWRITEBYTECODE='1')
plan={'diagnostic_only':True,'hypothesis':'Native accepted TCP_NODELAY may differ from Go and affect Linuxecho; optionA/B on exactactualsocket only.','sequence':'Observednative0 vs1 only; no manufactured0 ifalready1. 3warm+10measuredpairs,200requests eachnativeoption, unchangedGo control aftereachnativebatch, alternatingoptionorder.','identity_mechanism':'Both establishedIPv4endpoints -> inode -> matchingserverFDs -> lowestalias -> pidfd_getfd. MultipleRustclonedFDaliases share the same socket.','terminal_setup':'Unsupported/denied pidfd stops without privilege/kernel changes or fallback.','source':identity(WORK/'echo.lo'),'server_sources':[identity(ROOT/p) for p in ['runtime/native/src/http/server.rs','internal/adapter/server.go']],'packages':[identity(p/name) for p in [HOST,PACKAGE] for name in ['toolchain.json','provenance.json','inventory.json']],'diagnostic_source':identity(WORK/'repro.go'),'maintained_sources_unchanged':True}
(WORK/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
r=stage('native-build',[HOST/'bin/lo','build',WORK/'echo.lo','--target','linux/arm64','--output',WORK/'native','--format','json'],env,600)
if r.returncode:raise SystemExit(r.returncode)
goenv=dict(env,GOOS='linux',GOARCH='arm64',GOARM64='v8.0',CGO_ENABLED='0')
r=stage('diagnostic-build',[GO,'build','-trimpath','-o',WORK/'repro',WORK/'repro.go'],goenv,600)
if r.returncode:raise SystemExit(r.returncode)
(WORK/'working').mkdir()
manifest={'files':[{'source':str(WORK/'native'),'path':'/input/native'},{'source':str(WORK/'repro'),'path':'/input/repro'},{'source':str(WORK/'echo.lo'),'path':'/input/echo.lo'},{'source':str(WORK/'working'),'path':'/work/repro'}],'cases':[{'id':'echo-nodelay','argv':['/input/repro','/input/native','/compiler/bin/lo','/input/echo.lo'],'cwd':'/work/repro','environment':{},'stdin':'','timeout_seconds':180,'outputs':[]}]}
(WORK/'batch.json').write_text(json.dumps(manifest,indent=2)+'\n')
(WORK/'artifacts.json').write_text(json.dumps({'native':identity(WORK/'native'),'diagnostic':identity(WORK/'repro'),'source':identity(WORK/'echo.lo')},indent=2)+'\n')
r=stage('guest',[sys.executable,'-B',ROOT/'tools/loqualification/batch.py','--preparation',ROOT/'_scratch/native-runtime','--package',PACKAGE,'--manifest',WORK/'batch.json','--work',WORK/'guest','--accelerator','hvf'],env,240)
report=json.loads((WORK/'guest/report.json').read_text());case=report['cases'][0]
sys.path.insert(0,str(ROOT/'tools/loqualification'));import batch
actual=batch.receive(ROOT/report['export'],(case['id'],),(0,))[0]
assert actual.status==case['status'] and actual.elapsed_ns==case['elapsed_ns']
assert actual.stdout==(WORK/'guest/0.stdout').read_bytes() and actual.stderr==(WORK/'guest/0.stderr').read_bytes()
value=json.loads(actual.stdout)
(WORK/'result.json').write_text(json.dumps({'guest_status':actual.status,'outer_status':r.returncode,'raw_report':identity(WORK/'guest/report.json'),'result':value},indent=2)+'\n')
print(json.dumps({'guest_status':actual.status,'state':value['state'],'error':value.get('error'),'result':str((WORK/'result.json').relative_to(ROOT))}))
if value['state']=='complete':
 import statistics
 rows=value['observations'];savings=[];controls=[]
 for pair in range(10):
  chosen=[row for row in rows if not row['warmup'] and row['pair']==pair]
  assert len(chosen)==4 and all(len(row['samples_ns'])==200 and not row.get('error') for row in chosen)
  native={row['native_nodelay']:row for row in chosen if row['backend']=='native'}
  go={row['native_nodelay']:row for row in chosen if row['backend']=='interpreter'}
  savings.append((native[0]['elapsed_ns']-native[1]['elapsed_ns'])/200)
  controls.append((go[0]['elapsed_ns']-go[1]['elapsed_ns'])/200)
 summary={'state':'complete_diagnostic_not_qualification','paired_native_saved_ns_per_request':savings,'median_native_saved_ns_per_request':statistics.median(savings),'paired_go_control_difference_ns_per_request':controls,'median_go_control_difference_ns_per_request':statistics.median(controls),'original_native_options':value['native_original_options'],'original_go_options':value['go_original_options'],'restored_native_options':value['restored_native_options'],'raw':identity(WORK/'result.json'),'limits':['Bodybytes/status verified everyrequest; no packettrace or fullHTTPheaderbyte equivalence claim.','Option is causal intervention; smallpaired diagnostic does not replace qualification.']}
 (WORK/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
else:
 print('Terminal setup/hypothesis result retained; no retry or fallback.')
