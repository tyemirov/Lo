from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess
import sys
ROOT=Path.cwd().resolve()
WORK=ROOT/'_scratch/i011-20261020/completion-20261022/http-echo-repro/cpu'
NATIVE=WORK.parent/'native'
GO='/opt/homebrew/Cellar/go/1.27.1/libexec/bin/go'


def identity(path):
 path=Path(path);assert path.resolve().is_relative_to(ROOT)
 return {'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}


def stage(name,argv,env,timeout):
 r=subprocess.run([str(x) for x in argv],cwd=ROOT,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout)
 for stream in ['stdout','stderr']:(WORK/(name+'.'+stream)).write_bytes(getattr(r,stream))
 (WORK/(name+'.json')).write_text(json.dumps({'command':[str(x) for x in argv],'status':r.returncode,'stdout':identity(WORK/(name+'.stdout')),'stderr':identity(WORK/(name+'.stderr'))},indent=2)+'\n')
 return r


if (WORK/'diagnostic-build.json').exists():raise ValueError('no replacement/retry')
expected=json.loads((WORK.parent/'artifacts.json').read_text())['native'];assert identity(NATIVE)==expected
plan={'diagnostic_only':True,'requests_per_backend':10000,'warmup_batches':3,'measured_batches':47,'requests_per_batch':200,'backend_order':'native/Go evenbatch,Go/native oddbatch','setup_requests':0,'gomaxprocs':1,'cpu_measure':'ProcessState.UserTime/SystemTime afterverifiedcleanexit; wholelifetime includesstartup/traffic/idle/shutdown. No subtraction.','no_socket_changes':True,'no_schedstat':True,'native':identity(NATIVE),'echo':identity(WORK/'echo.lo'),'diagnostic_source':identity(WORK/'repro.go'),'baseline_option_diagnostic':identity(WORK.parent/'configured/result.json')}
(WORK/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
env=dict(os.environ,CI='1',GOMAXPROCS='1',PYTHONDONTWRITEBYTECODE='1')
r=stage('diagnostic-build',[GO,'build','-trimpath','-o',WORK/'repro',WORK/'repro.go'],dict(env,GOOS='linux',GOARCH='arm64',GOARM64='v8.0',CGO_ENABLED='0'),600)
if r.returncode:raise SystemExit(r.returncode)
(WORK/'working').mkdir()
manifest={'files':[{'source':str(NATIVE),'path':'/input/native'},{'source':str(WORK/'repro'),'path':'/input/repro'},{'source':str(WORK/'echo.lo'),'path':'/input/echo.lo'},{'source':str(WORK/'working'),'path':'/work/repro'}],'cases':[{'id':'echo-lifetime-cpu','argv':['/input/repro','/input/native','/compiler/bin/lo','/input/echo.lo'],'cwd':'/work/repro','environment':{},'stdin':'','timeout_seconds':180,'outputs':[]}]}
(WORK/'batch.json').write_text(json.dumps(manifest,indent=2)+'\n')
(WORK/'artifacts.json').write_text(json.dumps({'native':identity(NATIVE),'diagnostic':identity(WORK/'repro'),'source':identity(WORK/'repro.go')},indent=2)+'\n')
r=stage('guest',[sys.executable,'-B',ROOT/'tools/loqualification/batch.py','--preparation',ROOT/'_scratch/native-runtime','--package',ROOT/'bin/distributions-i011-storage-20261023/lo-linux-arm64-software','--manifest',WORK/'batch.json','--work',WORK/'guest','--accelerator','hvf'],env,240)
assert identity(NATIVE)==expected
report=json.loads((WORK/'guest/report.json').read_text());case=report['cases'][0]
sys.path.insert(0,str(ROOT/'tools/loqualification'));import batch
actual=batch.receive(ROOT/report['export'],(case['id'],),(0,))[0]
assert actual.status==case['status'] and actual.elapsed_ns==case['elapsed_ns']
assert actual.stdout==(WORK/'guest/0.stdout').read_bytes() and actual.stderr==(WORK/'guest/0.stderr').read_bytes()
value=json.loads(actual.stdout)
assert value['gomaxprocs']==1 and value['gomaxprocs_environment']=='1'
(WORK/'result.json').write_text(json.dumps({'guest_status':actual.status,'outer_status':r.returncode,'raw_report':identity(WORK/'guest/report.json'),'result':value},indent=2)+'\n')
print(json.dumps({'state':value['state'],'status':actual.status,'error':value.get('error')}))
if value['state']=='complete':
 assert len(value['observations'])==100
 for backend in ['native','interpreter']:
  rows=[row for row in value['observations'] if row['backend']==backend]
  assert len(rows)==50 and sum(len(row['samples_ns']) for row in rows)==10000
  assert sum(row['warmup'] for row in rows)==3 and all(len(row['samples_ns'])==200 and not row.get('error') for row in rows)
  assert value['lifetime_cpu'][backend]['requests']==10000 and value['cleanup'][backend]=='exit0_empty_stderr'
 paired=[]
 for index in range(3,50):
  rows={row['backend']:row for row in value['observations'] if row['batch']==index}
  paired.append((rows['native']['elapsed_ns']-rows['interpreter']['elapsed_ns'])/200)
 totals=value['lifetime_cpu']
 summary={'state':'complete_directional_lifetime_cpu_not_qualification','lifetime_cpu':totals,'native_minus_go_total_cpu_ns':totals['native']['total_cpu_ns']-totals['interpreter']['total_cpu_ns'],'measured_batch_native_minus_go_ns_per_request':paired,'median_measured_batch_native_minus_go_ns_per_request':statistics.median(paired),'raw':identity(WORK/'result.json'),'limits':['Lifetime CPU includes startup,all10000requests,idleintervals,shutdown; not exact requestCPU.','ProcessState is OS-reported CPU accounting, not nanosecond precision claim.','Elapsed-minus-CPU cannot identify blocked vs runnable wait or establish scheduling causality.']}
 (WORK/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
