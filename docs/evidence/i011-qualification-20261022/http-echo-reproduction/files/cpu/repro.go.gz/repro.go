package main

import (
 "bufio"
 "bytes"
 "context"
 "encoding/json"
 "fmt"
 "io"
 "net"
 "net/http"
 "os"
 "os/exec"
 "runtime"
 "strings"
 "sync"
 "syscall"
 "time"
)

type capture struct { sync.Mutex; data []byte; overflow bool }
func (c *capture) Write(p []byte)(int,error){c.Lock();defer c.Unlock();n:=len(p);if n>65536-len(c.data){n=65536-len(c.data);c.overflow=true};c.data=append(c.data,p[:n]...);return len(p),nil}
func (c *capture) text()string{c.Lock();defer c.Unlock();return string(c.data)}
type server struct { cmd *exec.Cmd; reader *bufio.Reader; stderr *capture; address string; client *http.Client; local string; dials int; transport *http.Transport; started time.Time; setupNS int64; shutdownNS int64; lifetimeNS int64; userNS int64; systemNS int64; requests int }
type observation struct { Backend string `json:"backend"`; Warmup bool `json:"warmup"`; Batch int `json:"batch"`; Sample int `json:"sample"`; Samples []int64 `json:"samples_ns"`; Elapsed int64 `json:"elapsed_ns"`; Error string `json:"error,omitempty"` }
func start(ctx context.Context,argv []string)(*server,error){
 c:=exec.Command(argv[0],argv[1:]...);c.Stdin=nil;c.SysProcAttr=&syscall.SysProcAttr{Setpgid:true};errlog:=&capture{};c.Stderr=errlog;out,e:=c.StdoutPipe();if e!=nil{return nil,e};started:=time.Now();if e=c.Start();e!=nil{return nil,e}
 s:=&server{cmd:c,reader:bufio.NewReader(out),stderr:errlog,started:started};line:=make(chan []byte,1);go func(){v,_:=s.reader.ReadBytes('\n');line<-v}()
 select{case raw:=<-line:var v struct{Status string;Servers []struct{Address string}};if e=json.Unmarshal(raw,&v);e!=nil||v.Status!="ready"||len(v.Servers)!=1{_ = s.close();return nil,fmt.Errorf("readiness %q: %v",raw,e)};s.address=v.Servers[0].Address
 case <-time.After(10*time.Second):_ = s.close();return nil,fmt.Errorf("readiness deadline")}
 s.setupNS=time.Since(started).Nanoseconds()
 s.transport=&http.Transport{Proxy:nil,MaxIdleConnsPerHost:1,ForceAttemptHTTP2:false,DialContext:func(ctx context.Context,network,address string)(net.Conn,error){var d net.Dialer;conn,e:=d.DialContext(ctx,network,address);if e==nil{s.local=conn.LocalAddr().String();s.dials++};return conn,e}}
 s.client=&http.Client{Transport:s.transport,Timeout:5*time.Second};return s,nil
}
func(s *server)close()error{shutdown:=time.Now();if s.transport!=nil{s.transport.CloseIdleConnections()};if s.cmd==nil||s.cmd.Process==nil{return nil};_ = s.cmd.Process.Signal(syscall.SIGTERM);done:=make(chan error,1);go func(){done<-s.cmd.Wait()}();var e error;timedOut:=false;select{case e=<-done:case<-time.After(10*time.Second):timedOut=true;_ = syscall.Kill(-s.cmd.Process.Pid,syscall.SIGKILL);e=<-done};s.shutdownNS=time.Since(shutdown).Nanoseconds();s.lifetimeNS=time.Since(s.started).Nanoseconds();if s.cmd.ProcessState!=nil{s.userNS=s.cmd.ProcessState.UserTime().Nanoseconds();s.systemNS=s.cmd.ProcessState.SystemTime().Nanoseconds()};if timedOut||e!=nil||s.stderr.text()!=""||s.stderr.overflow{return fmt.Errorf("shutdown timeout=%v %v stderr=%q",timedOut,e,s.stderr.text())};return nil}

func(s *server)request(ctx context.Context)error{request,e:=http.NewRequestWithContext(ctx,"POST","http://"+s.address+"/benchmark",strings.NewReader("fixed varied payload 123"));if e!=nil{return e};request.Header.Set("Content-Type","application/octet-stream");response,e:=s.client.Do(request);if e!=nil{return e};body,e:=io.ReadAll(io.LimitReader(response.Body,1025));closeError:=response.Body.Close();if e!=nil||closeError!=nil||response.StatusCode!=200||!bytes.Equal(body,[]byte("fixed varied payload 123")){return fmt.Errorf("response status=%d body=%q read=%v close=%v",response.StatusCode,body,e,closeError)};if s.dials!=1{return fmt.Errorf("persistent connection changed: %d",s.dials)};s.requests++;return nil}
func run()(result map[string]any,returned error){
 result=map[string]any{"diagnostic_only":true,"state":"setup","gomaxprocs":runtime.GOMAXPROCS(0),"gomaxprocs_environment":os.Getenv("GOMAXPROCS"),"warmup_batches":3,"measured_batches":47,"requests_per_batch":200,"setup_requests":0,"expected_requests_per_backend":10000,"request_body":"fixed varied payload 123","socket_options":"Original unchanged; no pidfd/socketoption/schedstat operations","cpu_interpretation":"Whole server lifetime user/system CPU includes startup, all10000requests, idle intervals and shutdown; never subtract startup or label exact request CPU."}
 ctx,cancel:=context.WithTimeout(context.Background(),165*time.Second);defer cancel();servers:=map[string]*server{}
 defer func(){cleanup:=map[string]string{};totals:=map[string]any{};for _,name:=range []string{"native","interpreter"}{if s:=servers[name];s!=nil{if e:=s.close();e!=nil{cleanup[name]=e.Error();if returned==nil{returned=e}}else{cleanup[name]="exit0_empty_stderr"};totals[name]=map[string]any{"requests":s.requests,"connections":s.dials,"user_ns":s.userNS,"system_ns":s.systemNS,"total_cpu_ns":s.userNS+s.systemNS,"setup_wall_ns":s.setupNS,"shutdown_wall_ns":s.shutdownNS,"server_lifetime_wall_ns":s.lifetimeNS}}};result["cleanup"]=cleanup;result["lifetime_cpu"]=totals;if returned!=nil{result["error"]=returned.Error()}}()
 for _,name:=range []string{"native","interpreter"}{argv:=[]string{os.Args[1],"serve","--listen","0","--format","json"};if name=="interpreter"{argv=[]string{os.Args[2],"serve",os.Args[3],"--listen","0","--format","json"}};s,e:=start(ctx,argv);if e!=nil{return result,e};servers[name]=s}
 observations:=make([]observation,0,100)
 for batch:=0;batch<50;batch++{order:=[]string{"native","interpreter"};if batch%2==1{order=[]string{"interpreter","native"}};for _,name:=range order{o:=observation{Backend:name,Warmup:batch<3,Batch:batch,Sample:batch-3,Samples:make([]int64,0,200)};started:=time.Now();var e error;for request:=0;request<200;request++{before:=time.Now();e=servers[name].request(ctx);elapsed:=time.Since(before).Nanoseconds();o.Samples=append(o.Samples,elapsed);if e!=nil{o.Error=e.Error();break}};o.Elapsed=time.Since(started).Nanoseconds();observations=append(observations,o);result["observations"]=observations;if e!=nil{return result,e}}}
 for _,name:=range []string{"native","interpreter"}{if servers[name].requests!=10000{return result,fmt.Errorf("request count differs %s %d",name,servers[name].requests)}}
 result["state"]="complete";return result,nil
}
func main(){runtime.GOMAXPROCS(1);if e:=os.Setenv("GOMAXPROCS","1");e!=nil{panic(e)};if len(os.Args)!=4{fmt.Fprintln(os.Stderr,"usage: repro NATIVE GO_COMPILER SOURCE");os.Exit(2)};result,e:=run();status:=0;if e!=nil{status=2;result["error"]=e.Error()};result["status"]=status;encoded,err:=json.Marshal(result);if err!=nil{fmt.Fprintln(os.Stderr,err);os.Exit(3)};fmt.Println(string(encoded));os.Exit(status)}
