
/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/http-precision-100/darwin/http_echo:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000a48f8 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19>:
1000a48f8: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1000a48fc: a90167fa    	stp	x26, x25, [sp, #0x10]
1000a4900: a9025ff8    	stp	x24, x23, [sp, #0x20]
1000a4904: a90357f6    	stp	x22, x21, [sp, #0x30]
1000a4908: a9044ff4    	stp	x20, x19, [sp, #0x40]
1000a490c: a9057bfd    	stp	x29, x30, [sp, #0x50]
1000a4910: 910143fd    	add	x29, sp, #0x50
1000a4914: d14007ff    	sub	sp, sp, #0x1, lsl #12   ; =0x1000
1000a4918: f90003ff    	str	xzr, [sp]
1000a491c: d14007ff    	sub	sp, sp, #0x1, lsl #12   ; =0x1000
1000a4920: f90003ff    	str	xzr, [sp]
1000a4924: aa0103f4    	mov	x20, x1
1000a4928: aa0003f3    	mov	x19, x0
1000a492c: d28000d7    	mov	x23, #0x6               ; =6
1000a4930: f2f00017    	movk	x23, #0x8000, lsl #48
1000a4934: f9401c21    	ldr	x1, [x1, #0x38]
1000a4938: f9400e96    	ldr	x22, [x20, #0x18]
1000a493c: b9402295    	ldr	w21, [x20, #0x20]
1000a4940: 910003e0    	mov	x0, sp
1000a4944: 97ff7038    	bl	0x100080a24 <lo_runtime::context::Context::check_cancel::h888c0225e536f0b1>
1000a4948: f94003e8    	ldr	x8, [sp]
1000a494c: eb17011f    	cmp	x8, x23
1000a4950: 54000c61    	b.ne	0x1000a4adc <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x1e4>
1000a4954: 52800038    	mov	w24, #0x1               ; =1
1000a4958: d2840019    	mov	x25, #0x2000            ; =8192
1000a495c: f2a00819    	movk	x25, #0x40, lsl #16
1000a4960: f2c00119    	movk	x25, #0x8, lsl #32
1000a4964: 1400000d    	b	0x1000a4998 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0xa0>
1000a4968: aa1503e0    	mov	x0, x21
1000a496c: 52800301    	mov	w1, #0x18               ; =24
1000a4970: 52800102    	mov	w2, #0x8                ; =8
1000a4974: 94012ed7    	bl	0x1000f04d0 <___rust_dealloc>
1000a4978: f9401e81    	ldr	x1, [x20, #0x38]
1000a497c: f9400e96    	ldr	x22, [x20, #0x18]
1000a4980: b9402295    	ldr	w21, [x20, #0x20]
1000a4984: 910003e0    	mov	x0, sp
1000a4988: 97ff7027    	bl	0x100080a24 <lo_runtime::context::Context::check_cancel::h888c0225e536f0b1>
1000a498c: f94003e8    	ldr	x8, [sp]
1000a4990: eb17011f    	cmp	x8, x23
1000a4994: 54000a41    	b.ne	0x1000a4adc <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x1e4>
1000a4998: 940412d0    	bl	0x1001a94d8 <std::time::Instant::now::h3a6e0f9b70ba1ebe>
1000a499c: eb16001f    	cmp	x0, x22
1000a49a0: 1a9f07e8    	cset	w8, ne
1000a49a4: 5a9fa108    	csinv	w8, w8, wzr, ge
1000a49a8: 6b15003f    	cmp	w1, w21
1000a49ac: 5a9f23e9    	csetm	w9, lo
1000a49b0: 7100011f    	cmp	w8, #0x0
1000a49b4: 1a880128    	csel	w8, w9, w8, eq
1000a49b8: 7100091f    	cmp	w8, #0x2
1000a49bc: 54000ac3    	b.lo	0x1000a4b14 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x21c>
1000a49c0: f9402288    	ldr	x8, [x20, #0x40]
1000a49c4: f9400a89    	ldr	x9, [x20, #0x10]
1000a49c8: eb09011f    	cmp	x8, x9
1000a49cc: 54000cc3    	b.lo	0x1000a4b64 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x26c>
1000a49d0: 910003e0    	mov	x0, sp
1000a49d4: 52840001    	mov	w1, #0x2000             ; =8192
1000a49d8: 9404bc1e    	bl	0x1001d3a50 <_writev+0x1001d3a50>
1000a49dc: a942a280    	ldp	x0, x8, [x20, #0x28]
1000a49e0: f9400d08    	ldr	x8, [x8, #0x18]
1000a49e4: 910003e1    	mov	x1, sp
1000a49e8: 52840002    	mov	w2, #0x2000             ; =8192
1000a49ec: d63f0100    	blr	x8
1000a49f0: aa0103f5    	mov	x21, x1
1000a49f4: b4000300    	cbz	x0, 0x1000a4a54 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x15c>
1000a49f8: aa1503e0    	mov	x0, x21
1000a49fc: 97fda598    	bl	0x10000e05c <std::io::error::Error::kind::h60b884103ba922e6>
1000a4a00: 12001c08    	and	w8, w0, #0xff
1000a4a04: 71008d1f    	cmp	w8, #0x23
1000a4a08: 9ac82308    	lsl	x8, x24, x8
1000a4a0c: 8a190108    	and	x8, x8, x25
1000a4a10: fa409904    	ccmp	x8, #0x0, #0x4, ls
1000a4a14: 54000be0    	b.eq	0x1000a4b90 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x298>
1000a4a18: 924006a8    	and	x8, x21, #0x3
1000a4a1c: f100051f    	cmp	x8, #0x1
1000a4a20: 54fffac1    	b.ne	0x1000a4978 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x80>
1000a4a24: f85ffeb6    	ldr	x22, [x21, #-0x1]!
1000a4a28: f94006ba    	ldr	x26, [x21, #0x8]
1000a4a2c: f9400348    	ldr	x8, [x26]
1000a4a30: b4000068    	cbz	x8, 0x1000a4a3c <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x144>
1000a4a34: aa1603e0    	mov	x0, x22
1000a4a38: d63f0100    	blr	x8
1000a4a3c: f9400741    	ldr	x1, [x26, #0x8]
1000a4a40: b4fff941    	cbz	x1, 0x1000a4968 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x70>
1000a4a44: f9400b42    	ldr	x2, [x26, #0x10]
1000a4a48: aa1603e0    	mov	x0, x22
1000a4a4c: 94012ea1    	bl	0x1000f04d0 <___rust_dealloc>
1000a4a50: 17ffffc6    	b	0x1000a4968 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x70>
1000a4a54: b4000995    	cbz	x21, 0x1000a4b84 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x28c>
1000a4a58: 39412288    	ldrb	w8, [x20, #0x48]
1000a4a5c: 36000108    	tbz	w8, #0x0, 0x1000a4a7c <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x184>
1000a4a60: 9404129e    	bl	0x1001a94d8 <std::time::Instant::now::h3a6e0f9b70ba1ebe>
1000a4a64: 528000a2    	mov	w2, #0x5                ; =5
1000a4a68: 52800003    	mov	w3, #0x0                ; =0
1000a4a6c: 940412ce    	bl	0x1001a95a4 <_$LT$std..time..Instant$u20$as$u20$core..ops..arith..Add$LT$core..time..Duration$GT$$GT$::add::h8811036c841c9976>
1000a4a70: f9000e80    	str	x0, [x20, #0x18]
1000a4a74: b9002281    	str	w1, [x20, #0x20]
1000a4a78: 3901229f    	strb	wzr, [x20, #0x48]
1000a4a7c: f9000a9f    	str	xzr, [x20, #0x10]
1000a4a80: f1400abf    	cmp	x21, #0x2, lsl #12      ; =0x2000
1000a4a84: 540008e8    	b.hi	0x1000a4ba0 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x2a8>
1000a4a88: f9400288    	ldr	x8, [x20]
1000a4a8c: eb15011f    	cmp	x8, x21
1000a4a90: 54000163    	b.lo	0x1000a4abc <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x1c4>
1000a4a94: d2800016    	mov	x22, #0x0               ; =0
1000a4a98: f9400688    	ldr	x8, [x20, #0x8]
1000a4a9c: 8b160100    	add	x0, x8, x22
1000a4aa0: 910003e1    	mov	x1, sp
1000a4aa4: aa1503e2    	mov	x2, x21
1000a4aa8: 9404bbe4    	bl	0x1001d3a38 <_writev+0x1001d3a38>
1000a4aac: 8b1502c8    	add	x8, x22, x21
1000a4ab0: f9000a88    	str	x8, [x20, #0x10]
1000a4ab4: f900229f    	str	xzr, [x20, #0x40]
1000a4ab8: 17ffffb0    	b	0x1000a4978 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x80>
1000a4abc: aa1403e0    	mov	x0, x20
1000a4ac0: d2800001    	mov	x1, #0x0                ; =0
1000a4ac4: aa1503e2    	mov	x2, x21
1000a4ac8: 52800023    	mov	w3, #0x1                ; =1
1000a4acc: 52800024    	mov	w4, #0x1                ; =1
1000a4ad0: 97fec567    	bl	0x10005606c <alloc::raw_vec::RawVecInner$LT$A$GT$::reserve::do_reserve_and_handle::h6f745ea5938f0537>
1000a4ad4: f9400a96    	ldr	x22, [x20, #0x10]
1000a4ad8: 17fffff0    	b	0x1000a4a98 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x1a0>
1000a4adc: a94083ec    	ldp	x12, x0, [sp, #0x8]
1000a4ae0: a941a7ea    	ldp	x10, x9, [sp, #0x18]
1000a4ae4: f94017eb    	ldr	x11, [sp, #0x28]
1000a4ae8: a9003268    	stp	x8, x12, [x19]
1000a4aec: a9012a60    	stp	x0, x10, [x19, #0x10]
1000a4af0: a9022e69    	stp	x9, x11, [x19, #0x20]
1000a4af4: 91400bff    	add	sp, sp, #0x2, lsl #12   ; =0x2000
1000a4af8: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1000a4afc: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1000a4b00: a94357f6    	ldp	x22, x21, [sp, #0x30]
1000a4b04: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1000a4b08: a94167fa    	ldp	x26, x25, [sp, #0x10]
1000a4b0c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1000a4b10: d65f03c0    	ret
1000a4b14: 90000da8    	adrp	x8, 0x100258000 <lo_runtime::files::SESSION::h1f5d01f3e3bd8ce5>
1000a4b18: 910ee508    	add	x8, x8, #0x3b9
1000a4b1c: 3940011f    	ldrb	wzr, [x8]
1000a4b20: 52800320    	mov	w0, #0x19               ; =25
1000a4b24: 52800021    	mov	w1, #0x1                ; =1
1000a4b28: 94012e69    	bl	0x1000f04cc <___rust_alloc>
1000a4b2c: b4000440    	cbz	x0, 0x1000a4bb4 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x2bc>
1000a4b30: d00009e8    	adrp	x8, 0x1001e2000 <_$LT$lo_runtime..metadata..Coordinate$u20$as$u20$lo_runtime..metadata..Fields$GT$::field::NULL::h5cfea434f04d736f+0x40c0>
1000a4b34: 91287108    	add	x8, x8, #0xa1c
1000a4b38: 3dc00100    	ldr	q0, [x8]
1000a4b3c: 3d800000    	str	q0, [x0]
1000a4b40: 3cc09100    	ldur	q0, [x8, #0x9]
1000a4b44: 3c809000    	stur	q0, [x0, #0x9]
1000a4b48: d10006e8    	sub	x8, x23, #0x1
1000a4b4c: f00009c9    	adrp	x9, 0x1001df000 <_$LT$lo_runtime..metadata..Coordinate$u20$as$u20$lo_runtime..metadata..Fields$GT$::field::NULL::h5cfea434f04d736f+0x10c0>
1000a4b50: 91001929    	add	x9, x9, #0x6
1000a4b54: 5280032a    	mov	w10, #0x19              ; =25
1000a4b58: 5280022b    	mov	w11, #0x11              ; =17
1000a4b5c: 5280032c    	mov	w12, #0x19              ; =25
1000a4b60: 17ffffe2    	b	0x1000a4ae8 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x1f0>
1000a4b64: f9400689    	ldr	x9, [x20, #0x8]
1000a4b68: 38686929    	ldrb	w9, [x9, x8]
1000a4b6c: 91000508    	add	x8, x8, #0x1
1000a4b70: f9002288    	str	x8, [x20, #0x40]
1000a4b74: 52800028    	mov	w8, #0x1                ; =1
1000a4b78: 39002268    	strb	w8, [x19, #0x8]
1000a4b7c: 39002669    	strb	w9, [x19, #0x9]
1000a4b80: 14000002    	b	0x1000a4b88 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x290>
1000a4b84: 3900227f    	strb	wzr, [x19, #0x8]
1000a4b88: f9000277    	str	x23, [x19]
1000a4b8c: 17ffffda    	b	0x1000a4af4 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x1fc>
1000a4b90: aa1303e0    	mov	x0, x19
1000a4b94: aa1503e1    	mov	x1, x21
1000a4b98: 97fff4cc    	bl	0x1000a1ec8 <lo_runtime::http::client::io_fault::h6106b2997f7b8200>
1000a4b9c: 17ffffd6    	b	0x1000a4af4 <lo_runtime::http::client::Reader::byte::h85c9186ba19e3f19+0x1fc>
1000a4ba0: 90000d22    	adrp	x2, 0x100248000 <_lo_program_flows+0x3a60>
1000a4ba4: 912e0042    	add	x2, x2, #0xb80
1000a4ba8: aa1503e0    	mov	x0, x21
1000a4bac: 52840001    	mov	w1, #0x2000             ; =8192
1000a4bb0: 94049d52    	bl	0x1001cc0f8 <core::slice::index::slice_end_index_len_fail::h0189a5e61950f867>
1000a4bb4: b0000d02    	adrp	x2, 0x100245000 <_lo_program_flows+0xa60>
1000a4bb8: 910d4042    	add	x2, x2, #0x350
1000a4bbc: 52800020    	mov	w0, #0x1                ; =1
1000a4bc0: 52800321    	mov	w1, #0x19               ; =25
1000a4bc4: 94046e14    	bl	0x1001c0414 <alloc::raw_vec::handle_error::h3a2b2a11ce049f14>
