
/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/http-reader-candidate-100/darwin/http_echo:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000a4988 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887>:
1000a4988: d10243ff    	sub	sp, sp, #0x90
1000a498c: a9036ffc    	stp	x28, x27, [sp, #0x30]
1000a4990: a90467fa    	stp	x26, x25, [sp, #0x40]
1000a4994: a9055ff8    	stp	x24, x23, [sp, #0x50]
1000a4998: a90657f6    	stp	x22, x21, [sp, #0x60]
1000a499c: a9074ff4    	stp	x20, x19, [sp, #0x70]
1000a49a0: a9087bfd    	stp	x29, x30, [sp, #0x80]
1000a49a4: 910203fd    	add	x29, sp, #0x80
1000a49a8: aa0103f4    	mov	x20, x1
1000a49ac: aa0003f3    	mov	x19, x0
1000a49b0: d28000d7    	mov	x23, #0x6               ; =6
1000a49b4: f2f00017    	movk	x23, #0x8000, lsl #48
1000a49b8: f9401c21    	ldr	x1, [x1, #0x38]
1000a49bc: f9400e96    	ldr	x22, [x20, #0x18]
1000a49c0: b9402295    	ldr	w21, [x20, #0x20]
1000a49c4: 910003e0    	mov	x0, sp
1000a49c8: 97ff7017    	bl	0x100080a24 <lo_runtime::context::Context::check_cancel::h888c0225e536f0b1>
1000a49cc: f94003e8    	ldr	x8, [sp]
1000a49d0: eb17011f    	cmp	x8, x23
1000a49d4: 54000c21    	b.ne	0x1000a4b58 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x1d0>
1000a49d8: 52840918    	mov	w24, #0x2048            ; =8264
1000a49dc: 52800039    	mov	w25, #0x1               ; =1
1000a49e0: d284001a    	mov	x26, #0x2000            ; =8192
1000a49e4: f2a0081a    	movk	x26, #0x40, lsl #16
1000a49e8: f2c0011a    	movk	x26, #0x8, lsl #32
1000a49ec: 1400000d    	b	0x1000a4a20 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x98>
1000a49f0: aa1503e0    	mov	x0, x21
1000a49f4: 52800301    	mov	w1, #0x18               ; =24
1000a49f8: 52800102    	mov	w2, #0x8                ; =8
1000a49fc: 94012f56    	bl	0x1000f0754 <___rust_dealloc>
1000a4a00: f9401e81    	ldr	x1, [x20, #0x38]
1000a4a04: f9400e96    	ldr	x22, [x20, #0x18]
1000a4a08: b9402295    	ldr	w21, [x20, #0x20]
1000a4a0c: 910003e0    	mov	x0, sp
1000a4a10: 97ff7005    	bl	0x100080a24 <lo_runtime::context::Context::check_cancel::h888c0225e536f0b1>
1000a4a14: f94003e8    	ldr	x8, [sp]
1000a4a18: eb17011f    	cmp	x8, x23
1000a4a1c: 540009e1    	b.ne	0x1000a4b58 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x1d0>
1000a4a20: 9404134e    	bl	0x1001a9758 <std::time::Instant::now::h3a6e0f9b70ba1ebe>
1000a4a24: eb16001f    	cmp	x0, x22
1000a4a28: 1a9f07e8    	cset	w8, ne
1000a4a2c: 5a9fa108    	csinv	w8, w8, wzr, ge
1000a4a30: 6b15003f    	cmp	w1, w21
1000a4a34: 5a9f23e9    	csetm	w9, lo
1000a4a38: 7100011f    	cmp	w8, #0x0
1000a4a3c: 1a880128    	csel	w8, w9, w8, eq
1000a4a40: 7100091f    	cmp	w8, #0x2
1000a4a44: 54000a63    	b.lo	0x1000a4b90 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x208>
1000a4a48: f9502288    	ldr	x8, [x20, #0x2040]
1000a4a4c: f9400a89    	ldr	x9, [x20, #0x10]
1000a4a50: eb09011f    	cmp	x8, x9
1000a4a54: 54000c63    	b.lo	0x1000a4be0 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x258>
1000a4a58: a942a280    	ldp	x0, x8, [x20, #0x28]
1000a4a5c: f9400d08    	ldr	x8, [x8, #0x18]
1000a4a60: 91010281    	add	x1, x20, #0x40
1000a4a64: 52840002    	mov	w2, #0x2000             ; =8192
1000a4a68: d63f0100    	blr	x8
1000a4a6c: aa0103f5    	mov	x21, x1
1000a4a70: b4000300    	cbz	x0, 0x1000a4ad0 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x148>
1000a4a74: aa1503e0    	mov	x0, x21
1000a4a78: 97fda579    	bl	0x10000e05c <std::io::error::Error::kind::h60b884103ba922e6>
1000a4a7c: 12001c08    	and	w8, w0, #0xff
1000a4a80: 71008d1f    	cmp	w8, #0x23
1000a4a84: 9ac82328    	lsl	x8, x25, x8
1000a4a88: 8a1a0108    	and	x8, x8, x26
1000a4a8c: fa409904    	ccmp	x8, #0x0, #0x4, ls
1000a4a90: 54000be0    	b.eq	0x1000a4c0c <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x284>
1000a4a94: 924006a8    	and	x8, x21, #0x3
1000a4a98: f100051f    	cmp	x8, #0x1
1000a4a9c: 54fffb21    	b.ne	0x1000a4a00 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x78>
1000a4aa0: f85ffeb6    	ldr	x22, [x21, #-0x1]!
1000a4aa4: f94006bb    	ldr	x27, [x21, #0x8]
1000a4aa8: f9400368    	ldr	x8, [x27]
1000a4aac: b4000068    	cbz	x8, 0x1000a4ab8 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x130>
1000a4ab0: aa1603e0    	mov	x0, x22
1000a4ab4: d63f0100    	blr	x8
1000a4ab8: f9400761    	ldr	x1, [x27, #0x8]
1000a4abc: b4fff9a1    	cbz	x1, 0x1000a49f0 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x68>
1000a4ac0: f9400b62    	ldr	x2, [x27, #0x10]
1000a4ac4: aa1603e0    	mov	x0, x22
1000a4ac8: 94012f23    	bl	0x1000f0754 <___rust_dealloc>
1000a4acc: 17ffffc9    	b	0x1000a49f0 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x68>
1000a4ad0: b4000995    	cbz	x21, 0x1000a4c00 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x278>
1000a4ad4: 38786a88    	ldrb	w8, [x20, x24]
1000a4ad8: 36000108    	tbz	w8, #0x0, 0x1000a4af8 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x170>
1000a4adc: 9404131f    	bl	0x1001a9758 <std::time::Instant::now::h3a6e0f9b70ba1ebe>
1000a4ae0: 528000a2    	mov	w2, #0x5                ; =5
1000a4ae4: 52800003    	mov	w3, #0x0                ; =0
1000a4ae8: 9404134f    	bl	0x1001a9824 <_$LT$std..time..Instant$u20$as$u20$core..ops..arith..Add$LT$core..time..Duration$GT$$GT$::add::h8811036c841c9976>
1000a4aec: f9000e80    	str	x0, [x20, #0x18]
1000a4af0: b9002281    	str	w1, [x20, #0x20]
1000a4af4: 38386a9f    	strb	wzr, [x20, x24]
1000a4af8: f9000a9f    	str	xzr, [x20, #0x10]
1000a4afc: f1400abf    	cmp	x21, #0x2, lsl #12      ; =0x2000
1000a4b00: 540009a8    	b.hi	0x1000a4c34 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x2ac>
1000a4b04: f9400288    	ldr	x8, [x20]
1000a4b08: eb15011f    	cmp	x8, x21
1000a4b0c: 54000163    	b.lo	0x1000a4b38 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x1b0>
1000a4b10: d2800016    	mov	x22, #0x0               ; =0
1000a4b14: f9400688    	ldr	x8, [x20, #0x8]
1000a4b18: 8b160100    	add	x0, x8, x22
1000a4b1c: 91010281    	add	x1, x20, #0x40
1000a4b20: aa1503e2    	mov	x2, x21
1000a4b24: 9404bc65    	bl	0x1001d3cb8 <_writev+0x1001d3cb8>
1000a4b28: 8b1502c8    	add	x8, x22, x21
1000a4b2c: f9000a88    	str	x8, [x20, #0x10]
1000a4b30: f910229f    	str	xzr, [x20, #0x2040]
1000a4b34: 17ffffb3    	b	0x1000a4a00 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x78>
1000a4b38: aa1403e0    	mov	x0, x20
1000a4b3c: d2800001    	mov	x1, #0x0                ; =0
1000a4b40: aa1503e2    	mov	x2, x21
1000a4b44: 52800023    	mov	w3, #0x1                ; =1
1000a4b48: 52800024    	mov	w4, #0x1                ; =1
1000a4b4c: 97fec548    	bl	0x10005606c <alloc::raw_vec::RawVecInner$LT$A$GT$::reserve::do_reserve_and_handle::h6f745ea5938f0537>
1000a4b50: f9400a96    	ldr	x22, [x20, #0x10]
1000a4b54: 17fffff0    	b	0x1000a4b14 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x18c>
1000a4b58: a94083ec    	ldp	x12, x0, [sp, #0x8]
1000a4b5c: a941a7ea    	ldp	x10, x9, [sp, #0x18]
1000a4b60: f94017eb    	ldr	x11, [sp, #0x28]
1000a4b64: a9003268    	stp	x8, x12, [x19]
1000a4b68: a9012a60    	stp	x0, x10, [x19, #0x10]
1000a4b6c: a9022e69    	stp	x9, x11, [x19, #0x20]
1000a4b70: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1000a4b74: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1000a4b78: a94657f6    	ldp	x22, x21, [sp, #0x60]
1000a4b7c: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1000a4b80: a94467fa    	ldp	x26, x25, [sp, #0x40]
1000a4b84: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1000a4b88: 910243ff    	add	sp, sp, #0x90
1000a4b8c: d65f03c0    	ret
1000a4b90: 90000da8    	adrp	x8, 0x100258000 <lo_runtime::files::SESSION::h1f5d01f3e3bd8ce5>
1000a4b94: 910ee508    	add	x8, x8, #0x3b9
1000a4b98: 3940011f    	ldrb	wzr, [x8]
1000a4b9c: 52800320    	mov	w0, #0x19               ; =25
1000a4ba0: 52800021    	mov	w1, #0x1                ; =1
1000a4ba4: 94012eeb    	bl	0x1000f0750 <___rust_alloc>
1000a4ba8: b4000500    	cbz	x0, 0x1000a4c48 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x2c0>
1000a4bac: d00009e8    	adrp	x8, 0x1001e2000 <_$LT$lo_runtime..metadata..Coordinate$u20$as$u20$lo_runtime..metadata..Fields$GT$::field::NULL::h5cfea434f04d736f+0x3f30>
1000a4bb0: 912eb108    	add	x8, x8, #0xbac
1000a4bb4: 3dc00100    	ldr	q0, [x8]
1000a4bb8: 3d800000    	str	q0, [x0]
1000a4bbc: 3cc09100    	ldur	q0, [x8, #0x9]
1000a4bc0: 3c809000    	stur	q0, [x0, #0x9]
1000a4bc4: d10006e8    	sub	x8, x23, #0x1
1000a4bc8: f00009c9    	adrp	x9, 0x1001df000 <_$LT$lo_runtime..metadata..Coordinate$u20$as$u20$lo_runtime..metadata..Fields$GT$::field::NULL::h5cfea434f04d736f+0xf30>
1000a4bcc: 91065929    	add	x9, x9, #0x196
1000a4bd0: 5280032a    	mov	w10, #0x19              ; =25
1000a4bd4: 5280022b    	mov	w11, #0x11              ; =17
1000a4bd8: 5280032c    	mov	w12, #0x19              ; =25
1000a4bdc: 17ffffe2    	b	0x1000a4b64 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x1dc>
1000a4be0: f9400689    	ldr	x9, [x20, #0x8]
1000a4be4: 38686929    	ldrb	w9, [x9, x8]
1000a4be8: 91000508    	add	x8, x8, #0x1
1000a4bec: f9102288    	str	x8, [x20, #0x2040]
1000a4bf0: 52800028    	mov	w8, #0x1                ; =1
1000a4bf4: 39002268    	strb	w8, [x19, #0x8]
1000a4bf8: 39002669    	strb	w9, [x19, #0x9]
1000a4bfc: 14000002    	b	0x1000a4c04 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x27c>
1000a4c00: 3900227f    	strb	wzr, [x19, #0x8]
1000a4c04: f9000277    	str	x23, [x19]
1000a4c08: 17ffffda    	b	0x1000a4b70 <lo_runtime::http::client::Reader::byte::h4dd48b7ad43ea887+0x1e8>
1000a4c0c: aa1303e0    	mov	x0, x19
1000a4c10: aa1503e1    	mov	x1, x21
1000a4c14: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1000a4c18: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1000a4c1c: a94657f6    	ldp	x22, x21, [sp, #0x60]
1000a4c20: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1000a4c24: a94467fa    	ldp	x26, x25, [sp, #0x40]
1000a4c28: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1000a4c2c: 910243ff    	add	sp, sp, #0x90
1000a4c30: 17fff4a6    	b	0x1000a1ec8 <lo_runtime::http::client::io_fault::h6106b2997f7b8200>
1000a4c34: 90000d22    	adrp	x2, 0x100248000 <_lo_program_flows+0x3a60>
1000a4c38: 912e0042    	add	x2, x2, #0xb80
1000a4c3c: aa1503e0    	mov	x0, x21
1000a4c40: 52840001    	mov	w1, #0x2000             ; =8192
1000a4c44: 94049dcd    	bl	0x1001cc378 <core::slice::index::slice_end_index_len_fail::h0189a5e61950f867>
1000a4c48: b0000d02    	adrp	x2, 0x100245000 <_lo_program_flows+0xa60>
1000a4c4c: 910d4042    	add	x2, x2, #0x350
1000a4c50: 52800020    	mov	w0, #0x1                ; =1
1000a4c54: 52800321    	mov	w1, #0x19               ; =25
1000a4c58: 94046e8f    	bl	0x1001c0694 <alloc::raw_vec::handle_error::h3a2b2a11ce049f14>
