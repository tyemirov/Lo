"""Verify the frozen ten-path evidence inventory, then remove only those paths."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
from datetime import datetime, timezone

ROOT = Path.cwd().resolve()
BASE = ROOT / '_scratch/i011-20261020/completion-20261022'
WORK = BASE / 'old-guest-source-cleanup'
DURABLE = ROOT / 'docs/evidence/i011-qualification-20261022/old-guest-source-cleanup'
EXPECTED = {
    *(f'metadata-v2-characterization/{name}/guest/root' for name in ('linux', 'linux-controls', 'linux-green', 'linux-red')),
    *(f'literal-characterization/{name}/guest/root' for name in ('linux', 'linux-final', 'linux-grouped', 'linux-grouped-prefix')),
    *(f'literal-characterization/{name}/guest/root.cpio.gz' for name in ('linux-grouped', 'linux-grouped-prefix')),
}

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def path(value: str) -> Path:
    result = ROOT / value
    if not result.resolve().is_relative_to(ROOT):
        raise ValueError(f'Outside Lo: {value}')
    return result

def check_record(record: dict) -> None:
    data = path(record['path']).read_bytes()
    assert len(data) == record['bytes'], record['path']
    assert digest(data) == record['sha256'], record['path']

def check_archive(record: dict) -> None:
    packed = path(record['archive']).read_bytes()
    assert len(packed) == record['archive_bytes'], record['archive']
    assert digest(packed) == record['archive_sha256'], record['archive']
    assert packed[4:8] == bytes(4), record['archive']
    raw = gzip.decompress(packed)
    assert len(raw) == record['bytes'], record['archive']
    assert digest(raw) == record['sha256'], record['archive']

def main() -> None:
    inventory_path = WORK / 'inventory-final.json'
    raw = inventory_path.read_bytes()
    assert digest(raw) == '57cc53cb10a850b75f4108e3e09e088186ff7e43be4711b9f193cfb702fe245b'
    inventory = json.loads(raw)
    assert inventory['missing'] == []
    selected = inventory['selected']
    assert len(selected) == 10
    targets = [path(item['path']) for item in selected]
    assert {str(p.relative_to(BASE)) for p in targets} == EXPECTED
    receipt = json.loads((DURABLE / 'final-receipt.json').read_text())
    for key in ('inventory', 'inventory_archive', 'manifest', 'supplemental_manifest', 'prior_inventory_unchanged'):
        check_record(receipt[key])
    assert gzip.decompress(path(receipt['inventory_archive']['path']).read_bytes()) == raw
    archive_count = 0
    for key in ('manifest', 'supplemental_manifest'):
        manifest = json.loads(path(receipt[key]['path']).read_text())
        for record in manifest['records']:
            check_archive(record)
            archive_count += 1
    for record in inventory['prior_manifests']:
        check_record(record)
    retained = inventory['retained_canonical_bindings']
    for record in retained:
        p = path(record['path'])
        assert not any(p == t or p.is_relative_to(t) for t in targets)
        check_record(record)
    file_count = 0
    for item, target in zip(selected, targets):
        assert item['eligible'] is True
        for record in item['raw_evidence']:
            check_record(record)
            check_archive(record)
        if 'report_archive' in item:
            check_archive(item['report_archive'])
        if 'files' in item:
            actual = {str(p.relative_to(ROOT)) for p in target.rglob('*') if p.is_file()}
            expected = {f['path'] for f in item['files']}
            assert actual == expected, item['path']
            for record in item['files']:
                check_record(record)
                origin = record['retained_origin']
                if 'archive' in origin:
                    check_archive(origin)
                file_count += 1
        else:
            check_record(item)
            file_count += 1
    script = Path(__file__).read_bytes()
    packed = gzip.compress(script, mtime=0)
    script_archive = DURABLE / 'primary-cleanup.py.gz'
    assert not script_archive.exists()
    script_archive.write_bytes(packed)
    for target in targets:
        if target.is_dir():
            shutil.rmtree(target)
        else:
            target.unlink()
    assert all(not target.exists() for target in targets)
    for record in retained:
        check_record(record)
    for item in selected:
        for record in item['raw_evidence']:
            check_record(record)
    result = {
        'issue': 'I011', 'state': 'ten_derived_paths_removed_and_verified_absent',
        'time_utc': datetime.now(timezone.utc).isoformat(),
        'inventory_sha256': digest(raw), 'selected_paths': [str(t.relative_to(ROOT)) for t in targets],
        'verified_selected_files': file_count, 'verified_retained_bindings': len(retained),
        'verified_new_archive_records': archive_count,
        'logical_bytes_removed': inventory['total_logical_bytes'],
        'script_sha256': digest(script), 'script_archive_sha256': digest(packed),
        'qualification_claim': False,
    }
    (DURABLE / 'primary-cleanup.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))

if __name__ == '__main__':
    main()
