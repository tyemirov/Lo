"""Verify and remove twelve archived, reproducible task outputs."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[4]
WORK = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/i011-qualification-20261022/older-derived-cleanup'

def digest(path):
    assert path.resolve().is_relative_to(ROOT)
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load(name):
    return json.loads((WORK / name).read_text())

proposal = load('proposal.json')
assert digest(WORK / 'proposal.json') == '8498c37e750152388995c21ddb1e0fdc5d02277b3c59b8904963b0ca81bcd73b'
for row in proposal['inventory_bindings']:
    assert digest(ROOT / row['path']) == row['sha256']
inventory = load('inventory.json')
tars = load('package-tars.json')
selected = {row['path']: row for row in inventory['candidates'] if row.get('eligible')}
selected.update({row['path']: row for row in tars['candidates'] if row.get('eligible')})
assert set(selected) == {row['path'] for row in proposal['safe_paths']} and len(selected) == 12
paths = [ROOT / name for name in selected]
for path in paths:
    assert path.resolve().is_relative_to(ROOT / '_scratch/i011-20261020')
    assert not path.is_symlink() and path.exists()
retained = {}
verified_archives = set()
for row in inventory['durable_manifests']:
    assert digest(ROOT / row['path']) == row['sha256']
for name, row in selected.items():
    path = ROOT / name
    if 'sha256' in row:
        assert digest(path) == row['sha256']
    for raw in row.get('raw_evidence', []):
        packed = (ROOT / raw['archive']).read_bytes()
        assert hashlib.sha256(packed).hexdigest() == raw['archive_sha256']
        value = gzip.decompress(packed)
        assert len(value) == raw['bytes'] and hashlib.sha256(value).hexdigest() == raw['sha256']
        assert digest(ROOT / raw['source']) == raw['sha256']
        verified_archives.add(raw['archive'])
    for item in row.get('files', []):
        assert digest(ROOT / item['path']) == item['sha256']
        origin = item['retained_origin']
        if isinstance(origin, str):
            retained[origin] = item['sha256']
        elif origin['kind'] == 'same canonical bytes outside cleanup candidates':
            assert origin['sha256'] == item['sha256']
            retained[origin['path']] = item['sha256']
        else:
            assert origin['kind'] == 'reconstructible case metadata'
            assert (ROOT / origin['batch']).is_file()
    for member in row.get('members', []):
        retained[member['retained_canonical']] = member['sha256']
    if 'retained_receipt' in row:
        retained[row['retained_receipt']['path']] = row['retained_receipt']['sha256']
for name, expected in retained.items():
    assert not any((ROOT / name).is_relative_to(path) for path in paths)
    assert digest(ROOT / name) == expected
DEST.mkdir()
archives = []
for name in ['proposal.json', 'inventory.json', 'package-tars.json', 'execute.py']:
    raw = (WORK / name).read_bytes()
    packed = gzip.compress(raw, mtime=0)
    archive = name + '.gz'
    (DEST / archive).write_bytes(packed)
    assert gzip.decompress((DEST / archive).read_bytes()) == raw
    archives.append({'archive': archive, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'archive_sha256': hashlib.sha256(packed).hexdigest(), 'archive_bytes': len(packed)})
receipt = {'state': 'verified_before_cleanup', 'archives': archives, 'paths': list(selected), 'retained_files_verified': len(retained), 'raw_archives_verified': len(verified_archives), 'logical_bytes': proposal['safe_logical_bytes'], 'physical_reclaim_claim': False}
(DEST / 'primary-cleanup.json').write_text(json.dumps(receipt, indent=2) + '\n')
for path in paths:
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink()
assert all(not path.exists() for path in paths)
for name, expected in retained.items():
    assert digest(ROOT / name) == expected
receipt['state'] = 'twelve_paths_removed_and_verified_absent'
(DEST / 'primary-cleanup.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'removed': len(paths), 'retained_files_verified': len(retained), 'raw_archives_verified': len(verified_archives)}))
