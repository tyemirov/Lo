{
  "issue": "I011",
  "resumed_plan": ".mprlab/I011-PLAN.md",
  "scratch": "_scratch/i011-20261020/completion-20261022",
  "steps": [
    "preserve_invalid_campaign",
    "audit_current_inputs",
    "validate_linux_guest_initialization",
    "review_http_measurement",
    "predeclare_fixed_http_experiment",
    "complete_both_target_qualification",
    "audit_evidence",
    "independent_review",
    "close_I011_if_all_gates_pass",
    "preserve_results_and_cleanup"
  ],
  "ownership": {
    "root": [
      "campaign",
      "experiment_design",
      "evidence",
      "documentation",
      "tracker"
    ],
    "reviewer": "/root/i011_completion_review"
  },
  "delegation": {
    "role": "mpr-architect",
    "model": "gpt-6-astra",
    "effort": "high",
    "actual": "role_metadata;telemetry_unavailable",
    "external_runtime_contract": "prohibited_by_repository_boundary"
  },
  "runtime_candidate": {
    "source_files": [
      "runtime/native/src/http/client.rs",
      "runtime/native/src/http/server.rs"
    ],
    "hypothesis": "reuse_initialized_reader_scratch_to_avoid8192byte_clear_per_onebyte_server_read",
    "baseline": "installed_package_HTTP_public_contracts",
    "runtime_output": "_scratch/i011-20261020/completion-20261022/reader-runtime",
    "package_output": "bin/distributions-i011-20261022",
    "review": "/root/i011_completion_review;approved",
    "final_revalidation": [
      "full_ci",
      "Linux_native_corpus",
      "strict_semantic_report",
      "offline_all4combos_and_Metal",
      "8lane_campaign",
      "evidence_audit",
      "independent_review"
    ]
  }
}
