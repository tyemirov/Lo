package integration_test

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"testing"
)

func TestLLVMLiteralSequenceEventsAndCleanup(t *testing.T) {
	scenarios := []llvmRuntimeScenario{literalSequenceScenario([]string{"0", "1", "256"}, 0)}
	large := "1" + strings.Repeat("0", 315654)
	for index := 0; index < 3; index++ {
		items := []string{"0", "1", "256"}
		items[index] = large
		scenarios = append(scenarios, literalSequenceScenario(items, index+1))
	}
	runLLVMRuntimeTargetScenarios(t, semanticNativeTarget(), scenarios)
}

func literalSequenceScenario(items []string, number int) llvmRuntimeScenario {
	return llvmRuntimeScenario{
		name:           fmt.Sprintf("literal-prefix-%d", number),
		source:         "return List.new(\n  " + strings.Join(items, ",\n  ") + "\n)\n",
		number:         number,
		harness:        "testdata/native-qualification/literal-sequence.c",
		expectedStdout: "literal-sequence-prefixes-ok\n",
		transform: func(t *testing.T, module []byte) []byte {
			t.Helper()
			var metadata struct {
				Locations []struct {
					ID                      uint64
					Action, Text, Operation string
					Start                   struct{ Offset, Line, Column int }
				}
			}
			if err := json.Unmarshal(locationMetadataBytes(t, module), &metadata); err != nil {
				t.Fatal(err)
			}
			expected := []string{"scope_enter", "statement_step", "expression_step",
				"expression_step", "literal", "charge_value", "expression_step", "literal", "charge_value",
				"expression_step", "literal", "charge_value", "operation", "charge_value", "cause"}
			sites := []string{}
			literals := []string{}
			var body uint64
			literalIndex := 0
			literalOffset := len("return List.new(\n  ")
			for _, location := range metadata.Locations {
				if location.Action == "body" {
					body = location.ID
					continue
				}
				if len(sites) >= len(expected) || location.Action != expected[len(sites)] {
					t.Fatalf("literal sequence source action order: %+v", metadata.Locations)
				}
				if location.Action == "literal" {
					literals = append(literals, location.Text)
					if literalIndex >= len(items) || location.Text != items[literalIndex] || location.Start.Offset != literalOffset || location.Start.Line != literalIndex+2 || location.Start.Column != 3 {
						t.Fatalf("original literal runtime site lost text/order/coordinates at index%d", literalIndex)
					}
					literalOffset += len(items[literalIndex]) + len(",\n  ")
					literalIndex++
				}
				if location.Action == "operation" && location.Operation != "List.new" {
					t.Fatalf("unexpected operation: %+v", location)
				}
				sites = append(sites, fmt.Sprintf("i64 %d", location.ID))
			}
			if len(sites) != 15 || strings.Join(literals, ",") != strings.Join(items, ",") {
				t.Fatalf("literal sequence site count%d, literal count%d", len(sites), len(literals))
			}
			text := string(module)
			for _, symbol := range []string{"scope_enter", "step", "literal", "charge_value", "op_List_2Enew", "cause"} {
				wrapper := map[string]string{"scope_enter": "enter", "charge_value": "charge", "op_List_2Enew": "list"}[symbol]
				if wrapper == "" {
					wrapper = symbol
				}
				text = strings.ReplaceAll(text, "call void @lo_"+symbol+"(", "call void @lo_literal_sequence_"+wrapper+"(")
				text += "\ndeclare void @lo_literal_sequence_" + wrapper + "(ptr,ptr,i64,i64,ptr)\n"
			}
			text = strings.ReplaceAll(text, "call void @lo_scope_leave(", "call void @lo_literal_sequence_scope_leave(")
			text = strings.ReplaceAll(text, "call void @lo_value_release(", "call void @lo_literal_sequence_release(")
			text += "\ndeclare void @lo_literal_sequence_scope_leave(ptr,ptr,i64)\ndeclare void @lo_literal_sequence_release(ptr)\n"
			text += fmt.Sprintf("@lo_literal_sequence_sites = constant [15 x i64] [%s]\n@lo_literal_sequence_body_site = constant i64 %d\n", strings.Join(sites, ", "), body)
			return []byte(text)
		},
	}
}

func TestLLVMLiteralSequenceFailureLocations(t *testing.T) {
	if os.Getenv("LO_TEST_BACKEND") != "llvm" {
		t.Skip("requires the explicit LLVM runtime lane")
	}
	source := "return List.new(\n  11,\n  22,\n  33\n)\n"
	path := sourceFile(t, source)
	artifact, built := buildForTest(t, path)
	if built.status != 0 {
		t.Fatalf("build literal step boundaries: %+v", built)
	}
	for index, item := range []string{"11", "22", "33"} {
		t.Run("step-"+item, func(t *testing.T) {
			for lane, args := range map[string][]string{
				"interpreter": {"run", path, "--max-steps", fmt.Sprint(index + 2), "--format", "json"},
				"native":      {"run", "--max-steps", fmt.Sprint(index + 2), "--format", "json"},
			} {
				executable := binary
				if lane == "native" {
					executable = artifact
				}
				got := runExecutable(t, executable, args...)
				assertLiteralSequenceFailure(t, got, strings.Index(source, item), index+2, 3)
			}
		})
	}
	large := "1" + strings.Repeat("0", 315654)
	for index := 0; index < 3; index++ {
		t.Run(fmt.Sprintf("literal-%d", index), func(t *testing.T) {
			items := []string{"11", "22", "33"}
			items[index] = large
			source := "return List.new(\n  " + strings.Join(items, ",\n  ") + "\n)\n"
			path := sourceFile(t, source)
			artifact, built := buildForTest(t, path)
			if built.status != 0 {
				t.Fatalf("build admitted literal limit: %+v", built)
			}
			for lane, args := range map[string][]string{"interpreter": {"run", path, "--format", "json"}, "native": {"run", "--format", "json"}} {
				executable := binary
				if lane == "native" {
					executable = artifact
				}
				assertLiteralSequenceFailure(t, runExecutable(t, executable, args...), strings.Index(source, large), index+2, 3)
			}
		})
	}
}

func assertLiteralSequenceFailure(t *testing.T, got result, offset, line, column int) {
	t.Helper()
	if got.status != 2 || got.stdout != "" {
		t.Fatalf("literal failure: %+v", got)
	}
	diagnostic := diagnostics(t, got.stderr).Diagnostics[0]
	if diagnostic.Code != "runtime.limit" || diagnostic.Span != nil {
		t.Fatalf("terminal limit diagnostic shape changed: %+v (runtime sites separately verify offset%d line%d column%d)", diagnostic, offset, line, column)
	}
}
