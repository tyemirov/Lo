"""Remove only the verified campaign's explicitly excluded generated copies."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
from datetime import datetime, timezone

ROOT = Path.cwd().resolve()
BASE = ROOT / '_scratch/i011-20261020/completion-20261022'
WORK = BASE / 'storage-nonpass-preparation'
DEST = ROOT / 'docs/evidence/i011-qualification-20261022/storage-nonpass'

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def local(name: str) -> Path:
    p = ROOT / name
    assert p.resolve().is_relative_to(ROOT), name
    return p

def checked(record: dict) -> None:
    p = local(record['path'])
    with p.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == record['sha256'], record['path']
    if 'bytes' in record:
        assert p.stat().st_size == record['bytes'], record['path']

def main() -> None:
    inventory_bytes = (WORK / 'derived-cleanup-inventory.json').read_bytes()
    assert digest(inventory_bytes) == 'b949e02946ddba276440358842cd87e383433d29811ae556192bdd232c772653'
    inventory = json.loads(inventory_bytes)
    checked(inventory['manifest'])
    checked(inventory['verification'])
    manifest = json.loads(local(inventory['manifest']['path']).read_text())
    supplement = (DEST / 'verification-supplement.json').read_bytes()
    assert digest(supplement) == '6ba05cc9fcccdc80d6f3e090fed8f460f5bc0ad879a9006dbb1a4fcbc6df6bee'
    for record in json.loads(supplement)['records']:
        packed = local(record['archive']).read_bytes()
        assert digest(packed) == record['archive_sha256']
        assert packed[4:8] == bytes(4)
        raw = gzip.decompress(packed)
        assert digest(raw) == record['sha256'] and len(raw) == record['bytes']
    candidates = inventory['candidates']
    assert len(candidates) == 56
    assert sum(c['kind'] == 'derived_guest' for c in candidates) == 16
    exclusions = {r['path']: r for r in manifest['excluded_groups']}
    targets = [local(c['path']) for c in candidates]
    for candidate, target in zip(candidates, targets):
        assert exclusions[candidate['path']] == candidate['manifest_exclusion']
        assert target.is_relative_to(BASE / 'storage-final') or target.is_relative_to(BASE / 'storage-checks/public-linux')
        assert target.exists()
        assert all(target == other or not (target.is_relative_to(other) or other.is_relative_to(target)) for other in targets)
    protected = manifest['input_identities']
    for name, record in protected.items():
        p = local(name)
        assert not any(p == target or p.is_relative_to(target) for target in targets), name
        checked(record)
    for package in manifest['packages']:
        checked(package['archive'])
        checked(package['receipt'])
    script = Path(__file__).read_bytes()
    packed = gzip.compress(script, mtime=0)
    out = DEST / 'primary-cleanup.py.gz'
    assert not out.exists()
    out.write_bytes(packed)
    for target in targets:
        if target.is_dir():
            shutil.rmtree(target)
        else:
            target.unlink()
    assert all(not target.exists() for target in targets)
    for record in protected.values():
        checked(record)
    for package in manifest['packages']:
        checked(package['archive'])
        checked(package['receipt'])
    result = {
        'issue': 'I011', 'state': '56_derived_paths_removed_and_verified_absent',
        'time_utc': datetime.now(timezone.utc).isoformat(),
        'inventory_sha256': digest(inventory_bytes),
        'manifest_sha256': inventory['manifest']['sha256'],
        'removed_paths': [c['path'] for c in candidates],
        'retained_inputs_verified': len(protected), 'retained_packages_verified': len(manifest['packages']),
        'script_sha256': digest(script),
        'script_archive': {'archive': str(out.relative_to(ROOT)), 'archive_sha256': digest(packed), 'sha256': digest(script), 'bytes': len(script)},
        'i011_complete': False,
    }
    receipt = DEST / 'primary-cleanup.json'
    assert not receipt.exists()
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'removed_paths'}))

if __name__ == '__main__':
    main()
