.PHONY: i011-continuation-strict-report
i011-continuation-strict-report: | tool-state
	python3 -B tools/semanticcoverage/report.py --interpreter _scratch/i011-20261020/completion-20261022/continuation/corpus/darwin/interpreter.jsonl --llvm darwin/arm64=_scratch/i011-20261020/completion-20261022/continuation/corpus/darwin/llvm.jsonl --llvm linux/arm64=_scratch/i011-20261020/completion-20261022/continuation/corpus/linux/semantic-linux-arm64.jsonl --output _scratch/i011-20261020/completion-20261022/continuation/semantic-report.json </dev/null
