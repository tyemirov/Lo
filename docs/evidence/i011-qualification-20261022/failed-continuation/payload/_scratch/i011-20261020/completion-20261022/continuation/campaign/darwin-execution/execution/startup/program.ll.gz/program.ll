; Lo native lowering; ABI lo-native-1; LLVM 21
source_filename = "/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo"
target triple = "aarch64-apple-darwin"

%lo.result = type { i32, i32, ptr }

@lo_program_metadata = constant [3952 x i8] c"{\22abi\22:\22lo-native-1\22,\22artifact\22:{\22source_sha256\22:\224336023f72dee9bfa682ee0e6cb6384369e92d47b1e99acf621fa88d5b874515\22,\22source\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo\22,\22compiler\22:\22lo-native-llvm-v1\22,\22toolchain\22:\22LLVM 21.1.8\22,\22target\22:\22darwin/arm64\22,\22device_backend\22:\22software\22},\22derivatives\22:[],\22flows\22:[],\22has_result\22:true,\22locations\22:[{\22id\22:0,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:9,\22line\22:2,\22column\22:1},\22action\22:\22body\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:1,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:9,\22line\22:2,\22column\22:1},\22action\22:\22scope_enter\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:2,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:8,\22line\22:1,\22column\22:9},\22action\22:\22statement_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:3,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo\22,\22start\22:{\22offset\22:7,\22line\22:1,\22column\22:8},\22end\22:{\22offset\22:8,\22line\22:1,\22column\22:9},\22action\22:\22expression_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:4,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo\22,\22start\22:{\22offset\22:7,\22line\22:1,\22column\22:8},\22end\22:{\22offset\22:8,\22line\22:1,\22column\22:9},\22action\22:\22literal\22,\22type\22:1,\22text\22:\227\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:5,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo\22,\22start\22:{\22offset\22:7,\22line\22:1,\22column\22:8},\22end\22:{\22offset\22:8,\22line\22:1,\22column\22:9},\22action\22:\22charge_value\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:6,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:8,\22line\22:1,\22column\22:9},\22action\22:\22cause\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0}],\22source\22:{\22path\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup/source.lo\22,\22sha256\22:\224336023f72dee9bfa682ee0e6cb6384369e92d47b1e99acf621fa88d5b874515\22},\22types\22:[{\22id\22:0,\22name\22:\22Null\22,\22kind\22:\22Null\22},{\22id\22:1,\22name\22:\22Int\22,\22kind\22:\22Int\22}]}", align 1
@lo_program_metadata_size = constant i64 3952
@lo_program_flow_count = constant i64 0
@lo_program_flows = constant [0 x ptr] zeroinitializer

declare void @lo_cause(ptr, ptr, i64, i64, ptr)
declare void @lo_charge_value(ptr, ptr, i64, i64, ptr)
declare void @lo_invalid_status(ptr, ptr, i64, i64, ptr)
declare void @lo_literal(ptr, ptr, i64, i64, ptr)
declare void @lo_scope_enter(ptr, ptr, i64, i64, ptr)
declare void @lo_step(ptr, ptr, i64, i64, ptr)
declare void @lo_value_retain(ptr)
declare void @lo_value_release(ptr)
declare void @lo_scope_leave(ptr, ptr, i64)
declare void @lo_flow_leave(ptr)
declare i32 @lo_boolean_value(ptr)

declare void @lo_derivative_leave(ptr)

define internal void @lo_result_copy_value(ptr %out, ptr %result) #0 {
entry:
  %old_pointer = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %old = load ptr, ptr %old_pointer, align 8
  %value_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 2
  %value = load ptr, ptr %value_pointer, align 8
  call void @lo_value_retain(ptr %value)
  call void @lo_value_release(ptr %old)
  %copy = load %lo.result, ptr %result, align 8
  store %lo.result %copy, ptr %out, align 8
  ret void
}
define internal void @lo_result_copy_host(ptr %out, ptr %result) #0 {
entry:
  %old_pointer = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %old = load ptr, ptr %old_pointer, align 8
  call void @lo_value_release(ptr %old)
  %code_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 1
  %code = load i32, ptr %code_pointer, align 4
  %copy = insertvalue %lo.result { i32 2, i32 0, ptr null }, i32 %code, 1
  store %lo.result %copy, ptr %out, align 8
  ret void
}
define internal i1 @lo_result_transfer(ptr %out, ptr %result, ptr %owned) #0 {
entry:
  %status_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 0
  %status = load i32, ptr %status_pointer, align 4
  switch i32 %status, label %unknown [ i32 0, label %payload i32 1, label %payload i32 2, label %host ]
payload:
  %value_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 2
  %value = load ptr, ptr %value_pointer, align 8
  store ptr %value, ptr %owned, align 8
  call void @lo_result_copy_value(ptr %out, ptr %result)
  ret i1 true
host:
  call void @lo_result_copy_host(ptr %out, ptr %result)
  ret i1 true
unknown:
  ret i1 false
}


define void @lo_entry(ptr %context, ptr %arguments, i64 %argc, i64 %callsite, ptr %out) #0 !dbg !6 {
entry:
  %v1 = alloca ptr, align 8
  store ptr null, ptr %v1, align 8
  %v2 = alloca ptr, align 8
  store ptr null, ptr %v2, align 8
  %v3 = alloca ptr, align 8
  store ptr null, ptr %v3, align 8
  %v4 = alloca ptr, align 8
  store ptr null, ptr %v4, align 8
  %v5 = alloca ptr, align 8
  store ptr null, ptr %v5, align 8
  %v6 = alloca ptr, align 8
  store ptr null, ptr %v6, align 8
  %v7 = alloca ptr, align 8
  store ptr null, ptr %v7, align 8
  %v8 = alloca ptr, align 8
  store ptr null, ptr %v8, align 8
  %r1 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r1, align 8
  %r2 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r2, align 8
  %r3 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r3, align 8
  %r4 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r4, align 8
  %r5 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r5, align 8
  %r6 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r6, align 8
  %r7 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r7, align 8
  %r8 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r8, align 8
  %args7 = alloca [1 x ptr], align 8
  %args8 = alloca [1 x ptr], align 8
  store %lo.result zeroinitializer, ptr %out, align 8
  br label %b0
b0:
  %x1 = icmp eq i64 %argc, 0, !dbg !8
  br i1 %x1, label %b4, label %b5, !dbg !8
b1:
  %x2 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x2), !dbg !8
  store ptr null, ptr %v1, align 8, !dbg !8
  %x3 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x3), !dbg !8
  store ptr null, ptr %v2, align 8, !dbg !8
  %x4 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x4), !dbg !8
  store ptr null, ptr %v3, align 8, !dbg !8
  %x5 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x5), !dbg !8
  store ptr null, ptr %v4, align 8, !dbg !8
  %x6 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x6), !dbg !8
  store ptr null, ptr %v5, align 8, !dbg !8
  %x7 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x7), !dbg !8
  store ptr null, ptr %v6, align 8, !dbg !8
  %x8 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x8), !dbg !8
  store ptr null, ptr %v7, align 8, !dbg !8
  %x9 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x9), !dbg !8
  store ptr null, ptr %v8, align 8, !dbg !8
  ret void, !dbg !8
b2:
  br label %b1, !dbg !8
b3:
  %x10 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x11 = load ptr, ptr %x10, align 8
  call void @lo_scope_leave(ptr %context, ptr %x11, i64 0), !dbg !8
  %x12 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x12), !dbg !8
  store ptr null, ptr %v1, align 8, !dbg !8
  %x13 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x13), !dbg !8
  store ptr null, ptr %v2, align 8, !dbg !8
  %x14 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x14), !dbg !8
  store ptr null, ptr %v3, align 8, !dbg !8
  %x15 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x15), !dbg !8
  store ptr null, ptr %v4, align 8, !dbg !8
  %x16 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x16), !dbg !8
  store ptr null, ptr %v5, align 8, !dbg !8
  %x17 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x17), !dbg !8
  store ptr null, ptr %v6, align 8, !dbg !8
  %x18 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x18), !dbg !8
  store ptr null, ptr %v7, align 8, !dbg !8
  %x19 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x19), !dbg !8
  store ptr null, ptr %v8, align 8, !dbg !8
  br label %b1, !dbg !8
b4:
  call void @lo_scope_enter(ptr %context, ptr null, i64 0, i64 1, ptr %r2), !dbg !10
  %x20 = getelementptr %lo.result, ptr %r2, i32 0, i32 0
  %x21 = load i32, ptr %x20, align 4, !dbg !10
  switch i32 %x21, label %b5 [ i32 0, label %b6 i32 1, label %b5 i32 2, label %b7 ], !dbg !10
b5:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 0, ptr %r1), !dbg !8
  call void @lo_result_copy_host(ptr %out, ptr %r1), !dbg !8
  br label %b1, !dbg !8
b6:
  %x22 = getelementptr %lo.result, ptr %r2, i32 0, i32 2
  %x23 = load ptr, ptr %x22, align 8
  store ptr %x23, ptr %v2, align 8, !dbg !10
  call void @lo_step(ptr %context, ptr null, i64 0, i64 2, ptr %r3), !dbg !12
  %x24 = getelementptr %lo.result, ptr %r3, i32 0, i32 0
  %x25 = load i32, ptr %x24, align 4, !dbg !12
  switch i32 %x25, label %b14 [ i32 0, label %b10 i32 1, label %b14 i32 2, label %b11 ], !dbg !12
b7:
  %x26 = call i1 @lo_result_transfer(ptr %out, ptr %r2, ptr %v2), !dbg !8
  br i1 %x26, label %b1, label %b5, !dbg !8
b10:
  %x27 = getelementptr %lo.result, ptr %r3, i32 0, i32 2
  %x28 = load ptr, ptr %x27, align 8
  store ptr %x28, ptr %v3, align 8, !dbg !12
  call void @lo_step(ptr %context, ptr null, i64 0, i64 3, ptr %r5), !dbg !14
  %x29 = getelementptr %lo.result, ptr %r5, i32 0, i32 0
  %x30 = load i32, ptr %x29, align 4, !dbg !14
  switch i32 %x30, label %b14 [ i32 0, label %b15 i32 1, label %b14 i32 2, label %b16 ], !dbg !14
b11:
  %x31 = call i1 @lo_result_transfer(ptr %out, ptr %r3, ptr %v3), !dbg !8
  br i1 %x31, label %b3, label %b14, !dbg !8
b14:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 0, ptr %r4), !dbg !8
  call void @lo_result_copy_host(ptr %out, ptr %r4), !dbg !8
  br label %b3, !dbg !8
b15:
  %x32 = getelementptr %lo.result, ptr %r5, i32 0, i32 2
  %x33 = load ptr, ptr %x32, align 8
  store ptr %x33, ptr %v5, align 8, !dbg !14
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 4, ptr %r6), !dbg !16
  %x34 = getelementptr %lo.result, ptr %r6, i32 0, i32 0
  %x35 = load i32, ptr %x34, align 4, !dbg !16
  switch i32 %x35, label %b14 [ i32 0, label %b19 i32 1, label %b14 i32 2, label %b20 ], !dbg !16
b16:
  %x36 = call i1 @lo_result_transfer(ptr %out, ptr %r5, ptr %v5), !dbg !8
  br i1 %x36, label %b3, label %b14, !dbg !8
b19:
  %x37 = getelementptr %lo.result, ptr %r6, i32 0, i32 2
  %x38 = load ptr, ptr %x37, align 8
  store ptr %x38, ptr %v6, align 8, !dbg !16
  %x40 = load ptr, ptr %v6, align 8
  %x39 = getelementptr [1 x ptr], ptr %args7, i64 0, i64 0, !dbg !18
  store ptr %x40, ptr %x39, align 8, !dbg !18
  call void @lo_charge_value(ptr %context, ptr %args7, i64 1, i64 5, ptr %r7), !dbg !18
  %x41 = getelementptr %lo.result, ptr %r7, i32 0, i32 0
  %x42 = load i32, ptr %x41, align 4, !dbg !18
  switch i32 %x42, label %b14 [ i32 0, label %b23 i32 1, label %b14 i32 2, label %b24 ], !dbg !18
b20:
  %x43 = call i1 @lo_result_transfer(ptr %out, ptr %r6, ptr %v6), !dbg !8
  br i1 %x43, label %b3, label %b14, !dbg !8
b23:
  %x44 = getelementptr %lo.result, ptr %r7, i32 0, i32 2
  %x45 = load ptr, ptr %x44, align 8
  store ptr %x45, ptr %v7, align 8, !dbg !18
  %x47 = load ptr, ptr %v6, align 8
  %x46 = getelementptr [1 x ptr], ptr %args8, i64 0, i64 0, !dbg !20
  store ptr %x47, ptr %x46, align 8, !dbg !20
  call void @lo_cause(ptr %context, ptr %args8, i64 1, i64 6, ptr %r8), !dbg !20
  %x48 = getelementptr %lo.result, ptr %r8, i32 0, i32 0
  %x49 = load i32, ptr %x48, align 4, !dbg !20
  switch i32 %x49, label %b14 [ i32 0, label %b27 i32 1, label %b27 i32 2, label %b27 ], !dbg !20
b24:
  %x50 = call i1 @lo_result_transfer(ptr %out, ptr %r7, ptr %v7), !dbg !8
  br i1 %x50, label %b3, label %b14, !dbg !8
b27:
  %x51 = call i1 @lo_result_transfer(ptr %out, ptr %r8, ptr %v8), !dbg !8
  br i1 %x51, label %b3, label %b14, !dbg !8
}

attributes #0 = { noinline "fp-contract"="off" "frame-pointer"="all" }
attributes #1 = { noinline optnone "fp-contract"="off" "frame-pointer"="all" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3}
!0 = distinct !DICompileUnit(language: DW_LANG_C, file: !1, producer: "Lo lo-native-1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)
!1 = !DIFile(filename: "source.lo", directory: "/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/startup")
!2 = !{i32 2, !"Dwarf Version", i32 4}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !DISubroutineType(types: !5)
!5 = !{null}
!6 = distinct !DISubprogram(name: "<top>", linkageName: "lo_entry", scope: !1, file: !1, line: 1, type: !4, scopeLine: 1, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!8 = !DILocation(line: 1, column: 1, scope: !7)
!9 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!10 = !DILocation(line: 1, column: 1, scope: !9)
!11 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!12 = !DILocation(line: 1, column: 1, scope: !11)
!13 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!14 = !DILocation(line: 1, column: 8, scope: !13)
!15 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!16 = !DILocation(line: 1, column: 8, scope: !15)
!17 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!18 = !DILocation(line: 1, column: 8, scope: !17)
!19 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!20 = !DILocation(line: 1, column: 1, scope: !19)
