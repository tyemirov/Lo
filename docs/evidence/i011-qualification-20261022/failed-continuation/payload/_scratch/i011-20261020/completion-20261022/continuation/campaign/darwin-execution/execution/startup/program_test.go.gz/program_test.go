package fixture
import("context";"testing";"github.com/MarcoPoloResearchLab/Lo/internal/compiler";"github.com/MarcoPoloResearchLab/Lo/internal/eval";"github.com/MarcoPoloResearchLab/Lo/internal/execution"
"github.com/MarcoPoloResearchLab/Lo/internal/device";"github.com/MarcoPoloResearchLab/Lo/internal/source";"github.com/MarcoPoloResearchLab/Lo/internal/value")
type boundary struct{execution.Boundary}
func(boundary)Read(context.Context,value.Text)(value.Bytes,error){return nil,execution.Denied("read","benchmark")}
func(boundary)Commit(context.Context,value.Target)(value.Value,error){return nil,execution.Denied("commit","benchmark")}
var sink value.Value
func BenchmarkExecution(b *testing.B){
 file,err:=source.New("startup.lo","return 7\n");if err!=nil{b.Fatal(err)};p,d:=compiler.Check(file);if d!=nil{b.Fatal(d)}
 interpreted,err:=eval.Program(p);if err!=nil{b.Fatal(err)}
 budget,err:=execution.NewBudget(10000000);if err!=nil{b.Fatal(err)}
 reference,err:=interpreted.Run(context.Background(),boundary{},budget,device.DefaultConfig());if err!=nil{b.Fatal(err)}
 expected:=value.TextResult(reference);if independent:="7";independent!=""&&expected!=independent{b.Fatalf("reference %s want %s",expected,independent)}
 b.ReportAllocs();b.ResetTimer();for b.Loop(){v,err:=interpreted.Run(context.Background(),boundary{},budget,device.DefaultConfig());if err!=nil{b.Fatal(err)};sink=v}
}

