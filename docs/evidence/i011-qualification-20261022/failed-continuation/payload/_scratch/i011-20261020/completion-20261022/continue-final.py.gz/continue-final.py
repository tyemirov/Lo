from pathlib import Path
import argparse,hashlib,importlib.util,json,os,shutil,signal,subprocess,sys
ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('i011_original_driver',BASE/'final-run.py')
original=importlib.util.module_from_spec(spec);sys.modules[spec.name]=original;spec.loader.exec_module(original)
campaign=original.campaign
save=original.save
now=original.now

def load(path):
    assert path.resolve().is_relative_to(ROOT)
    return json.loads(path.read_text())
def receipt(path):return {'path':str(path.relative_to(ROOT)),'sha256':campaign.sha(path)}
def main():
    work=BASE/'continuation';prior=BASE/'final';frozen=load(prior/'frozen.json');previous=load(prior/'status.json')
    if work.exists():raise ValueError('continuation output exists')
    if previous['state']!='invalid' or previous.get('error')!='component-tools failed':raise ValueError('unexpected predecessor outcome')
    if [(j['name'],j['status']) for j in previous['jobs']]!=[('ci',0),('linux-corpus',0),('component-tools',2)]:raise ValueError('unexpected predecessor jobs')
    if any(j.get('remaining_owned_members')!=[] for j in previous['jobs']):raise ValueError('predecessor cleanup incomplete')
    args=argparse.Namespace(darwin_package=ROOT/'bin/distributions-i011-20261022/lo-darwin-arm64-software',linux_package=ROOT/'bin/distributions-i011-20261022/lo-linux-arm64-software',preparation=ROOT/'_scratch/native-runtime',frontend=ROOT/'bin/distributions-i011-20261022/lo-darwin-arm64-software/bin/lo',accelerator='hvf')
    def verify():
      sources,identity=original.source_identity()
      if sources!=frozen['sources'] or identity!=frozen['semantic_source_sha256']:raise ValueError('source differs from predecessor freeze')
      if original.package_files()!=frozen['package_files'] or campaign.snapshot(args)!=frozen['campaign_inputs']:raise ValueError('packages or tools differ from predecessor freeze')
      if load(prior/'status.json')!=previous:raise ValueError('predecessor status changed')
      for job in previous['jobs']:
        for stream in ['stdout','stderr']:
          if campaign.sha(prior/(job['name']+'.'+stream))!=job[stream+'_sha256']:raise ValueError('predecessor log changed')
    verify();work.mkdir();shutil.copyfile(prior/'frozen.json',work/'frozen.json')
    reused=[]
    for job in previous['jobs'][:2]:
      item=dict(job)
      for stream in ['stdout','stderr']:item[stream]=str((prior/(job['name']+'.'+stream)).relative_to(ROOT))
      reused.append(item)
    runtime=BASE/'reader-runtime';runtime_receipt=receipt(runtime/'build-receipt.json')
    state={'state':'running','source_sha256':frozen['semantic_source_sha256'],'start_utc':now(),'predecessor':receipt(prior/'status.json'),'predecessor_freeze':receipt(prior/'frozen.json'),'reused_jobs':reused,'corrected_environment':{'LO_TEST_RUNTIME_DISTRIBUTION':str(runtime.relative_to(ROOT)),'runtime_receipt':runtime_receipt},'jobs':[],'i011_complete':False,'code_validation_complete':False,'performance_complete':False}
    save(work/'status.json',state)
    package='bin/distributions-i011-20261022';metal=package+'/lo-darwin-arm64-metal'
    common=['COMPILER_DISTRIBUTION_OUTPUT='+package,'LLVM_TOOLCHAIN='+metal+'/toolchain.json','SEMANTIC_COMPILER='+metal+'/bin/lo','SEMANTIC_TOOLCHAIN='+metal+'/toolchain.json','NATIVE_RUNTIME_STATE=_scratch/native-runtime']
    child=None
    def interrupted(*_):raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM,interrupted)
    def run(name,argv):
      nonlocal child
      verify()
      if campaign.sha(runtime/'build-receipt.json')!=runtime_receipt['sha256']:raise ValueError('corrected runtime input changed')
      record={'name':name,'command':argv,'start_utc':now(),'status':None};state['jobs'].append(record);save(work/'status.json',state)
      env=dict(os.environ,CI='1',PYTHONDONTWRITEBYTECODE='1',LO_TEST_COMPILER=str(ROOT/metal/'bin/lo'),LO_TEST_RUNTIME_DISTRIBUTION=str(runtime))
      env.pop('LO_TEST_BACKEND',None)
      for stream in ['stdout','stderr']:record[stream]=str((work/(name+'.'+stream)).relative_to(ROOT))
      with (work/(name+'.stdout')).open('xb') as out,(work/(name+'.stderr')).open('xb') as err:
        child=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
        record['pid']=child.pid;save(work/'status.json',state);record['status']=child.wait()
      cleaned=campaign.stop(child);child=None;record['remaining_owned_members']=list(cleaned.remaining_owned_members);record['finish_utc']=now()
      for stream in ['stdout','stderr']:record[stream+'_sha256']=campaign.sha(ROOT/record[stream])
      verify()
      if campaign.sha(runtime/'build-receipt.json')!=runtime_receipt['sha256']:raise ValueError('corrected runtime input changed during job')
      save(work/'status.json',state);return record['status']
    try:
      if run('component-tools',['make','-s','test-native-runtime-tools','test-compiler-distribution-tools',*common]):raise ValueError('component-tools failed')
      if run('offline',['make','-s','test-compiler-distributions',*common,'COMPILER_DISTRIBUTION_ACCEPTANCE='+str(work/'offline')]):raise ValueError('offline failed')
      (work/'corpus').mkdir();original.extract_ci(prior/'ci.stdout',work/'corpus/darwin')
      (work/'corpus/linux').mkdir();source=prior/'corpus/linux/semantic-linux-arm64.jsonl';copied=work/'corpus/linux/semantic-linux-arm64.jsonl';shutil.copyfile(source,copied)
      state['reused_linux_events']={'original':receipt(source),'copy':receipt(copied)};save(work/'status.json',state)
      if run('semantic-report',['make','-s','-f','Makefile','-f',str(BASE/'continuation.mk'),'i011-continuation-strict-report']):raise ValueError('semantic-report failed')
      state['code_validation_complete']=True;save(work/'status.json',state)
      status=run('performance',['make','-s','benchmark-native-campaign','COMPILER_DISTRIBUTION_OUTPUT='+package,'NATIVE_CAMPAIGN_WORK='+str(work/'campaign'),'LINUX_ACCELERATOR=hvf'])
      report=load(work/'campaign/report.json')
      if report['state']!='complete' or report['measurement_complete'] is not True:raise ValueError('performance incomplete or invalid')
      if status!=(0 if report['qualification_outcome']=='pass' else 2):raise ValueError('campaign Make status differs from outcome')
      state.update(state='performance-pass' if report['qualification_outcome']=='pass' else 'performance-nonpass',performance_complete=True,performance_outcome=report['qualification_outcome'])
      return 0 if status==0 else 2
    except BaseException as error:
      state.update(state='invalid',error=str(error));return 2
    finally:
      if child is not None:
        try:result=campaign.stop(child);state['remaining_owned_members']=list(result.remaining_owned_members)
        except BaseException as error:state['cleanup_error']=str(error)
      state['finish_utc']=now();save(work/'status.json',state)
if __name__=='__main__':raise SystemExit(main())
