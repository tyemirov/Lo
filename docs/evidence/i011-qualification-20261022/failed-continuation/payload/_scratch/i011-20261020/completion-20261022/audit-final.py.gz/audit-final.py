from pathlib import Path
import argparse,copy,gzip,hashlib,importlib.util,json,sys
ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
WORK=BASE/'continuation'
sys.path.insert(0,str(ROOT/'tools/nativebench'))
import campaign,merge,qualification

def load(path):
    assert path.resolve().is_relative_to(ROOT)
    return json.loads(path.read_text())
def sha(path):
    assert path.resolve().is_relative_to(ROOT)
    return campaign.sha(path)
def require(condition,message):
    if not condition:raise ValueError(message)
def receipt(path):return {'path':str(path.relative_to(ROOT)),'sha256':sha(path)}
def audit():
    frozen=load(WORK/'frozen.json');state=load(WORK/'status.json')
    require(state.get('state')=='performance-pass' and not state.get('error') and not state.get('cleanup_error'),'final driver not passed')
    predecessor=ROOT/state['predecessor']['path'];previous=load(predecessor)
    require(sha(predecessor)==state['predecessor']['sha256'] and previous['state']=='invalid' and previous.get('error')=='component-tools failed','predecessor terminal record differs')
    require([(j['name'],j['status']) for j in previous['jobs']]==[('ci',0),('linux-corpus',0),('component-tools',2)],'predecessor outcome differs')
    require(sha(ROOT/state['predecessor_freeze']['path'])==state['predecessor_freeze']['sha256']==sha(WORK/'frozen.json'),'predecessor freeze differs')
    require([j['name'] for j in state['reused_jobs']]==['ci','linux-corpus'],'unexpected reused jobs')
    for original,reused in zip(previous['jobs'][:2],state['reused_jobs']):
      require(all(reused[key]==value for key,value in original.items()),'reused job record differs')
      for stream in ['stdout','stderr']:require(ROOT/reused[stream]==predecessor.parent/(original['name']+'.'+stream),'reused stream path differs')
    require([job['name'] for job in state['jobs']]==['component-tools','offline','semantic-report','performance'],'unexpected continuation job sequence')
    combined=state['reused_jobs']+state['jobs']
    require(all(job.get('status')==0 and job.get('remaining_owned_members')==[] and 'finish_utc' in job for job in combined),'job status or cleanup failed')
    for job in previous['jobs']:
      require(job.get('remaining_owned_members')==[],'predecessor cleanup failed')
      for stream in ['stdout','stderr']:require(sha(predecessor.parent/(job['name']+'.'+stream))==job[stream+'_sha256'],'predecessor stream identity differs')
    for job in combined:
      for stream in ['stdout','stderr']:require(sha(ROOT/job[stream])==job[stream+'_sha256'],'job log identity differs')
    corrected=state['corrected_environment'];runtime=ROOT/corrected['LO_TEST_RUNTIME_DISTRIBUTION'];runtime_receipt=corrected['runtime_receipt']
    require(runtime==BASE/'reader-runtime' and ROOT/runtime_receipt['path']==runtime/'build-receipt.json' and sha(runtime/'build-receipt.json')==runtime_receipt['sha256'] and 'metal' in load(runtime/'build-receipt.json'),'corrected runtime input differs')
    reused_events=state['reused_linux_events'];require(sha(ROOT/reused_events['original']['path'])==reused_events['original']['sha256']==reused_events['copy']['sha256']==sha(ROOT/reused_events['copy']['path']),'reused Linux events differ')
    require(state['source_sha256']==frozen['semantic_source_sha256'],'source binding differs')
    for name,digest in frozen['sources'].items():require(sha(ROOT/name)==digest,'source differs:'+name)
    for name,digest in frozen['package_files'].items():require(sha(ROOT/name)==digest,'package file differs:'+name)
    for index in ['orchestration.json','continuation-orchestration.json']:
      orchestration=load(ROOT/'docs/evidence/i011-qualification-20261022'/index)
      for record in orchestration['records']:
        require(sha(ROOT/record['original_path'])==record['original_sha256'],'orchestration differs')
        archive=ROOT/record['archive'];require(sha(archive)==record['archive_sha256'],'orchestration archive differs')
        require(hashlib.sha256(gzip.decompress(archive.read_bytes())).hexdigest()==record['original_sha256'],'orchestration decoded identity differs')
    semantic=load(WORK/'semantic-report.json')
    spec=importlib.util.spec_from_file_location('i011_semantic_audit',ROOT/'tools/semanticcoverage/report.py')
    semantic_module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=semantic_module;spec.loader.exec_module(semantic_module)
    recomputed=BASE/'audit-semantic-recomputed.json'
    semantic_inputs=semantic_module.Inputs(ROOT/'testdata/semantic-migration/matrix.json',WORK/'corpus/darwin/interpreter.jsonl',{'darwin/arm64':WORK/'corpus/darwin/llvm.jsonl','linux/arm64':WORK/'corpus/linux/semantic-linux-arm64.jsonl'},recomputed)
    require(semantic_module.report(semantic_inputs)==0 and load(recomputed)==semantic,'semantic event recomputation differs')
    for lane,variant in [('interpreter','lo-darwin-arm64-metal'),('llvm:darwin/arm64','lo-darwin-arm64-metal'),('llvm:linux/arm64','lo-linux-arm64-software')]:
      identity=semantic['execution_identity'][lane];package=ROOT/'bin/distributions-i011-20261022'/variant
      compiler=package/'bin/lo';require(identity['compiler']==str(compiler.relative_to(ROOT)) and identity['compiler_sha256']==frozen['package_files'][str(compiler.relative_to(ROOT))],'semantic compiler differs from frozen package')
      if lane!='interpreter':
        manifest=package/'toolchain.json';require(identity['toolchain']==str(manifest.relative_to(ROOT)) and identity['toolchain_sha256']==frozen['package_files'][str(manifest.relative_to(ROOT))],'semantic toolchain differs from frozen package')
        runtime=load(manifest)['targets'][identity['target']]['runtime'];runtime_path=(package/runtime['path']).resolve()
        require(runtime_path.is_relative_to(ROOT) and identity['runtime_sha256']==runtime['sha256']==frozen['package_files'][str(runtime_path.relative_to(ROOT))],'semantic runtime differs from frozen package')
    require(semantic['execution_status']=='passed' and semantic['qualification_status']=='passed' and semantic['missing_targets']==[] and semantic['qualification_gaps']==[],'strict semantic qualification failed')
    require(semantic['source_sha256']==frozen['sources'],'semantic source inventory differs')
    for lane,path in [('interpreter',WORK/'corpus/darwin/interpreter.jsonl'),('llvm:darwin/arm64',WORK/'corpus/darwin/llvm.jsonl'),('llvm:linux/arm64',WORK/'corpus/linux/semantic-linux-arm64.jsonl')]:require(sha(path)==semantic['log_sha256'][lane],'semantic log identity differs')
    offline=load(WORK/'offline/validation.json')
    require(offline['status']=='passed','offline qualification failed')
    require(offline['guard']['status']==0,'offline guard failed')
    require({(cell['host'],cell['target']) for cell in offline['matrix']}=={(host,target) for host in ['darwin/arm64','linux/arm64'] for target in ['darwin/arm64','linux/arm64']} and len(offline['matrix'])==4,'offline matrix incomplete')
    require(all(cell['compile']['status']==0 and cell['execute']['status']==0 for cell in offline['matrix']),'offline cell failed')
    require(offline['metal']['compile']['status']==0 and offline['metal']['execute']['status']==0,'Metal package qualification failed')
    for cell in [*offline['matrix'],offline['metal'],offline['relocation']]:
      require(cell['compile']['status']==0 and cell['execute']['status']==0,'offline build/execution failed')
      values=json.loads(cell['execute']['stdout'])['result']['value']['value']
      require({name:value['value'] for name,value in values.items()}=={'count':'3','error':'Math.DivideByZero','large':'123456789012345678901234567891','tensor':'6','text':'λ雪'},'representative result differs')
    require({row['host'] for row in offline['training']}=={'darwin/arm64','linux/arm64'} and len(offline['training'])==2,'training target coverage incomplete')
    for cell in offline['training']:
      require(cell['compile']['status']==0 and cell['execute']['status']==0,'training build/execution failed')
      fields=json.loads(cell['execute']['stdout'])['result']['value']['value']
      require(fields['steps']['value']=='500' and float(fields['loss']['value'])<1e-10<float(fields['initial_loss']['value']),'training result differs')
      predictions=fields['predictions']['value']['values']
      require(len(predictions)==4 and all(abs(float(value)-expected)<=1e-4 for value,expected in zip(predictions,[0,1,1,0])),'training predictions differ')
    require(len(offline['rejections'])==9 and len({row['case'] for row in offline['rejections']})==9 and all(row['status']==2 and row['prior_output_preserved'] and row['staging_empty'] for row in offline['rejections']),'rejection qualification incomplete')
    require(set(offline['packages'])=={'darwin','linux','metal'},'offline package inventory differs')
    for key,record in offline['packages'].items():
      variant={'darwin':'lo-darwin-arm64-software','linux':'lo-linux-arm64-software','metal':'lo-darwin-arm64-metal'}[key]
      expected_package=ROOT/'bin/distributions-i011-20261022'/variant
      require(record['package']==str(expected_package.relative_to(ROOT)),'offline package is not final package')
      for name,field in [('toolchain.json','toolchain_sha256'),('inventory.json','inventory_sha256'),('bin/lo','frontend_sha256')]:require(record[field]==frozen['package_files'][str((expected_package/name).relative_to(ROOT))],'offline package differs from final freeze')
      package=ROOT/record['package'];require(sha(ROOT/record['archive'])==record['archive_sha256'],'package archive differs')
      require(sha(package/'toolchain.json')==record['toolchain_sha256'] and sha(package/'inventory.json')==record['inventory_sha256'] and sha(package/'bin/lo')==record['frontend_sha256'],'offline package identity differs')
    def verify_build(cell,key,target):
      package=ROOT/offline['packages'][key]['package'];manifest=load(package/'toolchain.json')
      runtime=manifest['targets'][target]['runtime'];built=json.loads(cell['compile']['stdout'])
      require(built['command']=='build' and built['status']=='ok' and built['target']==target and built['abi']=='lo-native-1' and built['codegen']=='llvm' and built['runtime_sha256']==runtime['sha256'],'offline build runtime or target differs')
      runtime_path=(package/runtime['path']).resolve();require(runtime_path.is_relative_to(ROOT) and runtime['sha256']==frozen['package_files'][str(runtime_path.relative_to(ROOT))],'offline runtime differs from freeze')
    for cell in offline['matrix']:verify_build(cell,cell['host'].split('/')[0],cell['target'])
    for cell in offline['training']:verify_build(cell,cell['host'].split('/')[0],cell['host'])
    verify_build(offline['metal'],'metal','darwin/arm64');verify_build(offline['relocation'],'darwin','darwin/arm64')
    directory=WORK/'campaign';summary=load(directory/'report.json');config=load(directory/'config.json')
    require(summary['state']=='complete' and summary['measurement_complete'] is True and summary['qualification_outcome']=='pass','campaign not complete pass')
    require(not summary.get('error') and not summary.get('cleanup_error') and summary['remaining_owned_members']==[],'campaign error/cleanup')
    require(sha(directory/'config.json')==summary['config_sha256'],'config identity differs')
    require(config['samples']==10 and config['warmup']==3 and config['concurrency']==1 and config['lanes']==list(qualification.LANES),'campaign contract differs')
    expected=[(target,lane) for target in ['darwin','linux'] for lane in qualification.LANES]
    require([(row['target'],row['lane']) for row in summary['subprocesses']]==expected,'campaign lane order/inventory differs')
    args=argparse.Namespace(**{key:Path(value) for key,value in config['paths'].items()},accelerator='hvf')
    current=campaign.snapshot(args)
    require(all(config[key]==value for key,value in current.items()),'campaign inputs changed')
    require(current==frozen['campaign_inputs'],'campaign differs from final source freeze')
    paths={target:[] for target in ['darwin','linux']};lanes=[]
    for item in summary['subprocesses']:
      target,lane=item['target'],item['lane'];path=directory/f'{target}-{lane}'/'report.json'
      require(sha(path)==item['report_sha256'] and str(path.relative_to(ROOT))==item['report'],'lane binding differs')
      require(item['measurement_complete'] is True,'lane incomplete')
      for stream in ['stdout','stderr']:require(sha(ROOT/item[stream])==item[stream+'_sha256'],'lane log binding differs')
      raw,_=merge.admit(path);calculated=copy.deepcopy(raw);qualification.completion(calculated,0)
      require(raw['lanes']==[lane] and raw['merge_identity']['target']==target+'/arm64','lane target/inventory differs')
      identity=raw['merge_identity'];declared=config['source_identity'][target]
      require(identity['package']==config['packages'][target] and all(identity[key]==declared[key] for key in ['source','harness','evaluator']) and identity['producer']['source_identity']==declared['producer']['source_identity'] and identity['reference']['source_identity']==declared['reference']['source_identity'],'lane differs from predeclared provenance')
      require(identity['accelerator']==('none' if target=='darwin' else 'hvf') and identity['measurement']['samples']==10 and identity['measurement']['warmup']==3,'lane sample or accelerator contract differs')
      require(calculated['measurement_complete'] and not calculated.get('measurement_error'),'invalid lane')
      require(raw['gate_failures']==calculated['gate_failures'] and raw['gates_passed']==calculated['gates_passed'],'lane gates differ')
      require(item['status']==(0 if calculated['gates_passed'] else 2) and item['qualification_outcome']==campaign.outcome(calculated),'lane Make outcome differs')
      require(calculated['gates_passed'],'lane gate failed')
      paths[target].append(path);lanes.append({'target':target,'lane':lane,'report':receipt(path),'gate_failures':calculated['gate_failures']})
    require([item['target'] for item in summary['merges']]==['darwin','linux'],'target merge inventory differs')
    targets={}
    for item in summary['merges']:
      target=item['target'];path=directory/(target+'-merged.json');stored=load(path);calculated=merge.merge(paths[target])
      require(stored==calculated and sha(path)==item['report_sha256'],'target merge differs')
      require(calculated['measurement_complete'] and calculated['qualification_complete'] and calculated['gates_passed'],'target merge not qualified')
      require(item['qualification_outcome']==campaign.outcome(calculated)=='pass' and item['gate_failures']==[],'target outcome differs')
      targets[target]={'report':receipt(path),'callback_speedup':calculated['callback_speedup'],'callback_interval95':calculated['callback_bootstrap_95_percent'],'gate_failures':calculated['gate_failures'],'max_build_seconds':max(r['elapsed_ns'] for r in calculated['build'])/1e9,'max_build_rss_bytes':max(r['peak_process_tree_rss_bytes'] for r in calculated['build']),'max_artifact_bytes':max(r['artifact_bytes'] for r in calculated['build']),'http':[{key:row[key] for key in ['name','p95','reciprocal_throughput']} for row in calculated['http']]}
    require(state['jobs'][-1]['status']==0 and summary['qualification_outcome']=='pass','outer Make outcome differs')
    return {'issue':'I011','audit_status':'all_code_and_performance_checks_passed','i011_complete':False,'source_sha256':state['source_sha256'],'frozen':receipt(WORK/'frozen.json'),'driver':receipt(WORK/'status.json'),'semantic':receipt(WORK/'semantic-report.json'),'semantic_reference_count':len(semantic['references']),'offline':receipt(WORK/'offline/validation.json'),'packages_verified':len(frozen['package_files']),'lanes':lanes,'targets':targets,'pending':['approved_manual_documentation_review','independent_completion_review','owned_scratch_cleanup']}
if __name__=='__main__':
    try:
      result=audit();output=BASE/'final-audit.json'
      with output.open('x') as file:file.write(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
      print(json.dumps({'audit':'passed','output':str(output.relative_to(ROOT))}))
    except (ValueError,KeyError,TypeError,OSError,AssertionError) as error:
      print(json.dumps({'audit':'failed','error':str(error)}),file=sys.stderr);raise SystemExit(2)
