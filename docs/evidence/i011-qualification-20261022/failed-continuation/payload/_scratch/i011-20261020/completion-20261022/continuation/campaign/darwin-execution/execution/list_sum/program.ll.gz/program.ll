; Lo native lowering; ABI lo-native-1; LLVM 21
source_filename = "/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo"
target triple = "aarch64-apple-darwin"

%lo.result = type { i32, i32, ptr }

@lo_program_metadata = constant [11138 x i8] c"{\22abi\22:\22lo-native-1\22,\22artifact\22:{\22source_sha256\22:\225640eab42d3927d0feaf3cdd7fe7e2f998ab4bb269fff1f1cccf36eee4b666d4\22,\22source\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22compiler\22:\22lo-native-llvm-v1\22,\22toolchain\22:\22LLVM 21.1.8\22,\22target\22:\22darwin/arm64\22,\22device_backend\22:\22software\22},\22derivatives\22:[],\22flows\22:[],\22has_result\22:true,\22locations\22:[{\22id\22:0,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:35,\22line\22:2,\22column\22:1},\22action\22:\22body\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:1,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:35,\22line\22:2,\22column\22:1},\22action\22:\22scope_enter\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:2,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:34,\22line\22:1,\22column\22:35},\22action\22:\22statement_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:3,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:7,\22line\22:1,\22column\22:8},\22end\22:{\22offset\22:34,\22line\22:1,\22column\22:35},\22action\22:\22expression_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:4,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:16,\22line\22:1,\22column\22:17},\22end\22:{\22offset\22:33,\22line\22:1,\22column\22:34},\22action\22:\22expression_step\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:5,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:25,\22line\22:1,\22column\22:26},\22end\22:{\22offset\22:26,\22line\22:1,\22column\22:27},\22action\22:\22expression_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:6,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:25,\22line\22:1,\22column\22:26},\22end\22:{\22offset\22:26,\22line\22:1,\22column\22:27},\22action\22:\22literal\22,\22type\22:1,\22text\22:\221\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:7,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:25,\22line\22:1,\22column\22:26},\22end\22:{\22offset\22:26,\22line\22:1,\22column\22:27},\22action\22:\22charge_value\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:8,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:27,\22line\22:1,\22column\22:28},\22end\22:{\22offset\22:28,\22line\22:1,\22column\22:29},\22action\22:\22expression_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:9,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:27,\22line\22:1,\22column\22:28},\22end\22:{\22offset\22:28,\22line\22:1,\22column\22:29},\22action\22:\22literal\22,\22type\22:1,\22text\22:\222\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:10,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:27,\22line\22:1,\22column\22:28},\22end\22:{\22offset\22:28,\22line\22:1,\22column\22:29},\22action\22:\22charge_value\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:11,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:29,\22line\22:1,\22column\22:30},\22end\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22action\22:\22expression_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:12,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:29,\22line\22:1,\22column\22:30},\22end\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22action\22:\22literal\22,\22type\22:1,\22text\22:\223\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:13,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:29,\22line\22:1,\22column\22:30},\22end\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22action\22:\22charge_value\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:14,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:31,\22line\22:1,\22column\22:32},\22end\22:{\22offset\22:32,\22line\22:1,\22column\22:33},\22action\22:\22expression_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:15,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:31,\22line\22:1,\22column\22:32},\22end\22:{\22offset\22:32,\22line\22:1,\22column\22:33},\22action\22:\22literal\22,\22type\22:1,\22text\22:\224\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:16,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:31,\22line\22:1,\22column\22:32},\22end\22:{\22offset\22:32,\22line\22:1,\22column\22:33},\22action\22:\22charge_value\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:17,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:16,\22line\22:1,\22column\22:17},\22end\22:{\22offset\22:33,\22line\22:1,\22column\22:34},\22action\22:\22operation\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22List.new\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:1,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:1,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:1,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:1,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:18,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:16,\22line\22:1,\22column\22:17},\22end\22:{\22offset\22:33,\22line\22:1,\22column\22:34},\22action\22:\22charge_value\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:19,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:7,\22line\22:1,\22column\22:8},\22end\22:{\22offset\22:34,\22line\22:1,\22column\22:35},\22action\22:\22operation\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22Math.sum\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:2,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:20,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:7,\22line\22:1,\22column\22:8},\22end\22:{\22offset\22:34,\22line\22:1,\22column\22:35},\22action\22:\22charge_value\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:21,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:34,\22line\22:1,\22column\22:35},\22action\22:\22cause\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0}],\22source\22:{\22path\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum/source.lo\22,\22sha256\22:\225640eab42d3927d0feaf3cdd7fe7e2f998ab4bb269fff1f1cccf36eee4b666d4\22},\22types\22:[{\22id\22:0,\22name\22:\22Null\22,\22kind\22:\22Null\22},{\22id\22:1,\22name\22:\22Int\22,\22kind\22:\22Int\22},{\22id\22:2,\22name\22:\22List\5Cu003cInt\5Cu003e\22,\22kind\22:\22List\22}]}", align 1
@lo_program_metadata_size = constant i64 11138
@lo_program_flow_count = constant i64 0
@lo_program_flows = constant [0 x ptr] zeroinitializer

declare void @lo_cause(ptr, ptr, i64, i64, ptr)
declare void @lo_charge_value(ptr, ptr, i64, i64, ptr)
declare void @lo_invalid_status(ptr, ptr, i64, i64, ptr)
declare void @lo_literal(ptr, ptr, i64, i64, ptr)
declare void @lo_op_List_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_op_Math_2Esum(ptr, ptr, i64, i64, ptr)
declare void @lo_scope_enter(ptr, ptr, i64, i64, ptr)
declare void @lo_step(ptr, ptr, i64, i64, ptr)
declare void @lo_value_retain(ptr)
declare void @lo_value_release(ptr)
declare void @lo_scope_leave(ptr, ptr, i64)
declare void @lo_flow_leave(ptr)
declare i32 @lo_boolean_value(ptr)

declare void @lo_derivative_leave(ptr)

define internal void @lo_result_copy_value(ptr %out, ptr %result) #0 {
entry:
  %old_pointer = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %old = load ptr, ptr %old_pointer, align 8
  %value_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 2
  %value = load ptr, ptr %value_pointer, align 8
  call void @lo_value_retain(ptr %value)
  call void @lo_value_release(ptr %old)
  %copy = load %lo.result, ptr %result, align 8
  store %lo.result %copy, ptr %out, align 8
  ret void
}
define internal void @lo_result_copy_host(ptr %out, ptr %result) #0 {
entry:
  %old_pointer = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %old = load ptr, ptr %old_pointer, align 8
  call void @lo_value_release(ptr %old)
  %code_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 1
  %code = load i32, ptr %code_pointer, align 4
  %copy = insertvalue %lo.result { i32 2, i32 0, ptr null }, i32 %code, 1
  store %lo.result %copy, ptr %out, align 8
  ret void
}
define internal i1 @lo_result_transfer(ptr %out, ptr %result, ptr %owned) #0 {
entry:
  %status_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 0
  %status = load i32, ptr %status_pointer, align 4
  switch i32 %status, label %unknown [ i32 0, label %payload i32 1, label %payload i32 2, label %host ]
payload:
  %value_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 2
  %value = load ptr, ptr %value_pointer, align 8
  store ptr %value, ptr %owned, align 8
  call void @lo_result_copy_value(ptr %out, ptr %result)
  ret i1 true
host:
  call void @lo_result_copy_host(ptr %out, ptr %result)
  ret i1 true
unknown:
  ret i1 false
}


define void @lo_entry(ptr %context, ptr %arguments, i64 %argc, i64 %callsite, ptr %out) #0 !dbg !6 {
entry:
  %v1 = alloca ptr, align 8
  store ptr null, ptr %v1, align 8
  %v2 = alloca ptr, align 8
  store ptr null, ptr %v2, align 8
  %v3 = alloca ptr, align 8
  store ptr null, ptr %v3, align 8
  %v4 = alloca ptr, align 8
  store ptr null, ptr %v4, align 8
  %v5 = alloca ptr, align 8
  store ptr null, ptr %v5, align 8
  %v6 = alloca ptr, align 8
  store ptr null, ptr %v6, align 8
  %v7 = alloca ptr, align 8
  store ptr null, ptr %v7, align 8
  %v8 = alloca ptr, align 8
  store ptr null, ptr %v8, align 8
  %v9 = alloca ptr, align 8
  store ptr null, ptr %v9, align 8
  %v10 = alloca ptr, align 8
  store ptr null, ptr %v10, align 8
  %v11 = alloca ptr, align 8
  store ptr null, ptr %v11, align 8
  %v12 = alloca ptr, align 8
  store ptr null, ptr %v12, align 8
  %v13 = alloca ptr, align 8
  store ptr null, ptr %v13, align 8
  %v14 = alloca ptr, align 8
  store ptr null, ptr %v14, align 8
  %v15 = alloca ptr, align 8
  store ptr null, ptr %v15, align 8
  %v16 = alloca ptr, align 8
  store ptr null, ptr %v16, align 8
  %v17 = alloca ptr, align 8
  store ptr null, ptr %v17, align 8
  %v18 = alloca ptr, align 8
  store ptr null, ptr %v18, align 8
  %v19 = alloca ptr, align 8
  store ptr null, ptr %v19, align 8
  %v20 = alloca ptr, align 8
  store ptr null, ptr %v20, align 8
  %v21 = alloca ptr, align 8
  store ptr null, ptr %v21, align 8
  %v22 = alloca ptr, align 8
  store ptr null, ptr %v22, align 8
  %v23 = alloca ptr, align 8
  store ptr null, ptr %v23, align 8
  %r1 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r1, align 8
  %r2 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r2, align 8
  %r3 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r3, align 8
  %r4 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r4, align 8
  %r5 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r5, align 8
  %r6 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r6, align 8
  %r7 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r7, align 8
  %r8 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r8, align 8
  %r9 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r9, align 8
  %r10 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r10, align 8
  %r11 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r11, align 8
  %r12 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r12, align 8
  %r13 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r13, align 8
  %r14 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r14, align 8
  %r15 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r15, align 8
  %r16 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r16, align 8
  %r17 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r17, align 8
  %r18 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r18, align 8
  %r19 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r19, align 8
  %r20 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r20, align 8
  %r21 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r21, align 8
  %r22 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r22, align 8
  %r23 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r23, align 8
  %args9 = alloca [1 x ptr], align 8
  %args12 = alloca [1 x ptr], align 8
  %args15 = alloca [1 x ptr], align 8
  %args18 = alloca [1 x ptr], align 8
  %args19 = alloca [4 x ptr], align 8
  %args20 = alloca [1 x ptr], align 8
  %args21 = alloca [1 x ptr], align 8
  %args22 = alloca [1 x ptr], align 8
  %args23 = alloca [1 x ptr], align 8
  store %lo.result zeroinitializer, ptr %out, align 8
  br label %b0
b0:
  %x1 = icmp eq i64 %argc, 0, !dbg !8
  br i1 %x1, label %b4, label %b5, !dbg !8
b1:
  %x2 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x2), !dbg !8
  store ptr null, ptr %v1, align 8, !dbg !8
  %x3 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x3), !dbg !8
  store ptr null, ptr %v2, align 8, !dbg !8
  %x4 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x4), !dbg !8
  store ptr null, ptr %v3, align 8, !dbg !8
  %x5 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x5), !dbg !8
  store ptr null, ptr %v4, align 8, !dbg !8
  %x6 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x6), !dbg !8
  store ptr null, ptr %v5, align 8, !dbg !8
  %x7 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x7), !dbg !8
  store ptr null, ptr %v6, align 8, !dbg !8
  %x8 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x8), !dbg !8
  store ptr null, ptr %v7, align 8, !dbg !8
  %x9 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x9), !dbg !8
  store ptr null, ptr %v8, align 8, !dbg !8
  %x10 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x10), !dbg !8
  store ptr null, ptr %v9, align 8, !dbg !8
  %x11 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x11), !dbg !8
  store ptr null, ptr %v10, align 8, !dbg !8
  %x12 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x12), !dbg !8
  store ptr null, ptr %v11, align 8, !dbg !8
  %x13 = load ptr, ptr %v12, align 8
  call void @lo_value_release(ptr %x13), !dbg !8
  store ptr null, ptr %v12, align 8, !dbg !8
  %x14 = load ptr, ptr %v13, align 8
  call void @lo_value_release(ptr %x14), !dbg !8
  store ptr null, ptr %v13, align 8, !dbg !8
  %x15 = load ptr, ptr %v14, align 8
  call void @lo_value_release(ptr %x15), !dbg !8
  store ptr null, ptr %v14, align 8, !dbg !8
  %x16 = load ptr, ptr %v15, align 8
  call void @lo_value_release(ptr %x16), !dbg !8
  store ptr null, ptr %v15, align 8, !dbg !8
  %x17 = load ptr, ptr %v16, align 8
  call void @lo_value_release(ptr %x17), !dbg !8
  store ptr null, ptr %v16, align 8, !dbg !8
  %x18 = load ptr, ptr %v17, align 8
  call void @lo_value_release(ptr %x18), !dbg !8
  store ptr null, ptr %v17, align 8, !dbg !8
  %x19 = load ptr, ptr %v18, align 8
  call void @lo_value_release(ptr %x19), !dbg !8
  store ptr null, ptr %v18, align 8, !dbg !8
  %x20 = load ptr, ptr %v19, align 8
  call void @lo_value_release(ptr %x20), !dbg !8
  store ptr null, ptr %v19, align 8, !dbg !8
  %x21 = load ptr, ptr %v20, align 8
  call void @lo_value_release(ptr %x21), !dbg !8
  store ptr null, ptr %v20, align 8, !dbg !8
  %x22 = load ptr, ptr %v21, align 8
  call void @lo_value_release(ptr %x22), !dbg !8
  store ptr null, ptr %v21, align 8, !dbg !8
  %x23 = load ptr, ptr %v22, align 8
  call void @lo_value_release(ptr %x23), !dbg !8
  store ptr null, ptr %v22, align 8, !dbg !8
  %x24 = load ptr, ptr %v23, align 8
  call void @lo_value_release(ptr %x24), !dbg !8
  store ptr null, ptr %v23, align 8, !dbg !8
  ret void, !dbg !8
b2:
  br label %b1, !dbg !8
b3:
  %x25 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x26 = load ptr, ptr %x25, align 8
  call void @lo_scope_leave(ptr %context, ptr %x26, i64 0), !dbg !8
  %x27 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x27), !dbg !8
  store ptr null, ptr %v1, align 8, !dbg !8
  %x28 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x28), !dbg !8
  store ptr null, ptr %v2, align 8, !dbg !8
  %x29 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x29), !dbg !8
  store ptr null, ptr %v3, align 8, !dbg !8
  %x30 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x30), !dbg !8
  store ptr null, ptr %v4, align 8, !dbg !8
  %x31 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x31), !dbg !8
  store ptr null, ptr %v5, align 8, !dbg !8
  %x32 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x32), !dbg !8
  store ptr null, ptr %v6, align 8, !dbg !8
  %x33 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x33), !dbg !8
  store ptr null, ptr %v7, align 8, !dbg !8
  %x34 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x34), !dbg !8
  store ptr null, ptr %v8, align 8, !dbg !8
  %x35 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x35), !dbg !8
  store ptr null, ptr %v9, align 8, !dbg !8
  %x36 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x36), !dbg !8
  store ptr null, ptr %v10, align 8, !dbg !8
  %x37 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x37), !dbg !8
  store ptr null, ptr %v11, align 8, !dbg !8
  %x38 = load ptr, ptr %v12, align 8
  call void @lo_value_release(ptr %x38), !dbg !8
  store ptr null, ptr %v12, align 8, !dbg !8
  %x39 = load ptr, ptr %v13, align 8
  call void @lo_value_release(ptr %x39), !dbg !8
  store ptr null, ptr %v13, align 8, !dbg !8
  %x40 = load ptr, ptr %v14, align 8
  call void @lo_value_release(ptr %x40), !dbg !8
  store ptr null, ptr %v14, align 8, !dbg !8
  %x41 = load ptr, ptr %v15, align 8
  call void @lo_value_release(ptr %x41), !dbg !8
  store ptr null, ptr %v15, align 8, !dbg !8
  %x42 = load ptr, ptr %v16, align 8
  call void @lo_value_release(ptr %x42), !dbg !8
  store ptr null, ptr %v16, align 8, !dbg !8
  %x43 = load ptr, ptr %v17, align 8
  call void @lo_value_release(ptr %x43), !dbg !8
  store ptr null, ptr %v17, align 8, !dbg !8
  %x44 = load ptr, ptr %v18, align 8
  call void @lo_value_release(ptr %x44), !dbg !8
  store ptr null, ptr %v18, align 8, !dbg !8
  %x45 = load ptr, ptr %v19, align 8
  call void @lo_value_release(ptr %x45), !dbg !8
  store ptr null, ptr %v19, align 8, !dbg !8
  %x46 = load ptr, ptr %v20, align 8
  call void @lo_value_release(ptr %x46), !dbg !8
  store ptr null, ptr %v20, align 8, !dbg !8
  %x47 = load ptr, ptr %v21, align 8
  call void @lo_value_release(ptr %x47), !dbg !8
  store ptr null, ptr %v21, align 8, !dbg !8
  %x48 = load ptr, ptr %v22, align 8
  call void @lo_value_release(ptr %x48), !dbg !8
  store ptr null, ptr %v22, align 8, !dbg !8
  %x49 = load ptr, ptr %v23, align 8
  call void @lo_value_release(ptr %x49), !dbg !8
  store ptr null, ptr %v23, align 8, !dbg !8
  br label %b1, !dbg !8
b4:
  call void @lo_scope_enter(ptr %context, ptr null, i64 0, i64 1, ptr %r2), !dbg !10
  %x50 = getelementptr %lo.result, ptr %r2, i32 0, i32 0
  %x51 = load i32, ptr %x50, align 4, !dbg !10
  switch i32 %x51, label %b5 [ i32 0, label %b6 i32 1, label %b5 i32 2, label %b7 ], !dbg !10
b5:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 0, ptr %r1), !dbg !8
  call void @lo_result_copy_host(ptr %out, ptr %r1), !dbg !8
  br label %b1, !dbg !8
b6:
  %x52 = getelementptr %lo.result, ptr %r2, i32 0, i32 2
  %x53 = load ptr, ptr %x52, align 8
  store ptr %x53, ptr %v2, align 8, !dbg !10
  call void @lo_step(ptr %context, ptr null, i64 0, i64 2, ptr %r3), !dbg !12
  %x54 = getelementptr %lo.result, ptr %r3, i32 0, i32 0
  %x55 = load i32, ptr %x54, align 4, !dbg !12
  switch i32 %x55, label %b14 [ i32 0, label %b10 i32 1, label %b14 i32 2, label %b11 ], !dbg !12
b7:
  %x56 = call i1 @lo_result_transfer(ptr %out, ptr %r2, ptr %v2), !dbg !8
  br i1 %x56, label %b1, label %b5, !dbg !8
b10:
  %x57 = getelementptr %lo.result, ptr %r3, i32 0, i32 2
  %x58 = load ptr, ptr %x57, align 8
  store ptr %x58, ptr %v3, align 8, !dbg !12
  call void @lo_step(ptr %context, ptr null, i64 0, i64 3, ptr %r5), !dbg !14
  %x59 = getelementptr %lo.result, ptr %r5, i32 0, i32 0
  %x60 = load i32, ptr %x59, align 4, !dbg !14
  switch i32 %x60, label %b14 [ i32 0, label %b15 i32 1, label %b14 i32 2, label %b16 ], !dbg !14
b11:
  %x61 = call i1 @lo_result_transfer(ptr %out, ptr %r3, ptr %v3), !dbg !8
  br i1 %x61, label %b3, label %b14, !dbg !8
b14:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 0, ptr %r4), !dbg !8
  call void @lo_result_copy_host(ptr %out, ptr %r4), !dbg !8
  br label %b3, !dbg !8
b15:
  %x62 = getelementptr %lo.result, ptr %r5, i32 0, i32 2
  %x63 = load ptr, ptr %x62, align 8
  store ptr %x63, ptr %v5, align 8, !dbg !14
  call void @lo_step(ptr %context, ptr null, i64 0, i64 4, ptr %r6), !dbg !16
  %x64 = getelementptr %lo.result, ptr %r6, i32 0, i32 0
  %x65 = load i32, ptr %x64, align 4, !dbg !16
  switch i32 %x65, label %b14 [ i32 0, label %b19 i32 1, label %b14 i32 2, label %b20 ], !dbg !16
b16:
  %x66 = call i1 @lo_result_transfer(ptr %out, ptr %r5, ptr %v5), !dbg !8
  br i1 %x66, label %b3, label %b14, !dbg !8
b19:
  %x67 = getelementptr %lo.result, ptr %r6, i32 0, i32 2
  %x68 = load ptr, ptr %x67, align 8
  store ptr %x68, ptr %v6, align 8, !dbg !16
  call void @lo_step(ptr %context, ptr null, i64 0, i64 5, ptr %r7), !dbg !18
  %x69 = getelementptr %lo.result, ptr %r7, i32 0, i32 0
  %x70 = load i32, ptr %x69, align 4, !dbg !18
  switch i32 %x70, label %b14 [ i32 0, label %b23 i32 1, label %b14 i32 2, label %b24 ], !dbg !18
b20:
  %x71 = call i1 @lo_result_transfer(ptr %out, ptr %r6, ptr %v6), !dbg !8
  br i1 %x71, label %b3, label %b14, !dbg !8
b23:
  %x72 = getelementptr %lo.result, ptr %r7, i32 0, i32 2
  %x73 = load ptr, ptr %x72, align 8
  store ptr %x73, ptr %v7, align 8, !dbg !18
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 6, ptr %r8), !dbg !20
  %x74 = getelementptr %lo.result, ptr %r8, i32 0, i32 0
  %x75 = load i32, ptr %x74, align 4, !dbg !20
  switch i32 %x75, label %b14 [ i32 0, label %b27 i32 1, label %b14 i32 2, label %b28 ], !dbg !20
b24:
  %x76 = call i1 @lo_result_transfer(ptr %out, ptr %r7, ptr %v7), !dbg !8
  br i1 %x76, label %b3, label %b14, !dbg !8
b27:
  %x77 = getelementptr %lo.result, ptr %r8, i32 0, i32 2
  %x78 = load ptr, ptr %x77, align 8
  store ptr %x78, ptr %v8, align 8, !dbg !20
  %x80 = load ptr, ptr %v8, align 8
  %x79 = getelementptr [1 x ptr], ptr %args9, i64 0, i64 0, !dbg !22
  store ptr %x80, ptr %x79, align 8, !dbg !22
  call void @lo_charge_value(ptr %context, ptr %args9, i64 1, i64 7, ptr %r9), !dbg !22
  %x81 = getelementptr %lo.result, ptr %r9, i32 0, i32 0
  %x82 = load i32, ptr %x81, align 4, !dbg !22
  switch i32 %x82, label %b14 [ i32 0, label %b31 i32 1, label %b14 i32 2, label %b32 ], !dbg !22
b28:
  %x83 = call i1 @lo_result_transfer(ptr %out, ptr %r8, ptr %v8), !dbg !8
  br i1 %x83, label %b3, label %b14, !dbg !8
b31:
  %x84 = getelementptr %lo.result, ptr %r9, i32 0, i32 2
  %x85 = load ptr, ptr %x84, align 8
  store ptr %x85, ptr %v9, align 8, !dbg !22
  call void @lo_step(ptr %context, ptr null, i64 0, i64 8, ptr %r10), !dbg !24
  %x86 = getelementptr %lo.result, ptr %r10, i32 0, i32 0
  %x87 = load i32, ptr %x86, align 4, !dbg !24
  switch i32 %x87, label %b14 [ i32 0, label %b35 i32 1, label %b14 i32 2, label %b36 ], !dbg !24
b32:
  %x88 = call i1 @lo_result_transfer(ptr %out, ptr %r9, ptr %v9), !dbg !8
  br i1 %x88, label %b3, label %b14, !dbg !8
b35:
  %x89 = getelementptr %lo.result, ptr %r10, i32 0, i32 2
  %x90 = load ptr, ptr %x89, align 8
  store ptr %x90, ptr %v10, align 8, !dbg !24
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 9, ptr %r11), !dbg !26
  %x91 = getelementptr %lo.result, ptr %r11, i32 0, i32 0
  %x92 = load i32, ptr %x91, align 4, !dbg !26
  switch i32 %x92, label %b14 [ i32 0, label %b39 i32 1, label %b14 i32 2, label %b40 ], !dbg !26
b36:
  %x93 = call i1 @lo_result_transfer(ptr %out, ptr %r10, ptr %v10), !dbg !8
  br i1 %x93, label %b3, label %b14, !dbg !8
b39:
  %x94 = getelementptr %lo.result, ptr %r11, i32 0, i32 2
  %x95 = load ptr, ptr %x94, align 8
  store ptr %x95, ptr %v11, align 8, !dbg !26
  %x97 = load ptr, ptr %v11, align 8
  %x96 = getelementptr [1 x ptr], ptr %args12, i64 0, i64 0, !dbg !28
  store ptr %x97, ptr %x96, align 8, !dbg !28
  call void @lo_charge_value(ptr %context, ptr %args12, i64 1, i64 10, ptr %r12), !dbg !28
  %x98 = getelementptr %lo.result, ptr %r12, i32 0, i32 0
  %x99 = load i32, ptr %x98, align 4, !dbg !28
  switch i32 %x99, label %b14 [ i32 0, label %b43 i32 1, label %b14 i32 2, label %b44 ], !dbg !28
b40:
  %x100 = call i1 @lo_result_transfer(ptr %out, ptr %r11, ptr %v11), !dbg !8
  br i1 %x100, label %b3, label %b14, !dbg !8
b43:
  %x101 = getelementptr %lo.result, ptr %r12, i32 0, i32 2
  %x102 = load ptr, ptr %x101, align 8
  store ptr %x102, ptr %v12, align 8, !dbg !28
  call void @lo_step(ptr %context, ptr null, i64 0, i64 11, ptr %r13), !dbg !30
  %x103 = getelementptr %lo.result, ptr %r13, i32 0, i32 0
  %x104 = load i32, ptr %x103, align 4, !dbg !30
  switch i32 %x104, label %b14 [ i32 0, label %b47 i32 1, label %b14 i32 2, label %b48 ], !dbg !30
b44:
  %x105 = call i1 @lo_result_transfer(ptr %out, ptr %r12, ptr %v12), !dbg !8
  br i1 %x105, label %b3, label %b14, !dbg !8
b47:
  %x106 = getelementptr %lo.result, ptr %r13, i32 0, i32 2
  %x107 = load ptr, ptr %x106, align 8
  store ptr %x107, ptr %v13, align 8, !dbg !30
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 12, ptr %r14), !dbg !32
  %x108 = getelementptr %lo.result, ptr %r14, i32 0, i32 0
  %x109 = load i32, ptr %x108, align 4, !dbg !32
  switch i32 %x109, label %b14 [ i32 0, label %b51 i32 1, label %b14 i32 2, label %b52 ], !dbg !32
b48:
  %x110 = call i1 @lo_result_transfer(ptr %out, ptr %r13, ptr %v13), !dbg !8
  br i1 %x110, label %b3, label %b14, !dbg !8
b51:
  %x111 = getelementptr %lo.result, ptr %r14, i32 0, i32 2
  %x112 = load ptr, ptr %x111, align 8
  store ptr %x112, ptr %v14, align 8, !dbg !32
  %x114 = load ptr, ptr %v14, align 8
  %x113 = getelementptr [1 x ptr], ptr %args15, i64 0, i64 0, !dbg !34
  store ptr %x114, ptr %x113, align 8, !dbg !34
  call void @lo_charge_value(ptr %context, ptr %args15, i64 1, i64 13, ptr %r15), !dbg !34
  %x115 = getelementptr %lo.result, ptr %r15, i32 0, i32 0
  %x116 = load i32, ptr %x115, align 4, !dbg !34
  switch i32 %x116, label %b14 [ i32 0, label %b55 i32 1, label %b14 i32 2, label %b56 ], !dbg !34
b52:
  %x117 = call i1 @lo_result_transfer(ptr %out, ptr %r14, ptr %v14), !dbg !8
  br i1 %x117, label %b3, label %b14, !dbg !8
b55:
  %x118 = getelementptr %lo.result, ptr %r15, i32 0, i32 2
  %x119 = load ptr, ptr %x118, align 8
  store ptr %x119, ptr %v15, align 8, !dbg !34
  call void @lo_step(ptr %context, ptr null, i64 0, i64 14, ptr %r16), !dbg !36
  %x120 = getelementptr %lo.result, ptr %r16, i32 0, i32 0
  %x121 = load i32, ptr %x120, align 4, !dbg !36
  switch i32 %x121, label %b14 [ i32 0, label %b59 i32 1, label %b14 i32 2, label %b60 ], !dbg !36
b56:
  %x122 = call i1 @lo_result_transfer(ptr %out, ptr %r15, ptr %v15), !dbg !8
  br i1 %x122, label %b3, label %b14, !dbg !8
b59:
  %x123 = getelementptr %lo.result, ptr %r16, i32 0, i32 2
  %x124 = load ptr, ptr %x123, align 8
  store ptr %x124, ptr %v16, align 8, !dbg !36
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 15, ptr %r17), !dbg !38
  %x125 = getelementptr %lo.result, ptr %r17, i32 0, i32 0
  %x126 = load i32, ptr %x125, align 4, !dbg !38
  switch i32 %x126, label %b14 [ i32 0, label %b63 i32 1, label %b14 i32 2, label %b64 ], !dbg !38
b60:
  %x127 = call i1 @lo_result_transfer(ptr %out, ptr %r16, ptr %v16), !dbg !8
  br i1 %x127, label %b3, label %b14, !dbg !8
b63:
  %x128 = getelementptr %lo.result, ptr %r17, i32 0, i32 2
  %x129 = load ptr, ptr %x128, align 8
  store ptr %x129, ptr %v17, align 8, !dbg !38
  %x131 = load ptr, ptr %v17, align 8
  %x130 = getelementptr [1 x ptr], ptr %args18, i64 0, i64 0, !dbg !40
  store ptr %x131, ptr %x130, align 8, !dbg !40
  call void @lo_charge_value(ptr %context, ptr %args18, i64 1, i64 16, ptr %r18), !dbg !40
  %x132 = getelementptr %lo.result, ptr %r18, i32 0, i32 0
  %x133 = load i32, ptr %x132, align 4, !dbg !40
  switch i32 %x133, label %b14 [ i32 0, label %b67 i32 1, label %b14 i32 2, label %b68 ], !dbg !40
b64:
  %x134 = call i1 @lo_result_transfer(ptr %out, ptr %r17, ptr %v17), !dbg !8
  br i1 %x134, label %b3, label %b14, !dbg !8
b67:
  %x135 = getelementptr %lo.result, ptr %r18, i32 0, i32 2
  %x136 = load ptr, ptr %x135, align 8
  store ptr %x136, ptr %v18, align 8, !dbg !40
  %x138 = load ptr, ptr %v8, align 8
  %x137 = getelementptr [4 x ptr], ptr %args19, i64 0, i64 0, !dbg !42
  store ptr %x138, ptr %x137, align 8, !dbg !42
  %x140 = load ptr, ptr %v11, align 8
  %x139 = getelementptr [4 x ptr], ptr %args19, i64 0, i64 1, !dbg !42
  store ptr %x140, ptr %x139, align 8, !dbg !42
  %x142 = load ptr, ptr %v14, align 8
  %x141 = getelementptr [4 x ptr], ptr %args19, i64 0, i64 2, !dbg !42
  store ptr %x142, ptr %x141, align 8, !dbg !42
  %x144 = load ptr, ptr %v17, align 8
  %x143 = getelementptr [4 x ptr], ptr %args19, i64 0, i64 3, !dbg !42
  store ptr %x144, ptr %x143, align 8, !dbg !42
  call void @lo_op_List_2Enew(ptr %context, ptr %args19, i64 4, i64 17, ptr %r19), !dbg !42
  %x145 = getelementptr %lo.result, ptr %r19, i32 0, i32 0
  %x146 = load i32, ptr %x145, align 4, !dbg !42
  switch i32 %x146, label %b14 [ i32 0, label %b71 i32 1, label %b14 i32 2, label %b72 ], !dbg !42
b68:
  %x147 = call i1 @lo_result_transfer(ptr %out, ptr %r18, ptr %v18), !dbg !8
  br i1 %x147, label %b3, label %b14, !dbg !8
b71:
  %x148 = getelementptr %lo.result, ptr %r19, i32 0, i32 2
  %x149 = load ptr, ptr %x148, align 8
  store ptr %x149, ptr %v19, align 8, !dbg !42
  %x151 = load ptr, ptr %v19, align 8
  %x150 = getelementptr [1 x ptr], ptr %args20, i64 0, i64 0, !dbg !44
  store ptr %x151, ptr %x150, align 8, !dbg !44
  call void @lo_charge_value(ptr %context, ptr %args20, i64 1, i64 18, ptr %r20), !dbg !44
  %x152 = getelementptr %lo.result, ptr %r20, i32 0, i32 0
  %x153 = load i32, ptr %x152, align 4, !dbg !44
  switch i32 %x153, label %b14 [ i32 0, label %b75 i32 1, label %b14 i32 2, label %b76 ], !dbg !44
b72:
  %x154 = call i1 @lo_result_transfer(ptr %out, ptr %r19, ptr %v19), !dbg !8
  br i1 %x154, label %b3, label %b14, !dbg !8
b75:
  %x155 = getelementptr %lo.result, ptr %r20, i32 0, i32 2
  %x156 = load ptr, ptr %x155, align 8
  store ptr %x156, ptr %v20, align 8, !dbg !44
  %x158 = load ptr, ptr %v19, align 8
  %x157 = getelementptr [1 x ptr], ptr %args21, i64 0, i64 0, !dbg !46
  store ptr %x158, ptr %x157, align 8, !dbg !46
  call void @lo_op_Math_2Esum(ptr %context, ptr %args21, i64 1, i64 19, ptr %r21), !dbg !46
  %x159 = getelementptr %lo.result, ptr %r21, i32 0, i32 0
  %x160 = load i32, ptr %x159, align 4, !dbg !46
  switch i32 %x160, label %b14 [ i32 0, label %b79 i32 1, label %b14 i32 2, label %b80 ], !dbg !46
b76:
  %x161 = call i1 @lo_result_transfer(ptr %out, ptr %r20, ptr %v20), !dbg !8
  br i1 %x161, label %b3, label %b14, !dbg !8
b79:
  %x162 = getelementptr %lo.result, ptr %r21, i32 0, i32 2
  %x163 = load ptr, ptr %x162, align 8
  store ptr %x163, ptr %v21, align 8, !dbg !46
  %x165 = load ptr, ptr %v21, align 8
  %x164 = getelementptr [1 x ptr], ptr %args22, i64 0, i64 0, !dbg !48
  store ptr %x165, ptr %x164, align 8, !dbg !48
  call void @lo_charge_value(ptr %context, ptr %args22, i64 1, i64 20, ptr %r22), !dbg !48
  %x166 = getelementptr %lo.result, ptr %r22, i32 0, i32 0
  %x167 = load i32, ptr %x166, align 4, !dbg !48
  switch i32 %x167, label %b14 [ i32 0, label %b83 i32 1, label %b14 i32 2, label %b84 ], !dbg !48
b80:
  %x168 = call i1 @lo_result_transfer(ptr %out, ptr %r21, ptr %v21), !dbg !8
  br i1 %x168, label %b3, label %b14, !dbg !8
b83:
  %x169 = getelementptr %lo.result, ptr %r22, i32 0, i32 2
  %x170 = load ptr, ptr %x169, align 8
  store ptr %x170, ptr %v22, align 8, !dbg !48
  %x172 = load ptr, ptr %v21, align 8
  %x171 = getelementptr [1 x ptr], ptr %args23, i64 0, i64 0, !dbg !50
  store ptr %x172, ptr %x171, align 8, !dbg !50
  call void @lo_cause(ptr %context, ptr %args23, i64 1, i64 21, ptr %r23), !dbg !50
  %x173 = getelementptr %lo.result, ptr %r23, i32 0, i32 0
  %x174 = load i32, ptr %x173, align 4, !dbg !50
  switch i32 %x174, label %b14 [ i32 0, label %b87 i32 1, label %b87 i32 2, label %b87 ], !dbg !50
b84:
  %x175 = call i1 @lo_result_transfer(ptr %out, ptr %r22, ptr %v22), !dbg !8
  br i1 %x175, label %b3, label %b14, !dbg !8
b87:
  %x176 = call i1 @lo_result_transfer(ptr %out, ptr %r23, ptr %v23), !dbg !8
  br i1 %x176, label %b3, label %b14, !dbg !8
}

attributes #0 = { noinline "fp-contract"="off" "frame-pointer"="all" }
attributes #1 = { noinline optnone "fp-contract"="off" "frame-pointer"="all" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3}
!0 = distinct !DICompileUnit(language: DW_LANG_C, file: !1, producer: "Lo lo-native-1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)
!1 = !DIFile(filename: "source.lo", directory: "/Users/tyemirov/Development/Research/Lo/_scratch/i011-20261020/completion-20261022/continuation/campaign/darwin-execution/execution/list_sum")
!2 = !{i32 2, !"Dwarf Version", i32 4}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !DISubroutineType(types: !5)
!5 = !{null}
!6 = distinct !DISubprogram(name: "<top>", linkageName: "lo_entry", scope: !1, file: !1, line: 1, type: !4, scopeLine: 1, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!8 = !DILocation(line: 1, column: 1, scope: !7)
!9 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!10 = !DILocation(line: 1, column: 1, scope: !9)
!11 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!12 = !DILocation(line: 1, column: 1, scope: !11)
!13 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!14 = !DILocation(line: 1, column: 8, scope: !13)
!15 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!16 = !DILocation(line: 1, column: 17, scope: !15)
!17 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!18 = !DILocation(line: 1, column: 26, scope: !17)
!19 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!20 = !DILocation(line: 1, column: 26, scope: !19)
!21 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!22 = !DILocation(line: 1, column: 26, scope: !21)
!23 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!24 = !DILocation(line: 1, column: 28, scope: !23)
!25 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!26 = !DILocation(line: 1, column: 28, scope: !25)
!27 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!28 = !DILocation(line: 1, column: 28, scope: !27)
!29 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!30 = !DILocation(line: 1, column: 30, scope: !29)
!31 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!32 = !DILocation(line: 1, column: 30, scope: !31)
!33 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!34 = !DILocation(line: 1, column: 30, scope: !33)
!35 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!36 = !DILocation(line: 1, column: 32, scope: !35)
!37 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!38 = !DILocation(line: 1, column: 32, scope: !37)
!39 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!40 = !DILocation(line: 1, column: 32, scope: !39)
!41 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!42 = !DILocation(line: 1, column: 17, scope: !41)
!43 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!44 = !DILocation(line: 1, column: 17, scope: !43)
!45 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!46 = !DILocation(line: 1, column: 8, scope: !45)
!47 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!48 = !DILocation(line: 1, column: 8, scope: !47)
!49 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!50 = !DILocation(line: 1, column: 1, scope: !49)
