.PHONY: i011-completion-guest-check
i011-completion-guest-check: | tool-state
	LO_NATIVE_PREPARATION="$(abspath _scratch/native-runtime)" UV_NO_CONFIG=1 uv run --offline --with pytest==8.3.5 python -B -m pytest -p no:cacheprovider --basetemp "$(abspath _scratch/i011-20261020/completion-20261022/guest-tests)" -q tools/loqualification/test_batch.py -k reaps_detached </dev/null

.PHONY: i011-completion-reader-packages
i011-completion-reader-packages: | tool-state
	$(MAKE) --no-print-directory package-compiler-distributions NATIVE_RUNTIME_OUTPUT="$(abspath _scratch/i011-20261020/completion-20261022/reader-runtime)" COMPILER_DISTRIBUTION_OUTPUT=bin/distributions-i011-20261022 </dev/null

.PHONY: i011-completion-reader-focused
i011-completion-reader-focused: | tool-state
	LO_TEST_BACKEND=llvm LO_TEST_COMPILER="$(CURDIR)/bin/distributions-i011-20261022/lo-darwin-arm64-metal/bin/lo" LO_LLVM_TOOLCHAIN="$(CURDIR)/bin/distributions-i011-20261022/lo-darwin-arm64-metal/toolchain.json" $(GO) test -count=1 -json -timeout=15m ./tests/integration -run '^TestLLVMHTTP(KeepAlivePipelining|ServerRequestFraming|SharedRequestDeadline|ClientCancellation|ChunkLengthGrammar|ResponseFraming)$$' </dev/null
	python3 -B tools/loqualification/suite.py --preparation _scratch/native-runtime --package bin/distributions-i011-20261022/lo-linux-arm64-software --matrix testdata/semantic-migration/matrix.json --work _scratch/i011-20261020/completion-20261022/reader-focused-linux --go "$(shell command -v $(GO))" --accelerator hvf --pattern '^TestLLVMHTTP(KeepAlivePipelining|ServerRequestFraming|SharedRequestDeadline|ClientCancellation|ChunkLengthGrammar|ResponseFraming)$$' </dev/null

.PHONY: i011-completion-strict-report
i011-completion-strict-report: | tool-state
	python3 -B tools/semanticcoverage/report.py --interpreter _scratch/i011-20261020/completion-20261022/final/corpus/darwin/interpreter.jsonl --llvm darwin/arm64=_scratch/i011-20261020/completion-20261022/final/corpus/darwin/llvm.jsonl --llvm linux/arm64=_scratch/i011-20261020/completion-20261022/final/corpus/linux/semantic-linux-arm64.jsonl --output _scratch/i011-20261020/completion-20261022/final/semantic-report.json </dev/null
