"""Run the fixed two-case register allocator diagnostic; never qualification."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import threading
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[4]
BASE = Path(__file__).resolve().parent
PACKAGE = ROOT / 'bin/distributions-i011-20261022/lo-darwin-arm64-software'
WORK = BASE / 'fast-allocator'
CASES = ('records_10000', 'map_10000')
EXPECTED = {'records_10000': '499961', 'map_10000': '1499883'}
EMISSION_NS = {'records_10000': 11380030917, 'map_10000': 10586642833}
BUILD_NS = 180_000_000_000
EXECUTION_SECONDS = 30
SAMPLE_SECONDS = 0.05
STREAM_BYTES = 1 << 20
PS_COMMAND = ['/bin/ps', '-axo', 'pid=,ppid=,rss=']
sys.path.insert(0, str(ROOT / 'tools/nativebench'))
import campaign


def local(path: Path) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(ROOT):
        raise ValueError('path crosses Lo boundary: ' + str(path))
    return path


def digest(path: Path) -> str:
    return campaign.sha(local(path))


def receipt(path: Path) -> dict[str, Any]:
    return {'path': str(local(path).relative_to(ROOT)), 'sha256': digest(path),
            'bytes': path.stat().st_size}


def save(path: Path, value: dict[str, Any]) -> None:
    local(path)
    campaign.save(path, value)


class Wait4Process(subprocess.Popen[bytes]):
    """One wait4 owner retains direct-child CPU accounting during group cleanup."""
    def __init__(self, argv: list[str], **kwargs: Any) -> None:
        self.reaped = threading.Event()
        self.usage: Any = None
        self.reap_error: BaseException | None = None
        super().__init__(argv, **kwargs)
        threading.Thread(target=self.collect, daemon=True).start()

    def collect(self) -> None:
        try:
            _, status, self.usage = os.wait4(self.pid, 0)
            self.returncode = os.waitstatus_to_exitcode(status)
        except BaseException as error:
            self.reap_error = error
        finally:
            self.reaped.set()

    def poll(self) -> int | None:
        if self.reap_error is not None:
            raise ValueError('wait4 failed') from self.reap_error
        return self.returncode

    def wait(self, timeout: float | None = None) -> int:
        if not self.reaped.wait(timeout):
            raise subprocess.TimeoutExpired(self.args, timeout)
        if self.reap_error is not None:
            raise ValueError('wait4 failed') from self.reap_error
        assert self.returncode is not None
        return self.returncode


def sampled_rss(pid: int, deadline: float) -> int:
    """Bound each process-table observation by time, bytes, and owned cleanup."""
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        return 0
    sampler = subprocess.Popen(PS_COMMAND, cwd=ROOT, env=dict(os.environ, CI='1', LC_ALL='C'),
                               stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    selector = selectors.DefaultSelector()
    data: dict[str, bytearray] = {'stdout': bytearray(), 'stderr': bytearray()}
    sample_deadline = time.monotonic() + min(0.5, remaining)
    try:
        for label, pipe in [('stdout', sampler.stdout), ('stderr', sampler.stderr)]:
            assert pipe is not None
            os.set_blocking(pipe.fileno(), False)
            selector.register(pipe, selectors.EVENT_READ, label)
        while selector.get_map():
            if time.monotonic() >= sample_deadline:
                raise ValueError('RSS process inventory exceeded its deadline')
            for key, _ in selector.select(min(0.01, max(0, sample_deadline-time.monotonic()))):
                chunk = os.read(key.fileobj.fileno(), 65536)
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                if sum(len(value) for value in data.values()) + len(chunk) > STREAM_BYTES:
                    raise ValueError('RSS process inventory exceeded 1 MiB')
                data[key.data].extend(chunk)
        status = sampler.wait(timeout=max(0.001, sample_deadline-time.monotonic()))
        if status or data['stderr'] or not data['stdout']:
            raise ValueError('RSS process inventory failed')
        rows = [tuple(map(int, line.split())) for line in data['stdout'].decode('ascii').splitlines()]
        if any(len(row) != 3 or any(value < 0 for value in row) for row in rows):
            raise ValueError('RSS process inventory has invalid PID/PPID/RSS columns')
        if len({row[0] for row in rows}) != len(rows):
            raise ValueError('RSS process inventory contains duplicate PIDs')
        owned = {pid}
        while True:
            descendants = {child for child, parent, _ in rows if parent in owned}
            if descendants <= owned:
                break
            owned |= descendants
        return sum(size*1024 for child, _, size in rows if child in owned)
    finally:
        selector.close()
        for pipe in (sampler.stdout, sampler.stderr):
            if pipe is not None:
                pipe.close()
        campaign.stop(sampler)


def main() -> int:
    local(WORK)
    if WORK.exists():
        raise ValueError('fast-allocator output exists; overwrite and retries prohibited')
    manifest_path = local(PACKAGE / 'toolchain.json')
    manifest = json.loads(manifest_path.read_text())
    target = manifest['targets']['darwin/arm64']
    compiler = local(PACKAGE / manifest['compiler']['path'])
    linker = local(PACKAGE / target['linker']['path'])
    runtime = local(PACKAGE / target['runtime']['path'])
    original = {name: BASE / ('baseline' if name == 'records_10000' else 'map-continuation')
                for name in CASES}
    designs = {name: json.loads(local(original[name] / 'design.json').read_text()) for name in CASES}
    reports = {name: json.loads(local(original[name] / 'report.json').read_text()) for name in CASES}
    if any(designs[name]['expected'] != EXPECTED for name in CASES):
        raise ValueError('original expected results differ from the fixed experiment')
    spec = importlib.util.spec_from_file_location('fast_allocator_semantic_source',
                                                local(ROOT / 'tools/semanticcoverage/report.py'))
    assert spec is not None and spec.loader is not None
    source_module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = source_module
    spec.loader.exec_module(source_module)
    sources, source_hash = source_module.source_identity()
    for name in CASES:
        if designs[name]['manifest'] != manifest:
            raise ValueError('current package manifest differs from baseline: ' + name)
        for original_name, sha in designs[name]['files'].items():
            if digest(ROOT / original_name) != sha:
                raise ValueError('original baseline input changed: ' + original_name)
        if reports[name]['design_sha256'] != digest(original[name] / 'design.json'):
            raise ValueError('original report design digest differs: ' + name)
        if designs[name]['sources'] != sources or designs[name]['source_sha256'] != source_hash:
            raise ValueError('current source differs from baseline: ' + name)
    inventory_path = local(PACKAGE / 'inventory.json')
    inventory = json.loads(inventory_path.read_text())
    files = {str(local(PACKAGE / name).relative_to(ROOT)): sha
             for name, sha in inventory['files'].items()}
    for name, sha in files.items():
        if digest(ROOT / name) != sha:
            raise ValueError('package inventory mismatch: ' + name)
    reconciliation = json.loads(local(BASE / 'baseline-reconciliation.json').read_text())
    for field in ('original_driver', 'original_design', 'actual_result', 'canonical_schema_source'):
        item = reconciliation[field]
        if digest(ROOT / item['path']) != item['sha256']:
            raise ValueError('baseline reconciliation input changed: ' + field)
    if reconciliation['expected_result'] != {'command': 'run', 'status': 'ok',
            'result': {'type': 'Int', 'value': EXPECTED['records_10000']}}:
        raise ValueError('reconciled original records expectation differs')
    if reconciliation['actual_matches_predeclared_numeric_result'] is not True:
        raise ValueError('original records result was not reconciled')
    extra = [Path(__file__), BASE / 'fast-allocator.mk', ROOT / 'tools/nativebench/campaign.py',
             ROOT / 'tools/semanticcoverage/report.py', manifest_path, inventory_path,
             BASE / 'baseline-reconciliation.json', BASE / 'profile.py', BASE / 'profile-map.py',
             BASE / 'profile.mk', BASE / 'profile-map.mk', BASE / 'emitter-bin', BASE / 'emitter/main.go']
    extra.extend(ROOT / reconciliation[field]['path'] for field in
                 ('original_driver', 'original_design', 'actual_result', 'canonical_schema_source'))
    plans: list[dict[str, Any]] = []
    for name in CASES:
        record = next(record for record in reports[name]['records'] if record['case'] == name)
        emission = next(stage for stage in record['stages'] if stage['stage'] == 'emission')
        if emission['wall_ns'] != EMISSION_NS[name] or emission['status']:
            raise ValueError('original emission budget differs: ' + name)
        ir = local(original[name] / name / 'program.ll')
        if digest(ir) != record['ir']['sha256']:
            raise ValueError('original IR hash differs: ' + name)
        source = local(BASE.parent / 'continuation/campaign/darwin-build' / ('build_' + name + '.lo'))
        if digest(source) != record['emission']['source_sha256']:
            raise ValueError('original source hash differs: ' + name)
        directory = local(WORK / name)
        object_file, artifact = directory / 'program.o', directory / 'program'
        baseline_argv = next(stage for stage in record['stages'] if stage['stage'] == 'compile')['argv']
        replacements = {str(original[name] / name / 'program.o'): str(object_file),
                        '-ftime-trace=' + str(original[name] / name / 'time-trace.json'):
                        '-ftime-trace=' + str(directory / 'time-trace.json')}
        compile_argv = [replacements.get(arg, arg) for arg in baseline_argv] + ['-mllvm', '-regalloc=fast']
        canonical = [str(compiler), '-target', target['triple'], '-O2', '-g', '-fPIC',
                     '-ffp-contract=off', '-c', str(ir), '-o', str(object_file),
                     '-mmacosx-version-min=27.0', '-ftime-report=per-pass',
                     '-ftime-trace=' + str(directory / 'time-trace.json'), '-mllvm', '-regalloc=fast']
        if compile_argv != canonical:
            raise ValueError('baseline compilation flags differ from the fixed recipe: ' + name)
        substitutions = {'{object}': str(object_file), '{runtime}': str(runtime), '{output}': str(artifact),
                         **{'{input:'+key+'}': str(local(PACKAGE/value['path']))
                            for key, value in target['inputs'].items()}}
        link_argv = [str(linker), *[substitutions.get(arg, arg) for arg in target['link_args']],
                     '-oso_prefix', str(directory)+os.sep]
        plans.append({'case': name, 'expected': {'command': 'run', 'status': 'ok',
                       'result': {'type': 'Int', 'value': EXPECTED[name]}},
                      'baseline_emission_wall_ns': EMISSION_NS[name],
                      'remaining_compile_link_budget_ns': BUILD_NS - EMISSION_NS[name],
                      'ir': receipt(ir), 'baseline_compile_argv': baseline_argv,
                      'commands': {'compile': compile_argv, 'link': link_argv,
                                   'execute': [str(artifact), 'run', '--max-steps', '10000000', '--format', 'json']}})
        extra.extend([source, ir, original[name] / 'design.json', original[name] / 'report.json',
                      original[name] / name / 'compile.stderr', original[name] / name / 'time-trace.json'])
    for path in extra:
        files[str(local(path).relative_to(ROOT))] = digest(path)
    design = {'issue': 'I011', 'kind': 'instrumented_diagnostic_not_qualification',
              'qualification_claim': False, 'cases': plans, 'builds_per_case': 1,
              'only_candidate_flag_difference': ['-mllvm', '-regalloc=fast'],
              'retries': 0, 'sample_removal': False, 'quiet_host_admission': False,
              'total_build_budget_ns_including_original_emission': BUILD_NS,
              'runtime_execution_seconds': EXECUTION_SECONDS, 'diagnostic_stream_bytes': STREAM_BYTES,
              'rss_sampling_seconds': SAMPLE_SECONDS, 'rss_sampler_deadline_seconds': 0.5,
              'rss_sampler_command': PS_COMMAND, 'sources': sources, 'source_sha256': source_hash,
              'files': files, 'package_manifest': manifest, 'start_context': campaign.stamp()}
    WORK.mkdir()
    save(WORK / 'design.json', design)
    state: dict[str, Any] = {'state': 'running', 'qualification_claim': False,
                             'design_sha256': digest(WORK / 'design.json'), 'records': []}
    save(WORK / 'report.json', state)
    env = dict(os.environ, CI='1', PATH='', LC_ALL='C', LANG='C', ZERO_AR_DATE='1')
    for key in ('HOME', 'TMPDIR', 'TMP', 'TEMP'):
        value = os.environ.get(key)
        if not value or not local(Path(value)).is_dir():
            raise ValueError('Make must declare an existing repository-local ' + key)
    active: Wait4Process | None = None

    def interrupted(*_: Any) -> None:
        raise KeyboardInterrupt('experiment interrupted')

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)

    def verify() -> None:
        if digest(WORK / 'design.json') != state['design_sha256']:
            raise ValueError('frozen design changed')
        for name, sha in {**sources, **files}.items():
            if digest(ROOT / name) != sha:
                raise ValueError('frozen source or input changed: ' + name)
        if source_module.source_identity() != (sources, source_hash):
            raise ValueError('source inventory changed')

    def run(case: dict[str, Any], stage: str, argv: list[str], deadline: float,
            directory: Path) -> bool:
        nonlocal active
        record: dict[str, Any] = {'stage': stage, 'argv': argv,
                                  'peak_sampled_process_tree_rss_bytes': 0, 'rss_samples': 0}
        case['stages'].append(record)
        output_paths = {stream: directory / (stage+'.'+stream) for stream in ('stdout', 'stderr')}
        outputs = {stream: path.open('xb') for stream, path in output_paths.items()}
        selector = selectors.DefaultSelector()
        before = time.perf_counter_ns()
        stream_bytes = 0
        next_sample = time.monotonic()
        try:
            if time.monotonic() >= deadline:
                record['timed_out_before_launch'] = True
                return False
            active = Wait4Process(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            record['pid'] = active.pid
            save(WORK / 'report.json', state)
            for label, pipe in [('stdout', active.stdout), ('stderr', active.stderr)]:
                assert pipe is not None
                os.set_blocking(pipe.fileno(), False)
                selector.register(pipe, selectors.EVENT_READ, label)
            while True:
                now = time.monotonic()
                if now >= deadline:
                    record['timed_out'] = True
                    break
                for key, _ in selector.select(min(SAMPLE_SECONDS, max(0, deadline-now))):
                    chunk = os.read(key.fileobj.fileno(), 65536)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        continue
                    remaining = STREAM_BYTES-stream_bytes
                    outputs[key.data].write(chunk[:remaining])
                    stream_bytes += len(chunk)
                    if stream_bytes > STREAM_BYTES:
                        record['diagnostic_limit_exceeded'] = True
                        break
                if record.get('diagnostic_limit_exceeded'):
                    break
                if active.poll() is not None and not selector.get_map():
                    break
                if time.monotonic() >= next_sample and active.poll() is None:
                    record['peak_sampled_process_tree_rss_bytes'] = max(
                        record['peak_sampled_process_tree_rss_bytes'], sampled_rss(active.pid, deadline))
                    record['rss_samples'] += 1
                    next_sample += SAMPLE_SECONDS
        finally:
            selector.close()
            if active is not None:
                try:
                    cleaned = campaign.stop(active)
                    record['remaining_owned_members'] = cleaned.remaining_owned_members
                    record['cleanup_signal_observations'] = cleaned.signal_observations
                except campaign.CleanupError as error:
                    record['cleanup_error'] = str(error)
                    record['remaining_owned_members'] = error.result.remaining_owned_members
                finally:
                    record['status'] = active.returncode
                    record['cpu_user_seconds'] = active.usage.ru_utime if active.usage else None
                    record['cpu_system_seconds'] = active.usage.ru_stime if active.usage else None
                    for label, pipe in [('stdout', active.stdout), ('stderr', active.stderr)]:
                        if pipe is not None:
                            while stream_bytes <= STREAM_BYTES:
                                try:
                                    chunk = os.read(pipe.fileno(), 65536)
                                except BlockingIOError:
                                    break
                                if not chunk:
                                    break
                                outputs[label].write(chunk[:max(0, STREAM_BYTES-stream_bytes)])
                                stream_bytes += len(chunk)
                                if stream_bytes > STREAM_BYTES:
                                    record['diagnostic_limit_exceeded'] = True
                            pipe.close()
                    active = None
            for output in outputs.values():
                output.close()
            for stream, path in output_paths.items():
                record[stream] = receipt(path)
            record['observed_stream_bytes'] = stream_bytes
            record['wall_ns'] = time.perf_counter_ns()-before
            save(WORK / 'report.json', state)
        if record.get('cleanup_error'):
            raise ValueError('stage owned-group cleanup failed: ' + record['cleanup_error'])
        return record.get('status') == 0 and not any(record.get(key) for key in
                ('timed_out', 'timed_out_before_launch', 'diagnostic_limit_exceeded', 'cleanup_error'))

    try:
        for plan in plans:
            verify()
            case = {'case': plan['case'], 'stages': [], 'build_complete': False,
                    'expected_result_verified': False, 'ir': plan['ir'], 'start_context': campaign.stamp()}
            state['records'].append(case)
            directory = local(WORK / plan['case'])
            directory.mkdir()
            deadline = time.monotonic() + plan['remaining_compile_link_budget_ns']/1e9
            build_start = time.perf_counter_ns()
            try:
                if not run(case, 'compile', plan['commands']['compile'], deadline, directory):
                    continue
                trace = json.loads((directory / 'time-trace.json').read_text())
                if not isinstance(trace.get('traceEvents'), list) or not trace['traceEvents']:
                    raise ValueError('compiler trace JSON has no events')
                if 'Clang time report' not in (directory / 'compile.stderr').read_text():
                    raise ValueError('compiler per-pass report is absent')
                case['compiler_profiles_verified'] = True
                if not run(case, 'link', plan['commands']['link'], deadline, directory):
                    continue
                case['candidate_compile_link_wall_ns'] = time.perf_counter_ns()-build_start
                case['combined_build_wall_ns'] = EMISSION_NS[plan['case']] + case['candidate_compile_link_wall_ns']
                case['build_complete'] = case['combined_build_wall_ns'] <= BUILD_NS
                if not case['build_complete']:
                    case['build_budget_exceeded'] = True
                    continue
                if not run(case, 'execute', plan['commands']['execute'],
                           time.monotonic()+EXECUTION_SECONDS, directory):
                    continue
                actual = json.loads((directory / 'execute.stdout').read_text())
                if actual != plan['expected']:
                    raise ValueError('native result differs from frozen expected result')
                case['expected_result_verified'] = True
            except Exception as error:
                case['error'] = str(error)
                if any(stage.get('cleanup_error') for stage in case['stages']):
                    raise
            finally:
                case['files'] = {path.name: receipt(path) for path in sorted(directory.iterdir()) if path.is_file()}
                verify()
                case['post_case_inputs_verified'] = True
                case['finish_context'] = campaign.stamp()
                save(WORK / 'report.json', state)
        state['state'] = 'complete' if len(state['records']) == len(CASES) and all(
            case['build_complete'] and case['expected_result_verified'] and case['post_case_inputs_verified']
            for case in state['records']) else 'incomplete'
        return 0 if state['state'] == 'complete' else 2
    except BaseException as error:
        state.update(state='invalid', error=str(error))
        return 2
    finally:
        if active is not None:
            try:
                state['remaining_owned_members'] = campaign.stop(active).remaining_owned_members
            except BaseException as error:
                state['cleanup_error'] = str(error)
        save(WORK / 'report.json', state)
        print(json.dumps({'state': state['state'], 'report': str((WORK / 'report.json').relative_to(ROOT))}))


if __name__ == '__main__':
    raise SystemExit(main())
