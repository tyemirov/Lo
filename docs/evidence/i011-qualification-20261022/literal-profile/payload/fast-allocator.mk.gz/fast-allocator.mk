.PHONY: i011-literal-fast-allocator-syntax i011-literal-fast-allocator
i011-literal-fast-allocator-syntax: | tool-state
	python3 -B -c 'from pathlib import Path; p=Path("_scratch/i011-20261020/completion-20261022/literal-profile/fast-allocator.py"); compile(p.read_text(), str(p), "exec")' </dev/null

i011-literal-fast-allocator: | tool-state
	python3 -B _scratch/i011-20261020/completion-20261022/literal-profile/fast-allocator.py </dev/null
