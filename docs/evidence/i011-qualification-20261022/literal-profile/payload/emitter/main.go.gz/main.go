package main

import (
 "context"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "strings"
 "time"

 "github.com/MarcoPoloResearchLab/Lo/internal/compiler"
 "github.com/MarcoPoloResearchLab/Lo/internal/device"
 "github.com/MarcoPoloResearchLab/Lo/internal/llvmemit"
 "github.com/MarcoPoloResearchLab/Lo/internal/nativebuild"
 "github.com/MarcoPoloResearchLab/Lo/internal/nativeplan"
 "github.com/MarcoPoloResearchLab/Lo/internal/source"
)

func local(root, raw string, input bool) (string, error) {
 path, err := filepath.Abs(raw)
 if err != nil { return "", err }
 parent := filepath.Dir(path)
 if input { parent = path }
 resolved, err := filepath.EvalSymlinks(parent)
 if err != nil { return "", err }
 relative, err := filepath.Rel(root, resolved)
 if err != nil || relative == ".." || strings.HasPrefix(relative, ".."+string(filepath.Separator)) { return "", fmt.Errorf("path leaves Lo: %s", raw) }
 return path, nil
}

func run() error {
 if len(os.Args) != 4 { return fmt.Errorf("expected source output runtime_sha256") }
 root, err := os.Getwd()
 if err != nil { return err }
 input, err := local(root, os.Args[1], true)
 if err != nil { return err }
 output, err := local(root, os.Args[2], false)
 if err != nil { return err }
 runtimeDigest := os.Args[3]
 if value, err := hex.DecodeString(runtimeDigest); err != nil || len(value) != sha256.Size { return fmt.Errorf("invalid runtime digest") }
 text, err := os.ReadFile(input)
 if err != nil { return err }
 frontStart := time.Now()
 file, err := source.New(input, string(text))
 if err != nil { return err }
 program, diagnostic := compiler.Check(file)
 if diagnostic != nil { return diagnostic }
 frontElapsed := time.Since(frontStart)
 ctx, cancel := context.WithTimeout(context.Background(), nativebuild.BuildTimeout)
 defer cancel()
 lowerStart := time.Now()
 plan, err := nativeplan.Lower(ctx, program)
 if err != nil { return err }
 lowerElapsed := time.Since(lowerStart)
 sourceDigest := sha256.Sum256(text)
 artifact, err := json.Marshal(struct {
  SourceDigest string `json:"source_sha256"`
  Source string `json:"source"`
  Compiler string `json:"compiler"`
  Toolchain string `json:"toolchain"`
  Target string `json:"target"`
  Backend device.BuildBackend `json:"device_backend"`
  Runtime string `json:"runtime_sha256,omitempty"`
 }{hex.EncodeToString(sourceDigest[:]),input,nativebuild.LLVMCompilerIdentity,"LLVM 21.1.8","darwin/arm64",device.SoftwareBuild,runtimeDigest})
 if err != nil { return err }
 emitStart := time.Now()
 module, err := llvmemit.EmitArtifact(ctx, plan, "darwin/arm64", artifact)
 if err != nil { return err }
 emitElapsed := time.Since(emitStart)
 module = append(module, []byte(`
declare i32 @lo_cli_main(i32, ptr, ptr)
define i32 @main(i32 %argc, ptr %argv, ptr %envp) {
entry:
  %status = call i32 @lo_cli_main(i32 %argc, ptr %argv, ptr %envp)
  ret i32 %status
}
`)...)
 stream, err := os.Create(output)
 if err != nil { return err }
 _, writeError := stream.Write(module)
 closeError := stream.Close()
 if writeError != nil { return writeError }
 if closeError != nil { return closeError }
 moduleDigest := sha256.Sum256(module)
 return json.NewEncoder(os.Stdout).Encode(map[string]any{"source_sha256":hex.EncodeToString(sourceDigest[:]),"front_ns":frontElapsed.Nanoseconds(),"lower_ns":lowerElapsed.Nanoseconds(),"emit_ns":emitElapsed.Nanoseconds(),"module_bytes":len(module),"module_sha256":hex.EncodeToString(moduleDigest[:])})
}

func main() {
 if err := run(); err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(2) }
}
