.PHONY: i011-literal-profile-build i011-literal-profile
i011-literal-profile-build: | tool-state
	$(GO) build -o _scratch/i011-20261020/completion-20261022/literal-profile/emitter-bin ./_scratch/i011-20261020/completion-20261022/literal-profile/emitter </dev/null

i011-literal-profile: | tool-state
	python3 -B _scratch/i011-20261020/completion-20261022/literal-profile/profile.py </dev/null
