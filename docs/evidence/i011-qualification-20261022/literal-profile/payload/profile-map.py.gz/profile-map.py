from pathlib import Path
import hashlib,importlib.util,json,os,re,signal,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[4]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/nativebench'))
import campaign
PACKAGE=ROOT/'bin/distributions-i011-20261022/lo-darwin-arm64-software'
SOURCE=BASE.parent/'continuation/campaign/darwin-build'
CASES=('map_10000',)

def local(path):
    assert path.resolve().is_relative_to(ROOT),str(path)
    return path

def sha(path):return campaign.sha(local(path))
def save(path,value):
    temp=path.with_name('.'+path.name+'.tmp');temp.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n');temp.replace(path)
def rss(pid,deadline):
    output=subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True,timeout=min(1.0,max(0.001,deadline-time.monotonic())))
    rows=[tuple(map(int,line.split())) for line in output.splitlines()]
    owned={pid}
    while True:
      new={child for child,parent,_ in rows if parent in owned}
      if not new-owned:break
      owned|=new
    return sum(size*1024 for child,_,size in rows if child in owned)

def main():
    work=BASE/'map-continuation'
    if work.exists():raise ValueError('diagnostic output exists; retries prohibited')
    manifest=json.loads((PACKAGE/'toolchain.json').read_text());target=manifest['targets']['darwin/arm64']
    compiler=local(PACKAGE/manifest['compiler']['path']);linker=local(PACKAGE/target['linker']['path']);runtime=local(PACKAGE/target['runtime']['path']);emitter=BASE/'emitter-bin'
    files=[BASE/'baseline/design.json',BASE/'baseline/report.json',BASE/'baseline-reconciliation.json',compiler,linker,runtime,emitter,PACKAGE/'toolchain.json',PACKAGE/'bin/lo',BASE/'emitter/main.go',Path(__file__),BASE/'profile-map.mk',*(SOURCE/('build_'+name+'.lo') for name in CASES)]
    inventory=json.loads((PACKAGE/'inventory.json').read_text())
    for name,digest in inventory['files'].items():
      path=local(PACKAGE/name)
      if sha(path)!=digest:raise ValueError('package inventory mismatch:'+name)
      files.append(path)
    files.append(PACKAGE/'inventory.json')
    frozen={str(path.relative_to(ROOT)):sha(path) for path in files}
    spec=importlib.util.spec_from_file_location('profile_semantic_source',ROOT/'tools/semanticcoverage/report.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);sources,source_hash=module.source_identity()
    total=sum((index*37+11)%101 for index in range(10000));expected={'records_10000':str(total),'map_10000':str(total*3)}
    design={'issue':'I011','expected':expected,'start_context':campaign.stamp(),'kind':'instrumented_diagnostic_not_qualification','predeclared_design':{'path':str((BASE/'baseline/design.json').relative_to(ROOT)),'sha256':sha(BASE/'baseline/design.json')},'no_record_case_retry':True,'cases':list(CASES),'builds_per_case':1,'case_deadline_seconds':180,'execution_validation_deadline_seconds':30,'retries':0,'sample_removal':False,'quiet_host_admission':False,'rss_sampling_seconds':0.05,'clang_flags':['-target',target['triple'],'-O2','-g','-fPIC','-ffp-contract=off','-c','-mmacosx-version-min=27.0','-ftime-report=per-pass','-ftime-trace=<case>/time-trace.json'],'emission_driver':'diagnostic binary compiled from current compiler/nativeplan/llvmemit source; canonical artifact metadata and main wrapper; excludes tool snapshot admission','source_sha256':source_hash,'sources':sources,'files':frozen,'manifest':manifest}
    work.mkdir();save(work/'design.json',design)
    state={'state':'running','design_sha256':sha(work/'design.json'),'records':[],'qualification_claim':False};save(work/'report.json',state)
    env=dict(os.environ,CI='1',PATH='',HOME=str(BASE/'home'),TMPDIR=str(BASE/'tmp'),TMP=str(BASE/'tmp'),TEMP=str(BASE/'tmp'),LC_ALL='C',LANG='C',ZERO_AR_DATE='1')
    active=None
    def interrupted(*_):raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM,interrupted)
    def verify():
      if sha(work/'design.json')!=state['design_sha256']:raise ValueError('diagnostic design changed')
      for name,digest in frozen.items():
        if sha(ROOT/name)!=digest:raise ValueError('diagnostic input changed:'+name)
      if module.source_identity()!=(sources,source_hash):raise ValueError('diagnostic source changed')
    def run(case,name,argv,deadline):
      nonlocal active
      record={'stage':name,'argv':argv,'peak_sampled_process_tree_rss_bytes':0};case['stages'].append(record)
      before=time.perf_counter_ns();usage=None
      with (directory/(name+'.stdout')).open('xb') as out,(directory/(name+'.stderr')).open('xb') as err:
        active=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
        record['pid']=active.pid;save(work/'report.json',state)
        while True:
          pid,status,observed=os.wait4(active.pid,os.WNOHANG)
          if pid:
            active.returncode=os.waitstatus_to_exitcode(status);usage=observed;break
          if time.monotonic()>=deadline:
            record['timed_out']=True;campaign.stop(active);break
          if sum((directory/(name+'.'+stream)).stat().st_size for stream in ['stdout','stderr'])>1<<20:
            record['diagnostic_limit_exceeded']=True;campaign.stop(active);break
          record['peak_sampled_process_tree_rss_bytes']=max(record['peak_sampled_process_tree_rss_bytes'],rss(active.pid,deadline));time.sleep(min(0.05,max(0,deadline-time.monotonic())))
      record.update(status=active.returncode,wall_ns=time.perf_counter_ns()-before,cpu_user_seconds=usage.ru_utime if usage else None,cpu_system_seconds=usage.ru_stime if usage else None)
      cleaned=campaign.stop(active);active=None;record['remaining_owned_members']=list(cleaned.remaining_owned_members)
      for stream in ['stdout','stderr']:
        path=directory/(name+'.'+stream);record[stream]={'path':str(path.relative_to(ROOT)),'sha256':sha(path),'bytes':path.stat().st_size}
      save(work/'report.json',state)
      if sum(record[stream]['bytes'] for stream in ['stdout','stderr'])>1<<20:raise ValueError('diagnostic stream exceeded1MiB')
      return record['status']==0 and not record.get('timed_out')
    try:
      for name in CASES:
        verify();directory=work/name;directory.mkdir();source=SOURCE/('build_'+name+'.lo');ir=directory/'program.ll';object_file=directory/'program.o';artifact=directory/'program';case={'case':name,'stages':[],'build_complete':False};state['records'].append(case);save(work/'report.json',state)
        deadline=time.monotonic()+180
        try:
          if not run(case,'emission',[str(emitter),str(source),str(ir),target['runtime']['sha256']],deadline):continue
          case['emission']=json.loads((directory/'emission.stdout').read_text());text=ir.read_text();lines=text.splitlines();case['ir']={'bytes':ir.stat().st_size,'sha256':sha(ir),'functions':sum(line.startswith('define ') for line in lines),'blocks':sum(bool(re.fullmatch(r'[A-Za-z_.$][\w.$]*:',line)) for line in lines),'instructions':sum(line.startswith('  ') for line in lines),'allocas':sum(' = alloca ' in line for line in lines),'debug_metadata':sum(bool(re.match(r'!\d+ = ',line)) for line in lines),'optnone_functions':sum(line.startswith('define ') and '#1 ' in line for line in lines)};del text,lines;save(work/'report.json',state)
          flags=[str(compiler),'-target',target['triple'],'-O2','-g','-fPIC','-ffp-contract=off','-c',str(ir),'-o',str(object_file),'-mmacosx-version-min=27.0','-ftime-report=per-pass','-ftime-trace='+str(directory/'time-trace.json')]
          if not run(case,'compile',flags,deadline):continue
          substitutions={'{object}':str(object_file),'{runtime}':str(runtime),'{output}':str(artifact),**{'{input:'+key+'}':str(local(PACKAGE/value['path'])) for key,value in target['inputs'].items()}}
          args=[substitutions.get(arg,arg) for arg in target['link_args']]+['-oso_prefix',str(directory)+os.sep]
          if not run(case,'link',[str(linker),*args],deadline):continue
          case.update(build_complete=True,artifact_bytes=artifact.stat().st_size,artifact_sha256=sha(artifact))
          if not run(case,'execute',[str(artifact),'run','--max-steps','10000000','--format','json'],time.monotonic()+30):continue
          actual=json.loads((directory/'execute.stdout').read_text())
          if actual.get('command')!='run' or actual.get('status')!='ok' or actual.get('result')!={'type':'Int','value':expected[name]}:raise ValueError('diagnostic executable result differs')
          case['expected_result_verified']=True
        finally:
          if active is not None:
            case['remaining_owned_members']=list(campaign.stop(active).remaining_owned_members);active=None
          verify();case['post_case_inputs_verified']=True;case['finish_context']=campaign.stamp();save(work/'report.json',state)
      state['state']='complete' if all(case['build_complete'] and case.get('expected_result_verified') and case.get('post_case_inputs_verified') and case['stages'][-1]['status']==0 and not case['stages'][-1].get('timed_out') for case in state['records']) else 'incomplete'
      return 0 if state['state']=='complete' else 2
    except BaseException as error:
      state.update(state='invalid',error=str(error));return 2
    finally:
      if active is not None:
        try:state['remaining_owned_members']=list(campaign.stop(active).remaining_owned_members)
        except BaseException as error:state['cleanup_error']=str(error)
      save(work/'report.json',state)
      print(json.dumps({'state':state['state'],'report':str((work/'report.json').relative_to(ROOT))}))
if __name__=='__main__':raise SystemExit(main())
