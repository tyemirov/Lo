from pathlib import Path
import argparse,copy,gzip,hashlib,importlib.util,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
WORK=BASE/'compact-final'
sys.path.insert(0,str(ROOT/'tools/nativebench'))
import campaign,merge,qualification

def load(path):
    assert path.resolve().is_relative_to(ROOT)
    return json.loads(path.read_text())
def sha(path):
    assert path.resolve().is_relative_to(ROOT)
    return campaign.sha(path)
def require(condition,message):
    if not condition:raise ValueError(message)
def receipt(path):return {'path':str(path.relative_to(ROOT)),'sha256':sha(path)}
def verify_orchestration(state):
    path=ROOT/'docs/evidence/i011-qualification-20261022/compact-orchestration/manifest.json';record=load(path)
    require(record['initial_freeze_covers_scripts'] is False and record['timing']=='post-start capture','orchestration capture timing differs')
    require(record['run_start_utc']==state['start_utc'],'orchestration run binding differs')
    expected={str((BASE/name).relative_to(ROOT)) for name in ['compact-final-run.py','compact-final.mk','audit-compact-final.py']}
    require({item['source'] for item in record['records']}==expected and len(record['records'])==3,'orchestration script inventory differs')
    for item in record['records']:
      archive=ROOT/item['archive'];raw=gzip.decompress(archive.read_bytes())
      require(sha(archive)==item['archive_sha256'] and hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['bytes'],'orchestration archive differs')
      require(sha(ROOT/item['source'])==item['sha256'],'orchestration script changed after capture')
    return receipt(path)

def verify_raw_corpora(frozen,state):
    package_name='github.com/MarcoPoloResearchLab/Lo/tests/integration'
    complete=[];current=None
    for line in (WORK/'ci.stdout').read_text().splitlines():
      try:event=json.loads(line)
      except ValueError:continue
      if event.get('Package')!=package_name:continue
      if event.get('Action')=='start':
        require(current is None,'overlapping raw CI integration groups');current=[]
      require(current is not None,'CI integration event outside a group')
      current.append(line)
      if 'Test' not in event and event.get('Action') in {'pass','fail','skip'}:
        require(event['Action']=='pass','raw CI integration group failed');complete.append(current);current=None
    require(current is None and len(complete)==2,'raw CI group inventory differs')
    seen=set()
    for lines in complete:
      identities=[json.loads(json.loads(line)['Output'].split('LO_SEMANTIC_IDENTITY=',1)[1]) for line in lines if 'LO_SEMANTIC_IDENTITY=' in json.loads(line).get('Output','')]
      require(len(identities)==1,'raw CI identity inventory differs')
      identity=identities[0];backend=identity['backend'];require(backend in {'interpreter','llvm'} and backend not in seen,'raw CI backend differs');seen.add(backend)
      expected=('\n'.join(lines)+'\n').encode();path=WORK/'corpus/darwin'/(backend+'.jsonl')
      require(path.read_bytes()==expected,'CI corpus is not exact raw-log extraction')
      bound=state['ci_corpora'][backend]
      require(bound['identity']==identity and bound['path']==str(path.relative_to(ROOT)) and bound['sha256']==sha(path),'CI corpus orchestration binding differs')
    linux=WORK/'corpus/linux';report=load(linux/'report.json');guest=load(linux/'guest/report.json');batch=load(linux/'batch.json')
    require({key:value for key,value in report.items() if key not in {'events','test_binary_sha256','fixture_identities','pattern'}}==guest,'Linux suite and guest reports differ')
    require(load(WORK/'linux-corpus.stdout')==report,'Linux job stdout and suite report differ')
    package=ROOT/'bin/distributions-i011-compact-20261022/lo-linux-arm64-software'
    require(report['package']==str(package.relative_to(ROOT)) and report['package_path']=='/workspace/'+str(package.relative_to(ROOT)) and report['target']=='linux/arm64' and report['accelerator']=='hvf','Linux orchestration target or package differs')
    require(report['compiler_sha256']==frozen['package_files'][str((package/'bin/lo').relative_to(ROOT))] and report['manifest_sha256']==frozen['package_files'][str((package/'toolchain.json').relative_to(ROOT))],'Linux orchestration package identity differs')
    require(report['batch_sha256']==sha(linux/'batch.json') and len(report['cases'])==len(batch['cases'])==1,'Linux batch binding differs')
    case=report['cases'][0];declared=batch['cases'][0]
    require(case['id']==declared['id']=='semantic-linux-arm64' and case['status']==0 and case['argv']==declared['argv'] and case['cwd']==declared['cwd'],'Linux case declaration differs')
    require(report['test_binary_sha256']==sha(linux/'inputs/integration.test'),'Linux test binary differs')
    for record in report['fixture_identities'].values():require(record['sha256']==sha(linux/'inputs'/record['path']),'Linux prebuilt fixture differs')
    spec=importlib.util.spec_from_file_location('compact_audit_batch',ROOT/'tools/loqualification/batch.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    exported=module.receive(ROOT/report['export'],('semantic-linux-arm64',),(0,))[0]
    require(exported.status==case['status'] and exported.elapsed_ns==case['elapsed_ns'],'Linux raw export result differs')
    for record in case['streams']:
      path=ROOT/record['path'];require(path.resolve().is_relative_to(ROOT),'Linux stream leaves Lo')
      raw=path.read_bytes();require(len(raw)==record['bytes'] and sha(path)==record['sha256'],'Linux stream hash differs')
      require(raw==getattr(exported,record['name']),'Linux stream differs from raw export')
    require({record['name'] for record in case['streams']}=={'stdout','stderr'},'Linux stream inventory differs')
    events=ROOT/report['events'];require(events==linux/'semantic-linux-arm64.jsonl','Linux event output path differs')
    regenerated=BASE/'compact-audit-linux-recomputed.jsonl'
    with (linux/'guest/0.stdout').open('rb') as source,regenerated.open('wb') as output:
      conversion=subprocess.run(['go','tool','test2json','-p',package_name],cwd=ROOT,env=dict(os.environ,CI='1'),stdin=source,stdout=output,stderr=subprocess.PIPE,timeout=30,check=False)
    require(conversion.returncode==0 and conversion.stderr==b'','Linux raw event conversion failed')
    def logical(path):
      rows=[]
      for line in path.read_text().splitlines():
        row=json.loads(line);row.pop('Time',None)
        if 'Test' not in row:row.pop('Elapsed',None)
        rows.append(row)
      return rows
    require(logical(regenerated)==logical(events),'Linux events differ from raw guest output')
    return {'ci_raw_extraction':'exact bytes','linux_raw_export':'case/status/elapsed/streams verified','linux_conversion':'all event fields except conversion-generated Time and package Elapsed','linux_regenerated':receipt(regenerated)}

def audit():
    frozen=load(WORK/'frozen.json');state=load(WORK/'status.json')
    require(state.get('state')=='performance-pass' and not state.get('error') and not state.get('cleanup_error'),'final driver not passed')
    require([j['name'] for j in state['jobs']]==['ci','linux-corpus','component-tools','offline','semantic-report','performance'],'unexpected fresh job sequence')
    for job in state['jobs']:
      require(job.get('status')==0 and job.get('remaining_owned_members')==[] and 'finish_utc' in job,'job status or cleanup failed')
      for stream in ['stdout','stderr']:require(sha(WORK/(job['name']+'.'+stream))==job[stream+'_sha256'],'job log identity differs')
    require(state['source_sha256']==frozen['semantic_source_sha256'],'source binding differs')
    for name,digest in frozen['sources'].items():require(sha(ROOT/name)==digest,'source differs:'+name)
    for name,digest in frozen['package_files'].items():require(sha(ROOT/name)==digest,'package file differs:'+name)
    require(frozen['runtime_inputs']['selected_runtime']==str((BASE/'compact-runtime').relative_to(ROOT)),'selected runtime path differs')
    for name,digest in frozen['runtime_inputs']['files'].items():require(sha(ROOT/name)==digest,'runtime input differs:'+name)
    runtime=BASE/'compact-runtime'
    require(bool(load(runtime/'build-receipt.json').get('metal',{}).get('sources')) and 'metal' in load(runtime/'toolchain.json'),'final runtime lacks real Metal build inventory')
    require(load(runtime/'toolchain.json')['abi']=='lo-native-2','final runtime ABI differs')
    orchestration=verify_orchestration(state)
    raw_corpora=verify_raw_corpora(frozen,state)
    semantic=load(WORK/'semantic-report.json')
    spec=importlib.util.spec_from_file_location('i011_semantic_audit',ROOT/'tools/semanticcoverage/report.py')
    semantic_module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=semantic_module;spec.loader.exec_module(semantic_module)
    recomputed=BASE/'compact-audit-semantic-recomputed.json'
    semantic_inputs=semantic_module.Inputs(ROOT/'testdata/semantic-migration/matrix.json',WORK/'corpus/darwin/interpreter.jsonl',{'darwin/arm64':WORK/'corpus/darwin/llvm.jsonl','linux/arm64':WORK/'corpus/linux/semantic-linux-arm64.jsonl'},recomputed)
    require(semantic_module.report(semantic_inputs)==0 and load(recomputed)==semantic,'semantic event recomputation differs')
    for lane,variant in [('interpreter','lo-darwin-arm64-metal'),('llvm:darwin/arm64','lo-darwin-arm64-metal'),('llvm:linux/arm64','lo-linux-arm64-software')]:
      identity=semantic['execution_identity'][lane];package=ROOT/'bin/distributions-i011-compact-20261022'/variant
      compiler=package/'bin/lo';require(identity['compiler']==str(compiler.relative_to(ROOT)) and identity['compiler_sha256']==frozen['package_files'][str(compiler.relative_to(ROOT))],'semantic compiler differs from frozen package')
      if lane!='interpreter':
        manifest=package/'toolchain.json';require(identity['toolchain']==str(manifest.relative_to(ROOT)) and identity['toolchain_sha256']==frozen['package_files'][str(manifest.relative_to(ROOT))],'semantic toolchain differs from frozen package')
        runtime=load(manifest)['targets'][identity['target']]['runtime'];runtime_path=(package/runtime['path']).resolve()
        require(runtime_path.is_relative_to(ROOT) and identity['runtime_sha256']==runtime['sha256']==frozen['package_files'][str(runtime_path.relative_to(ROOT))],'semantic runtime differs from frozen package')
    require(semantic['execution_status']=='passed' and semantic['qualification_status']=='passed' and semantic['missing_targets']==[] and semantic['qualification_gaps']==[],'strict semantic qualification failed')
    require(semantic['source_sha256']==frozen['sources'],'semantic source inventory differs')
    for lane,path in [('interpreter',WORK/'corpus/darwin/interpreter.jsonl'),('llvm:darwin/arm64',WORK/'corpus/darwin/llvm.jsonl'),('llvm:linux/arm64',WORK/'corpus/linux/semantic-linux-arm64.jsonl')]:require(sha(path)==semantic['log_sha256'][lane],'semantic log identity differs')
    offline=load(WORK/'offline/validation.json')
    require(offline['status']=='passed','offline qualification failed')
    require(offline['guard']['status']==0,'offline guard failed')
    require({(cell['host'],cell['target']) for cell in offline['matrix']}=={(host,target) for host in ['darwin/arm64','linux/arm64'] for target in ['darwin/arm64','linux/arm64']} and len(offline['matrix'])==4,'offline matrix incomplete')
    require(all(cell['compile']['status']==0 and cell['execute']['status']==0 for cell in offline['matrix']),'offline cell failed')
    require(offline['metal']['compile']['status']==0 and offline['metal']['execute']['status']==0,'Metal package qualification failed')
    for cell in [*offline['matrix'],offline['metal'],offline['relocation']]:
      require(cell['compile']['status']==0 and cell['execute']['status']==0,'offline build/execution failed')
      values=json.loads(cell['execute']['stdout'])['result']['value']['value']
      require({name:value['value'] for name,value in values.items()}=={'count':'3','error':'Math.DivideByZero','large':'123456789012345678901234567891','tensor':'6','text':'λ雪'},'representative result differs')
    require({row['host'] for row in offline['training']}=={'darwin/arm64','linux/arm64'} and len(offline['training'])==2,'training target coverage incomplete')
    for cell in offline['training']:
      require(cell['compile']['status']==0 and cell['execute']['status']==0,'training build/execution failed')
      fields=json.loads(cell['execute']['stdout'])['result']['value']['value']
      require(fields['steps']['value']=='500' and float(fields['loss']['value'])<1e-10<float(fields['initial_loss']['value']),'training result differs')
      predictions=fields['predictions']['value']['values']
      require(len(predictions)==4 and all(abs(float(value)-expected)<=1e-4 for value,expected in zip(predictions,[0,1,1,0])),'training predictions differ')
    require(len(offline['rejections'])==9 and len({row['case'] for row in offline['rejections']})==9 and all(row['status']==2 and row['prior_output_preserved'] and row['staging_empty'] for row in offline['rejections']),'rejection qualification incomplete')
    require(set(offline['packages'])=={'darwin','linux','metal'},'offline package inventory differs')
    for key,record in offline['packages'].items():
      variant={'darwin':'lo-darwin-arm64-software','linux':'lo-linux-arm64-software','metal':'lo-darwin-arm64-metal'}[key]
      expected_package=ROOT/'bin/distributions-i011-compact-20261022'/variant
      require(record['package']==str(expected_package.relative_to(ROOT)),'offline package is not final package')
      for name,field in [('toolchain.json','toolchain_sha256'),('inventory.json','inventory_sha256'),('bin/lo','frontend_sha256')]:require(record[field]==frozen['package_files'][str((expected_package/name).relative_to(ROOT))],'offline package differs from final freeze')
      package=ROOT/record['package'];require(sha(ROOT/record['archive'])==record['archive_sha256'],'package archive differs')
      require(sha(package/'toolchain.json')==record['toolchain_sha256'] and sha(package/'inventory.json')==record['inventory_sha256'] and sha(package/'bin/lo')==record['frontend_sha256'],'offline package identity differs')
    def verify_build(cell,key,target):
      package=ROOT/offline['packages'][key]['package'];manifest=load(package/'toolchain.json')
      runtime=manifest['targets'][target]['runtime'];built=json.loads(cell['compile']['stdout'])
      require(built['command']=='build' and built['status']=='ok' and built['target']==target and built['abi']=='lo-native-2' and built['codegen']=='llvm' and built['runtime_sha256']==runtime['sha256'],'offline build runtime or target differs')
      runtime_path=(package/runtime['path']).resolve();require(runtime_path.is_relative_to(ROOT) and runtime['sha256']==frozen['package_files'][str(runtime_path.relative_to(ROOT))],'offline runtime differs from freeze')
    for cell in offline['matrix']:verify_build(cell,cell['host'].split('/')[0],cell['target'])
    for cell in offline['training']:verify_build(cell,cell['host'].split('/')[0],cell['host'])
    verify_build(offline['metal'],'metal','darwin/arm64');verify_build(offline['relocation'],'darwin','darwin/arm64')
    directory=WORK/'campaign';summary=load(directory/'report.json');config=load(directory/'config.json')
    require(summary['state']=='complete' and summary['measurement_complete'] is True and summary['qualification_outcome']=='pass','campaign not complete pass')
    require(not summary.get('error') and not summary.get('cleanup_error') and summary['remaining_owned_members']==[],'campaign error/cleanup')
    require(sha(directory/'config.json')==summary['config_sha256'],'config identity differs')
    require(config['samples']==10 and config['warmup']==3 and config['concurrency']==1 and config['lanes']==list(qualification.LANES),'campaign contract differs')
    expected=[(target,lane) for target in ['darwin','linux'] for lane in qualification.LANES]
    require([(row['target'],row['lane']) for row in summary['subprocesses']]==expected,'campaign lane order/inventory differs')
    args=argparse.Namespace(**{key:Path(value) for key,value in config['paths'].items()},accelerator='hvf')
    current=campaign.snapshot(args)
    require(all(config[key]==value for key,value in current.items()),'campaign inputs changed')
    require(current==frozen['campaign_inputs'],'campaign differs from final source freeze')
    paths={target:[] for target in ['darwin','linux']};lanes=[]
    for item in summary['subprocesses']:
      target,lane=item['target'],item['lane'];path=directory/f'{target}-{lane}'/'report.json'
      require(sha(path)==item['report_sha256'] and str(path.relative_to(ROOT))==item['report'],'lane binding differs')
      require(item['measurement_complete'] is True,'lane incomplete')
      for stream in ['stdout','stderr']:require(sha(ROOT/item[stream])==item[stream+'_sha256'],'lane log binding differs')
      raw,_=merge.admit(path);calculated=copy.deepcopy(raw);qualification.completion(calculated,0)
      require(raw['lanes']==[lane] and raw['merge_identity']['target']==target+'/arm64','lane target/inventory differs')
      identity=raw['merge_identity'];declared=config['source_identity'][target]
      require(identity['package']==config['packages'][target] and all(identity[key]==declared[key] for key in ['source','harness','evaluator']) and identity['producer']['source_identity']==declared['producer']['source_identity'] and identity['reference']['source_identity']==declared['reference']['source_identity'],'lane differs from predeclared provenance')
      require(identity['accelerator']==('none' if target=='darwin' else 'hvf') and identity['measurement']['samples']==10 and identity['measurement']['warmup']==3,'lane sample or accelerator contract differs')
      require(calculated['measurement_complete'] and not calculated.get('measurement_error'),'invalid lane')
      require(raw['gate_failures']==calculated['gate_failures'] and raw['gates_passed']==calculated['gates_passed'],'lane gates differ')
      require(item['status']==(0 if calculated['gates_passed'] else 2) and item['qualification_outcome']==campaign.outcome(calculated),'lane Make outcome differs')
      require(calculated['gates_passed'],'lane gate failed')
      paths[target].append(path);lanes.append({'target':target,'lane':lane,'report':receipt(path),'gate_failures':calculated['gate_failures']})
    require([item['target'] for item in summary['merges']]==['darwin','linux'],'target merge inventory differs')
    targets={}
    for item in summary['merges']:
      target=item['target'];path=directory/(target+'-merged.json');stored=load(path);calculated=merge.merge(paths[target])
      require(stored==calculated and sha(path)==item['report_sha256'],'target merge differs')
      require(calculated['measurement_complete'] and calculated['qualification_complete'] and calculated['gates_passed'],'target merge not qualified')
      require(item['qualification_outcome']==campaign.outcome(calculated)=='pass' and item['gate_failures']==[],'target outcome differs')
      targets[target]={'report':receipt(path),'callback_speedup':calculated['callback_speedup'],'callback_interval95':calculated['callback_bootstrap_95_percent'],'gate_failures':calculated['gate_failures'],'max_build_seconds':max(r['elapsed_ns'] for r in calculated['build'])/1e9,'max_build_rss_bytes':max(r['peak_process_tree_rss_bytes'] for r in calculated['build']),'max_artifact_bytes':max(r['artifact_bytes'] for r in calculated['build']),'http':[{key:row[key] for key in ['name','p95','reciprocal_throughput']} for row in calculated['http']]}
    require(state['jobs'][-1]['status']==0 and summary['qualification_outcome']=='pass','outer Make outcome differs')
    return {'issue':'I011','audit_status':'all_code_and_performance_checks_passed','i011_complete':False,'source_sha256':state['source_sha256'],'frozen':receipt(WORK/'frozen.json'),'driver':receipt(WORK/'status.json'),'semantic':receipt(WORK/'semantic-report.json'),'semantic_reference_count':len(semantic['references']),'offline':receipt(WORK/'offline/validation.json'),'packages_verified':len(frozen['package_files']),'raw_corpora':raw_corpora,'post_start_orchestration':orchestration,'lanes':lanes,'targets':targets,'pending':['approved_manual_documentation_review','independent_completion_review','owned_scratch_cleanup']}
if __name__=='__main__':
    try:
      result=audit();output=BASE/'compact-final-audit.json'
      with output.open('x') as file:file.write(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
      print(json.dumps({'audit':'passed','output':str(output.relative_to(ROOT))}))
    except (ValueError,KeyError,TypeError,OSError,AssertionError) as error:
      print(json.dumps({'audit':'failed','error':str(error)}),file=sys.stderr);raise SystemExit(2)
