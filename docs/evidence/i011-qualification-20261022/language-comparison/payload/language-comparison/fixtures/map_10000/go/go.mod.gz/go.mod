module lo.local/i011/comparison/map_10000

go 1.27.1
