#![no_std]
#![no_main]
extern "C" { static DATA: [i64; 10000]; fn printf(format: *const u8, ...) -> i32; }
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
#[no_mangle]
pub unsafe extern "C" fn main(_argc: i32, _argv: *mut *mut u8) -> i32 {
 let mut total: i64 = 0;
 for index in 0..10000 { total += *core::ptr::addr_of!(DATA).cast::<i64>().add(index) * 3; }
 printf(b"%lld\n\0".as_ptr(), total);
 0
}
