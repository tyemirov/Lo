package main

import ("fmt"; "lo.local/i011/comparison/map_10000/data")

func main() {
 total := int64(0)
 for _, value := range data.DATA { total += value * 3 }
 fmt.Printf("%d\n", total)
}
