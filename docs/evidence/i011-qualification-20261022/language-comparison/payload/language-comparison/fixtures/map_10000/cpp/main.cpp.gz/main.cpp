extern "C" { extern long long DATA[10000]; int printf(const char *, ...); }
static_assert(sizeof(long long) == 8);
int main() { long long total = 0; for (unsigned long index = 0; index < 10000; ++index) { total += DATA[index] * 3; } return printf("%lld\n", total) < 0; }
