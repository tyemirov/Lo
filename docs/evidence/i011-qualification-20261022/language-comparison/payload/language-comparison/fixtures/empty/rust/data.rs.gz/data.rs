#![no_std]
#[no_mangle]
pub static DATA: [i64; 0] = [];
