extern "C" { long long DATA[1] = {0}; }
