package main

import ("fmt"; "lo.local/i011/comparison/empty/data")

func main() {
 total := int64(7)
 for _, value := range data.DATA { total += value * 3 }
 fmt.Printf("%d\n", total)
}
