extern "C" { extern long long DATA[1]; int printf(const char *, ...); }
static_assert(sizeof(long long) == 8);
int main() { long long total = 7; for (unsigned long index = 0; index < 0; ++index) { total += DATA[index] * 3; } return printf("%lld\n", total) < 0; }
