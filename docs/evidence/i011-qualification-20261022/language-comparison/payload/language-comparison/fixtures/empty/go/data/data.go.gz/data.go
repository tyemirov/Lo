package data

var DATA = [...]int64{}
