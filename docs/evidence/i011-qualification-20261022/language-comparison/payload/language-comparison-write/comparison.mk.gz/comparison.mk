.PHONY: i011-language-write-syntax i011-language-write
i011-language-write-syntax: | tool-state
	python3 -B -c 'from pathlib import Path; import json; root=Path.cwd().resolve(); base=root/"_scratch/i011-20261020/completion-20261022/language-comparison-write"; assert base.resolve().is_relative_to(root); p=base/"compare.py"; compile(p.read_text(), str(p), "exec"); json.loads((base/"plan.json").read_text())' </dev/null

i011-language-write: | tool-state
	python3 -B _scratch/i011-20261020/completion-20261022/language-comparison-write/compare.py </dev/null
