#![no_std]
#![no_main]
extern "C" { static DATA: [i64; 10000]; fn write(fd: i32, buffer: *const u8, length: usize) -> isize; }
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
#[no_mangle]
pub unsafe extern "C" fn main(_argc: i32, _argv: *mut *mut u8) -> i32 {
 let mut total: i64 = 0;
 for index in 0..10000 { total += *core::ptr::addr_of!(DATA).cast::<i64>().add(index) * 3; }
 let mut magnitude = total as u64;
 let mut reversed = [0u8; 32];
 let mut digits = 0usize;
 loop { *reversed.as_mut_ptr().add(digits) = b'0' + (magnitude % 10) as u8; digits += 1; magnitude /= 10; if magnitude == 0 { break; } }
 let mut output = [0u8; 32];
 for index in 0..digits { *output.as_mut_ptr().add(index) = *reversed.as_ptr().add(digits-index-1); }
 *output.as_mut_ptr().add(digits) = b'\n';
 let length = digits + 1;
 if write(1, output.as_ptr(), length) != length as isize { return 1; }
 0
}
