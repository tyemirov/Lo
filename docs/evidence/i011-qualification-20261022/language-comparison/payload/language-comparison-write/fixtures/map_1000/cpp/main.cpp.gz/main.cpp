extern "C" { extern long long DATA[1000]; long write(int, const void *, unsigned long); }
static_assert(sizeof(long long) == 8);
int main() {
 long long total = 0;
 for (unsigned long index = 0; index < 1000; ++index) { total += DATA[index] * 3; }
 char output[32]; unsigned long digits = 0; unsigned long long magnitude = static_cast<unsigned long long>(total);
 do { output[digits++] = static_cast<char>('0' + magnitude % 10); magnitude /= 10; } while (magnitude != 0);
 for (unsigned long index = 0; index < digits / 2; ++index) { char saved = output[index]; output[index] = output[digits-index-1]; output[digits-index-1] = saved; }
 output[digits] = '\n'; unsigned long length = digits + 1;
 return write(1, output, length) == static_cast<long>(length) ? 0 : 1;
}
