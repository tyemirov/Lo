"""Separate write-based reference diagnostic; preserve the original printf failures."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import selectors
import signal
import struct
import statistics
import subprocess
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[4]
BASE = Path(__file__).resolve().parent
OUTPUT = BASE / 'observations'
PACKAGE = ROOT / 'bin/distributions-i011-20261022/lo-darwin-arm64-software'
RUST_PREFIX = ROOT / '_scratch/native-runtime/rust-prefix'
LANGUAGES = ('rust', 'cpp')
CASES = ('empty', 'map_1000', 'map_10000')
LIMIT = 1 << 20
SAMPLE_SECONDS = 0.05
HELPER = BASE.parent / 'literal-profile/fast-allocator.py'
spec = importlib.util.spec_from_file_location('comparison_bounded_measurement', HELPER)
assert spec is not None and spec.loader is not None
measurement = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = measurement
spec.loader.exec_module(measurement)
campaign = measurement.campaign
local = measurement.local
receipt = measurement.receipt


def load(path: Path) -> dict[str, Any]:
    return json.loads(local(path).read_text())


def save(path: Path, value: dict[str, Any]) -> None:
    campaign.save(local(path), value)


def macho_deployment(path: Path) -> dict[str, Any]:
    data = local(path).read_bytes()
    if len(data) < 32 or struct.unpack_from('<II', data) != (0xfeedfacf, 0x0100000c):
        raise ValueError('expected native arm64 Mach-O: '+str(path))
    count = struct.unpack_from('<I', data, 16)[0]
    offset = 32
    versions = []
    for _ in range(count):
        if offset+8 > len(data):
            raise ValueError('truncated Mach-O load command')
        command, size = struct.unpack_from('<II', data, offset)
        if size < 8 or offset+size > len(data):
            raise ValueError('invalid Mach-O load command size')
        if command == 0x32:
            if size < 24:
                raise ValueError('truncated LC_BUILD_VERSION')
            platform, version = struct.unpack_from('<II', data, offset+8)
            if platform != 1:
                raise ValueError('Mach-O build platform is not macOS')
            versions.append(version)
        elif command == 0x24:
            if size < 16:
                raise ValueError('truncated LC_VERSION_MIN_MACOSX')
            versions.append(struct.unpack_from('<I', data, offset+8)[0])
        offset += size
    if not versions or any(version != 27 << 16 for version in versions):
        raise ValueError('Mach-O deployment differs from frozen macOS27.0')
    return {'minimum_versions_raw': versions, 'minimum_version': '27.0'}


def summarize(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    complete = {}
    for language in LANGUAGES:
        for case in CASES:
            observed = [record for record in records if record['phase'] == 'measurement'
                        and record['language'] == language and record['case'] == case]
            cell: dict[str, Any] = {'language': language, 'case': case,
                'observations': [record['label'] for record in observed], 'required_observations': 3,
                'summary_complete': len(observed) == 3 and all(record['build_complete'] and
                    record['expected_result_verified'] for record in observed)}
            if cell['summary_complete']:
                cell['build_wall_ns_median'] = statistics.median(record['whole_build_wall_ns'] for record in observed)
                cell['build_stage_wall_ns_sum_median'] = statistics.median(sum(stage['wall_ns']
                    for stage in record['stages'] if stage['stage'] != 'execute') for record in observed)
                for field in ('cpu_user_seconds', 'cpu_system_seconds'):
                    cell['build_'+field+'_median'] = statistics.median(sum(stage[field] for stage in
                        record['stages'] if stage['stage'] != 'execute') for record in observed)
                cell['peak_sampled_process_tree_rss_bytes_median'] = statistics.median(max(
                    stage['peak_sampled_process_tree_rss_bytes'] for stage in record['stages']
                    if stage['stage'] != 'execute') for record in observed)
                cell['artifact_bytes_median'] = statistics.median(record['artifact']['bytes'] for record in observed)
                resource_samples = {
                    'build_wall_ns': [record['whole_build_wall_ns'] for record in observed],
                    'build_stage_wall_ns_sum': [sum(stage['wall_ns'] for stage in record['stages']
                        if stage['stage'] != 'execute') for record in observed],
                    'build_cpu_user_seconds': [sum(stage['cpu_user_seconds'] for stage in record['stages']
                        if stage['stage'] != 'execute') for record in observed],
                    'build_cpu_system_seconds': [sum(stage['cpu_system_seconds'] for stage in record['stages']
                        if stage['stage'] != 'execute') for record in observed],
                    'peak_sampled_process_tree_rss_bytes': [max(stage['peak_sampled_process_tree_rss_bytes']
                        for stage in record['stages'] if stage['stage'] != 'execute') for record in observed],
                    'artifact_bytes': [record['artifact']['bytes'] for record in observed]}
                for metric, values in resource_samples.items():
                    cell[metric+'_samples'] = values
                    cell[metric+'_range'] = [min(values), max(values)]
                complete[language, case] = cell
            else:
                cell['summary_error'] = 'missing or failed fixed observations; no successful-subset estimate'
            result.append(cell)
    for cell in result:
        empty = complete.get((cell['language'], 'empty'))
        if cell['summary_complete'] and empty is not None:
            for metric in ('build_wall_ns', 'build_stage_wall_ns_sum', 'build_cpu_user_seconds',
                           'build_cpu_system_seconds', 'peak_sampled_process_tree_rss_bytes', 'artifact_bytes'):
                cell[metric+'_delta_from_empty_median'] = cell[metric+'_median']-empty[metric+'_median']
                differences = [current-baseline for current in cell[metric+'_samples']
                               for baseline in empty[metric+'_samples']]
                cell[metric+'_all_pairwise_empty_delta_range'] = [min(differences), max(differences)]
    return result


def commands(language: str, case: str, directory: Path, tools: dict[str, Path]) -> list[dict[str, Any]]:
    fixture = local(BASE / 'fixtures' / case)
    artifact = local(directory / 'program')
    result: list[dict[str, Any]] = []
    for unit in ('data', 'main'):
        source = fixture / language / (unit+('.rs' if language == 'rust' else '.cpp'))
        object_file = local(directory / (unit+'.o'))
        if language == 'rust':
            argv = [str(tools['rust']), str(source), '--crate-name', 'comparison_'+unit,
                    '--crate-type', 'lib' if unit == 'data' else 'bin', '--edition', '2021',
                    '--target', 'aarch64-apple-darwin', '--sysroot', str(RUST_PREFIX), '--emit=obj',
                    '-Copt-level=2', '-Cdebuginfo=2', '-Cpanic=abort', '-Crelocation-model=pic',
                    '-o', str(object_file)]
        else:
            argv = [str(tools['clang']), '-x', 'c++', '-std=c++17', '-O2', '-g', '-fPIC',
                    '-target', 'aarch64-apple-darwin', '-mmacosx-version-min=27.0',
                    '-nostdinc', '-nostdinc++', '-fno-exceptions', '-fno-rtti',
                    '-ffp-contract=off', '-c', str(source), '-o', str(object_file)]
        result.append({'stage': 'compile-'+unit, 'cwd': str(ROOT), 'argv': argv})
    result.append({'stage': 'link', 'cwd': str(ROOT), 'argv': [str(tools['linker']),
                   '-dead_strip', '-arch', 'arm64', '-platform_version', 'macos', '27.0', '27.0',
                   '-o', str(artifact), str(directory/'data.o'), str(directory/'main.o'), str(tools['system'])]})
    return result


def main() -> int:
    local(OUTPUT)
    if OUTPUT.exists():
        raise ValueError('observation directory exists; overwrite and retries prohibited')
    plan = load(BASE/'plan.json')
    if plan['languages'] != list(LANGUAGES) or plan['case_order'] != list(CASES):
        raise ValueError('fixed language or case order changed')
    manifest = load(PACKAGE/'toolchain.json')
    target = manifest['targets']['darwin/arm64']
    tools = {'clang': local(PACKAGE/manifest['compiler']['path']),
             'linker': local(PACKAGE/target['linker']['path']),
             'system': local(PACKAGE/target['inputs']['system']['path']),
             'rust': local(RUST_PREFIX/'bin/rustc')}
    inventory = load(PACKAGE/'inventory.json')
    frozen = dict(plan['fixture_sha256'])
    for name, sha in inventory['files'].items():
        frozen[str(local(PACKAGE/name).relative_to(ROOT))] = sha
    original = plan['original_printf_experiment']
    original_design_path = local(ROOT/original['design']['path'])
    if campaign.sha(original_design_path) != original['design']['sha256']:
        raise ValueError('original printf experiment design changed')
    original_design = load(original_design_path)
    original_report_path = local(ROOT/original['report_path'])
    original_report = load(original_report_path)
    if original_report['state'] not in original['required_terminal_states'] or len(
            original_report['observations']) != original['required_observation_count']:
        raise ValueError('original 48-observation experiment must finish unchanged before this diagnostic')
    if original_report['design_sha256'] != original['design']['sha256']:
        raise ValueError('original terminal report belongs to another design')
    failed_links = []
    for observation in original_report['observations']:
        if observation['language'] not in LANGUAGES:
            continue
        for stage in observation['stages']:
            if stage['stage'] != 'link' or stage.get('status') == 0:
                continue
            failure = {'label': observation['label'], 'status': stage.get('status'),
                       'argv': stage['argv']}
            for stream in ('stdout', 'stderr'):
                item = stage[stream]
                path = local(ROOT/item['path'])
                if campaign.sha(path) != item['sha256'] or path.stat().st_size != item['bytes']:
                    raise ValueError('original printf failure receipt changed')
                failure[stream] = item
                frozen[item['path']] = item['sha256']
            if 'printf' not in local(ROOT/stage['stderr']['path']).read_text():
                raise ValueError('original failed reference link is not the declared printf failure')
            failed_links.append(failure)
    if len(failed_links) != 24:
        raise ValueError('expected all 24 original Rust/C++ printf link failures')
    # Bind every original source/tool input as well as its finished report.
    for name, sha in original_design['files'].items():
        if campaign.sha(local(ROOT/name)) != sha:
            raise ValueError('original frozen input changed: '+name)
        if name in frozen and frozen[name] != sha:
            raise ValueError('new diagnostic selected different original tools: '+name)
        frozen[name] = sha
    original_receipts = {'design': receipt(original_design_path),
                         'report': receipt(original_report_path), 'failed_links': failed_links}
    inputs = [Path(__file__), BASE/'comparison.mk', BASE/'plan.json', HELPER,
              ROOT/'tools/nativebench/campaign.py', ROOT/'tests/corpus/corpus.go',
              PACKAGE/'inventory.json', PACKAGE/'toolchain.json', original_design_path, original_report_path]
    inputs.extend(path for path in local(RUST_PREFIX).rglob('*') if local(path).is_file())
    for path in inputs:
        frozen[str(local(path).relative_to(ROOT))] = campaign.sha(path)
    for name, sha in frozen.items():
        if campaign.sha(local(ROOT/name)) != sha:
            raise ValueError('fixture or tool input digest mismatch: '+name)
    tool_identity = {name: receipt(path) for name, path in tools.items()}
    env = dict(os.environ, CI='1', CGO_ENABLED='0', GOTOOLCHAIN='local', GOENV='off', GOWORK='off',
               GOOS='darwin', GOARCH='arm64', GOFLAGS='', GOCACHEPROG='', GOEXPERIMENT='',
               GOPROXY='off', GOSUMDB='off',
               LC_ALL='C', LANG='C', ZERO_AR_DATE='1', MACOSX_DEPLOYMENT_TARGET='27.0')
    env.pop('GOROOT', None)
    for name in ('HOME', 'TMPDIR', 'TMP', 'TEMP', 'GOCACHE', 'GOMODCACHE', 'GOPATH',
                 'CLANG_MODULE_CACHE_PATH'):
        value = env.get(name)
        if not value or not local(Path(value)).is_dir():
            raise ValueError('Make must declare an existing repository-local '+name)
    selected_environment = {name: env[name] for name in ('CI', 'HOME', 'TMPDIR', 'TMP', 'TEMP',
        'GOCACHE', 'GOMODCACHE', 'GOPATH', 'CGO_ENABLED', 'GOTOOLCHAIN', 'GOENV', 'GOWORK',
        'GOOS', 'GOARCH', 'GOFLAGS', 'GOCACHEPROG', 'GOEXPERIMENT', 'GOPROXY', 'GOSUMDB', 'CLANG_MODULE_CACHE_PATH',
        'MACOSX_DEPLOYMENT_TARGET')}
    observations: list[dict[str, Any]] = []
    for round_index in range(4):
        offset = round_index % len(LANGUAGES)
        order = LANGUAGES[offset:]+LANGUAGES[:offset]
        for case in CASES:
            for language in order:
                label = f'round{round_index}-{case}-{language}'
                directory = local(OUTPUT/label)
                observations.append({'label': label, 'round': round_index,
                    'phase': 'warmup' if round_index == 0 else 'measurement', 'case': case,
                    'language': language, 'observed_order': list(order),
                    'commands': commands(language, case, directory, tools),
                    'execute': [str(directory/'program')]})
    design = {'plan': plan, 'files': frozen, 'tool_identity': tool_identity,
              'original_printf_experiment_receipts': original_receipts,
              'environment': selected_environment, 'observations': observations,
              'host_context': campaign.stamp(), 'qualification_claim': False}
    OUTPUT.mkdir()
    save(OUTPUT/'design.json', design)
    state: dict[str, Any] = {'state': 'preflight', 'qualification_claim': False,
        'design_sha256': campaign.sha(OUTPUT/'design.json'), 'preflight': [], 'observations': []}
    save(OUTPUT/'report.json', state)
    active: Any = None

    def interrupted(*_: Any) -> None:
        raise KeyboardInterrupt('comparison interrupted')

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)

    def verify() -> None:
        if campaign.sha(OUTPUT/'design.json') != state['design_sha256']:
            raise ValueError('frozen design changed')
        for name, sha in frozen.items():
            if campaign.sha(local(ROOT/name)) != sha:
                raise ValueError('frozen input changed: '+name)

    def run(record: dict[str, Any], stage: str, argv: list[str], cwd: Path,
            directory: Path, deadline: float, allowance: int) -> bool:
        nonlocal active
        metric: dict[str, Any] = {'stage': stage, 'argv': argv, 'cwd': str(cwd),
            'peak_sampled_process_tree_rss_bytes': 0, 'rss_samples': 0}
        record['stages'].append(metric)
        paths = {name: directory/(stage+'.'+name) for name in ('stdout', 'stderr')}
        streams = {name: local(path).open('xb') for name, path in paths.items()}
        selector = selectors.DefaultSelector()
        before = time.perf_counter_ns()
        size = 0
        next_sample = time.monotonic()
        def capture(label: str, chunk: bytes) -> None:
            nonlocal size
            streams[label].write(chunk[:max(0, allowance-size)])
            size += len(chunk)
            if size > allowance:
                metric['diagnostic_limit_exceeded'] = True
        try:
            if time.monotonic() >= deadline:
                metric['timed_out_before_launch'] = True
                return False
            active = measurement.Wait4Process(argv, cwd=local(cwd), env=env, stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            metric['pid'] = active.pid
            for label, pipe in [('stdout', active.stdout), ('stderr', active.stderr)]:
                assert pipe is not None
                os.set_blocking(pipe.fileno(), False)
                selector.register(pipe, selectors.EVENT_READ, label)
            while True:
                now = time.monotonic()
                if now >= deadline:
                    metric['timed_out'] = True
                    break
                for key, _ in selector.select(min(SAMPLE_SECONDS, max(0, deadline-now))):
                    chunk = os.read(key.fileobj.fileno(), 65536)
                    if not chunk:
                        selector.unregister(key.fileobj)
                    else:
                        capture(key.data, chunk)
                    if metric.get('diagnostic_limit_exceeded'):
                        break
                if metric.get('diagnostic_limit_exceeded') or active.poll() is not None and not selector.get_map():
                    break
                if time.monotonic() >= next_sample and active.poll() is None:
                    metric['peak_sampled_process_tree_rss_bytes'] = max(metric['peak_sampled_process_tree_rss_bytes'],
                        measurement.sampled_rss(active.pid, deadline))
                    metric['rss_samples'] += 1
                    next_sample += SAMPLE_SECONDS
        finally:
            selector.close()
            if active is not None:
                try:
                    cleaned = campaign.stop(active)
                    metric['remaining_owned_members'] = cleaned.remaining_owned_members
                    metric['cleanup_signal_observations'] = cleaned.signal_observations
                except campaign.CleanupError as error:
                    metric['cleanup_error'] = str(error)
                    metric['remaining_owned_members'] = error.result.remaining_owned_members
                finally:
                    metric.update(status=active.returncode,
                        cpu_user_seconds=active.usage.ru_utime if active.usage else None,
                        cpu_system_seconds=active.usage.ru_stime if active.usage else None)
                    for label, pipe in [('stdout', active.stdout), ('stderr', active.stderr)]:
                        if pipe is not None:
                            while size <= allowance:
                                try:
                                    chunk = os.read(pipe.fileno(), 65536)
                                except BlockingIOError:
                                    break
                                if not chunk:
                                    break
                                capture(label, chunk)
                            pipe.close()
                    active = None
            for stream in streams.values():
                stream.close()
            metric.update(wall_ns=time.perf_counter_ns()-before, observed_stream_bytes=size,
                          **{name: receipt(path) for name, path in paths.items()})
            save(OUTPUT/'report.json', state)
        if metric.get('cleanup_error'):
            raise RuntimeError('owned group cleanup failed: '+metric['cleanup_error'])
        return metric.get('status') == 0 and not any(metric.get(key) for key in
            ('timed_out', 'timed_out_before_launch', 'diagnostic_limit_exceeded'))

    try:
        verify()
        for language, argv, required in [
            ('rust', [str(tools['rust']), '--version'], 'rustc 1.85.1'),
            ('clang', [str(tools['clang']), '--version'], 'clang version 21.1.8')]:
            record = {'language': language, 'stages': []}
            state['preflight'].append(record)
            if not run(record, language+'-version', argv, ROOT, OUTPUT, time.monotonic()+10, LIMIT):
                raise ValueError(language+' version preflight failed')
            version = (OUTPUT/(language+'-version.stdout')).read_text().strip()
            record['reported_version'] = version
            if required not in version:
                raise ValueError(language+' version differs from fixed design')
        state['state'] = 'running'
        for observation in observations:
            verify()
            directory = local(OUTPUT/observation['label'])
            directory.mkdir()
            record = {key: value for key, value in observation.items() if key not in ('commands', 'execute')}
            record.update(stages=[], start_context=campaign.stamp(), build_complete=False,
                          expected_result_verified=False, materialization_verified=False)
            state['observations'].append(record)
            before = time.perf_counter_ns()
            deadline = time.monotonic()+180
            used = 0
            try:
                complete = True
                for command in observation['commands']:
                    if not run(record, command['stage'], command['argv'], Path(command['cwd']),
                               directory, deadline, max(0, LIMIT-used)):
                        complete = False
                        break
                    used += sum(record['stages'][-1][name]['bytes'] for name in ('stdout', 'stderr'))
                record['whole_build_wall_ns'] = time.perf_counter_ns()-before
                record['build_complete'] = complete and record['whole_build_wall_ns'] <= 180e9
                if not record['build_complete']:
                    continue
                if observation['language'] in ('rust', 'cpp'):
                    record['object_deployment'] = {unit: macho_deployment(directory/(unit+'.o'))
                                                   for unit in ('data', 'main')}
                artifact = directory/'program'
                record['artifact'] = receipt(artifact)
                size = plan['sizes'][observation['case']]
                if size and observation['language'] != 'lo':
                    pattern = b''.join(struct.pack('<q', (index*37+11)%101) for index in range(size))
                    if pattern not in artifact.read_bytes():
                        raise ValueError('artifact lacks complete materialized int64 DATA pattern')
                    record['materialization_verified'] = True
                    record['data_pattern_sha256'] = hashlib.sha256(pattern).hexdigest()
                else:
                    record['materialization_check'] = 'not applicable: empty case'
                if not run(record, 'execute', observation['execute'], ROOT, directory,
                           time.monotonic()+30, max(0, LIMIT-used)):
                    continue
                actual = (directory/'execute.stdout').read_text()
                expected = plan['expected'][observation['case']]
                if actual != expected+'\n':
                    raise ValueError('reference execution result differs')
                record['expected_result_verified'] = True
            except Exception as error:
                record['error'] = str(error)
                if any(stage.get('cleanup_error') for stage in record['stages']):
                    raise
            finally:
                record['files'] = {path.name: receipt(path) for path in sorted(directory.iterdir()) if path.is_file()}
                verify()
                record['post_observation_inputs_verified'] = True
                record['finish_context'] = campaign.stamp()
                if observation['round'] == 0 and observation['case'] == 'empty':
                    record['preflight'] = True
                    record['preflight_passed'] = bool(record['build_complete'] and
                        record['expected_result_verified'] and record.get('object_deployment'))
                    if not record['preflight_passed']:
                        state['preflight_failure'] = observation['label']
                        save(OUTPUT/'report.json', state)
                        raise ValueError('empty reference preflight failed; later observations prohibited')
                    if observation['language'] == 'cpp':
                        state['empty_preflights_passed'] = True
                save(OUTPUT/'report.json', state)
        state['summary'] = summarize(state['observations'])
        state['state'] = 'complete' if len(state['observations']) == 24 and all(
            record['build_complete'] and record['expected_result_verified'] for record in state['observations']) else 'incomplete'
        return 0 if state['state'] == 'complete' else 2
    except BaseException as error:
        state.update(state='preflight_failed' if state.get('preflight_failure') else 'invalid', error=str(error))
        return 2
    finally:
        state['summary'] = summarize(state['observations'])
        if active is not None:
            try:
                state['remaining_owned_members'] = campaign.stop(active).remaining_owned_members
            except BaseException as error:
                state['cleanup_error'] = str(error)
        save(OUTPUT/'report.json', state)
        print(json.dumps({'state': state['state'], 'report': str((OUTPUT/'report.json').relative_to(ROOT))}))


if __name__ == '__main__':
    raise SystemExit(main())
