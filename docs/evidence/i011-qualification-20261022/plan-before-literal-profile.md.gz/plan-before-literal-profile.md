# I011 execution plan

Task: Qualify the standalone compiler on both targets and remove Go generation.
Owned temporary directory: `_scratch/i011-20261020/`.
Use the primary checkout. Keep packages in `bin/distributions/`.

## Current state

I011 is in progress. The user removed quiet-host admission and kept all numeric thresholds.
Record external load as context. Keep all samples and run one owned timing job at a time.
The maintained campaign collects all eight lanes, then merges both target reports.
Do not retry automatically or select samples from different attempts.

Go generation and its embedded runtime bundle are removed.
All executable builds use LLVM, LLD, and the precompiled Rust runtime.
B001 through B004 are closed.
Source freeze7 passed full CI, both native corpora, and all 394 semantic references.
The unchanged packages passed all four offline combinations, Metal packaging, relocation, and nine rejection cases.
Both installed compiler hosts passed 500-step XOR training. All 56 component checks passed.
These results keep their original source identity in the maintained nonperformance receipt.

The revised producers passed startup diagnostics under a bounded CPU workload on both targets.
These results verify the measurement path under load. They do not establish full performance acceptance.
B006 passed all 25 focused campaign checks.
B005 passed 21 semantic scenarios on each target after the first capture correction.
The next CI run exposed the same defect in another synchronous capture fixture.
That CI run stopped cleanly. Its owned process group is empty.
B005 corrected all seven synchronous capture fixtures with one shared regular-file helper.
Its 178 Darwin and 176 Linux checks passed, as did the host-to-Linux capture staging check.
Preserve the concurrent readiness pipe. Keep runtime, compiler, packages, and numeric limits unchanged.

## Current files and evidence

Use `_scratch/i011-20261020/measurement-capture-final/` for the complete capture correction and next candidate.
The fixture worker uses its `fixture-capture/` subdirectory.
The `stalled-device/` subdirectory retains the second blocked fixture and process observation.
Preserve the prior candidate under `_scratch/i011-20261020/measurement-contract-final/`.
Its source identity is `02c7b7dee63dca37cdc0f767972d376a2b6ff0341d301e4312a6ee687640e6c1`.
Source freeze7 retains identity `30456a563ea64716d16e3b0d954338fae144fdde5b66a13f570c31c6bbf501e2`.
Do not relabel old execution records with a new aggregate source identity.
The preservation index retains prior campaigns and failed checks as historical evidence.
The current source identity is `b81dcd1d1928d92fe44c582488c05d4090651a8bf2051576aef0a8b60208d2dc`.
Independent review approved its 32 source differences and all 339 unchanged package files.
Driver exec `80904` completed fresh CI and now runs one full campaign.
The native lane passed 2,635 cases without failures or skips. All 197 qualification-tool checks passed.
The user requested documented findings before corrective work.
`docs/native-qualification-findings.md` records the snapshot at `2026-10-22T02:47:26Z`.
Darwin execution and process lanes passed. All four Darwin HTTP gates are inconclusive.
Build observations are partial. Linux lanes and final audits remain pending.
Keep the current campaign unchanged. Do not start fixes or additional experiments during this documentation step.

## Remaining work

- [x] Review and implement the revised measurement contract.
- [x] Verify both public producers during a bounded background workload.
- [x] Correct B006 and pass its focused checks.
- [x] Preserve the second blocked fixture and stop owned CI processes.
- [x] Complete B005 with bounded stdout and stderr regressions.
- [x] Pass all affected fixture groups on both supported targets.
- [x] Review the complete correction and record new source identities.
- [x] Verify bounded reuse of unchanged package and semantic evidence.
- [x] Pass fresh final CI after the last correction.
- [ ] Run one complete eight-lane campaign and both strict target merges.
- [ ] Report absolute costs, paired ratios, uncertainty, and supported next actions.
- [x] Record interim findings before corrective work, with immutable evidence copies and explicit limits.
- [ ] Complete document checks, the evidence audit, and independent completion review.
- [x] Close B005 and B006 after their required checks pass.
- [ ] Close I011 only after all required gates pass.
- [ ] After task completion, preserve useful evidence and remove the owned temporary directory and plans.

## Ownership

The fixtures worker owns the seven capture fixtures, their shared helper, related integration tests, and opted-in guest transport.
The primary agent owns process control, plans, issues, evidence, source inventories, and final integration.
The architect reviews shared changes, repeated failures, bounded evidence reuse, and final completion.
Requested worker assignment: `mpr-worker`, `gpt-6.1-sol`, `medium`.
Requested architect assignment: `mpr-architect`, `gpt-6-astra`, `high`.
Actual assignment telemetry is unavailable.
Keep all files, caches, and child process output inside Lo. Preserve other agents' edits.
Do not examine or change file permission modes. Do not require physical devices.

## Decision value

Correctness and offline acceptance support the compiler migration.
Performance measurements qualify the fixed workloads in the recorded environments.
They cannot select between LLVM and Cranelift or promise performance on every machine.
A failed timing gate identifies an investigation scope, not its cause.
An inconclusive result leaves acceptance unresolved.
Do not add an experiment without a specified decision and a design fixed before execution.
If all required gates pass, complete the evidence review and stop I011 performance work.
