"""Run fresh final CI, then the maintained full campaign with frozen inputs."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools/nativebench'))
from campaign import stop


def stamp():
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'monotonic': time.monotonic()}


def main():
    state_path = BASE / 'validation-status.json'
    if state_path.exists():
        raise ValueError('validation status already exists')
    env = dict(os.environ, CI='1', PYTHONDONTWRITEBYTECODE='1')
    env.pop('LO_TEST_BACKEND', None)
    state = {'start': stamp(), 'state': 'running', 'jobs': [], 'active_owned_jobs': []}
    child = None
    active = None
    def save():
        state_path.write_text(json.dumps(state, indent=2) + '\n')
    def verify(stage):
        with (BASE / ('freeze-' + stage + '.log')).open('xb') as output:
            subprocess.run([sys.executable, '-B', str(BASE / 'freeze-and-reuse.py'), 'verify'],
                cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, check=True)
    def interrupted(*_):
        raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        verify('before-ci')
        jobs = [
            ('ci', ['make', '-s', 'ci', 'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                'LLVM_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json',
                'SEMANTIC_COMPILER=bin/distributions/lo-darwin-arm64-metal/bin/lo',
                'SEMANTIC_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json',
                'NATIVE_RUNTIME_STATE=_scratch/native-runtime', 'TEST_ARGS=-json -count=1'],
                dict(env, LO_TEST_COMPILER=str(ROOT / 'bin/distributions/lo-darwin-arm64-metal/bin/lo'))),
            ('performance', ['make', '-s', 'benchmark-native-campaign',
                'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                'NATIVE_CAMPAIGN_WORK=' + str(BASE / 'full-campaign'),
                'LINUX_ACCELERATOR=hvf'], env),
        ]
        save()
        for name, argv, environment in jobs:
            active = {'name': name, 'command': argv, 'start': stamp(), 'status': None}
            state['jobs'].append(active)
            with (BASE / (name + '.stdout')).open('xb') as stdout, (BASE / (name + '.stderr')).open('xb') as stderr:
                child = subprocess.Popen(argv, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                    stdout=stdout, stderr=stderr, start_new_session=True)
                active['pid'] = child.pid
                state['active_owned_jobs'] = [child.pid]
                save()
                status = child.wait()
            child = None
            active.update(status=status, finish=stamp())
            state['active_owned_jobs'] = []
            for stream in ('stdout', 'stderr'):
                path = BASE / (name + '.' + stream)
                active[stream] = {'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            save()
            verify('after-' + name)
            if status:
                state['state'] = name + '-nonzero'
                return status
        state['state'] = 'passed'
        return 0
    except KeyboardInterrupt:
        state.update(state='interrupted', error='owned validation interrupted')
        return 130
    except Exception as error:
        state.update(state='invalid', error=str(error))
        return 2
    finally:
        if child is not None:
            stop(child)
            active.update(status=child.returncode, finish=stamp())
        state['active_owned_jobs'] = []
        state['finish'] = stamp()
        save()


if __name__ == '__main__':
    raise SystemExit(main())
