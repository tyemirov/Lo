.PHONY: i011-fixture-capture-linux
i011-fixture-capture-linux: | tool-state
	python3 -B tools/loqualification/suite.py --preparation _scratch/native-runtime --package bin/distributions/lo-linux-arm64-software --matrix testdata/semantic-migration/matrix.json --work _scratch/i011-20261020/measurement-contract/fixture-capture/linux-semantic-green-run2 --go "$(shell command -v $(GO))" --accelerator hvf --timeout 180 --pattern TestSemanticNative </dev/null
