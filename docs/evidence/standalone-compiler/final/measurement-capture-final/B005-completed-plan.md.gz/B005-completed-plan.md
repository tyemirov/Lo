# B005 execution plan

Task: Correct synchronous fixture capture without a runtime change.
Owned task files: `_scratch/i011-20261020/measurement-contract/fixture-capture/`.
Correction files: `_scratch/i011-20261020/measurement-capture-final/fixture-capture/`.
Use the primary checkout and preserve other agents' changes.

- [x] Read the issue, code, and repository guides.
- [x] Preserve the stalled CI process sample and generated artifact.
- [x] Obtain independent approval for regular-file capture.
- [x] Add a bounded public regression and preserve its expected failure.
- [x] Correct capture, preserve complete output, and retain all semantic assertions.
- [x] Pass the regression and all affected scenarios on both supported targets.
- [x] Run fresh final CI with the completed stack.
- [x] Update the issue and remove this plan after completion.

The fixtures worker owns the capture fixture and its bounded test changes.
The primary agent owns process control, evidence, documentation, and final integration.
Keep all files and tool state inside Lo. Do not examine or change file permission modes.
Create the capture file only for scenarios that use capture.

## Complete capture correction

Fresh CI stopped at the device resource failure case with the same pipe capture defect.
Six other fixtures invoke the CLI before they read the output pipe.
The architect approved one shared regular-file capture helper for these fixtures and the semantic fixture.
Preserve the concurrent readiness pipe in `device-http-lifetime.c`.

- [x] Preserve the second CI observation and stop its owned processes.
- [x] Add bounded regressions for large stdout and stderr through the public CLI.
- [x] Replace all synchronous pipe capture with the shared helper.
- [x] Preserve complete bounded output, descriptor restoration, cleanup, and all existing assertions.
- [x] Prepare the capture file in the selected host or guest scenario directory.
- [x] Run all affected fixture groups on both supported targets.
- [x] Review the source changes and preserve fresh fixture evidence before final CI.
