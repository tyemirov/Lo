# B006 execution plan

Task: Preserve campaign terminal records after owned-process cleanup errors.
Owned task files: `_scratch/i011-20261020/measurement-contract/cleanup-finalization/`.
Use the primary checkout and preserve other agents' changes.

- [x] Read the issue and repository guides.
- [x] Preserve the EPERM traceback and the empty owned-group inventory.
- [x] Obtain independent approval for bounded process inventory and guaranteed finalization.
- [x] Add failing public boundary tests for observation, signaling, and finalization errors.
- [x] Correct owned-group cleanup and retain separate primary and cleanup errors.
- [x] Pass focused campaign checks and fresh final CI.
- [x] Update the issue and remove this plan after completion.

The optimization worker owns `campaign.py` and `test_campaign.py`.
The primary agent owns the new validation driver, evidence, and documentation.
Keep all files and tool state inside Lo. Do not inspect file permission modes.
Observe process IDs and group IDs only. Never signal an unrelated process group.
