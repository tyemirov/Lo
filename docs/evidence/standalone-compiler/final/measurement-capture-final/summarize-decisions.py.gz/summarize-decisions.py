"""Summarize the completed campaign for decisions without changing its gates."""
from pathlib import Path
import hashlib
import json
import statistics

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]


def main():
    output=BASE/'decision-results.json'
    if output.exists():
        raise ValueError('decision result output must be fresh')
    summary=json.loads((BASE/'full-campaign/report.json').read_text())
    if summary.get('state')!='complete' or not summary.get('measurement_complete'):
        raise ValueError('decision summary requires a complete valid campaign')
    targets={}
    for target in ('darwin','linux'):
        path=BASE/'full-campaign'/f'{target}-merged.json'
        raw=json.loads(path.read_text())
        data={'source_report':str(path.relative_to(ROOT)), 'source_report_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
              'gates_passed':raw['gates_passed'],'gate_failures':raw['gate_failures'],
              'callback_speedup':raw['callback_speedup'],'callback_interval':raw['callback_bootstrap_95_percent'],
              'callback_gate':raw['callback_gate'],'execution':[],'process':[],'http':[],'build':[]}
        for lane in ('execution','process'):
            for case in raw[lane]:
                samples=case['samples'] if lane=='execution' else case['samples_ns']
                medians={backend:statistics.median([pair['results'][backend]['ns'] if lane=='execution' else pair[backend] for pair in samples]) for backend in ('native','interpreter')}
                data[lane].append({'case':case['name'],'median_ns':medians,
                    'paired_ratio':case['native_over_interpreter'],'interval':case['bootstrap_95_percent'],'gate':case['gate'],
                    'gate_scope':'callback aggregate' if lane=='execution' and case['name'].startswith(('map_','filter_','fold_')) else 'individual'})
        for case in raw['http']:
            data['http'].append({'case':case['name'],'median_p95_ns':{backend:statistics.median(pair[backend]['p95_ns'] for pair in case['samples']) for backend in ('native','interpreter')},
                'median_requests_per_second':{backend:statistics.median(pair[backend]['requests_per_second'] for pair in case['samples']) for backend in ('native','interpreter')},
                'p95':case['p95'],'reciprocal_throughput':case['reciprocal_throughput']})
        for name in dict.fromkeys(case['name'] for case in raw['build']):
            samples=[case for case in raw['build'] if case['name']==name]
            measured=[case['elapsed_ns'] for case in samples if case['phase']=='measurement']
            data['build'].append({'case':name,'first_build_ns':next(case['elapsed_ns'] for case in samples if case['phase']=='first-build'),
                'median_measured_ns':statistics.median(measured),'maximum_elapsed_ns':max(case['elapsed_ns'] for case in samples),
                'maximum_sampled_rss_bytes':max(case['peak_process_tree_rss_bytes'] for case in samples),
                'maximum_artifact_bytes':max(case['artifact_bytes'] for case in samples),'maximum_diagnostic_bytes':max(case['diagnostic_bytes'] for case in samples)})
        targets[target]=data
    result={'issue':'I011','qualification_outcome':summary['qualification_outcome'],'targets':targets,
        'limits':['Absolute costs describe the recorded environments.','The paired ratio is the median of individual ratios, not the ratio of the two displayed medians.','Timing identifies an investigation scope, not a causal profile.','All source measurements remain in the merged reports.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'qualification_outcome':result['qualification_outcome'],'output':str(output.relative_to(ROOT))}))


if __name__=='__main__':
    main()
