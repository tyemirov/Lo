"""Run final CI and one full serial campaign against the recorded source inventory."""
from __future__ import annotations

from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools/nativebench'))
from campaign import CleanupError, stop


def stamp() -> dict[str, Any]:
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'monotonic': time.monotonic()}


def main() -> int:
    state_path = BASE / 'validation-status.json'
    if state_path.exists():
        raise ValueError('validation status already exists')
    env = dict(os.environ, CI='1', PYTHONDONTWRITEBYTECODE='1')
    env.pop('LO_TEST_BACKEND', None)
    state: dict[str, Any] = {'start': stamp(), 'state': 'running', 'jobs': [],
                            'remaining_owned_members': [], 'active_owned_jobs': [], 'cleanup_errors': []}
    child: subprocess.Popen[Any] | None = None
    active: dict[str, Any] | None = None
    result = 2

    def save() -> None:
        temporary = state_path.with_name('.validation-status.tmp')
        temporary.write_text(json.dumps(state, indent=2, allow_nan=False) + '\n')
        temporary.replace(state_path)

    def verify(stage: str) -> None:
        with (BASE / ('freeze-' + stage + '.log')).open('xb') as output:
            subprocess.run([sys.executable, '-B', str(BASE / 'freeze-and-reuse.py'), 'verify'],
                cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, check=True)

    def interrupted(*_: Any) -> None:
        raise KeyboardInterrupt()

    def cleanup() -> None:
        nonlocal child
        if child is None:
            return
        try:
            observed = stop(child)
            state['remaining_owned_members'] = list(observed.remaining_owned_members)
            state.setdefault('cleanup_signal_observations', []).extend(observed.signal_observations)
        except CleanupError as error:
            state['cleanup_errors'].append(str(error))
            observed = error.result
            state['remaining_owned_members'] = (None if observed.remaining_owned_members is None
                                                else list(observed.remaining_owned_members))
            state.setdefault('cleanup_signal_observations', []).extend(observed.signal_observations)
        except Exception as error:
            state['cleanup_errors'].append('owned cleanup failed: ' + str(error))
            state['remaining_owned_members'] = None
        finally:
            if active is not None:
                active['status'] = child.returncode
            state['active_owned_jobs'] = state['remaining_owned_members']
            child = None

    def artifacts() -> None:
        if active is None:
            return
        active['finish'] = stamp()
        for stream in ('stdout', 'stderr'):
            path = BASE / (active['name'] + '.' + stream)
            try:
                with path.open('rb') as source:
                    digest = hashlib.file_digest(source, 'sha256').hexdigest()
                active[stream] = {'path': str(path.relative_to(ROOT)), 'sha256': digest}
            except Exception as error:
                state['cleanup_errors'].append(stream + ' artifact hashing failed: ' + str(error))

    previous = {number: signal.getsignal(number) for number in (signal.SIGTERM, signal.SIGINT)}
    for number in previous:
        signal.signal(number, interrupted)
    try:
        verify('before-ci')
        jobs = [
            ('ci', ['make', '-s', 'ci', 'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                'LLVM_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json',
                'SEMANTIC_COMPILER=bin/distributions/lo-darwin-arm64-metal/bin/lo',
                'SEMANTIC_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json',
                'NATIVE_RUNTIME_STATE=_scratch/native-runtime', 'TEST_ARGS=-json -count=1'],
                dict(env, LO_TEST_COMPILER=str(ROOT / 'bin/distributions/lo-darwin-arm64-metal/bin/lo'))),
            ('performance', ['make', '-s', 'benchmark-native-campaign',
                'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                'NATIVE_CAMPAIGN_WORK=' + str(BASE / 'full-campaign'), 'LINUX_ACCELERATOR=hvf'], env),
        ]
        save()
        for name, argv, environment in jobs:
            active = {'name': name, 'command': argv, 'start': stamp(), 'status': None}
            state['jobs'].append(active)
            with (BASE / (name + '.stdout')).open('xb') as stdout, (BASE / (name + '.stderr')).open('xb') as stderr:
                child = subprocess.Popen(argv, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                    stdout=stdout, stderr=stderr, start_new_session=True)
                active['pid'] = child.pid
                state['active_owned_jobs'] = [child.pid]
                state['remaining_owned_members'] = None
                save()
                active['status'] = child.wait()
            cleanup()
            artifacts()
            save()
            if state['cleanup_errors']:
                raise ValueError('validation finalization failed')
            verify('after-' + name)
            if active['status']:
                state['state'] = name + '-nonzero'
                result = active['status']
                break
        else:
            state['state'] = 'passed'
            result = 0
    except KeyboardInterrupt:
        state.update(state='interrupted', error='owned validation interrupted')
        result = 130
    except Exception as error:
        state.update(state='invalid', error=str(error))
        result = 2
    finally:
        for number in previous:
            signal.signal(number, signal.SIG_IGN)
        try:
            cleanup()
            artifacts()
            if state['cleanup_errors'] and state['state'] == 'passed':
                state.update(state='invalid', error='validation finalization failed')
                result = 2
            state['finish'] = stamp()
        finally:
            try:
                save()
            finally:
                for number, handler in previous.items():
                    signal.signal(number, handler)
    return result


if __name__ == '__main__':
    raise SystemExit(main())
