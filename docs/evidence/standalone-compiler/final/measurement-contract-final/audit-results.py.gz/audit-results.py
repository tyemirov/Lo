"""Audit completed measurement evidence without executing any validation jobs.

Complete valid failed/inconclusive gates produce a valid audit with
performance_passed=false. This audit does not close I011 or replace final review.
"""
from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'docs/evidence/standalone-compiler'
sys.path.insert(0, str(ROOT / 'tools/nativebench'))
import campaign
import identity
import merge
import qualification


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def local(path: Path) -> Path:
    path = path.resolve()
    require(path.is_relative_to(ROOT), 'audit path leaves Lo: '+str(path))
    return path


def sha(path: Path) -> str:
    with local(path).open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(local(path).read_text(), object_pairs_hook=merge.unique_object, parse_constant=merge.reject_constant)
    require(isinstance(value,dict),'expected object: '+str(path))
    return value


def expected_source() -> str:
    value=load(BASE/'frozen-inputs.json')['semantic_source_sha256']
    require(isinstance(value,str) and len(value)==64 and all(c in '0123456789abcdef' for c in value),'invalid final frozen source identity')
    return value


def receipt(path: Path) -> dict[str,str]:
    return {'path':local(path).relative_to(ROOT).as_posix(),'sha256':sha(path)}


def verify_record(record: dict[str,Any]) -> Path:
    path = local(ROOT/record['path'])
    require(sha(path)==record['sha256'],'record digest differs: '+str(path))
    return path


def module(name: str,path: Path) -> Any:
    spec=importlib.util.spec_from_file_location(name,local(path))
    require(spec is not None and spec.loader is not None,'audit module unavailable')
    value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value)
    return value


def archive_record(record: dict[str,Any]) -> None:
    path=local(EVIDENCE/record['archive'])
    require(sha(path)==record['archive_sha256'],'compressed archive digest differs: '+str(path))
    require(hashlib.sha256(gzip.decompress(path.read_bytes())).hexdigest()==record['sha256'],
            'decoded archive digest differs: '+str(path))


def reuse_audit(review_path: Path) -> dict[str,Any]:
    freezer=module('lo_measurement_audit_freezer',BASE/'freeze-and-reuse.py')
    frozen=load(BASE/'frozen-inputs.json')
    require(freezer.current()==frozen,'freeze-and-reuse verify: current sources/packages differ')
    require(frozen['semantic_source_sha256']==expected_source(),'current source identity differs')
    old=load(ROOT/'_scratch/i011-20261020/frozen-inputs-7.json')
    require(frozen['packages']==old['packages'] and len(frozen['packages'])==339,'339 unchanged package inputs not proved')
    reviewed=load(BASE/'nonperformance-reuse-reviewed.json')
    retained=load(EVIDENCE/'nonperformance-reuse.json')
    review=load(review_path)
    require(review.get('status')=='approved_bounded_reuse_and_load_diagnostic' and review.get('findings')==[] and
            review.get('source_sha256')==expected_source() and review.get('i011_complete') is False,'bounded reuse/load review not approved')
    for name,expected in review['reviewed_sha256'].items():
        path=BASE/'nonperformance-reuse-reviewed.json' if name=='docs/evidence/standalone-compiler/nonperformance-reuse.json' else ROOT/name
        require(sha(path)==expected,'reviewed identity changed: '+name)
    require(retained.get('independent_review',{}).get('sha256')==sha(review_path),'maintained receipt does not bind bounded approval')
    archive_record(retained['independent_review'])
    before=copy.deepcopy(reviewed);after=copy.deepcopy(retained)
    before.pop('status');after.pop('status');after.pop('independent_review')
    require(before==after,'reviewed reuse claims changed beyond status/review receipt')
    changes=[]
    for group in ('sources','measurement_sources'):
        for name in sorted(old[group].keys()|frozen[group].keys()):
            a,b=old[group].get(name),frozen[group].get(name)
            if a!=b:
                require(name in freezer.ALLOWED,'unreviewed implementation difference: '+name)
                changes.append({'inventory':group,'path':name,'before_sha256':a,'after_sha256':b,
                    'change':'added' if a is None else 'removed' if b is None else 'changed',
                    'impact':freezer.impact(name)})
    require(retained['changes']==changes,'exact reviewed source differences disagree')
    require(retained['current_semantic_source_sha256']==expected_source() and retained['original_semantic_source_sha256']==old['semantic_source_sha256'],
            'reuse current/original execution identities disagree')
    require(retained['unchanged_package_files']==339,'reuse package count differs')
    require(retained['current_inventory']['sha256']==sha(BASE/'frozen-inputs.json') and
            retained['original_inventory']['sha256']==sha(ROOT/'_scratch/i011-20261020/frozen-inputs-7.json'), 'reuse inventory bindings differ')
    require(len(retained['retained_evidence'])==18,'reuse must retain all eighteen old records')
    require(len({item['source'] for item in retained['retained_evidence']})==18,'duplicate old evidence record')
    for record in retained['retained_evidence']:archive_record(record)
    affected=affected_acceptance(retained,freezer)
    return {'affected_acceptance_evidence':affected,'bounded_reuse_approved':True,'receipt':receipt(EVIDENCE/'nonperformance-reuse.json'),
        'reviewed_copy':receipt(BASE/'nonperformance-reuse-reviewed.json'),'review':receipt(review_path),
        'frozen_inputs':receipt(BASE/'frozen-inputs.json'),'verified_unchanged_package_files':339,
        'verified_old_archives':18,'exact_source_changes':changes,
        'current_source_identity':expected_source(),'old_execution_identity':old['semantic_source_sha256'],
        'limit':'Old semantic/offline execution retains its original identity; it is not a new Linux corpus or strict report.'}


def affected_acceptance(retained: dict[str,Any],freezer: Any) -> dict[str,Any]:
    affected=retained['affected_acceptance_evidence']
    require(set(affected)=={'handoff','source_changes','darwin_green','linux_hvf_green','linux_receipt'},'affected acceptance schema differs')
    handoff_path=verify_record(affected['handoff']);handoff=load(handoff_path)
    require(handoff['issue']=='B005' and affected['source_changes']==handoff['changes'] and
            {item['path'] for item in handoff['changes']}==freezer.AFFECTED,'B005 affected source inventory differs')
    for item in handoff['changes']:
        require(sha(ROOT/item['path'])==item['after_sha256'],'B005 affected source changed')
    require(handoff['red']['counts']['fail']>0 and handoff['red']['package_passed'] is False,'B005 expected failure absent')
    verify_record(handoff['red']['receipt'])
    for lane in ('darwin_green','linux_hvf_green'):
        detail=affected[lane];require(detail==handoff[lane],'B005 lane handoff differs')
        require(detail['counts']=={'pass':21,'fail':0,'skip':0} and detail['package_passed'] is True,'B005 affected checks did not pass')
        path=verify_record(detail['receipt'])
        events=[json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
        actual={name:sum(event.get('Action')==name and bool(event.get('Test')) for event in events) for name in ('pass','fail','skip')}
        require(actual==detail['counts'],'B005 raw affected counts differ')
        require(any(event.get('Action')=='pass' and event.get('Test')=='TestSemanticNativeCaptureLargeOutput/native-runtime' for event in events),'B005 large-output regression absent')
        require(any(event.get('Action')=='pass' and not event.get('Test') for event in events),'B005 package pass absent')
    require(affected['linux_receipt']==handoff['linux_receipt'],'B005 Linux suite receipt differs')
    linux=load(verify_record(affected['linux_receipt']))
    require(linux['target']=='linux/arm64' and linux['accelerator']=='hvf' and len(linux['cases'])==1 and linux['cases'][0]['status']==0,'B005 Linux HVF suite did not pass')
    return {**affected,'scope':'Fresh affected B005 checks only; retained old full corpus keeps its original execution identity.'}


def ci_audit(state: dict[str,Any]) -> dict[str,Any]:
    jobs=state['jobs'];require([item['name'] for item in jobs]==['ci','performance'],'validation job sequence differs')
    ci=jobs[0];require(ci.get('status')==0 and 'finish' in ci,'final CI did not complete successfully')
    output=verify_record(ci['stdout']);verify_record(ci['stderr'])
    semantic=module('lo_measurement_audit_semantic',ROOT/'tools/semanticcoverage/report.py')
    executions=[];active=None
    for line in output.read_text().splitlines():
        if not line.startswith('{'):continue
        event=json.loads(line)
        require(event.get('Action')!='fail','CI contains a failed test/package event')
        if event.get('Package')!=semantic.PACKAGE:continue
        action,test=event.get('Action'),event.get('Test')
        if action=='start' and not test:
            require(active is None,'overlapping integration package executions')
            active={'statuses':{},'identities':[]}
        elif active is not None:
            if action=='output' and test=='TestSemanticCoverageRunIdentity' and semantic.IDENTITY_MARKER in event.get('Output',''):
                active['identities'].append(json.loads(event['Output'].split(semantic.IDENTITY_MARKER,1)[1]))
            elif test and action in ('pass','fail','skip'):
                require(test not in active['statuses'],'duplicate CI test completion: '+test)
                active['statuses'][test]=action
            elif not test and action in ('pass','fail','skip'):
                require(action=='pass','integration package did not pass')
                executions.append(active);active=None
    require(active is None and len(executions)==2,'CI must complete exactly two integration package executions')
    results={}
    matrix_sha=sha(ROOT/'testdata/semantic-migration/matrix.json')
    for execution in executions:
        require(len(execution['identities'])==1,'CI must retain one original identity marker per package execution')
        actual=execution['identities'][0];semantic.verify_identity(actual)
        require(actual['source_sha256']==expected_source() and actual['matrix_sha256']==matrix_sha and actual['target']=='darwin/arm64',
                'CI source/matrix/target identity differs')
        require(actual['compiler']=='bin/distributions/lo-darwin-arm64-metal/bin/lo','CI did not use declared installed Metal compiler')
        require(actual['backend'] not in results,'duplicate CI backend lane')
        for gate in semantic.COVERAGE_GATES:
            require(execution['statuses'].get(gate)=='pass','CI semantic coverage gate did not pass: '+gate)
        require(execution['statuses'].get('TestSemanticNativeCaptureLargeOutput/native-runtime')=='pass', 'fresh CI B005 regression did not pass')
        results[actual['backend']]={'identity':actual,'counts':{name:sum(value==name for value in execution['statuses'].values()) for name in ('pass','fail','skip')}}
    require(set(results)=={'interpreter','llvm'},'CI lacks interpreter/native package pair')
    return {'passed':True,'stdout':receipt(output),'stderr':receipt(ROOT/ci['stderr']['path']),'lanes':results,
            'limit':'Fresh Darwin CI identities only; old Linux corpus remains under bounded reuse.'}


def performance_audit(state: dict[str,Any]) -> dict[str,Any]:
    directory=BASE/'full-campaign';summary=load(directory/'report.json');config=load(directory/'config.json')
    require(summary.get('state')=='complete' and summary.get('measurement_complete') is True and not summary.get('error'),
            'full campaign is incomplete or invalid')
    require(not summary.get('cleanup_error') and summary.get('remaining_owned_members')==[] and
            isinstance(summary.get('cleanup_signal_observations'),list) and
            all(isinstance(item,str) for item in summary['cleanup_signal_observations']), 'campaign cleanup evidence incomplete or failed')
    require(summary['config_sha256']==sha(directory/'config.json'),'campaign config digest differs')
    require(config['samples']==10 and config['warmup']==3 and config['concurrency']==1 and
            config['load_policy']==identity.LOAD_POLICY and config['accelerator']=='hvf' and
            config['lanes']==list(qualification.LANES),'campaign measurement contract differs')
    expected_paths={'darwin_package':ROOT/'bin/distributions/lo-darwin-arm64-software',
        'linux_package':ROOT/'bin/distributions/lo-linux-arm64-software','preparation':ROOT/'_scratch/native-runtime',
        'frontend':ROOT/'bin/distributions/lo-darwin-arm64-software/bin/lo','work':directory}
    require(config['paths']=={key:str(value) for key,value in expected_paths.items()},'campaign declared paths differ')
    arguments=argparse.Namespace(**expected_paths,accelerator='hvf')
    observed=campaign.snapshot(arguments)
    require(all(config[key]==value for key,value in observed.items()),'current campaign snapshot differs from predeclared inputs')
    require(all(value['source']['semantic_source_sha256']==expected_source() for value in config['source_identity'].values()),'campaign source differs')
    expected=[(target,lane) for target in ('darwin','linux') for lane in qualification.LANES]
    require([(item['target'],item['lane']) for item in summary['subprocesses']]==expected,'campaign must contain exactly eight ordered unique whole lanes, without retries')
    lane_paths={target:[] for target in ('darwin','linux')};lanes=[]
    for item in summary['subprocesses']:
        target,lane=item['target'],item['lane'];path=directory/f'{target}-{lane}'/'report.json'
        require(item['report']==path.relative_to(ROOT).as_posix() and item['report_sha256']==sha(path),'lane report binding differs')
        require(item['measurement_complete'] is True and 'finish' in item,'lane measurement incomplete')
        for stream in ('stdout','stderr'):
            require(sha(ROOT/item[stream])==item[stream+'_sha256'],'lane log digest differs')
        report,_=merge.admit(path)
        require(report['lanes']==[lane] and report['merge_identity']['target']==target+'/arm64','lane target/inventory differs')
        actual=report['merge_identity'];declared=config['source_identity'][target]
        require(actual['package']==config['packages'][target] and actual['measurement']['samples']==10 and
                actual['measurement']['warmup']==3 and actual['measurement']['load_policy']==identity.LOAD_POLICY,'lane package/sample/load contract differs')
        require(actual['accelerator']==('none' if target=='darwin' else 'hvf'),'lane accelerator differs')
        require(all(actual[key]==declared[key] for key in ('source','harness','evaluator')) and
                actual['producer']['source_identity']==declared['producer']['source_identity'] and
                actual['reference']['source_identity']==declared['reference']['source_identity'],'lane source provenance differs')
        identity.verify_source_identity(ROOT,actual)
        calculated=copy.deepcopy(report);qualification.completion(calculated,0)
        require(calculated['measurement_complete'] is True and not calculated.get('measurement_error'),'lane measurement invalid')
        require(item['status']==(0 if calculated['gates_passed'] else 2),'Make lane exit disagrees with recomputed gates')
        require(item['qualification_outcome']==campaign.outcome(calculated) and item['gate_failures']==calculated['gate_failures'],'lane outcome differs')
        require(report['gates_passed']==calculated['gates_passed'] and report['gate_failures']==calculated['gate_failures'],'stored lane gates differ')
        lane_paths[target].append(path)
        lanes.append({'target':target,'lane':lane,'report':receipt(path),'status':item['status'],
            'qualification_outcome':item['qualification_outcome'],'gate_failures':calculated['gate_failures']})
    require([item['target'] for item in summary['merges']]==['darwin','linux'],'campaign must retain two target merges')
    merges={};all_failures=[]
    for item in summary['merges']:
        target=item['target'];path=directory/(target+'-merged.json')
        calculated=merge.merge(lane_paths[target]);stored=load(path)
        require(stored==calculated,'stored target merge differs from maintained recomputation: '+target)
        require(item['report']==path.relative_to(ROOT).as_posix() and item['report_sha256']==sha(path) and item['measurement_complete'] is True,'merge receipt differs')
        require(item['qualification_outcome']==campaign.outcome(calculated) and item['gate_failures']==calculated['gate_failures'],'merge gate outcome differs')
        require(calculated['measurement_complete'] is True,'merged measurement incomplete')
        all_failures.extend(target+':'+failure for failure in calculated['gate_failures'])
        merges[target]={'report':receipt(path),'performance_passed':calculated['gates_passed'],
            'qualification_complete':calculated['qualification_complete'],'gate_failures':calculated['gate_failures'],
            'callback_speedup':calculated['callback_speedup'],'callback_bootstrap_95_percent':calculated['callback_bootstrap_95_percent'],
            'max_build_seconds':max(row['elapsed_ns'] for row in calculated['build'])/1e9,
            'max_build_rss_bytes':max(row['peak_process_tree_rss_bytes'] for row in calculated['build']),
            'max_artifact_bytes':max(row['artifact_bytes'] for row in calculated['build']),
            'max_diagnostic_bytes':max(row['diagnostic_bytes'] for row in calculated['build'])}
    outcomes=[item['qualification_outcome'] for item in summary['merges']]
    outcome='fail' if 'fail' in outcomes else 'inconclusive' if 'inconclusive' in outcomes else 'pass'
    require(summary['qualification_outcome']==outcome,'campaign aggregate outcome differs')
    require(state['jobs'][1]['status']==(0 if outcome=='pass' else 2),'outer Make status disagrees with completed campaign outcome')
    for stream in ('stdout','stderr'):verify_record(state['jobs'][1][stream])
    return {'completed_measurement':True,'performance_passed':outcome=='pass','qualification_outcome':outcome,
        'gate_failures':all_failures,'config':receipt(directory/'config.json'),'campaign':receipt(directory/'report.json'),
        'lanes':lanes,'targets':merges,'no_automatic_retries':True,
        'cleanup_signal_observations':summary['cleanup_signal_observations'],'remaining_owned_members':summary['remaining_owned_members']}


def load_audit() -> dict[str,Any]:
    directory=BASE/'load-diagnostic-1';status=load(directory/'status.json')
    require(status.get('complete') is True and status.get('diagnostic_valid') is True and status.get('error') is None and status.get('terminal_state')=='valid' and
            status.get('cleanup_errors')==[] and status.get('finalization_errors')==[],'controlled load diagnostic incomplete/invalid')
    require([item['target'] for item in status['runs']]==['darwin/arm64','linux/arm64'],'load diagnostic lacks both software targets')
    cleanup=[status['worker_cleanup'],*status['benchmark_cleanup']]
    require(len(cleanup)==3 and all(item.get('reaped') is True and type(item.get('returncode')) is int and
            item.get('remaining_owned_members')==[] and item.get('cleanup_error') is None and
            isinstance(item.get('signal_observations'),list) for item in cleanup),'owned load diagnostic children not all reaped')
    require(status['worker_cleanup']['pid']==status['worker']['pid'] and status['worker_cleanup']['returncode']==0, 'CPU worker cleanup identity/status differs')
    require([item['pid'] for item in status['benchmark_cleanup']]==[item['pid'] for item in status['runs']] and
            [item['returncode'] for item in status['benchmark_cleanup']]==[item['make_exit_status'] for item in status['runs']], 'benchmark cleanup identity/status differs')
    path=verify_record(status['workload_progress']);rows=[json.loads(line) for line in path.read_text().splitlines()]
    require(rows and rows[-1]['phase']=='stopped','CPU worker did not finish owned cleanup')
    for run in status['runs']:
        require(run.get('diagnostic_valid') is True and run.get('measurement_complete') is True,'load target diagnostic invalid')
        before,after=run['workload_before'],run['workload_after'];start,end=run['started']['monotonic_seconds'],run['completed']['monotonic_seconds']
        overlapping=[row for row in rows if row.get('phase')=='working' and start<=row['monotonic_seconds']<=end]
        require(before in rows and after in rows and before['monotonic_seconds']<start<=end<after['monotonic_seconds'] and
                before['iterations']<after['iterations'] and len(overlapping)==run['workload_overlapping_progress_records'] and bool(overlapping), 'controlled workload overlap not proved')
        original=verify_record(run['source_report']);raw=verify_record(run['raw_report'])
        require(sha(original)==sha(raw),'copied raw diagnostic report differs')
        for stream in ('stdout','stderr'):verify_record(run[stream])
        report=load(raw);qualification.validate_measurements(report);calculated=copy.deepcopy(report);qualification.completion(calculated,0)
        require(calculated['measurement_complete'] is True and report.get('measurement_error') is None and
                report['samples']==10 and report['warmup']==3 and report['expected_inventory']=={'execution':['startup']},'load diagnostic samples invalid')
        require(run['make_exit_status']==(0 if calculated['gates_passed'] else 2),'diagnostic Make status disagrees with gate')
    return {'valid':True,'status':receipt(directory/'status.json'),'cpu_progress':receipt(path),'owned_children_reaped':3,'cleanup':cleanup,
        'limit':'Progress overlaps producer command lifetimes, including preparation; individual pair wall-clock boundaries are unavailable.'}


def audit(review_path: Path) -> dict[str,Any]:
    state=load(BASE/'validation-status.json')
    require(state.get('active_owned_jobs')==[] and not state.get('cleanup_error') and not state.get('cleanup_errors') and
            not state.get('finalization_errors') and state.get('error') is None and 'finish' in state and state.get('state') in ('passed','performance-nonzero'),
            'validation driver not terminal with valid completed measurements')
    reuse=reuse_audit(review_path);ci=ci_audit(state);load_result=load_audit();performance=performance_audit(state)
    for phase in ('before-ci','after-ci','after-performance'):
        require(load(BASE/('freeze-'+phase+'.log'))=={'verified':True,'semantic_source_sha256':expected_source()},'final freeze verification receipt differs: '+phase)
    return {'audit_status':'valid_completed_measurement','completed_measurement':True,
        'performance_passed':performance['performance_passed'],'i011_checks_passed':performance['performance_passed'],
        'i011_complete':False,'gate_failures':performance['gate_failures'],'source_sha256':expected_source(),
        'check_identities':{'frozen_inputs':receipt(BASE/'frozen-inputs.json'),'reuse_review':receipt(review_path),
            'campaign_config':performance['config'],'package_file_count':339,'original_nonperformance_archives':18},
        'validation_status':receipt(BASE/'validation-status.json'),'ci':ci,'nonperformance_reuse':reuse,
        'controlled_load_diagnostic':load_result,'performance':performance,
        'limits':['Final documentation/repository checks and independent full completion review remain separate.',
            'Failed/inconclusive performance gates remain valid complete measurements, but cannot close I011.',
            'No new Linux semantic corpus or strict semantic report is claimed for the measurement-only source identity.',
            'Physical Metal execution and performance remain unmeasured.']}


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reuse-review',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    try:
        output=local(args.output);require(output.is_relative_to(BASE),'audit output must remain in the owned measurement task')
        require(not output.exists(),'audit output path must be fresh')
        result=audit(local(args.reuse_review))
        with output.open('x') as stream:stream.write(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
        print(json.dumps({'output':receipt(output),'completed_measurement':True,'performance_passed':result['performance_passed'],'i011_checks_passed':result['i011_checks_passed']}))
        return 0
    except (OSError,ValueError,KeyError,TypeError,AttributeError) as error:
        print(json.dumps({'audit_status':'invalid_or_incomplete','error':str(error)}),file=sys.stderr)
        return 2


if __name__=='__main__':
    raise SystemExit(main())
