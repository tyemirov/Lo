"""Record the corrected measurement tools, affected fixture checks, and unchanged packages."""
from pathlib import Path
import difflib
import gzip
import hashlib
import json
import runpy
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
OLD = ROOT / '_scratch/i011-20261020/frozen-inputs-7.json'
NEW = BASE / 'frozen-inputs.json'
EVIDENCE = ROOT / 'docs/evidence/standalone-compiler'
ALLOWED = {
    'Makefile', 'scripts/qualify_native.py',
    'tools/loqualification/performance-runner/main.go',
    'tools/loqualification/performance-runner/main_test.go',
    'tools/loqualification/test_performance.py',
    'tools/nativebench/qualification.py', 'tools/nativebench/identity.py',
    'tools/nativebench/merge.py', 'tools/nativebench/campaign.py',
    'tools/nativebench/test_campaign.py', 'tools/nativebench/test_measurements.py',
    'tools/nativebench/test_merge.py', 'tools/nativebench/test_qualification.py',
    'testdata/native-qualification/semantic-effects.c',
    'tests/integration/semantic_native_test.go', 'tests/integration/llvm_lifetime_test.go',
}
AFFECTED = {
    'testdata/native-qualification/semantic-effects.c',
    'tests/integration/semantic_native_test.go', 'tests/integration/llvm_lifetime_test.go',
}

def impact(name):
    return ('semantic capture fixture or its tests; fresh affected scenarios required on both targets'
            if name in AFFECTED else
            'measurement tooling or its tests; no compiler, runtime, or offline acceptance change')


def digest(path):
    resolved = path.resolve()
    if not resolved.is_relative_to(ROOT):
        raise ValueError('input leaves Lo: ' + str(path))
    with resolved.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def current():
    sources, identity = runpy.run_path(str(ROOT / 'tools/semanticcoverage/report.py'))['source_identity']()
    extra = {str(path.relative_to(ROOT)): digest(path)
             for folder in ('tools/nativebench', 'scripts')
             for path in sorted((ROOT / folder).rglob('*'))
             if path.is_file() and path.suffix in {'.py', '.go', '.txt'}}
    packages = {str(path.relative_to(ROOT)): digest(path)
                for path in sorted((ROOT / 'bin/distributions').rglob('*')) if path.is_file()}
    return {'semantic_source_sha256': identity, 'sources': sources,
            'measurement_sources': extra, 'packages': packages}


def main():
    actual = current()
    if sys.argv[1] == 'verify':
        if actual != json.loads(NEW.read_text()):
            raise ValueError('current sources, measurement inputs, or packages differ from the recorded inventory')
        print(json.dumps({'verified': True, 'semantic_source_sha256': actual['semantic_source_sha256']}))
        return
    if sys.argv[1] != 'record' or NEW.exists():
        raise ValueError('record requires a fresh inventory path')
    old = json.loads(OLD.read_text())
    if actual['packages'] != old['packages']:
        raise ValueError('installed packages differ from freeze7')
    changes = []
    for inventory in ('sources', 'measurement_sources'):
        previous, next_values = old[inventory], actual[inventory]
        for name in sorted(previous.keys() | next_values.keys()):
            before, after = previous.get(name), next_values.get(name)
            if before != after:
                if name not in ALLOWED:
                    raise ValueError('unreviewed source difference: ' + name)
                changes.append({'inventory': inventory, 'path': name, 'before_sha256': before,
                                'after_sha256': after,
                                'change': 'added' if before is None else 'removed' if after is None else 'changed',
                                'impact': impact(name)})
    old_make = ROOT / '_scratch/i011-20261020/final-corpus-7/linux/guest/root/workspace/Makefile'
    if digest(old_make) != old['sources']['Makefile']:
        raise ValueError('retained old Makefile differs from freeze7')
    make_diff = ''.join(difflib.unified_diff(old_make.read_text().splitlines(True),
        (ROOT / 'Makefile').read_text().splitlines(True), fromfile='freeze7/Makefile', tofile='current/Makefile'))
    (BASE / 'makefile-change.diff').write_text(make_diff)
    receipt_path = EVIDENCE / 'nonperformance-validation.json'
    receipt = json.loads(receipt_path.read_text())
    for record in receipt['evidence']:
        archive = EVIDENCE / record['archive']
        if digest(archive) != record['archive_sha256']:
            raise ValueError('archive identity differs: ' + str(archive))
        if hashlib.sha256(gzip.decompress(archive.read_bytes())).hexdigest() != record['sha256']:
            raise ValueError('decoded evidence identity differs: ' + str(archive))
    affected_path = ROOT / '_scratch/i011-20261020/measurement-contract/fixture-capture/handoff.json'
    affected = json.loads(affected_path.read_text())
    if {item['path'] for item in affected['changes']} != AFFECTED:
        raise ValueError('affected fixture inventory differs')
    for item in affected['changes']:
        if digest(ROOT / item['path']) != item['after_sha256']:
            raise ValueError('affected fixture source changed: ' + item['path'])
    for lane in ('darwin_green', 'linux_hvf_green'):
        evidence = affected[lane]
        if evidence['counts'] != {'pass': 21, 'fail': 0, 'skip': 0} or not evidence['package_passed']:
            raise ValueError('affected fixture checks did not pass: ' + lane)
        record = evidence['receipt']
        if digest(ROOT / record['path']) != record['sha256']:
            raise ValueError('affected fixture evidence changed: ' + lane)
        events = [json.loads(line) for line in (ROOT / record['path']).read_text().splitlines() if line.startswith('{')]
        actual_counts = {name: sum(event.get('Action') == name and bool(event.get('Test')) for event in events)
                         for name in ('pass', 'fail', 'skip')}
        if actual_counts != evidence['counts']:
            raise ValueError('affected fixture raw counts differ: ' + lane)
    linux_record = affected['linux_receipt']
    if digest(ROOT / linux_record['path']) != linux_record['sha256']:
        raise ValueError('affected Linux suite receipt changed')
    NEW.write_text(json.dumps(actual, indent=2) + '\n')
    result = {
        'issue': 'I011', 'status': 'dependency identities verified; final independent review pending',
        'original_semantic_source_sha256': old['semantic_source_sha256'],
        'current_semantic_source_sha256': actual['semantic_source_sha256'],
        'original_inventory': {'path': str(OLD.relative_to(ROOT)), 'sha256': digest(OLD)},
        'current_inventory': {'path': str(NEW.relative_to(ROOT)), 'sha256': digest(NEW)},
        'changes': changes, 'makefile_diff': {'path': str((BASE / 'makefile-change.diff').relative_to(ROOT)),
                                             'sha256': digest(BASE / 'makefile-change.diff')},
        'unchanged_package_files': len(actual['packages']), 'packages': receipt['packages'],
        'retained_receipt': {'path': str(receipt_path.relative_to(ROOT)), 'sha256': digest(receipt_path)},
        'retained_evidence': receipt['evidence'],
        'original_execution_identity': old['semantic_source_sha256'],
        'affected_acceptance_evidence': {
            'handoff': {'path': str(affected_path.relative_to(ROOT)), 'sha256': digest(affected_path)},
            'source_changes': affected['changes'],
            'darwin_green': affected['darwin_green'],
            'linux_hvf_green': affected['linux_hvf_green'],
            'linux_receipt': affected['linux_receipt'],
        },
        'claims': ['Previously qualified offline behavior and unaffected semantic checks apply to the unchanged installed packages.',
                   'Compiler, runtime, semantic reporter, shared guest transport, and package construction inputs are unchanged.',
                   'The semantic capture fixture and its tests changed. All 21 affected scenarios passed on each supported target.',
                   'The affected checks retain their original execution identities and do not replace the full semantic corpus.',
                   'The retained checks were not rerun against the new aggregate source identity.',
                   'Fresh CI and new performance measurements are separate evidence; old timing samples are not reused.'],
    }
    (EVIDENCE / 'nonperformance-reuse.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'recorded': True, 'changes': len(changes), 'package_files': len(actual['packages']),
                      'verified_old_evidence': len(receipt['evidence']),
                      'semantic_source_sha256': actual['semantic_source_sha256']}))


if __name__ == '__main__':
    main()
