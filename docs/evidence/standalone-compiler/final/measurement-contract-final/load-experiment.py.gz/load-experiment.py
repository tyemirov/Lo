"""Run two real startup diagnostics with an owned bounded background workload.

This is a measurement-integrity diagnostic, not full performance qualification.
Progress proves overlap with producer command lifetimes, including preparation;
current reports do not provide individual-pair wall-clock boundaries.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
MAX_SECONDS = 900


def stamp() -> dict[str, Any]:
    return {'monotonic_seconds': time.monotonic(), 'timestamp_utc': datetime.now(timezone.utc).isoformat()}


def local(path: Path) -> Path:
    value = path.resolve()
    if not value.is_relative_to(ROOT):
        raise ValueError('diagnostic path leaves Lo: ' + str(path))
    return value


def receipt(path: Path) -> dict[str, str]:
    path = local(path)
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def progress(path: Path) -> list[dict[str, Any]]:
    # Ignore only an unfinished live line; complete lines remain exact JSON.
    data = path.read_bytes()
    complete = data[:data.rfind(b'\n')+1]
    return [json.loads(line) for line in complete.splitlines()]


def cpu_worker(path: Path, deadline: float) -> int:
    path = local(path)
    if not math.isfinite(deadline) or not 0 < deadline-time.monotonic() <= MAX_SECONDS:
        raise ValueError("CPU worker deadline must be finite and within 15 minutes")
    stopped = False
    def stop(signum: int, frame: Any) -> None:
        nonlocal stopped
        stopped = True
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    counter, value, last = 0, 1, 0.0
    with path.open('x') as output:
        while not stopped and time.monotonic() < deadline:
            for _ in range(8192):
                value = ((value * 1664525 + 1013904223) ^ (value >> 7)) & 0xffffffff
            counter += 8192
            now = time.monotonic()
            if now - last >= .5:
                output.write(json.dumps({**stamp(), 'phase': 'working', 'iterations': counter, 'checksum': value}) + '\n')
                output.flush()
                last = now
        output.write(json.dumps({**stamp(), 'phase': 'stopped' if stopped else 'deadline', 'iterations': counter, 'checksum': value}) + '\n')
        output.flush()
    return 0


def stop_owned(child: subprocess.Popen[Any] | None) -> dict[str, Any] | None:
    """Retain bounded cleanup evidence without preventing other owned cleanup."""
    if child is None:
        return None
    from campaign import CleanupError, stop
    cleaned = None
    errors: list[str] = []
    try:
        cleaned = stop(child)
    except CleanupError as error:
        cleaned = error.result
        errors.append(str(error))
    except Exception as error:
        errors.append('owned cleanup failed: '+str(error))
        try:
            child.wait(timeout=2)
        except Exception as reap_error:
            errors.append('independent direct-child reap failed: '+str(reap_error))
    members = None if cleaned is None or cleaned.remaining_owned_members is None else list(cleaned.remaining_owned_members)
    status = child.returncode if cleaned is None else cleaned.direct_child_status
    observations = [] if cleaned is None else list(cleaned.signal_observations)
    if members != [] and not errors:
        errors.append('owned group not confirmed empty')
    if status is None and not errors:
        errors.append('direct child not reaped')
    return {'pid':child.pid,'returncode':status,'reaped':status is not None,
            'remaining_owned_members':members,'signal_observations':observations,
            'cleanup_error':'; '.join(errors) if errors else None}


def run(work: Path) -> int:
    sys.path.insert(0, str(ROOT / 'tools/nativebench'))
    import identity
    import qualification

    work = local(work)
    if work.exists():
        raise ValueError('diagnostic output path must be fresh: ' + str(work))
    work.mkdir(parents=True)
    deadline = time.monotonic() + MAX_SECONDS
    status_path, progress_path = work / 'status.json', work / 'cpu-progress.jsonl'
    state: dict[str, Any] = {'diagnostic': 'real paired startup measurement during controlled background workload',
        'complete': False, 'diagnostic_valid': False, 'performance_qualification_complete': False,
        'started': stamp(), 'deadline_monotonic_seconds': deadline, 'maximum_seconds': MAX_SECONDS,
        'runs': [], 'error': None, 'cleanup_errors': [], 'finalization_errors': [],
        'worker_cleanup': None, 'benchmark_cleanup': [],
        'limits': ['Diagnostic selection only; not full corpus qualification.',
                   'Workload progress overlaps producer commands, including preparation; individual pair timestamps are unavailable.',
                   'Load percentages are neither an admission condition nor a diagnostic success condition.',
                   'Performance outcomes are reported independently of measurement integrity.']}
    worker = None
    current = None
    write(status_path,state)
    try:
        env = dict(os.environ, CI='1')
        for variable, suffix in {'TMPDIR':'tmp', 'TMP':'tmp', 'TEMP':'tmp', 'GOCACHE':'go-build',
                'GOMODCACHE':'modules', 'GOPATH':'gopath', 'UV_CACHE_DIR':'uv-cache',
                'PYTHONPYCACHEPREFIX':'python-cache', 'XDG_CACHE_HOME':'cache',
                'XDG_CONFIG_HOME':'config', 'XDG_DATA_HOME':'data', 'XDG_STATE_HOME':'state'}.items():
            path = ROOT / '_scratch/build-state' / suffix
            path.mkdir(parents=True, exist_ok=True)
            env[variable] = str(path)
        env.update({'GOENV':'off','GOWORK':'off','GOTOOLCHAIN':'local','GOTELEMETRY':'off','UV_NO_CONFIG':'1'})
        source_files = ['scripts/qualify_native.py','tools/loqualification/performance.py',
            'tools/loqualification/performance-runner/main.go','tools/nativebench/main.go',
            'tools/nativebench/harness.c.txt','tools/nativebench/allocation.c.txt',
            'tools/nativebench/identity.py','tools/nativebench/qualification.py','tools/nativebench/campaign.py','Makefile']
        before_sources = {name: receipt(ROOT / name)['sha256'] for name in source_files}
        packages = {}
        for target in ('darwin','linux'):
            package = ROOT / f'bin/distributions/lo-{target}-arm64-software'
            packages[target] = identity.package_provenance(ROOT, package / 'bin/lo', package / 'toolchain.json', target+'/arm64')[0]
        frozen_path=Path(__file__).resolve().parent/'frozen-inputs.json'
        frozen=json.loads(frozen_path.read_text())
        if identity.semantic_source(ROOT)!=frozen['semantic_source_sha256']:
            raise ValueError('diagnostic source differs from final frozen inventory')
        state['frozen_inputs']=receipt(frozen_path)
        state.update({'driver':receipt(Path(__file__)), 'producer_sources':before_sources,
                      'semantic_source_sha256':identity.semantic_source(ROOT),'packages':packages})
        write(status_path,state)
        with (work/'cpu.stdout').open('xb') as stdout, (work/'cpu.stderr').open('xb') as stderr:
            worker = subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'--cpu-worker',
                str(progress_path),'--deadline',str(deadline)], cwd=ROOT,env=env,
                stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
        ready_deadline = min(deadline,time.monotonic()+10)
        while time.monotonic()<ready_deadline:
            if worker.poll() is not None:
                raise ValueError('owned CPU worker ended before readiness')
            if progress_path.exists() and any(item.get('phase')=='working' and item['iterations']>0 for item in progress(progress_path)):
                break
            time.sleep(.05)
        else:
            raise ValueError('owned CPU worker readiness deadline expired')
        state['worker']={'pid':worker.pid,'ready':stamp(),'progress':str(progress_path.relative_to(ROOT))}
        write(status_path,state)
        for target, make_target in [('darwin','benchmark-standalone'),('linux','benchmark-native-linux')]:
            directory = work / target
            command = ['make','-s',make_target,'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                'NATIVE_RUNTIME_STATE=_scratch/native-runtime',
                'NATIVE_BENCH_COMPILER=bin/distributions/lo-darwin-arm64-software/bin/lo',
                'SEMANTIC_COMPILER=bin/distributions/lo-darwin-arm64-software/bin/lo',
                'LINUX_ACCELERATOR=hvf','BENCH_COUNT=10','NATIVE_BENCH_LANE=execution',
                'NATIVE_BENCH_ARGS=--case startup','NATIVE_BENCH_WORK='+str(directory)]
            if worker.poll() is not None:
                raise ValueError('owned CPU worker ended before benchmark')
            before = progress(progress_path)[-1]
            entry = {'target':target+'/arm64','command':command,'started':stamp(), 'workload_before':before}
            state['runs'].append(entry);write(status_path,state)
            remaining = deadline-time.monotonic()
            if remaining<=0:
                raise ValueError('diagnostic 15-minute deadline expired before producer')
            with (work/(target+'.stdout')).open('xb') as stdout, (work/(target+'.stderr')).open('xb') as stderr:
                current = subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,
                    stdout=stdout,stderr=stderr,start_new_session=True)
                entry['pid']=current.pid;write(status_path,state)
                result = current.wait(timeout=remaining)
            entry.update({'completed':stamp(),'make_exit_status':result,
                'stdout':receipt(work/(target+'.stdout')),'stderr':receipt(work/(target+'.stderr'))})
            cleaned=stop_owned(current);current=None
            state['benchmark_cleanup'].append(cleaned)
            if cleaned['cleanup_error']:
                state['cleanup_errors'].append(cleaned['cleanup_error'])
                raise ValueError('benchmark owned cleanup failed')
            if worker.poll() is not None:
                raise ValueError('owned CPU worker ended before benchmark completed')
            # Obtain an observed progress point after producer completion, not merely a live PID.
            progress_deadline=min(deadline,time.monotonic()+5)
            while time.monotonic()<progress_deadline:
                observed=progress(progress_path)
                if observed and observed[-1]['monotonic_seconds']>entry['completed']['monotonic_seconds']:
                    break
                if worker.poll() is not None:
                    raise ValueError('owned CPU worker ended before post-benchmark progress')
                time.sleep(.05)
            else:
                raise ValueError('owned CPU worker lacked post-benchmark progress')
            working=[item for item in observed if item.get('phase')=='working']
            overlapping=[item for item in working if entry['started']['monotonic_seconds']<=item['monotonic_seconds']<=entry['completed']['monotonic_seconds']]
            if not overlapping or observed[-1]['iterations']<=before['iterations']:
                raise ValueError('owned workload has no progress overlapping the producer command')
            entry['workload_after']=observed[-1]
            entry['workload_overlapping_progress_records']=len(overlapping)
            path=directory/'report.json'
            report=json.loads(path.read_text())
            qualification.validate_measurements(report)
            if report.get('measurement_complete') is not True or report.get('measurement_error') is not None:
                raise ValueError('producer did not finish valid measurements')
            if report.get('samples')!=10 or report.get('warmup')!=3 or report.get('expected_inventory')!={'execution':['startup']}:
                raise ValueError('producer sample/fixture inventory differs')
            if report.get('lanes')!=['execution'] or report.get('scope')!='diagnostic selection':
                raise ValueError('producer is not the selected startup diagnostic')
            if report['execution'][0].get('native_benchmark_verified') is not True:
                raise ValueError('native startup result was not verified')
            recalculated=copy.deepcopy(report);qualification.completion(recalculated,0)
            if recalculated.get('measurement_complete') is not True or recalculated.get('gates_passed') is not report.get('gates_passed'):
                raise ValueError('recomputed measurement/performance result differs')
            expected_status=0 if recalculated['gates_passed'] is True else 2
            if result!=expected_status:
                raise ValueError('Make exit differs from recomputed performance gate: '+str(result))
            identity.verify_source_identity(ROOT,report['merge_identity'])
            if report['merge_identity']['package']!=packages[target] or report['merge_identity']['target']!=target+'/arm64':
                raise ValueError('producer package or target identity differs')
            raw=work/(target+'-raw-report.json')
            with raw.open('xb') as output:output.write(path.read_bytes())
            entry.update({'diagnostic_valid':True,'source_report':receipt(path),'raw_report':receipt(raw),
                'measurement_complete':True,'performance_outcome':{'gates_passed':report['gates_passed'],
                    'gate':report.get('gate'),'execution':[{key:item[key] for key in ('name','native_over_interpreter','bootstrap_95_percent','gate') if key in item} for item in report['execution']]}})
            write(status_path,state)
        if {name:receipt(ROOT/name)['sha256'] for name in source_files}!=before_sources or identity.semantic_source(ROOT)!=state['semantic_source_sha256']:
            raise ValueError('producer or semantic sources changed during experiment')
        for target,expected in packages.items():
            package=ROOT/f'bin/distributions/lo-{target}-arm64-software'
            if identity.package_provenance(ROOT,package/'bin/lo',package/'toolchain.json',target+'/arm64')[0]!=expected:
                raise ValueError('installed package changed during experiment')
        state['diagnostic_valid']=True
    except (Exception,KeyboardInterrupt) as error:
        state['error']=str(error) or type(error).__name__
    finally:
        # Protect each owned cleanup and artifact separately; preserve the primary error.
        signal.signal(signal.SIGINT,signal.SIG_IGN)
        signal.signal(signal.SIGTERM,signal.SIG_IGN)
        try:
            if current is not None:
                cleaned=stop_owned(current)
                state['benchmark_cleanup'].append(cleaned)
                if cleaned['cleanup_error']:state['cleanup_errors'].append(cleaned['cleanup_error'])
        except Exception as error:
            state['cleanup_errors'].append('benchmark final cleanup failed: '+str(error))
        try:
            state['worker_cleanup']=stop_owned(worker)
            if state['worker_cleanup'] is not None and state['worker_cleanup']['cleanup_error']:
                state['cleanup_errors'].append(state['worker_cleanup']['cleanup_error'])
        except Exception as error:
            state['cleanup_errors'].append('worker final cleanup failed: '+str(error))
        try:
            if progress_path.exists():state['workload_progress']=receipt(progress_path)
        except Exception as error:
            state['finalization_errors'].append('progress hashing failed: '+str(error))
        try:
            state['completed']=stamp()
        except Exception as error:
            state['finalization_errors'].append('completion timestamp failed: '+str(error))
        state['complete']=True
        if state['cleanup_errors'] or state['finalization_errors']:
            state['diagnostic_valid']=False
        state['terminal_state']='valid' if state['diagnostic_valid'] and state['error'] is None else 'invalid'
        if state['terminal_state']=='invalid':state['diagnostic_valid']=False
        write(status_path,state)

    return 0 if state['diagnostic_valid'] else 1


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work',type=Path)
    parser.add_argument('--cpu-worker',type=Path)
    parser.add_argument('--deadline',type=float)
    args=parser.parse_args()
    if args.cpu_worker is not None:
        if args.work is not None or args.deadline is None:
            parser.error('CPU worker requires only --cpu-worker and --deadline')
        return cpu_worker(args.cpu_worker,args.deadline)
    if args.work is None or args.deadline is not None:
        parser.error('driver requires --work only')
    def interrupted(signum: int,frame: Any) -> None:
        raise InterruptedError('load experiment interrupted by signal '+str(signum))
    signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
    return run(args.work)


if __name__=='__main__':
    raise SystemExit(main())
