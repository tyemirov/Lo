from pathlib import Path
import hashlib, json, runpy, sys
root = Path.cwd().resolve()
path = root / '_scratch/i011-20261020/frozen-inputs-7.json'
report = runpy.run_path(str(root / 'tools/semanticcoverage/report.py'))
sources, identity = report['source_identity']()
def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()
if sys.argv[1] == 'record':
    if path.exists():
        raise SystemExit('freeze already exists')
    packages = {str(p.relative_to(root)): digest(p) for p in sorted((root / 'bin/distributions').rglob('*')) if p.is_file()}
    extra = {str(p.relative_to(root)): digest(p) for folder in ['tools/nativebench', 'scripts'] for p in sorted((root/folder).rglob('*')) if p.is_file() and p.suffix in {'.py', '.go', '.txt'}}
    result = {'semantic_source_sha256':identity,'sources':sources,'measurement_sources':extra,'packages':packages}
    path.write_text(json.dumps(result,indent=2)+'\n')
else:
    result=json.loads(path.read_text())
    if identity != result['semantic_source_sha256'] or sources != result['sources']:
        raise SystemExit('semantic source changed')
    for name, expected in {**result['measurement_sources'], **result['packages']}.items():
        if digest(root/name) != expected:
            raise SystemExit('frozen input changed: '+name)
print(json.dumps({'action':sys.argv[1],'source_sha256':identity,'source_files':len(sources),'package_files':len(result['packages'])}))
