"""Run the authorized campaign11 with explicit admission/measurement outcomes."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import time
from typing import Any, Callable

root = Path(__file__).resolve().parents[2]
base = root / '_scratch/i011-20261020'


def main(*, contract: Any = None, quiet_module: Any = None, audit: Any = None,
         process_start: Callable[..., Any] = subprocess.Popen,
         freeze_verify: Callable[[int, str], None] | None = None,
         on_record: Callable[[dict[str, Any]], None] | None = None) -> int:
    """Expose the real orchestration entry point with injected process boundaries."""
    if contract is None:
        spec = importlib.util.spec_from_file_location('lo_campaign11_driver_contract', base / 'campaign-contract-11.py')
        contract = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = contract
        spec.loader.exec_module(contract)
    plan = contract.plan11()
    sealed = contract.verify_bindings()
    if audit is None:
        audit = contract.module('lo_campaign11_driver_audit', 'final-evidence-audit-11.py')
    if audit.audit_nonperformance() != sealed['nonperformance_summary']:
        raise ValueError('Sealed nonperformance evidence identity audit differs; separate review is necessary')
    if quiet_module is None:
        quiet_module = contract.module('lo_campaign11_monitor', 'quiet-host-11.py')
    status_path = base / 'final-validation-status-11.json'
    if status_path.exists():
        raise ValueError('Campaign status path must be fresh')
    for definition in plan['attempts']:
        identifier = definition['id']
        paths = [root / definition[key] for key in ('performance_directory', 'trace', 'summary')]
        paths += [(root / definition['summary']).with_suffix('.writing')]
        paths += [base / f'performance-attempt-{identifier}.{suffix}' for suffix in ('stdout', 'stderr')]
        paths += [base / f'freeze-verify-11-attempt-{identifier}-{phase}.log' for phase in ('before', 'after')]
        if any(path.exists() for path in paths):
            raise ValueError('Campaign output paths must be fresh; no overwrite or lane reuse')
    state = {'campaign': 11, 'phase': 'preflight', 'complete': False, 'passed': False,
             'selected_attempt': None, 'attempts': [], 'running': [],
             'sealed_inputs': contract.receipt(base / 'campaign-inputs-11.json'),
             'error': None, 'terminal_reason': None}
    started = time.monotonic()
    env = dict(os.environ, CI='1')
    env.pop('LO_TEST_BACKEND', None)

    def record() -> None:
        state['elapsed_seconds'] = time.monotonic() - started
        status_path.write_text(json.dumps(state, indent=2, allow_nan=False) + '\n')
        if on_record is not None:
            on_record(state)

    def verify_freeze(identifier: int, phase: str) -> None:
        if freeze_verify is not None:
            freeze_verify(identifier, phase)
            return
        with (base / f'freeze-verify-11-attempt-{identifier}-{phase}.log').open('xb') as output:
            subprocess.run([sys.executable, '-B', str(base / 'freeze-inputs-7.py'), 'verify'],
                           stdin=subprocess.DEVNULL, stdout=output, cwd=root, env=env, check=True)

    entry = None
    record()
    try:
        for definition in plan['attempts']:
            identifier = definition['id']
            if identifier == 12 and state['attempts'][-1]['disposition'] != 'cpu-load-invalidated':
                raise ValueError('A second attempt is permitted only after CPU-load invalidation')
            contract.verify_bindings()
            verify_freeze(identifier, 'before')
            monitor = quiet_module.Monitor(os.getpid(), base / 'quiet-host-plan-11.json',
                                           root / definition['trace'], root / definition['summary'], identifier)
            entry = {'id': identifier, 'phase': 'admission', 'admission_status': 'pending',
                     'measurement_started': False, 'measurement_status': None,
                     'quiet_summary': None, 'disposition': 'admission-pending', 'terminal_reason': None}
            state['attempts'].append(entry)
            state['phase'] = 'admission'
            state['running'] = [f'admission-{identifier}']
            record()
            attempt_error = None
            try:
                print('START quiet admission ' + str(identifier), flush=True)
                monitor.admit()
                entry['admission_status'] = 'passed'
                entry['phase'] = 'measurement-launch'
                state['phase'] = 'measurement-launch'
                state['running'] = []
                record()
                with (base / f'performance-attempt-{identifier}.stdout').open('xb') as stdout, (base / f'performance-attempt-{identifier}.stderr').open('xb') as stderr:
                    child = process_start([sys.executable, '-B', str(base / 'final-performance-8.py'), '--attempt', str(identifier)],
                                          stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, cwd=root, env=env)
                    # Popen returned: a child actually exists. Before this point no measurement exit is claimed.
                    entry['measurement_started'] = True
                    entry['phase'] = 'measurement'
                    entry['disposition'] = 'measurement-running'
                    state['phase'] = 'measurement'
                    state['running'] = [f'performance-{identifier}']
                    record()
                    print('START complete eight-lane attempt ' + str(identifier), flush=True)
                    entry['measurement_status'] = child.wait()
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
                attempt_error = error
                entry['terminal_reason'] = str(error)
                if entry['admission_status'] != 'passed':
                    entry['admission_status'] = 'failed'
                    entry['disposition'] = 'admission-timeout' if str(error).startswith('quiet admission timed out after 3600 seconds') else 'admission-failed'
                else:
                    entry['disposition'] = 'measurement-start-failed' if not entry['measurement_started'] else 'measurement-failed'
            finally:
                try:
                    quiet = monitor.finish(entry['measurement_status'])
                    entry['quiet_summary'] = contract.receipt(root / definition['summary'])
                finally:
                    entry['phase'] = 'terminal'
                    state['running'] = []
                    record()
                    # Always check frozen inputs after admission/measurement, including admission failure.
                    verify_freeze(identifier, 'after')
                    contract.verify_bindings()
                    if audit.audit_nonperformance() != sealed['nonperformance_summary']:
                        raise ValueError('Post-attempt nonperformance evidence identity audit differs')
            if attempt_error is not None:
                raise attempt_error
            outcome_path = root / definition['performance_directory'] / 'runner-outcome.json'
            entry['runner_outcome'] = contract.receipt(outcome_path)
            outcome = contract.validate_runner(definition, entry['runner_outcome'])
            if entry['measurement_status'] == 0 and quiet['passed'] is True and outcome['failure_kind'] == 'passed':
                contract.validate_quiet(root / definition['summary'], plan)
                entry['disposition'] = 'passed'
                state['selected_attempt'] = identifier
                state['passed'] = True
                record()
                break
            if contract.retry_allowed(quiet, outcome):
                contract.validate_quiet(root / definition['summary'], plan, cpu_rejection=True)
                entry['disposition'] = 'cpu-load-invalidated'
                print('REJECT whole attempt ' + str(identifier) + ' for CPU load', flush=True)
                record()
                if identifier == 11:
                    continue
                raise ValueError('Both predeclared complete attempts are CPU-load-invalidated; campaign exhausted')
            entry['disposition'] = 'failed-no-retry'
            raise ValueError('Failed/inconclusive gate or observation/provenance failure; separate review is necessary')
        if not state['passed']:
            raise ValueError('No complete accepted performance attempt')
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        state['error'] = str(error)
        state['terminal_reason'] = str(error)
        state['passed'] = False
    finally:
        state['complete'] = True
        state['phase'] = 'terminal'
        state['running'] = []
        record()
    if not state['passed'] or state['error'] is not None:
        print('Campaign qualification incomplete: ' + str(state['error']), file=sys.stderr)
        return 1
    print('All campaign qualification commands passed', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
