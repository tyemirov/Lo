; Lo native lowering; ABI lo-native-1; LLVM 21
source_filename = "/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo"
target triple = "aarch64-apple-darwin"

%lo.result = type { i32, i32, ptr }

@lo_program_metadata = constant [31750 x i8] c"{\22abi\22:\22lo-native-1\22,\22artifact\22:{\22source_sha256\22:\228132c2eeb0d8e8506e7ca0313b9138d813695c147c716403d731f16aed30f562\22,\22source\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22compiler\22:\22lo-native-llvm-v1\22,\22toolchain\22:\22LLVM 21.1.8\22,\22target\22:\22darwin/arm64\22,\22device_backend\22:\22software\22},\22derivatives\22:[],\22flows\22:[{\22identity\22:\222:0\22,\22id\22:0,\22name\22:\22Handle\22,\22parameters\22:[{\22name\22:\22error\22,\22type\22:0}],\22output\22:0,\22handler\22:null,\22location\22:0},{\22identity\22:\222:52\22,\22id\22:1,\22name\22:\22Main\22,\22parameters\22:[],\22output\22:0,\22handler\22:0,\22location\22:1}],\22has_result\22:true,\22locations\22:[{\22id\22:0,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:51,\22line\22:1,\22column\22:52},\22action\22:\22flow\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:1,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:52,\22line\22:2,\22column\22:1},\22end\22:{\22offset\22:214,\22line\22:2,\22column\22:163},\22action\22:\22flow\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:2,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:228,\22line\22:2,\22column\22:177},\22action\22:\22body\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:3,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:228,\22line\22:2,\22column\22:177},\22action\22:\22scope_enter\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:4,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:215,\22line\22:2,\22column\22:164},\22end\22:{\22offset\22:228,\22line\22:2,\22column\22:177},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:5,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:222,\22line\22:2,\22column\22:171},\22end\22:{\22offset\22:228,\22line\22:2,\22column\22:177},\22action\22:\22expression_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:6,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:222,\22line\22:2,\22column\22:171},\22end\22:{\22offset\22:228,\22line\22:2,\22column\22:177},\22action\22:\22flow_call\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:7,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:222,\22line\22:2,\22column\22:171},\22end\22:{\22offset\22:228,\22line\22:2,\22column\22:177},\22action\22:\22charge_value\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:8,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:215,\22line\22:2,\22column\22:164},\22end\22:{\22offset\22:228,\22line\22:2,\22column\22:177},\22action\22:\22cause\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:9,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:51,\22line\22:1,\22column\22:52},\22action\22:\22body\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:10,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:51,\22line\22:1,\22column\22:52},\22action\22:\22flow_enter\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:11,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:51,\22line\22:1,\22column\22:52},\22action\22:\22scope_enter\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:12,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:12,\22line\22:1,\22column\22:13},\22end\22:{\22offset\22:24,\22line\22:1,\22column\22:25},\22action\22:\22parameter\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:13,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:37,\22line\22:1,\22column\22:38},\22end\22:{\22offset\22:49,\22line\22:1,\22column\22:50},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:14,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:44,\22line\22:1,\22column\22:45},\22end\22:{\22offset\22:49,\22line\22:1,\22column\22:50},\22action\22:\22expression_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:15,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:44,\22line\22:1,\22column\22:45},\22end\22:{\22offset\22:49,\22line\22:1,\22column\22:50},\22action\22:\22reference\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:16,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:44,\22line\22:1,\22column\22:45},\22end\22:{\22offset\22:49,\22line\22:1,\22column\22:50},\22action\22:\22charge_value\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:17,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:37,\22line\22:1,\22column\22:38},\22end\22:{\22offset\22:49,\22line\22:1,\22column\22:50},\22action\22:\22cause\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Handle\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:18,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:52,\22line\22:2,\22column\22:1},\22end\22:{\22offset\22:214,\22line\22:2,\22column\22:163},\22action\22:\22body\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:19,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:52,\22line\22:2,\22column\22:1},\22end\22:{\22offset\22:214,\22line\22:2,\22column\22:163},\22action\22:\22flow_enter\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:20,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:52,\22line\22:2,\22column\22:1},\22end\22:{\22offset\22:214,\22line\22:2,\22column\22:163},\22action\22:\22scope_enter\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:21,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:90,\22line\22:2,\22column\22:39},\22end\22:{\22offset\22:129,\22line\22:2,\22column\22:78},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:22,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:96,\22line\22:2,\22column\22:45},\22end\22:{\22offset\22:129,\22line\22:2,\22column\22:78},\22action\22:\22expression_step\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:23,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:96,\22line\22:2,\22column\22:45},\22end\22:{\22offset\22:129,\22line\22:2,\22column\22:78},\22action\22:\22expression_step\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:24,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:106,\22line\22:2,\22column\22:55},\22end\22:{\22offset\22:128,\22line\22:2,\22column\22:77},\22action\22:\22expression_step\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:25,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:120,\22line\22:2,\22column\22:69},\22end\22:{\22offset\22:127,\22line\22:2,\22column\22:76},\22action\22:\22expression_step\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:26,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:120,\22line\22:2,\22column\22:69},\22end\22:{\22offset\22:127,\22line\22:2,\22column\22:76},\22action\22:\22literal\22,\22type\22:5,\22text\22:\22first\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:27,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:120,\22line\22:2,\22column\22:69},\22end\22:{\22offset\22:127,\22line\22:2,\22column\22:76},\22action\22:\22charge_value\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:28,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:106,\22line\22:2,\22column\22:55},\22end\22:{\22offset\22:128,\22line\22:2,\22column\22:77},\22action\22:\22operation\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22File.Path.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:5,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:29,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:106,\22line\22:2,\22column\22:55},\22end\22:{\22offset\22:128,\22line\22:2,\22column\22:77},\22action\22:\22charge_value\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:30,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:96,\22line\22:2,\22column\22:45},\22end\22:{\22offset\22:129,\22line\22:2,\22column\22:78},\22action\22:\22operation\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22File.read\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:4,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:31,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:96,\22line\22:2,\22column\22:45},\22end\22:{\22offset\22:129,\22line\22:2,\22column\22:78},\22action\22:\22convert_success\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:32,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:96,\22line\22:2,\22column\22:45},\22end\22:{\22offset\22:129,\22line\22:2,\22column\22:78},\22action\22:\22convert_failure\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:33,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:96,\22line\22:2,\22column\22:45},\22end\22:{\22offset\22:129,\22line\22:2,\22column\22:78},\22action\22:\22charge_value\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:34,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:96,\22line\22:2,\22column\22:45},\22end\22:{\22offset\22:129,\22line\22:2,\22column\22:78},\22action\22:\22convert_propagate\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:35,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:96,\22line\22:2,\22column\22:45},\22end\22:{\22offset\22:129,\22line\22:2,\22column\22:78},\22action\22:\22charge_value\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:36,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:130,\22line\22:2,\22column\22:79},\22end\22:{\22offset\22:169,\22line\22:2,\22column\22:118},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:37,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:136,\22line\22:2,\22column\22:85},\22end\22:{\22offset\22:169,\22line\22:2,\22column\22:118},\22action\22:\22expression_step\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:38,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:136,\22line\22:2,\22column\22:85},\22end\22:{\22offset\22:169,\22line\22:2,\22column\22:118},\22action\22:\22expression_step\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:39,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:146,\22line\22:2,\22column\22:95},\22end\22:{\22offset\22:168,\22line\22:2,\22column\22:117},\22action\22:\22expression_step\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:40,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:160,\22line\22:2,\22column\22:109},\22end\22:{\22offset\22:167,\22line\22:2,\22column\22:116},\22action\22:\22expression_step\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:41,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:160,\22line\22:2,\22column\22:109},\22end\22:{\22offset\22:167,\22line\22:2,\22column\22:116},\22action\22:\22literal\22,\22type\22:5,\22text\22:\22later\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:42,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:160,\22line\22:2,\22column\22:109},\22end\22:{\22offset\22:167,\22line\22:2,\22column\22:116},\22action\22:\22charge_value\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:43,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:146,\22line\22:2,\22column\22:95},\22end\22:{\22offset\22:168,\22line\22:2,\22column\22:117},\22action\22:\22operation\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22File.Path.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:5,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:44,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:146,\22line\22:2,\22column\22:95},\22end\22:{\22offset\22:168,\22line\22:2,\22column\22:117},\22action\22:\22charge_value\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:45,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:136,\22line\22:2,\22column\22:85},\22end\22:{\22offset\22:169,\22line\22:2,\22column\22:118},\22action\22:\22operation\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22File.read\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:4,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:46,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:136,\22line\22:2,\22column\22:85},\22end\22:{\22offset\22:169,\22line\22:2,\22column\22:118},\22action\22:\22convert_success\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:47,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:136,\22line\22:2,\22column\22:85},\22end\22:{\22offset\22:169,\22line\22:2,\22column\22:118},\22action\22:\22convert_failure\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:48,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:136,\22line\22:2,\22column\22:85},\22end\22:{\22offset\22:169,\22line\22:2,\22column\22:118},\22action\22:\22charge_value\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:49,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:136,\22line\22:2,\22column\22:85},\22end\22:{\22offset\22:169,\22line\22:2,\22column\22:118},\22action\22:\22convert_propagate\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:50,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:136,\22line\22:2,\22column\22:85},\22end\22:{\22offset\22:169,\22line\22:2,\22column\22:118},\22action\22:\22charge_value\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:51,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:170,\22line\22:2,\22column\22:119},\22end\22:{\22offset\22:212,\22line\22:2,\22column\22:161},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:52,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:177,\22line\22:2,\22column\22:126},\22end\22:{\22offset\22:212,\22line\22:2,\22column\22:161},\22action\22:\22expression_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:53,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:187,\22line\22:2,\22column\22:136},\22end\22:{\22offset\22:195,\22line\22:2,\22column\22:144},\22action\22:\22expression_step\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:54,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:187,\22line\22:2,\22column\22:136},\22end\22:{\22offset\22:195,\22line\22:2,\22column\22:144},\22action\22:\22literal\22,\22type\22:5,\22text\22:\22missed\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:55,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:187,\22line\22:2,\22column\22:136},\22end\22:{\22offset\22:195,\22line\22:2,\22column\22:144},\22action\22:\22charge_value\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:56,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:196,\22line\22:2,\22column\22:145},\22end\22:{\22offset\22:198,\22line\22:2,\22column\22:147},\22action\22:\22expression_step\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:57,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:196,\22line\22:2,\22column\22:145},\22end\22:{\22offset\22:198,\22line\22:2,\22column\22:147},\22action\22:\22literal\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:58,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:196,\22line\22:2,\22column\22:145},\22end\22:{\22offset\22:198,\22line\22:2,\22column\22:147},\22action\22:\22charge_value\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:59,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:199,\22line\22:2,\22column\22:148},\22end\22:{\22offset\22:211,\22line\22:2,\22column\22:160},\22action\22:\22expression_step\22,\22type\22:6,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:60,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:199,\22line\22:2,\22column\22:148},\22end\22:{\22offset\22:211,\22line\22:2,\22column\22:160},\22action\22:\22expression_step\22,\22type\22:7,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:61,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:199,\22line\22:2,\22column\22:148},\22end\22:{\22offset\22:211,\22line\22:2,\22column\22:160},\22action\22:\22operation\22,\22type\22:7,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22Record.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:62,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:199,\22line\22:2,\22column\22:148},\22end\22:{\22offset\22:211,\22line\22:2,\22column\22:160},\22action\22:\22charge_value\22,\22type\22:7,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:63,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:199,\22line\22:2,\22column\22:148},\22end\22:{\22offset\22:211,\22line\22:2,\22column\22:160},\22action\22:\22convert_record_view\22,\22type\22:6,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:64,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:199,\22line\22:2,\22column\22:148},\22end\22:{\22offset\22:211,\22line\22:2,\22column\22:160},\22action\22:\22charge_value\22,\22type\22:6,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:65,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:177,\22line\22:2,\22column\22:126},\22end\22:{\22offset\22:212,\22line\22:2,\22column\22:161},\22action\22:\22operation\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22Error.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:5,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:5,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:6,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:66,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:177,\22line\22:2,\22column\22:126},\22end\22:{\22offset\22:212,\22line\22:2,\22column\22:161},\22action\22:\22charge_value\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:67,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22start\22:{\22offset\22:170,\22line\22:2,\22column\22:119},\22end\22:{\22offset\22:212,\22line\22:2,\22column\22:161},\22action\22:\22cause\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:1,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0}],\22source\22:{\22path\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002/3419148395.lo\22,\22sha256\22:\228132c2eeb0d8e8506e7ca0313b9138d813695c147c716403d731f16aed30f562\22},\22types\22:[{\22id\22:0,\22name\22:\22Error\22,\22kind\22:\22Error\22},{\22id\22:1,\22name\22:\22Null\22,\22kind\22:\22Null\22},{\22id\22:2,\22name\22:\22Bytes\22,\22kind\22:\22Bytes\22},{\22id\22:3,\22name\22:\22Bytes!\22,\22kind\22:\22Fallible\22},{\22id\22:4,\22name\22:\22File.Path\22,\22kind\22:\22File.Path\22},{\22id\22:5,\22name\22:\22String\22,\22kind\22:\22String\22},{\22id\22:6,\22name\22:\22Record\22,\22kind\22:\22Record\22},{\22id\22:7,\22name\22:\22Record{}\22,\22kind\22:\22ExactRecord\22}]}", align 1
@lo_program_metadata_size = constant i64 31750
@lo_program_flow_count = constant i64 2
@lo_program_flows = constant [2 x ptr] [ptr @lo_flow_0, ptr @lo_flow_1]

declare void @lo_cause(ptr, ptr, i64, i64, ptr)
declare void @lo_charge_value(ptr, ptr, i64, i64, ptr)
declare void @lo_convert_failure(ptr, ptr, i64, i64, ptr)
declare void @lo_convert_propagate(ptr, ptr, i64, i64, ptr)
declare void @lo_convert_record_view(ptr, ptr, i64, i64, ptr)
declare void @lo_convert_success(ptr, ptr, i64, i64, ptr)
declare void @lo_flow_enter(ptr, ptr, i64, i64, ptr)
declare void @lo_flow_error(ptr, i64, ptr, i64, i64, ptr)
declare void @lo_invalid_status(ptr, ptr, i64, i64, ptr)
declare void @lo_literal(ptr, ptr, i64, i64, ptr)
declare void @lo_op_Error_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_op_File_2EPath_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_op_File_2Eread(ptr, ptr, i64, i64, ptr)
declare void @lo_op_Record_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_scope_enter(ptr, ptr, i64, i64, ptr)
declare void @lo_step(ptr, ptr, i64, i64, ptr)
declare void @lo_value_retain(ptr)
declare void @lo_value_release(ptr)
declare void @lo_scope_leave(ptr, ptr, i64)
declare void @lo_flow_leave(ptr)
declare i32 @lo_boolean_value(ptr)

declare void @lo_derivative_leave(ptr)

define internal void @lo_result_copy_value(ptr %out, ptr %result) #0 {
entry:
  %old_pointer = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %old = load ptr, ptr %old_pointer, align 8
  %value_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 2
  %value = load ptr, ptr %value_pointer, align 8
  call void @lo_value_retain(ptr %value)
  call void @lo_value_release(ptr %old)
  %copy = load %lo.result, ptr %result, align 8
  store %lo.result %copy, ptr %out, align 8
  ret void
}
define internal void @lo_result_copy_host(ptr %out, ptr %result) #0 {
entry:
  %old_pointer = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %old = load ptr, ptr %old_pointer, align 8
  call void @lo_value_release(ptr %old)
  %code_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 1
  %code = load i32, ptr %code_pointer, align 4
  %copy = insertvalue %lo.result { i32 2, i32 0, ptr null }, i32 %code, 1
  store %lo.result %copy, ptr %out, align 8
  ret void
}
define internal i1 @lo_result_transfer(ptr %out, ptr %result, ptr %owned) #0 {
entry:
  %status_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 0
  %status = load i32, ptr %status_pointer, align 4
  switch i32 %status, label %unknown [ i32 0, label %payload i32 1, label %payload i32 2, label %host ]
payload:
  %value_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 2
  %value = load ptr, ptr %value_pointer, align 8
  store ptr %value, ptr %owned, align 8
  call void @lo_result_copy_value(ptr %out, ptr %result)
  ret i1 true
host:
  call void @lo_result_copy_host(ptr %out, ptr %result)
  ret i1 true
unknown:
  ret i1 false
}


define void @lo_semantic_entry(ptr %context, ptr %arguments, i64 %argc, i64 %callsite, ptr %out) #0 !dbg !6 {
entry:
  %v1 = alloca ptr, align 8
  store ptr null, ptr %v1, align 8
  %v2 = alloca ptr, align 8
  store ptr null, ptr %v2, align 8
  %v3 = alloca ptr, align 8
  store ptr null, ptr %v3, align 8
  %v4 = alloca ptr, align 8
  store ptr null, ptr %v4, align 8
  %v5 = alloca ptr, align 8
  store ptr null, ptr %v5, align 8
  %v6 = alloca ptr, align 8
  store ptr null, ptr %v6, align 8
  %v7 = alloca ptr, align 8
  store ptr null, ptr %v7, align 8
  %v8 = alloca ptr, align 8
  store ptr null, ptr %v8, align 8
  %r1 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r1, align 8
  %r2 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r2, align 8
  %r3 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r3, align 8
  %r4 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r4, align 8
  %r5 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r5, align 8
  %r6 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r6, align 8
  %r7 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r7, align 8
  %r8 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r8, align 8
  %args7 = alloca [1 x ptr], align 8
  %args8 = alloca [1 x ptr], align 8
  store %lo.result zeroinitializer, ptr %out, align 8
  br label %b0
b0:
  %x1 = icmp eq i64 %argc, 0, !dbg !8
  br i1 %x1, label %b4, label %b5, !dbg !8
b1:
  %x2 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x2), !dbg !8
  store ptr null, ptr %v1, align 8, !dbg !8
  %x3 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x3), !dbg !8
  store ptr null, ptr %v2, align 8, !dbg !8
  %x4 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x4), !dbg !8
  store ptr null, ptr %v3, align 8, !dbg !8
  %x5 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x5), !dbg !8
  store ptr null, ptr %v4, align 8, !dbg !8
  %x6 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x6), !dbg !8
  store ptr null, ptr %v5, align 8, !dbg !8
  %x7 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x7), !dbg !8
  store ptr null, ptr %v6, align 8, !dbg !8
  %x8 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x8), !dbg !8
  store ptr null, ptr %v7, align 8, !dbg !8
  %x9 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x9), !dbg !8
  store ptr null, ptr %v8, align 8, !dbg !8
  ret void, !dbg !8
b2:
  br label %b1, !dbg !8
b3:
  %x10 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x11 = load ptr, ptr %x10, align 8
  call void @lo_scope_leave(ptr %context, ptr %x11, i64 2), !dbg !8
  %x12 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x12), !dbg !8
  store ptr null, ptr %v1, align 8, !dbg !8
  %x13 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x13), !dbg !8
  store ptr null, ptr %v2, align 8, !dbg !8
  %x14 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x14), !dbg !8
  store ptr null, ptr %v3, align 8, !dbg !8
  %x15 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x15), !dbg !8
  store ptr null, ptr %v4, align 8, !dbg !8
  %x16 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x16), !dbg !8
  store ptr null, ptr %v5, align 8, !dbg !8
  %x17 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x17), !dbg !8
  store ptr null, ptr %v6, align 8, !dbg !8
  %x18 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x18), !dbg !8
  store ptr null, ptr %v7, align 8, !dbg !8
  %x19 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x19), !dbg !8
  store ptr null, ptr %v8, align 8, !dbg !8
  br label %b1, !dbg !8
b4:
  call void @lo_scope_enter(ptr %context, ptr null, i64 0, i64 3, ptr %r2), !dbg !10
  %x20 = getelementptr %lo.result, ptr %r2, i32 0, i32 0
  %x21 = load i32, ptr %x20, align 4, !dbg !10
  switch i32 %x21, label %b5 [ i32 0, label %b6 i32 1, label %b5 i32 2, label %b7 ], !dbg !10
b5:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 2, ptr %r1), !dbg !8
  call void @lo_result_copy_host(ptr %out, ptr %r1), !dbg !8
  br label %b1, !dbg !8
b6:
  %x22 = getelementptr %lo.result, ptr %r2, i32 0, i32 2
  %x23 = load ptr, ptr %x22, align 8
  store ptr %x23, ptr %v2, align 8, !dbg !10
  call void @lo_step(ptr %context, ptr null, i64 0, i64 4, ptr %r3), !dbg !12
  %x24 = getelementptr %lo.result, ptr %r3, i32 0, i32 0
  %x25 = load i32, ptr %x24, align 4, !dbg !12
  switch i32 %x25, label %b14 [ i32 0, label %b10 i32 1, label %b14 i32 2, label %b11 ], !dbg !12
b7:
  %x26 = call i1 @lo_result_transfer(ptr %out, ptr %r2, ptr %v2), !dbg !8
  br i1 %x26, label %b1, label %b5, !dbg !8
b10:
  %x27 = getelementptr %lo.result, ptr %r3, i32 0, i32 2
  %x28 = load ptr, ptr %x27, align 8
  store ptr %x28, ptr %v3, align 8, !dbg !12
  call void @lo_step(ptr %context, ptr null, i64 0, i64 5, ptr %r5), !dbg !14
  %x29 = getelementptr %lo.result, ptr %r5, i32 0, i32 0
  %x30 = load i32, ptr %x29, align 4, !dbg !14
  switch i32 %x30, label %b14 [ i32 0, label %b15 i32 1, label %b14 i32 2, label %b16 ], !dbg !14
b11:
  %x31 = call i1 @lo_result_transfer(ptr %out, ptr %r3, ptr %v3), !dbg !8
  br i1 %x31, label %b3, label %b14, !dbg !8
b14:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 2, ptr %r4), !dbg !8
  call void @lo_result_copy_host(ptr %out, ptr %r4), !dbg !8
  br label %b3, !dbg !8
b15:
  %x32 = getelementptr %lo.result, ptr %r5, i32 0, i32 2
  %x33 = load ptr, ptr %x32, align 8
  store ptr %x33, ptr %v5, align 8, !dbg !14
  call void @lo_flow_1(ptr %context, ptr null, i64 0, i64 6, ptr %r6), !dbg !16
  %x34 = getelementptr %lo.result, ptr %r6, i32 0, i32 0
  %x35 = load i32, ptr %x34, align 4, !dbg !16
  switch i32 %x35, label %b14 [ i32 0, label %b19 i32 1, label %b14 i32 2, label %b20 ], !dbg !16
b16:
  %x36 = call i1 @lo_result_transfer(ptr %out, ptr %r5, ptr %v5), !dbg !8
  br i1 %x36, label %b3, label %b14, !dbg !8
b19:
  %x37 = getelementptr %lo.result, ptr %r6, i32 0, i32 2
  %x38 = load ptr, ptr %x37, align 8
  store ptr %x38, ptr %v6, align 8, !dbg !16
  %x40 = load ptr, ptr %v6, align 8
  %x39 = getelementptr [1 x ptr], ptr %args7, i64 0, i64 0, !dbg !18
  store ptr %x40, ptr %x39, align 8, !dbg !18
  call void @lo_charge_value(ptr %context, ptr %args7, i64 1, i64 7, ptr %r7), !dbg !18
  %x41 = getelementptr %lo.result, ptr %r7, i32 0, i32 0
  %x42 = load i32, ptr %x41, align 4, !dbg !18
  switch i32 %x42, label %b14 [ i32 0, label %b23 i32 1, label %b14 i32 2, label %b24 ], !dbg !18
b20:
  %x43 = call i1 @lo_result_transfer(ptr %out, ptr %r6, ptr %v6), !dbg !8
  br i1 %x43, label %b3, label %b14, !dbg !8
b23:
  %x44 = getelementptr %lo.result, ptr %r7, i32 0, i32 2
  %x45 = load ptr, ptr %x44, align 8
  store ptr %x45, ptr %v7, align 8, !dbg !18
  %x47 = load ptr, ptr %v6, align 8
  %x46 = getelementptr [1 x ptr], ptr %args8, i64 0, i64 0, !dbg !20
  store ptr %x47, ptr %x46, align 8, !dbg !20
  call void @lo_cause(ptr %context, ptr %args8, i64 1, i64 8, ptr %r8), !dbg !20
  %x48 = getelementptr %lo.result, ptr %r8, i32 0, i32 0
  %x49 = load i32, ptr %x48, align 4, !dbg !20
  switch i32 %x49, label %b14 [ i32 0, label %b27 i32 1, label %b27 i32 2, label %b27 ], !dbg !20
b24:
  %x50 = call i1 @lo_result_transfer(ptr %out, ptr %r7, ptr %v7), !dbg !8
  br i1 %x50, label %b3, label %b14, !dbg !8
b27:
  %x51 = call i1 @lo_result_transfer(ptr %out, ptr %r8, ptr %v8), !dbg !8
  br i1 %x51, label %b3, label %b14, !dbg !8
}

define void @lo_flow_0(ptr %context, ptr %arguments, i64 %argc, i64 %callsite, ptr %out) #0 !dbg !21 {
entry:
  %v1 = alloca ptr, align 8
  store ptr null, ptr %v1, align 8
  %v2 = alloca ptr, align 8
  store ptr null, ptr %v2, align 8
  %v3 = alloca ptr, align 8
  store ptr null, ptr %v3, align 8
  %v4 = alloca ptr, align 8
  store ptr null, ptr %v4, align 8
  %v5 = alloca ptr, align 8
  store ptr null, ptr %v5, align 8
  %v6 = alloca ptr, align 8
  store ptr null, ptr %v6, align 8
  %v7 = alloca ptr, align 8
  store ptr null, ptr %v7, align 8
  %v8 = alloca ptr, align 8
  store ptr null, ptr %v8, align 8
  %v9 = alloca ptr, align 8
  store ptr null, ptr %v9, align 8
  %v10 = alloca ptr, align 8
  store ptr null, ptr %v10, align 8
  %v11 = alloca ptr, align 8
  store ptr null, ptr %v11, align 8
  %v12 = alloca ptr, align 8
  store ptr null, ptr %v12, align 8
  %v13 = alloca ptr, align 8
  store ptr null, ptr %v13, align 8
  %r1 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r1, align 8
  %r2 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r2, align 8
  %r3 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r3, align 8
  %r4 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r4, align 8
  %r5 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r5, align 8
  %r6 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r6, align 8
  %r7 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r7, align 8
  %r8 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r8, align 8
  %r9 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r9, align 8
  %r10 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r10, align 8
  %args8 = alloca [1 x ptr], align 8
  %args9 = alloca [1 x ptr], align 8
  %args10 = alloca [2 x ptr], align 8
  store %lo.result zeroinitializer, ptr %out, align 8
  br label %b0
b0:
  %x1 = icmp eq i64 %argc, 1, !dbg !23
  br i1 %x1, label %b4, label %b5, !dbg !23
b1:
  %x2 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x2), !dbg !23
  store ptr null, ptr %v1, align 8, !dbg !23
  %x3 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x3), !dbg !23
  store ptr null, ptr %v2, align 8, !dbg !23
  %x4 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x4), !dbg !23
  store ptr null, ptr %v3, align 8, !dbg !23
  %x5 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x5), !dbg !23
  store ptr null, ptr %v4, align 8, !dbg !23
  %x6 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x6), !dbg !23
  store ptr null, ptr %v6, align 8, !dbg !23
  %x7 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x7), !dbg !23
  store ptr null, ptr %v7, align 8, !dbg !23
  %x8 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x8), !dbg !23
  store ptr null, ptr %v8, align 8, !dbg !23
  %x9 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x9), !dbg !23
  store ptr null, ptr %v9, align 8, !dbg !23
  %x10 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x10), !dbg !23
  store ptr null, ptr %v10, align 8, !dbg !23
  %x11 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x11), !dbg !23
  store ptr null, ptr %v11, align 8, !dbg !23
  %x12 = load ptr, ptr %v12, align 8
  call void @lo_value_release(ptr %x12), !dbg !23
  store ptr null, ptr %v12, align 8, !dbg !23
  %x13 = load ptr, ptr %v13, align 8
  call void @lo_value_release(ptr %x13), !dbg !23
  store ptr null, ptr %v13, align 8, !dbg !23
  ret void, !dbg !23
b2:
  call void @lo_flow_leave(ptr %context), !dbg !23
  br label %b1, !dbg !23
b3:
  %x14 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x15 = load ptr, ptr %x14, align 8
  call void @lo_scope_leave(ptr %context, ptr %x15, i64 9), !dbg !23
  %x16 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x16), !dbg !23
  store ptr null, ptr %v1, align 8, !dbg !23
  %x17 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x17), !dbg !23
  store ptr null, ptr %v2, align 8, !dbg !23
  %x18 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x18), !dbg !23
  store ptr null, ptr %v3, align 8, !dbg !23
  %x19 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x19), !dbg !23
  store ptr null, ptr %v4, align 8, !dbg !23
  %x20 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x20), !dbg !23
  store ptr null, ptr %v6, align 8, !dbg !23
  %x21 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x21), !dbg !23
  store ptr null, ptr %v7, align 8, !dbg !23
  %x22 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x22), !dbg !23
  store ptr null, ptr %v8, align 8, !dbg !23
  %x23 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x23), !dbg !23
  store ptr null, ptr %v9, align 8, !dbg !23
  %x24 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x24), !dbg !23
  store ptr null, ptr %v10, align 8, !dbg !23
  %x25 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x25), !dbg !23
  store ptr null, ptr %v11, align 8, !dbg !23
  %x26 = load ptr, ptr %v12, align 8
  call void @lo_value_release(ptr %x26), !dbg !23
  store ptr null, ptr %v12, align 8, !dbg !23
  %x27 = load ptr, ptr %v13, align 8
  call void @lo_value_release(ptr %x27), !dbg !23
  store ptr null, ptr %v13, align 8, !dbg !23
  %x28 = getelementptr %lo.result, ptr %out, i32 0, i32 0
  %x29 = load i32, ptr %x28, align 4, !dbg !23
  switch i32 %x29, label %b14 [ i32 0, label %b2 i32 1, label %b31 i32 2, label %b2 ], !dbg !23
b4:
  call void @lo_flow_enter(ptr %context, ptr null, i64 0, i64 %callsite, ptr %r2), !dbg !25
  %x30 = getelementptr %lo.result, ptr %r2, i32 0, i32 0
  %x31 = load i32, ptr %x30, align 4, !dbg !25
  switch i32 %x31, label %b5 [ i32 0, label %b6 i32 1, label %b5 i32 2, label %b7 ], !dbg !25
b5:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 9, ptr %r1), !dbg !23
  call void @lo_result_copy_host(ptr %out, ptr %r1), !dbg !23
  br label %b1, !dbg !23
b6:
  %x32 = getelementptr %lo.result, ptr %r2, i32 0, i32 2
  %x33 = load ptr, ptr %x32, align 8
  store ptr %x33, ptr %v2, align 8, !dbg !25
  call void @lo_scope_enter(ptr %context, ptr null, i64 0, i64 11, ptr %r3), !dbg !27
  %x34 = getelementptr %lo.result, ptr %r3, i32 0, i32 0
  %x35 = load i32, ptr %x34, align 4, !dbg !27
  switch i32 %x35, label %b14 [ i32 0, label %b10 i32 1, label %b14 i32 2, label %b11 ], !dbg !27
b7:
  %x36 = call i1 @lo_result_transfer(ptr %out, ptr %r2, ptr %v2), !dbg !23
  br i1 %x36, label %b1, label %b5, !dbg !23
b10:
  %x37 = getelementptr %lo.result, ptr %r3, i32 0, i32 2
  %x38 = load ptr, ptr %x37, align 8
  store ptr %x38, ptr %v3, align 8, !dbg !27
  %x39 = getelementptr ptr, ptr %arguments, i64 0, !dbg !29
  %x40 = load ptr, ptr %x39, align 8, !dbg !29
  store ptr %x40, ptr %v5, align 8, !dbg !29
  call void @lo_step(ptr %context, ptr null, i64 0, i64 13, ptr %r5), !dbg !31
  %x41 = getelementptr %lo.result, ptr %r5, i32 0, i32 0
  %x42 = load i32, ptr %x41, align 4, !dbg !31
  switch i32 %x42, label %b19 [ i32 0, label %b15 i32 1, label %b19 i32 2, label %b16 ], !dbg !31
b11:
  %x43 = call i1 @lo_result_transfer(ptr %out, ptr %r3, ptr %v3), !dbg !23
  br i1 %x43, label %b2, label %b14, !dbg !23
b14:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 9, ptr %r4), !dbg !23
  call void @lo_result_copy_host(ptr %out, ptr %r4), !dbg !23
  br label %b2, !dbg !23
b15:
  %x44 = getelementptr %lo.result, ptr %r5, i32 0, i32 2
  %x45 = load ptr, ptr %x44, align 8
  store ptr %x45, ptr %v6, align 8, !dbg !31
  call void @lo_step(ptr %context, ptr null, i64 0, i64 14, ptr %r7), !dbg !33
  %x46 = getelementptr %lo.result, ptr %r7, i32 0, i32 0
  %x47 = load i32, ptr %x46, align 4, !dbg !33
  switch i32 %x47, label %b19 [ i32 0, label %b20 i32 1, label %b19 i32 2, label %b21 ], !dbg !33
b16:
  %x48 = call i1 @lo_result_transfer(ptr %out, ptr %r5, ptr %v6), !dbg !23
  br i1 %x48, label %b3, label %b19, !dbg !23
b19:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 9, ptr %r6), !dbg !23
  call void @lo_result_copy_host(ptr %out, ptr %r6), !dbg !23
  br label %b3, !dbg !23
b20:
  %x49 = getelementptr %lo.result, ptr %r7, i32 0, i32 2
  %x50 = load ptr, ptr %x49, align 8
  store ptr %x50, ptr %v8, align 8, !dbg !33
  %x51 = load ptr, ptr %v5, align 8
  call void @lo_value_retain(ptr %x51), !dbg !35
  store ptr %x51, ptr %v9, align 8, !dbg !35
  %x53 = load ptr, ptr %v9, align 8
  %x52 = getelementptr [1 x ptr], ptr %args8, i64 0, i64 0, !dbg !37
  store ptr %x53, ptr %x52, align 8, !dbg !37
  call void @lo_charge_value(ptr %context, ptr %args8, i64 1, i64 16, ptr %r8), !dbg !37
  %x54 = getelementptr %lo.result, ptr %r8, i32 0, i32 0
  %x55 = load i32, ptr %x54, align 4, !dbg !37
  switch i32 %x55, label %b19 [ i32 0, label %b24 i32 1, label %b19 i32 2, label %b25 ], !dbg !37
b21:
  %x56 = call i1 @lo_result_transfer(ptr %out, ptr %r7, ptr %v8), !dbg !23
  br i1 %x56, label %b3, label %b19, !dbg !23
b24:
  %x57 = getelementptr %lo.result, ptr %r8, i32 0, i32 2
  %x58 = load ptr, ptr %x57, align 8
  store ptr %x58, ptr %v10, align 8, !dbg !37
  %x60 = load ptr, ptr %v9, align 8
  %x59 = getelementptr [1 x ptr], ptr %args9, i64 0, i64 0, !dbg !39
  store ptr %x60, ptr %x59, align 8, !dbg !39
  call void @lo_cause(ptr %context, ptr %args9, i64 1, i64 17, ptr %r9), !dbg !39
  %x61 = getelementptr %lo.result, ptr %r9, i32 0, i32 0
  %x62 = load i32, ptr %x61, align 4, !dbg !39
  switch i32 %x62, label %b19 [ i32 0, label %b28 i32 1, label %b28 i32 2, label %b28 ], !dbg !39
b25:
  %x63 = call i1 @lo_result_transfer(ptr %out, ptr %r8, ptr %v10), !dbg !23
  br i1 %x63, label %b3, label %b19, !dbg !23
b28:
  %x64 = call i1 @lo_result_transfer(ptr %out, ptr %r9, ptr %v11), !dbg !23
  br i1 %x64, label %b3, label %b19, !dbg !23
b31:
  %x65 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x66 = load ptr, ptr %x65, align 8
  call void @lo_value_retain(ptr %x66), !dbg !23
  store ptr %x66, ptr %v12, align 8, !dbg !23
  %x68 = load ptr, ptr %v12, align 8
  %x67 = getelementptr [2 x ptr], ptr %args10, i64 0, i64 0, !dbg !23
  store ptr %x68, ptr %x67, align 8, !dbg !23
  %x70 = load ptr, ptr %v5, align 8
  %x69 = getelementptr [2 x ptr], ptr %args10, i64 0, i64 1, !dbg !23
  store ptr %x70, ptr %x69, align 8, !dbg !23
  call void @lo_flow_error(ptr %context, i64 0, ptr %args10, i64 2, i64 %callsite, ptr %r10), !dbg !23
  %x71 = getelementptr %lo.result, ptr %r10, i32 0, i32 0
  %x72 = load i32, ptr %x71, align 4, !dbg !23
  switch i32 %x72, label %b14 [ i32 0, label %b14 i32 1, label %b32 i32 2, label %b33 ], !dbg !23
b32:
  %x73 = getelementptr %lo.result, ptr %r10, i32 0, i32 2
  %x74 = load ptr, ptr %x73, align 8
  store ptr %x74, ptr %v13, align 8, !dbg !23
  call void @lo_result_copy_value(ptr %out, ptr %r10), !dbg !23
  br label %b2, !dbg !23
b33:
  %x75 = call i1 @lo_result_transfer(ptr %out, ptr %r10, ptr %v13), !dbg !23
  br i1 %x75, label %b2, label %b14, !dbg !23
}

define void @lo_flow_1(ptr %context, ptr %arguments, i64 %argc, i64 %callsite, ptr %out) #0 !dbg !40 {
entry:
  %v1 = alloca ptr, align 8
  store ptr null, ptr %v1, align 8
  %v2 = alloca ptr, align 8
  store ptr null, ptr %v2, align 8
  %v3 = alloca ptr, align 8
  store ptr null, ptr %v3, align 8
  %v4 = alloca ptr, align 8
  store ptr null, ptr %v4, align 8
  %v5 = alloca ptr, align 8
  store ptr null, ptr %v5, align 8
  %v6 = alloca ptr, align 8
  store ptr null, ptr %v6, align 8
  %v7 = alloca ptr, align 8
  store ptr null, ptr %v7, align 8
  %v8 = alloca ptr, align 8
  store ptr null, ptr %v8, align 8
  %v9 = alloca ptr, align 8
  store ptr null, ptr %v9, align 8
  %v10 = alloca ptr, align 8
  store ptr null, ptr %v10, align 8
  %v11 = alloca ptr, align 8
  store ptr null, ptr %v11, align 8
  %v12 = alloca ptr, align 8
  store ptr null, ptr %v12, align 8
  %v13 = alloca ptr, align 8
  store ptr null, ptr %v13, align 8
  %v14 = alloca ptr, align 8
  store ptr null, ptr %v14, align 8
  %v15 = alloca ptr, align 8
  store ptr null, ptr %v15, align 8
  %v16 = alloca ptr, align 8
  store ptr null, ptr %v16, align 8
  %v17 = alloca ptr, align 8
  store ptr null, ptr %v17, align 8
  %v18 = alloca ptr, align 8
  store ptr null, ptr %v18, align 8
  %v19 = alloca ptr, align 8
  store ptr null, ptr %v19, align 8
  %v20 = alloca ptr, align 8
  store ptr null, ptr %v20, align 8
  %v21 = alloca ptr, align 8
  store ptr null, ptr %v21, align 8
  %v22 = alloca ptr, align 8
  store ptr null, ptr %v22, align 8
  %v23 = alloca ptr, align 8
  store ptr null, ptr %v23, align 8
  %v24 = alloca ptr, align 8
  store ptr null, ptr %v24, align 8
  %v25 = alloca ptr, align 8
  store ptr null, ptr %v25, align 8
  %v26 = alloca ptr, align 8
  store ptr null, ptr %v26, align 8
  %v27 = alloca ptr, align 8
  store ptr null, ptr %v27, align 8
  %v28 = alloca ptr, align 8
  store ptr null, ptr %v28, align 8
  %v29 = alloca ptr, align 8
  store ptr null, ptr %v29, align 8
  %v30 = alloca ptr, align 8
  store ptr null, ptr %v30, align 8
  %v31 = alloca ptr, align 8
  store ptr null, ptr %v31, align 8
  %v32 = alloca ptr, align 8
  store ptr null, ptr %v32, align 8
  %v33 = alloca ptr, align 8
  store ptr null, ptr %v33, align 8
  %v34 = alloca ptr, align 8
  store ptr null, ptr %v34, align 8
  %v35 = alloca ptr, align 8
  store ptr null, ptr %v35, align 8
  %v36 = alloca ptr, align 8
  store ptr null, ptr %v36, align 8
  %v37 = alloca ptr, align 8
  store ptr null, ptr %v37, align 8
  %v38 = alloca ptr, align 8
  store ptr null, ptr %v38, align 8
  %v39 = alloca ptr, align 8
  store ptr null, ptr %v39, align 8
  %v40 = alloca ptr, align 8
  store ptr null, ptr %v40, align 8
  %v41 = alloca ptr, align 8
  store ptr null, ptr %v41, align 8
  %v42 = alloca ptr, align 8
  store ptr null, ptr %v42, align 8
  %v43 = alloca ptr, align 8
  store ptr null, ptr %v43, align 8
  %v44 = alloca ptr, align 8
  store ptr null, ptr %v44, align 8
  %v45 = alloca ptr, align 8
  store ptr null, ptr %v45, align 8
  %v46 = alloca ptr, align 8
  store ptr null, ptr %v46, align 8
  %v47 = alloca ptr, align 8
  store ptr null, ptr %v47, align 8
  %v48 = alloca ptr, align 8
  store ptr null, ptr %v48, align 8
  %v49 = alloca ptr, align 8
  store ptr null, ptr %v49, align 8
  %v50 = alloca ptr, align 8
  store ptr null, ptr %v50, align 8
  %v51 = alloca ptr, align 8
  store ptr null, ptr %v51, align 8
  %v52 = alloca ptr, align 8
  store ptr null, ptr %v52, align 8
  %v53 = alloca ptr, align 8
  store ptr null, ptr %v53, align 8
  %v54 = alloca ptr, align 8
  store ptr null, ptr %v54, align 8
  %v55 = alloca ptr, align 8
  store ptr null, ptr %v55, align 8
  %v56 = alloca ptr, align 8
  store ptr null, ptr %v56, align 8
  %v57 = alloca ptr, align 8
  store ptr null, ptr %v57, align 8
  %r1 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r1, align 8
  %r2 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r2, align 8
  %r3 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r3, align 8
  %r4 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r4, align 8
  %r5 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r5, align 8
  %r6 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r6, align 8
  %r7 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r7, align 8
  %r8 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r8, align 8
  %r9 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r9, align 8
  %r10 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r10, align 8
  %r11 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r11, align 8
  %r12 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r12, align 8
  %r13 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r13, align 8
  %r14 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r14, align 8
  %r15 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r15, align 8
  %r16 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r16, align 8
  %r17 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r17, align 8
  %r18 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r18, align 8
  %r19 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r19, align 8
  %r20 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r20, align 8
  %r21 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r21, align 8
  %r22 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r22, align 8
  %r23 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r23, align 8
  %r24 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r24, align 8
  %r25 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r25, align 8
  %r26 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r26, align 8
  %r27 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r27, align 8
  %r28 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r28, align 8
  %r29 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r29, align 8
  %r30 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r30, align 8
  %r31 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r31, align 8
  %r32 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r32, align 8
  %r33 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r33, align 8
  %r34 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r34, align 8
  %r35 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r35, align 8
  %r36 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r36, align 8
  %r37 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r37, align 8
  %r38 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r38, align 8
  %r39 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r39, align 8
  %r40 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r40, align 8
  %r41 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r41, align 8
  %r42 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r42, align 8
  %r43 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r43, align 8
  %r44 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r44, align 8
  %r45 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r45, align 8
  %r46 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r46, align 8
  %r47 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r47, align 8
  %r48 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r48, align 8
  %r49 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r49, align 8
  %r50 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r50, align 8
  %r51 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r51, align 8
  %r52 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r52, align 8
  %r53 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r53, align 8
  %r54 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r54, align 8
  %args12 = alloca [1 x ptr], align 8
  %args13 = alloca [1 x ptr], align 8
  %args14 = alloca [1 x ptr], align 8
  %args15 = alloca [1 x ptr], align 8
  %args16 = alloca [1 x ptr], align 8
  %args17 = alloca [1 x ptr], align 8
  %args18 = alloca [1 x ptr], align 8
  %args19 = alloca [1 x ptr], align 8
  %args20 = alloca [1 x ptr], align 8
  %args27 = alloca [1 x ptr], align 8
  %args28 = alloca [1 x ptr], align 8
  %args29 = alloca [1 x ptr], align 8
  %args30 = alloca [1 x ptr], align 8
  %args31 = alloca [1 x ptr], align 8
  %args32 = alloca [1 x ptr], align 8
  %args33 = alloca [1 x ptr], align 8
  %args34 = alloca [1 x ptr], align 8
  %args35 = alloca [1 x ptr], align 8
  %args40 = alloca [1 x ptr], align 8
  %args43 = alloca [1 x ptr], align 8
  %args47 = alloca [1 x ptr], align 8
  %args48 = alloca [1 x ptr], align 8
  %args49 = alloca [1 x ptr], align 8
  %args50 = alloca [3 x ptr], align 8
  %args51 = alloca [1 x ptr], align 8
  %args52 = alloca [1 x ptr], align 8
  %args53 = alloca [1 x ptr], align 8
  %args54 = alloca [1 x ptr], align 8
  store %lo.result zeroinitializer, ptr %out, align 8
  br label %b0
b0:
  %x1 = icmp eq i64 %argc, 0, !dbg !42
  br i1 %x1, label %b4, label %b5, !dbg !42
b1:
  %x2 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x2), !dbg !42
  store ptr null, ptr %v1, align 8, !dbg !42
  %x3 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x3), !dbg !42
  store ptr null, ptr %v2, align 8, !dbg !42
  %x4 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x4), !dbg !42
  store ptr null, ptr %v3, align 8, !dbg !42
  %x5 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x5), !dbg !42
  store ptr null, ptr %v4, align 8, !dbg !42
  %x6 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x6), !dbg !42
  store ptr null, ptr %v5, align 8, !dbg !42
  %x7 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x7), !dbg !42
  store ptr null, ptr %v6, align 8, !dbg !42
  %x8 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x8), !dbg !42
  store ptr null, ptr %v7, align 8, !dbg !42
  %x9 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x9), !dbg !42
  store ptr null, ptr %v8, align 8, !dbg !42
  %x10 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x10), !dbg !42
  store ptr null, ptr %v9, align 8, !dbg !42
  %x11 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x11), !dbg !42
  store ptr null, ptr %v10, align 8, !dbg !42
  %x12 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x12), !dbg !42
  store ptr null, ptr %v11, align 8, !dbg !42
  %x13 = load ptr, ptr %v12, align 8
  call void @lo_value_release(ptr %x13), !dbg !42
  store ptr null, ptr %v12, align 8, !dbg !42
  %x14 = load ptr, ptr %v13, align 8
  call void @lo_value_release(ptr %x14), !dbg !42
  store ptr null, ptr %v13, align 8, !dbg !42
  %x15 = load ptr, ptr %v14, align 8
  call void @lo_value_release(ptr %x15), !dbg !42
  store ptr null, ptr %v14, align 8, !dbg !42
  %x16 = load ptr, ptr %v15, align 8
  call void @lo_value_release(ptr %x16), !dbg !42
  store ptr null, ptr %v15, align 8, !dbg !42
  %x17 = load ptr, ptr %v16, align 8
  call void @lo_value_release(ptr %x17), !dbg !42
  store ptr null, ptr %v16, align 8, !dbg !42
  %x18 = load ptr, ptr %v17, align 8
  call void @lo_value_release(ptr %x18), !dbg !42
  store ptr null, ptr %v17, align 8, !dbg !42
  %x19 = load ptr, ptr %v18, align 8
  call void @lo_value_release(ptr %x19), !dbg !42
  store ptr null, ptr %v18, align 8, !dbg !42
  %x20 = load ptr, ptr %v19, align 8
  call void @lo_value_release(ptr %x20), !dbg !42
  store ptr null, ptr %v19, align 8, !dbg !42
  %x21 = load ptr, ptr %v20, align 8
  call void @lo_value_release(ptr %x21), !dbg !42
  store ptr null, ptr %v20, align 8, !dbg !42
  %x22 = load ptr, ptr %v21, align 8
  call void @lo_value_release(ptr %x22), !dbg !42
  store ptr null, ptr %v21, align 8, !dbg !42
  %x23 = load ptr, ptr %v22, align 8
  call void @lo_value_release(ptr %x23), !dbg !42
  store ptr null, ptr %v22, align 8, !dbg !42
  %x24 = load ptr, ptr %v23, align 8
  call void @lo_value_release(ptr %x24), !dbg !42
  store ptr null, ptr %v23, align 8, !dbg !42
  %x25 = load ptr, ptr %v24, align 8
  call void @lo_value_release(ptr %x25), !dbg !42
  store ptr null, ptr %v24, align 8, !dbg !42
  %x26 = load ptr, ptr %v25, align 8
  call void @lo_value_release(ptr %x26), !dbg !42
  store ptr null, ptr %v25, align 8, !dbg !42
  %x27 = load ptr, ptr %v26, align 8
  call void @lo_value_release(ptr %x27), !dbg !42
  store ptr null, ptr %v26, align 8, !dbg !42
  %x28 = load ptr, ptr %v27, align 8
  call void @lo_value_release(ptr %x28), !dbg !42
  store ptr null, ptr %v27, align 8, !dbg !42
  %x29 = load ptr, ptr %v28, align 8
  call void @lo_value_release(ptr %x29), !dbg !42
  store ptr null, ptr %v28, align 8, !dbg !42
  %x30 = load ptr, ptr %v29, align 8
  call void @lo_value_release(ptr %x30), !dbg !42
  store ptr null, ptr %v29, align 8, !dbg !42
  %x31 = load ptr, ptr %v30, align 8
  call void @lo_value_release(ptr %x31), !dbg !42
  store ptr null, ptr %v30, align 8, !dbg !42
  %x32 = load ptr, ptr %v31, align 8
  call void @lo_value_release(ptr %x32), !dbg !42
  store ptr null, ptr %v31, align 8, !dbg !42
  %x33 = load ptr, ptr %v32, align 8
  call void @lo_value_release(ptr %x33), !dbg !42
  store ptr null, ptr %v32, align 8, !dbg !42
  %x34 = load ptr, ptr %v33, align 8
  call void @lo_value_release(ptr %x34), !dbg !42
  store ptr null, ptr %v33, align 8, !dbg !42
  %x35 = load ptr, ptr %v34, align 8
  call void @lo_value_release(ptr %x35), !dbg !42
  store ptr null, ptr %v34, align 8, !dbg !42
  %x36 = load ptr, ptr %v35, align 8
  call void @lo_value_release(ptr %x36), !dbg !42
  store ptr null, ptr %v35, align 8, !dbg !42
  %x37 = load ptr, ptr %v36, align 8
  call void @lo_value_release(ptr %x37), !dbg !42
  store ptr null, ptr %v36, align 8, !dbg !42
  %x38 = load ptr, ptr %v37, align 8
  call void @lo_value_release(ptr %x38), !dbg !42
  store ptr null, ptr %v37, align 8, !dbg !42
  %x39 = load ptr, ptr %v38, align 8
  call void @lo_value_release(ptr %x39), !dbg !42
  store ptr null, ptr %v38, align 8, !dbg !42
  %x40 = load ptr, ptr %v39, align 8
  call void @lo_value_release(ptr %x40), !dbg !42
  store ptr null, ptr %v39, align 8, !dbg !42
  %x41 = load ptr, ptr %v40, align 8
  call void @lo_value_release(ptr %x41), !dbg !42
  store ptr null, ptr %v40, align 8, !dbg !42
  %x42 = load ptr, ptr %v41, align 8
  call void @lo_value_release(ptr %x42), !dbg !42
  store ptr null, ptr %v41, align 8, !dbg !42
  %x43 = load ptr, ptr %v42, align 8
  call void @lo_value_release(ptr %x43), !dbg !42
  store ptr null, ptr %v42, align 8, !dbg !42
  %x44 = load ptr, ptr %v43, align 8
  call void @lo_value_release(ptr %x44), !dbg !42
  store ptr null, ptr %v43, align 8, !dbg !42
  %x45 = load ptr, ptr %v44, align 8
  call void @lo_value_release(ptr %x45), !dbg !42
  store ptr null, ptr %v44, align 8, !dbg !42
  %x46 = load ptr, ptr %v45, align 8
  call void @lo_value_release(ptr %x46), !dbg !42
  store ptr null, ptr %v45, align 8, !dbg !42
  %x47 = load ptr, ptr %v46, align 8
  call void @lo_value_release(ptr %x47), !dbg !42
  store ptr null, ptr %v46, align 8, !dbg !42
  %x48 = load ptr, ptr %v47, align 8
  call void @lo_value_release(ptr %x48), !dbg !42
  store ptr null, ptr %v47, align 8, !dbg !42
  %x49 = load ptr, ptr %v48, align 8
  call void @lo_value_release(ptr %x49), !dbg !42
  store ptr null, ptr %v48, align 8, !dbg !42
  %x50 = load ptr, ptr %v49, align 8
  call void @lo_value_release(ptr %x50), !dbg !42
  store ptr null, ptr %v49, align 8, !dbg !42
  %x51 = load ptr, ptr %v50, align 8
  call void @lo_value_release(ptr %x51), !dbg !42
  store ptr null, ptr %v50, align 8, !dbg !42
  %x52 = load ptr, ptr %v51, align 8
  call void @lo_value_release(ptr %x52), !dbg !42
  store ptr null, ptr %v51, align 8, !dbg !42
  %x53 = load ptr, ptr %v52, align 8
  call void @lo_value_release(ptr %x53), !dbg !42
  store ptr null, ptr %v52, align 8, !dbg !42
  %x54 = load ptr, ptr %v53, align 8
  call void @lo_value_release(ptr %x54), !dbg !42
  store ptr null, ptr %v53, align 8, !dbg !42
  %x55 = load ptr, ptr %v54, align 8
  call void @lo_value_release(ptr %x55), !dbg !42
  store ptr null, ptr %v54, align 8, !dbg !42
  %x56 = load ptr, ptr %v55, align 8
  call void @lo_value_release(ptr %x56), !dbg !42
  store ptr null, ptr %v55, align 8, !dbg !42
  %x57 = load ptr, ptr %v56, align 8
  call void @lo_value_release(ptr %x57), !dbg !42
  store ptr null, ptr %v56, align 8, !dbg !42
  %x58 = load ptr, ptr %v57, align 8
  call void @lo_value_release(ptr %x58), !dbg !42
  store ptr null, ptr %v57, align 8, !dbg !42
  ret void, !dbg !42
b2:
  call void @lo_flow_leave(ptr %context), !dbg !42
  br label %b1, !dbg !42
b3:
  %x59 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x60 = load ptr, ptr %x59, align 8
  call void @lo_scope_leave(ptr %context, ptr %x60, i64 18), !dbg !42
  %x61 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x61), !dbg !42
  store ptr null, ptr %v1, align 8, !dbg !42
  %x62 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x62), !dbg !42
  store ptr null, ptr %v2, align 8, !dbg !42
  %x63 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x63), !dbg !42
  store ptr null, ptr %v3, align 8, !dbg !42
  %x64 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x64), !dbg !42
  store ptr null, ptr %v4, align 8, !dbg !42
  %x65 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x65), !dbg !42
  store ptr null, ptr %v5, align 8, !dbg !42
  %x66 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x66), !dbg !42
  store ptr null, ptr %v6, align 8, !dbg !42
  %x67 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x67), !dbg !42
  store ptr null, ptr %v7, align 8, !dbg !42
  %x68 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x68), !dbg !42
  store ptr null, ptr %v8, align 8, !dbg !42
  %x69 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x69), !dbg !42
  store ptr null, ptr %v9, align 8, !dbg !42
  %x70 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x70), !dbg !42
  store ptr null, ptr %v10, align 8, !dbg !42
  %x71 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x71), !dbg !42
  store ptr null, ptr %v11, align 8, !dbg !42
  %x72 = load ptr, ptr %v12, align 8
  call void @lo_value_release(ptr %x72), !dbg !42
  store ptr null, ptr %v12, align 8, !dbg !42
  %x73 = load ptr, ptr %v13, align 8
  call void @lo_value_release(ptr %x73), !dbg !42
  store ptr null, ptr %v13, align 8, !dbg !42
  %x74 = load ptr, ptr %v14, align 8
  call void @lo_value_release(ptr %x74), !dbg !42
  store ptr null, ptr %v14, align 8, !dbg !42
  %x75 = load ptr, ptr %v15, align 8
  call void @lo_value_release(ptr %x75), !dbg !42
  store ptr null, ptr %v15, align 8, !dbg !42
  %x76 = load ptr, ptr %v16, align 8
  call void @lo_value_release(ptr %x76), !dbg !42
  store ptr null, ptr %v16, align 8, !dbg !42
  %x77 = load ptr, ptr %v17, align 8
  call void @lo_value_release(ptr %x77), !dbg !42
  store ptr null, ptr %v17, align 8, !dbg !42
  %x78 = load ptr, ptr %v18, align 8
  call void @lo_value_release(ptr %x78), !dbg !42
  store ptr null, ptr %v18, align 8, !dbg !42
  %x79 = load ptr, ptr %v19, align 8
  call void @lo_value_release(ptr %x79), !dbg !42
  store ptr null, ptr %v19, align 8, !dbg !42
  %x80 = load ptr, ptr %v20, align 8
  call void @lo_value_release(ptr %x80), !dbg !42
  store ptr null, ptr %v20, align 8, !dbg !42
  %x81 = load ptr, ptr %v21, align 8
  call void @lo_value_release(ptr %x81), !dbg !42
  store ptr null, ptr %v21, align 8, !dbg !42
  %x82 = load ptr, ptr %v22, align 8
  call void @lo_value_release(ptr %x82), !dbg !42
  store ptr null, ptr %v22, align 8, !dbg !42
  %x83 = load ptr, ptr %v23, align 8
  call void @lo_value_release(ptr %x83), !dbg !42
  store ptr null, ptr %v23, align 8, !dbg !42
  %x84 = load ptr, ptr %v24, align 8
  call void @lo_value_release(ptr %x84), !dbg !42
  store ptr null, ptr %v24, align 8, !dbg !42
  %x85 = load ptr, ptr %v25, align 8
  call void @lo_value_release(ptr %x85), !dbg !42
  store ptr null, ptr %v25, align 8, !dbg !42
  %x86 = load ptr, ptr %v26, align 8
  call void @lo_value_release(ptr %x86), !dbg !42
  store ptr null, ptr %v26, align 8, !dbg !42
  %x87 = load ptr, ptr %v27, align 8
  call void @lo_value_release(ptr %x87), !dbg !42
  store ptr null, ptr %v27, align 8, !dbg !42
  %x88 = load ptr, ptr %v28, align 8
  call void @lo_value_release(ptr %x88), !dbg !42
  store ptr null, ptr %v28, align 8, !dbg !42
  %x89 = load ptr, ptr %v29, align 8
  call void @lo_value_release(ptr %x89), !dbg !42
  store ptr null, ptr %v29, align 8, !dbg !42
  %x90 = load ptr, ptr %v30, align 8
  call void @lo_value_release(ptr %x90), !dbg !42
  store ptr null, ptr %v30, align 8, !dbg !42
  %x91 = load ptr, ptr %v31, align 8
  call void @lo_value_release(ptr %x91), !dbg !42
  store ptr null, ptr %v31, align 8, !dbg !42
  %x92 = load ptr, ptr %v32, align 8
  call void @lo_value_release(ptr %x92), !dbg !42
  store ptr null, ptr %v32, align 8, !dbg !42
  %x93 = load ptr, ptr %v33, align 8
  call void @lo_value_release(ptr %x93), !dbg !42
  store ptr null, ptr %v33, align 8, !dbg !42
  %x94 = load ptr, ptr %v34, align 8
  call void @lo_value_release(ptr %x94), !dbg !42
  store ptr null, ptr %v34, align 8, !dbg !42
  %x95 = load ptr, ptr %v35, align 8
  call void @lo_value_release(ptr %x95), !dbg !42
  store ptr null, ptr %v35, align 8, !dbg !42
  %x96 = load ptr, ptr %v36, align 8
  call void @lo_value_release(ptr %x96), !dbg !42
  store ptr null, ptr %v36, align 8, !dbg !42
  %x97 = load ptr, ptr %v37, align 8
  call void @lo_value_release(ptr %x97), !dbg !42
  store ptr null, ptr %v37, align 8, !dbg !42
  %x98 = load ptr, ptr %v38, align 8
  call void @lo_value_release(ptr %x98), !dbg !42
  store ptr null, ptr %v38, align 8, !dbg !42
  %x99 = load ptr, ptr %v39, align 8
  call void @lo_value_release(ptr %x99), !dbg !42
  store ptr null, ptr %v39, align 8, !dbg !42
  %x100 = load ptr, ptr %v40, align 8
  call void @lo_value_release(ptr %x100), !dbg !42
  store ptr null, ptr %v40, align 8, !dbg !42
  %x101 = load ptr, ptr %v41, align 8
  call void @lo_value_release(ptr %x101), !dbg !42
  store ptr null, ptr %v41, align 8, !dbg !42
  %x102 = load ptr, ptr %v42, align 8
  call void @lo_value_release(ptr %x102), !dbg !42
  store ptr null, ptr %v42, align 8, !dbg !42
  %x103 = load ptr, ptr %v43, align 8
  call void @lo_value_release(ptr %x103), !dbg !42
  store ptr null, ptr %v43, align 8, !dbg !42
  %x104 = load ptr, ptr %v44, align 8
  call void @lo_value_release(ptr %x104), !dbg !42
  store ptr null, ptr %v44, align 8, !dbg !42
  %x105 = load ptr, ptr %v45, align 8
  call void @lo_value_release(ptr %x105), !dbg !42
  store ptr null, ptr %v45, align 8, !dbg !42
  %x106 = load ptr, ptr %v46, align 8
  call void @lo_value_release(ptr %x106), !dbg !42
  store ptr null, ptr %v46, align 8, !dbg !42
  %x107 = load ptr, ptr %v47, align 8
  call void @lo_value_release(ptr %x107), !dbg !42
  store ptr null, ptr %v47, align 8, !dbg !42
  %x108 = load ptr, ptr %v48, align 8
  call void @lo_value_release(ptr %x108), !dbg !42
  store ptr null, ptr %v48, align 8, !dbg !42
  %x109 = load ptr, ptr %v49, align 8
  call void @lo_value_release(ptr %x109), !dbg !42
  store ptr null, ptr %v49, align 8, !dbg !42
  %x110 = load ptr, ptr %v50, align 8
  call void @lo_value_release(ptr %x110), !dbg !42
  store ptr null, ptr %v50, align 8, !dbg !42
  %x111 = load ptr, ptr %v51, align 8
  call void @lo_value_release(ptr %x111), !dbg !42
  store ptr null, ptr %v51, align 8, !dbg !42
  %x112 = load ptr, ptr %v52, align 8
  call void @lo_value_release(ptr %x112), !dbg !42
  store ptr null, ptr %v52, align 8, !dbg !42
  %x113 = load ptr, ptr %v53, align 8
  call void @lo_value_release(ptr %x113), !dbg !42
  store ptr null, ptr %v53, align 8, !dbg !42
  %x114 = load ptr, ptr %v54, align 8
  call void @lo_value_release(ptr %x114), !dbg !42
  store ptr null, ptr %v54, align 8, !dbg !42
  %x115 = load ptr, ptr %v55, align 8
  call void @lo_value_release(ptr %x115), !dbg !42
  store ptr null, ptr %v55, align 8, !dbg !42
  %x116 = load ptr, ptr %v56, align 8
  call void @lo_value_release(ptr %x116), !dbg !42
  store ptr null, ptr %v56, align 8, !dbg !42
  %x117 = load ptr, ptr %v57, align 8
  call void @lo_value_release(ptr %x117), !dbg !42
  store ptr null, ptr %v57, align 8, !dbg !42
  %x118 = getelementptr %lo.result, ptr %out, i32 0, i32 0
  %x119 = load i32, ptr %x118, align 4, !dbg !42
  switch i32 %x119, label %b14 [ i32 0, label %b2 i32 1, label %b207 i32 2, label %b2 ], !dbg !42
b4:
  call void @lo_flow_enter(ptr %context, ptr null, i64 0, i64 %callsite, ptr %r2), !dbg !44
  %x120 = getelementptr %lo.result, ptr %r2, i32 0, i32 0
  %x121 = load i32, ptr %x120, align 4, !dbg !44
  switch i32 %x121, label %b5 [ i32 0, label %b6 i32 1, label %b5 i32 2, label %b7 ], !dbg !44
b5:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 18, ptr %r1), !dbg !42
  call void @lo_result_copy_host(ptr %out, ptr %r1), !dbg !42
  br label %b1, !dbg !42
b6:
  %x122 = getelementptr %lo.result, ptr %r2, i32 0, i32 2
  %x123 = load ptr, ptr %x122, align 8
  store ptr %x123, ptr %v2, align 8, !dbg !44
  call void @lo_scope_enter(ptr %context, ptr null, i64 0, i64 20, ptr %r3), !dbg !46
  %x124 = getelementptr %lo.result, ptr %r3, i32 0, i32 0
  %x125 = load i32, ptr %x124, align 4, !dbg !46
  switch i32 %x125, label %b14 [ i32 0, label %b10 i32 1, label %b14 i32 2, label %b11 ], !dbg !46
b7:
  %x126 = call i1 @lo_result_transfer(ptr %out, ptr %r2, ptr %v2), !dbg !42
  br i1 %x126, label %b1, label %b5, !dbg !42
b10:
  %x127 = getelementptr %lo.result, ptr %r3, i32 0, i32 2
  %x128 = load ptr, ptr %x127, align 8
  store ptr %x128, ptr %v3, align 8, !dbg !46
  call void @lo_step(ptr %context, ptr null, i64 0, i64 21, ptr %r5), !dbg !48
  %x129 = getelementptr %lo.result, ptr %r5, i32 0, i32 0
  %x130 = load i32, ptr %x129, align 4, !dbg !48
  switch i32 %x130, label %b19 [ i32 0, label %b15 i32 1, label %b19 i32 2, label %b16 ], !dbg !48
b11:
  %x131 = call i1 @lo_result_transfer(ptr %out, ptr %r3, ptr %v3), !dbg !42
  br i1 %x131, label %b2, label %b14, !dbg !42
b14:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 18, ptr %r4), !dbg !42
  call void @lo_result_copy_host(ptr %out, ptr %r4), !dbg !42
  br label %b2, !dbg !42
b15:
  %x132 = getelementptr %lo.result, ptr %r5, i32 0, i32 2
  %x133 = load ptr, ptr %x132, align 8
  store ptr %x133, ptr %v5, align 8, !dbg !48
  call void @lo_step(ptr %context, ptr null, i64 0, i64 22, ptr %r7), !dbg !50
  %x134 = getelementptr %lo.result, ptr %r7, i32 0, i32 0
  %x135 = load i32, ptr %x134, align 4, !dbg !50
  switch i32 %x135, label %b19 [ i32 0, label %b20 i32 1, label %b19 i32 2, label %b21 ], !dbg !50
b16:
  %x136 = call i1 @lo_result_transfer(ptr %out, ptr %r5, ptr %v5), !dbg !42
  br i1 %x136, label %b3, label %b19, !dbg !42
b19:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 18, ptr %r6), !dbg !42
  call void @lo_result_copy_host(ptr %out, ptr %r6), !dbg !42
  br label %b3, !dbg !42
b20:
  %x137 = getelementptr %lo.result, ptr %r7, i32 0, i32 2
  %x138 = load ptr, ptr %x137, align 8
  store ptr %x138, ptr %v7, align 8, !dbg !50
  call void @lo_step(ptr %context, ptr null, i64 0, i64 23, ptr %r8), !dbg !52
  %x139 = getelementptr %lo.result, ptr %r8, i32 0, i32 0
  %x140 = load i32, ptr %x139, align 4, !dbg !52
  switch i32 %x140, label %b19 [ i32 0, label %b24 i32 1, label %b19 i32 2, label %b25 ], !dbg !52
b21:
  %x141 = call i1 @lo_result_transfer(ptr %out, ptr %r7, ptr %v7), !dbg !42
  br i1 %x141, label %b3, label %b19, !dbg !42
b24:
  %x142 = getelementptr %lo.result, ptr %r8, i32 0, i32 2
  %x143 = load ptr, ptr %x142, align 8
  store ptr %x143, ptr %v8, align 8, !dbg !52
  call void @lo_step(ptr %context, ptr null, i64 0, i64 24, ptr %r9), !dbg !54
  %x144 = getelementptr %lo.result, ptr %r9, i32 0, i32 0
  %x145 = load i32, ptr %x144, align 4, !dbg !54
  switch i32 %x145, label %b19 [ i32 0, label %b28 i32 1, label %b19 i32 2, label %b29 ], !dbg !54
b25:
  %x146 = call i1 @lo_result_transfer(ptr %out, ptr %r8, ptr %v8), !dbg !42
  br i1 %x146, label %b3, label %b19, !dbg !42
b28:
  %x147 = getelementptr %lo.result, ptr %r9, i32 0, i32 2
  %x148 = load ptr, ptr %x147, align 8
  store ptr %x148, ptr %v9, align 8, !dbg !54
  call void @lo_step(ptr %context, ptr null, i64 0, i64 25, ptr %r10), !dbg !56
  %x149 = getelementptr %lo.result, ptr %r10, i32 0, i32 0
  %x150 = load i32, ptr %x149, align 4, !dbg !56
  switch i32 %x150, label %b19 [ i32 0, label %b32 i32 1, label %b19 i32 2, label %b33 ], !dbg !56
b29:
  %x151 = call i1 @lo_result_transfer(ptr %out, ptr %r9, ptr %v9), !dbg !42
  br i1 %x151, label %b3, label %b19, !dbg !42
b32:
  %x152 = getelementptr %lo.result, ptr %r10, i32 0, i32 2
  %x153 = load ptr, ptr %x152, align 8
  store ptr %x153, ptr %v10, align 8, !dbg !56
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 26, ptr %r11), !dbg !58
  %x154 = getelementptr %lo.result, ptr %r11, i32 0, i32 0
  %x155 = load i32, ptr %x154, align 4, !dbg !58
  switch i32 %x155, label %b19 [ i32 0, label %b36 i32 1, label %b19 i32 2, label %b37 ], !dbg !58
b33:
  %x156 = call i1 @lo_result_transfer(ptr %out, ptr %r10, ptr %v10), !dbg !42
  br i1 %x156, label %b3, label %b19, !dbg !42
b36:
  %x157 = getelementptr %lo.result, ptr %r11, i32 0, i32 2
  %x158 = load ptr, ptr %x157, align 8
  store ptr %x158, ptr %v11, align 8, !dbg !58
  %x160 = load ptr, ptr %v11, align 8
  %x159 = getelementptr [1 x ptr], ptr %args12, i64 0, i64 0, !dbg !60
  store ptr %x160, ptr %x159, align 8, !dbg !60
  call void @lo_charge_value(ptr %context, ptr %args12, i64 1, i64 27, ptr %r12), !dbg !60
  %x161 = getelementptr %lo.result, ptr %r12, i32 0, i32 0
  %x162 = load i32, ptr %x161, align 4, !dbg !60
  switch i32 %x162, label %b19 [ i32 0, label %b40 i32 1, label %b19 i32 2, label %b41 ], !dbg !60
b37:
  %x163 = call i1 @lo_result_transfer(ptr %out, ptr %r11, ptr %v11), !dbg !42
  br i1 %x163, label %b3, label %b19, !dbg !42
b40:
  %x164 = getelementptr %lo.result, ptr %r12, i32 0, i32 2
  %x165 = load ptr, ptr %x164, align 8
  store ptr %x165, ptr %v12, align 8, !dbg !60
  %x167 = load ptr, ptr %v11, align 8
  %x166 = getelementptr [1 x ptr], ptr %args13, i64 0, i64 0, !dbg !62
  store ptr %x167, ptr %x166, align 8, !dbg !62
  call void @lo_op_File_2EPath_2Enew(ptr %context, ptr %args13, i64 1, i64 28, ptr %r13), !dbg !62
  %x168 = getelementptr %lo.result, ptr %r13, i32 0, i32 0
  %x169 = load i32, ptr %x168, align 4, !dbg !62
  switch i32 %x169, label %b19 [ i32 0, label %b44 i32 1, label %b19 i32 2, label %b45 ], !dbg !62
b41:
  %x170 = call i1 @lo_result_transfer(ptr %out, ptr %r12, ptr %v12), !dbg !42
  br i1 %x170, label %b3, label %b19, !dbg !42
b44:
  %x171 = getelementptr %lo.result, ptr %r13, i32 0, i32 2
  %x172 = load ptr, ptr %x171, align 8
  store ptr %x172, ptr %v13, align 8, !dbg !62
  %x174 = load ptr, ptr %v13, align 8
  %x173 = getelementptr [1 x ptr], ptr %args14, i64 0, i64 0, !dbg !64
  store ptr %x174, ptr %x173, align 8, !dbg !64
  call void @lo_charge_value(ptr %context, ptr %args14, i64 1, i64 29, ptr %r14), !dbg !64
  %x175 = getelementptr %lo.result, ptr %r14, i32 0, i32 0
  %x176 = load i32, ptr %x175, align 4, !dbg !64
  switch i32 %x176, label %b19 [ i32 0, label %b48 i32 1, label %b19 i32 2, label %b49 ], !dbg !64
b45:
  %x177 = call i1 @lo_result_transfer(ptr %out, ptr %r13, ptr %v13), !dbg !42
  br i1 %x177, label %b3, label %b19, !dbg !42
b48:
  %x178 = getelementptr %lo.result, ptr %r14, i32 0, i32 2
  %x179 = load ptr, ptr %x178, align 8
  store ptr %x179, ptr %v14, align 8, !dbg !64
  %x181 = load ptr, ptr %v13, align 8
  %x180 = getelementptr [1 x ptr], ptr %args15, i64 0, i64 0, !dbg !66
  store ptr %x181, ptr %x180, align 8, !dbg !66
  call void @lo_semantic_read(ptr %context, ptr %args15, i64 1, i64 30, ptr %r15), !dbg !66
  %x182 = getelementptr %lo.result, ptr %r15, i32 0, i32 0
  %x183 = load i32, ptr %x182, align 4, !dbg !66
  switch i32 %x183, label %b19 [ i32 0, label %b52 i32 1, label %b53 i32 2, label %b55 ], !dbg !66
b49:
  %x184 = call i1 @lo_result_transfer(ptr %out, ptr %r14, ptr %v14), !dbg !42
  br i1 %x184, label %b3, label %b19, !dbg !42
b52:
  %x185 = getelementptr %lo.result, ptr %r15, i32 0, i32 2
  %x186 = load ptr, ptr %x185, align 8
  store ptr %x186, ptr %v15, align 8, !dbg !66
  %x188 = load ptr, ptr %v15, align 8
  %x187 = getelementptr [1 x ptr], ptr %args16, i64 0, i64 0, !dbg !68
  store ptr %x188, ptr %x187, align 8, !dbg !68
  call void @lo_convert_success(ptr %context, ptr %args16, i64 1, i64 31, ptr %r16), !dbg !68
  %x189 = getelementptr %lo.result, ptr %r16, i32 0, i32 0
  %x190 = load i32, ptr %x189, align 4, !dbg !68
  switch i32 %x190, label %b19 [ i32 0, label %b58 i32 1, label %b19 i32 2, label %b59 ], !dbg !68
b53:
  %x191 = getelementptr %lo.result, ptr %r15, i32 0, i32 2
  %x192 = load ptr, ptr %x191, align 8
  store ptr %x192, ptr %v15, align 8, !dbg !66
  %x194 = load ptr, ptr %v15, align 8
  %x193 = getelementptr [1 x ptr], ptr %args17, i64 0, i64 0, !dbg !70
  store ptr %x194, ptr %x193, align 8, !dbg !70
  call void @lo_convert_failure(ptr %context, ptr %args17, i64 1, i64 32, ptr %r17), !dbg !70
  %x195 = getelementptr %lo.result, ptr %r17, i32 0, i32 0
  %x196 = load i32, ptr %x195, align 4, !dbg !70
  switch i32 %x196, label %b19 [ i32 0, label %b62 i32 1, label %b19 i32 2, label %b63 ], !dbg !70
b54:
  %phi18 = phi ptr [ %phi_edge_18_0, %b58 ], [ %phi_edge_18_1, %b62 ], !dbg !66
  call void @lo_value_retain(ptr %phi18), !dbg !66
  store ptr %phi18, ptr %v18, align 8, !dbg !66
  %x198 = load ptr, ptr %v18, align 8
  %x197 = getelementptr [1 x ptr], ptr %args18, i64 0, i64 0, !dbg !72
  store ptr %x198, ptr %x197, align 8, !dbg !72
  call void @lo_charge_value(ptr %context, ptr %args18, i64 1, i64 33, ptr %r18), !dbg !72
  %x199 = getelementptr %lo.result, ptr %r18, i32 0, i32 0
  %x200 = load i32, ptr %x199, align 4, !dbg !72
  switch i32 %x200, label %b19 [ i32 0, label %b66 i32 1, label %b19 i32 2, label %b67 ], !dbg !72
b55:
  %x201 = call i1 @lo_result_transfer(ptr %out, ptr %r15, ptr %v15), !dbg !42
  br i1 %x201, label %b3, label %b19, !dbg !42
b58:
  %x202 = getelementptr %lo.result, ptr %r16, i32 0, i32 2
  %x203 = load ptr, ptr %x202, align 8
  store ptr %x203, ptr %v16, align 8, !dbg !68
  %phi_edge_18_0 = load ptr, ptr %v16, align 8
  br label %b54, !dbg !42
b59:
  %x204 = call i1 @lo_result_transfer(ptr %out, ptr %r16, ptr %v16), !dbg !42
  br i1 %x204, label %b3, label %b19, !dbg !42
b62:
  %x205 = getelementptr %lo.result, ptr %r17, i32 0, i32 2
  %x206 = load ptr, ptr %x205, align 8
  store ptr %x206, ptr %v17, align 8, !dbg !70
  %phi_edge_18_1 = load ptr, ptr %v17, align 8
  br label %b54, !dbg !42
b63:
  %x207 = call i1 @lo_result_transfer(ptr %out, ptr %r17, ptr %v17), !dbg !42
  br i1 %x207, label %b3, label %b19, !dbg !42
b66:
  %x208 = getelementptr %lo.result, ptr %r18, i32 0, i32 2
  %x209 = load ptr, ptr %x208, align 8
  store ptr %x209, ptr %v19, align 8, !dbg !72
  %x211 = load ptr, ptr %v18, align 8
  %x210 = getelementptr [1 x ptr], ptr %args19, i64 0, i64 0, !dbg !74
  store ptr %x211, ptr %x210, align 8, !dbg !74
  call void @lo_convert_propagate(ptr %context, ptr %args19, i64 1, i64 34, ptr %r19), !dbg !74
  %x212 = getelementptr %lo.result, ptr %r19, i32 0, i32 0
  %x213 = load i32, ptr %x212, align 4, !dbg !74
  switch i32 %x213, label %b19 [ i32 0, label %b70 i32 1, label %b71 i32 2, label %b71 ], !dbg !74
b67:
  %x214 = call i1 @lo_result_transfer(ptr %out, ptr %r18, ptr %v19), !dbg !42
  br i1 %x214, label %b3, label %b19, !dbg !42
b70:
  %x215 = getelementptr %lo.result, ptr %r19, i32 0, i32 2
  %x216 = load ptr, ptr %x215, align 8
  store ptr %x216, ptr %v20, align 8, !dbg !74
  %x218 = load ptr, ptr %v20, align 8
  %x217 = getelementptr [1 x ptr], ptr %args20, i64 0, i64 0, !dbg !76
  store ptr %x218, ptr %x217, align 8, !dbg !76
  call void @lo_charge_value(ptr %context, ptr %args20, i64 1, i64 35, ptr %r20), !dbg !76
  %x219 = getelementptr %lo.result, ptr %r20, i32 0, i32 0
  %x220 = load i32, ptr %x219, align 4, !dbg !76
  switch i32 %x220, label %b19 [ i32 0, label %b74 i32 1, label %b19 i32 2, label %b75 ], !dbg !76
b71:
  %x221 = call i1 @lo_result_transfer(ptr %out, ptr %r19, ptr %v20), !dbg !42
  br i1 %x221, label %b3, label %b19, !dbg !42
b74:
  %x222 = getelementptr %lo.result, ptr %r20, i32 0, i32 2
  %x223 = load ptr, ptr %x222, align 8
  store ptr %x223, ptr %v21, align 8, !dbg !76
  call void @lo_step(ptr %context, ptr null, i64 0, i64 36, ptr %r21), !dbg !78
  %x224 = getelementptr %lo.result, ptr %r21, i32 0, i32 0
  %x225 = load i32, ptr %x224, align 4, !dbg !78
  switch i32 %x225, label %b19 [ i32 0, label %b78 i32 1, label %b19 i32 2, label %b79 ], !dbg !78
b75:
  %x226 = call i1 @lo_result_transfer(ptr %out, ptr %r20, ptr %v21), !dbg !42
  br i1 %x226, label %b3, label %b19, !dbg !42
b78:
  %x227 = getelementptr %lo.result, ptr %r21, i32 0, i32 2
  %x228 = load ptr, ptr %x227, align 8
  store ptr %x228, ptr %v22, align 8, !dbg !78
  call void @lo_step(ptr %context, ptr null, i64 0, i64 37, ptr %r22), !dbg !80
  %x229 = getelementptr %lo.result, ptr %r22, i32 0, i32 0
  %x230 = load i32, ptr %x229, align 4, !dbg !80
  switch i32 %x230, label %b19 [ i32 0, label %b82 i32 1, label %b19 i32 2, label %b83 ], !dbg !80
b79:
  %x231 = call i1 @lo_result_transfer(ptr %out, ptr %r21, ptr %v22), !dbg !42
  br i1 %x231, label %b3, label %b19, !dbg !42
b82:
  %x232 = getelementptr %lo.result, ptr %r22, i32 0, i32 2
  %x233 = load ptr, ptr %x232, align 8
  store ptr %x233, ptr %v23, align 8, !dbg !80
  call void @lo_step(ptr %context, ptr null, i64 0, i64 38, ptr %r23), !dbg !82
  %x234 = getelementptr %lo.result, ptr %r23, i32 0, i32 0
  %x235 = load i32, ptr %x234, align 4, !dbg !82
  switch i32 %x235, label %b19 [ i32 0, label %b86 i32 1, label %b19 i32 2, label %b87 ], !dbg !82
b83:
  %x236 = call i1 @lo_result_transfer(ptr %out, ptr %r22, ptr %v23), !dbg !42
  br i1 %x236, label %b3, label %b19, !dbg !42
b86:
  %x237 = getelementptr %lo.result, ptr %r23, i32 0, i32 2
  %x238 = load ptr, ptr %x237, align 8
  store ptr %x238, ptr %v24, align 8, !dbg !82
  call void @lo_step(ptr %context, ptr null, i64 0, i64 39, ptr %r24), !dbg !84
  %x239 = getelementptr %lo.result, ptr %r24, i32 0, i32 0
  %x240 = load i32, ptr %x239, align 4, !dbg !84
  switch i32 %x240, label %b19 [ i32 0, label %b90 i32 1, label %b19 i32 2, label %b91 ], !dbg !84
b87:
  %x241 = call i1 @lo_result_transfer(ptr %out, ptr %r23, ptr %v24), !dbg !42
  br i1 %x241, label %b3, label %b19, !dbg !42
b90:
  %x242 = getelementptr %lo.result, ptr %r24, i32 0, i32 2
  %x243 = load ptr, ptr %x242, align 8
  store ptr %x243, ptr %v25, align 8, !dbg !84
  call void @lo_step(ptr %context, ptr null, i64 0, i64 40, ptr %r25), !dbg !86
  %x244 = getelementptr %lo.result, ptr %r25, i32 0, i32 0
  %x245 = load i32, ptr %x244, align 4, !dbg !86
  switch i32 %x245, label %b19 [ i32 0, label %b94 i32 1, label %b19 i32 2, label %b95 ], !dbg !86
b91:
  %x246 = call i1 @lo_result_transfer(ptr %out, ptr %r24, ptr %v25), !dbg !42
  br i1 %x246, label %b3, label %b19, !dbg !42
b94:
  %x247 = getelementptr %lo.result, ptr %r25, i32 0, i32 2
  %x248 = load ptr, ptr %x247, align 8
  store ptr %x248, ptr %v26, align 8, !dbg !86
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 41, ptr %r26), !dbg !88
  %x249 = getelementptr %lo.result, ptr %r26, i32 0, i32 0
  %x250 = load i32, ptr %x249, align 4, !dbg !88
  switch i32 %x250, label %b19 [ i32 0, label %b98 i32 1, label %b19 i32 2, label %b99 ], !dbg !88
b95:
  %x251 = call i1 @lo_result_transfer(ptr %out, ptr %r25, ptr %v26), !dbg !42
  br i1 %x251, label %b3, label %b19, !dbg !42
b98:
  %x252 = getelementptr %lo.result, ptr %r26, i32 0, i32 2
  %x253 = load ptr, ptr %x252, align 8
  store ptr %x253, ptr %v27, align 8, !dbg !88
  %x255 = load ptr, ptr %v27, align 8
  %x254 = getelementptr [1 x ptr], ptr %args27, i64 0, i64 0, !dbg !90
  store ptr %x255, ptr %x254, align 8, !dbg !90
  call void @lo_charge_value(ptr %context, ptr %args27, i64 1, i64 42, ptr %r27), !dbg !90
  %x256 = getelementptr %lo.result, ptr %r27, i32 0, i32 0
  %x257 = load i32, ptr %x256, align 4, !dbg !90
  switch i32 %x257, label %b19 [ i32 0, label %b102 i32 1, label %b19 i32 2, label %b103 ], !dbg !90
b99:
  %x258 = call i1 @lo_result_transfer(ptr %out, ptr %r26, ptr %v27), !dbg !42
  br i1 %x258, label %b3, label %b19, !dbg !42
b102:
  %x259 = getelementptr %lo.result, ptr %r27, i32 0, i32 2
  %x260 = load ptr, ptr %x259, align 8
  store ptr %x260, ptr %v28, align 8, !dbg !90
  %x262 = load ptr, ptr %v27, align 8
  %x261 = getelementptr [1 x ptr], ptr %args28, i64 0, i64 0, !dbg !92
  store ptr %x262, ptr %x261, align 8, !dbg !92
  call void @lo_op_File_2EPath_2Enew(ptr %context, ptr %args28, i64 1, i64 43, ptr %r28), !dbg !92
  %x263 = getelementptr %lo.result, ptr %r28, i32 0, i32 0
  %x264 = load i32, ptr %x263, align 4, !dbg !92
  switch i32 %x264, label %b19 [ i32 0, label %b106 i32 1, label %b19 i32 2, label %b107 ], !dbg !92
b103:
  %x265 = call i1 @lo_result_transfer(ptr %out, ptr %r27, ptr %v28), !dbg !42
  br i1 %x265, label %b3, label %b19, !dbg !42
b106:
  %x266 = getelementptr %lo.result, ptr %r28, i32 0, i32 2
  %x267 = load ptr, ptr %x266, align 8
  store ptr %x267, ptr %v29, align 8, !dbg !92
  %x269 = load ptr, ptr %v29, align 8
  %x268 = getelementptr [1 x ptr], ptr %args29, i64 0, i64 0, !dbg !94
  store ptr %x269, ptr %x268, align 8, !dbg !94
  call void @lo_charge_value(ptr %context, ptr %args29, i64 1, i64 44, ptr %r29), !dbg !94
  %x270 = getelementptr %lo.result, ptr %r29, i32 0, i32 0
  %x271 = load i32, ptr %x270, align 4, !dbg !94
  switch i32 %x271, label %b19 [ i32 0, label %b110 i32 1, label %b19 i32 2, label %b111 ], !dbg !94
b107:
  %x272 = call i1 @lo_result_transfer(ptr %out, ptr %r28, ptr %v29), !dbg !42
  br i1 %x272, label %b3, label %b19, !dbg !42
b110:
  %x273 = getelementptr %lo.result, ptr %r29, i32 0, i32 2
  %x274 = load ptr, ptr %x273, align 8
  store ptr %x274, ptr %v30, align 8, !dbg !94
  %x276 = load ptr, ptr %v29, align 8
  %x275 = getelementptr [1 x ptr], ptr %args30, i64 0, i64 0, !dbg !96
  store ptr %x276, ptr %x275, align 8, !dbg !96
  call void @lo_semantic_read(ptr %context, ptr %args30, i64 1, i64 45, ptr %r30), !dbg !96
  %x277 = getelementptr %lo.result, ptr %r30, i32 0, i32 0
  %x278 = load i32, ptr %x277, align 4, !dbg !96
  switch i32 %x278, label %b19 [ i32 0, label %b114 i32 1, label %b115 i32 2, label %b117 ], !dbg !96
b111:
  %x279 = call i1 @lo_result_transfer(ptr %out, ptr %r29, ptr %v30), !dbg !42
  br i1 %x279, label %b3, label %b19, !dbg !42
b114:
  %x280 = getelementptr %lo.result, ptr %r30, i32 0, i32 2
  %x281 = load ptr, ptr %x280, align 8
  store ptr %x281, ptr %v31, align 8, !dbg !96
  %x283 = load ptr, ptr %v31, align 8
  %x282 = getelementptr [1 x ptr], ptr %args31, i64 0, i64 0, !dbg !98
  store ptr %x283, ptr %x282, align 8, !dbg !98
  call void @lo_convert_success(ptr %context, ptr %args31, i64 1, i64 46, ptr %r31), !dbg !98
  %x284 = getelementptr %lo.result, ptr %r31, i32 0, i32 0
  %x285 = load i32, ptr %x284, align 4, !dbg !98
  switch i32 %x285, label %b19 [ i32 0, label %b120 i32 1, label %b19 i32 2, label %b121 ], !dbg !98
b115:
  %x286 = getelementptr %lo.result, ptr %r30, i32 0, i32 2
  %x287 = load ptr, ptr %x286, align 8
  store ptr %x287, ptr %v31, align 8, !dbg !96
  %x289 = load ptr, ptr %v31, align 8
  %x288 = getelementptr [1 x ptr], ptr %args32, i64 0, i64 0, !dbg !100
  store ptr %x289, ptr %x288, align 8, !dbg !100
  call void @lo_convert_failure(ptr %context, ptr %args32, i64 1, i64 47, ptr %r32), !dbg !100
  %x290 = getelementptr %lo.result, ptr %r32, i32 0, i32 0
  %x291 = load i32, ptr %x290, align 4, !dbg !100
  switch i32 %x291, label %b19 [ i32 0, label %b124 i32 1, label %b19 i32 2, label %b125 ], !dbg !100
b116:
  %phi34 = phi ptr [ %phi_edge_34_0, %b120 ], [ %phi_edge_34_1, %b124 ], !dbg !96
  call void @lo_value_retain(ptr %phi34), !dbg !96
  store ptr %phi34, ptr %v34, align 8, !dbg !96
  %x293 = load ptr, ptr %v34, align 8
  %x292 = getelementptr [1 x ptr], ptr %args33, i64 0, i64 0, !dbg !102
  store ptr %x293, ptr %x292, align 8, !dbg !102
  call void @lo_charge_value(ptr %context, ptr %args33, i64 1, i64 48, ptr %r33), !dbg !102
  %x294 = getelementptr %lo.result, ptr %r33, i32 0, i32 0
  %x295 = load i32, ptr %x294, align 4, !dbg !102
  switch i32 %x295, label %b19 [ i32 0, label %b128 i32 1, label %b19 i32 2, label %b129 ], !dbg !102
b117:
  %x296 = call i1 @lo_result_transfer(ptr %out, ptr %r30, ptr %v31), !dbg !42
  br i1 %x296, label %b3, label %b19, !dbg !42
b120:
  %x297 = getelementptr %lo.result, ptr %r31, i32 0, i32 2
  %x298 = load ptr, ptr %x297, align 8
  store ptr %x298, ptr %v32, align 8, !dbg !98
  %phi_edge_34_0 = load ptr, ptr %v32, align 8
  br label %b116, !dbg !42
b121:
  %x299 = call i1 @lo_result_transfer(ptr %out, ptr %r31, ptr %v32), !dbg !42
  br i1 %x299, label %b3, label %b19, !dbg !42
b124:
  %x300 = getelementptr %lo.result, ptr %r32, i32 0, i32 2
  %x301 = load ptr, ptr %x300, align 8
  store ptr %x301, ptr %v33, align 8, !dbg !100
  %phi_edge_34_1 = load ptr, ptr %v33, align 8
  br label %b116, !dbg !42
b125:
  %x302 = call i1 @lo_result_transfer(ptr %out, ptr %r32, ptr %v33), !dbg !42
  br i1 %x302, label %b3, label %b19, !dbg !42
b128:
  %x303 = getelementptr %lo.result, ptr %r33, i32 0, i32 2
  %x304 = load ptr, ptr %x303, align 8
  store ptr %x304, ptr %v35, align 8, !dbg !102
  %x306 = load ptr, ptr %v34, align 8
  %x305 = getelementptr [1 x ptr], ptr %args34, i64 0, i64 0, !dbg !104
  store ptr %x306, ptr %x305, align 8, !dbg !104
  call void @lo_convert_propagate(ptr %context, ptr %args34, i64 1, i64 49, ptr %r34), !dbg !104
  %x307 = getelementptr %lo.result, ptr %r34, i32 0, i32 0
  %x308 = load i32, ptr %x307, align 4, !dbg !104
  switch i32 %x308, label %b19 [ i32 0, label %b132 i32 1, label %b133 i32 2, label %b133 ], !dbg !104
b129:
  %x309 = call i1 @lo_result_transfer(ptr %out, ptr %r33, ptr %v35), !dbg !42
  br i1 %x309, label %b3, label %b19, !dbg !42
b132:
  %x310 = getelementptr %lo.result, ptr %r34, i32 0, i32 2
  %x311 = load ptr, ptr %x310, align 8
  store ptr %x311, ptr %v36, align 8, !dbg !104
  %x313 = load ptr, ptr %v36, align 8
  %x312 = getelementptr [1 x ptr], ptr %args35, i64 0, i64 0, !dbg !106
  store ptr %x313, ptr %x312, align 8, !dbg !106
  call void @lo_charge_value(ptr %context, ptr %args35, i64 1, i64 50, ptr %r35), !dbg !106
  %x314 = getelementptr %lo.result, ptr %r35, i32 0, i32 0
  %x315 = load i32, ptr %x314, align 4, !dbg !106
  switch i32 %x315, label %b19 [ i32 0, label %b136 i32 1, label %b19 i32 2, label %b137 ], !dbg !106
b133:
  %x316 = call i1 @lo_result_transfer(ptr %out, ptr %r34, ptr %v36), !dbg !42
  br i1 %x316, label %b3, label %b19, !dbg !42
b136:
  %x317 = getelementptr %lo.result, ptr %r35, i32 0, i32 2
  %x318 = load ptr, ptr %x317, align 8
  store ptr %x318, ptr %v37, align 8, !dbg !106
  call void @lo_step(ptr %context, ptr null, i64 0, i64 51, ptr %r36), !dbg !108
  %x319 = getelementptr %lo.result, ptr %r36, i32 0, i32 0
  %x320 = load i32, ptr %x319, align 4, !dbg !108
  switch i32 %x320, label %b19 [ i32 0, label %b140 i32 1, label %b19 i32 2, label %b141 ], !dbg !108
b137:
  %x321 = call i1 @lo_result_transfer(ptr %out, ptr %r35, ptr %v37), !dbg !42
  br i1 %x321, label %b3, label %b19, !dbg !42
b140:
  %x322 = getelementptr %lo.result, ptr %r36, i32 0, i32 2
  %x323 = load ptr, ptr %x322, align 8
  store ptr %x323, ptr %v38, align 8, !dbg !108
  call void @lo_step(ptr %context, ptr null, i64 0, i64 52, ptr %r37), !dbg !110
  %x324 = getelementptr %lo.result, ptr %r37, i32 0, i32 0
  %x325 = load i32, ptr %x324, align 4, !dbg !110
  switch i32 %x325, label %b19 [ i32 0, label %b144 i32 1, label %b19 i32 2, label %b145 ], !dbg !110
b141:
  %x326 = call i1 @lo_result_transfer(ptr %out, ptr %r36, ptr %v38), !dbg !42
  br i1 %x326, label %b3, label %b19, !dbg !42
b144:
  %x327 = getelementptr %lo.result, ptr %r37, i32 0, i32 2
  %x328 = load ptr, ptr %x327, align 8
  store ptr %x328, ptr %v39, align 8, !dbg !110
  call void @lo_step(ptr %context, ptr null, i64 0, i64 53, ptr %r38), !dbg !112
  %x329 = getelementptr %lo.result, ptr %r38, i32 0, i32 0
  %x330 = load i32, ptr %x329, align 4, !dbg !112
  switch i32 %x330, label %b19 [ i32 0, label %b148 i32 1, label %b19 i32 2, label %b149 ], !dbg !112
b145:
  %x331 = call i1 @lo_result_transfer(ptr %out, ptr %r37, ptr %v39), !dbg !42
  br i1 %x331, label %b3, label %b19, !dbg !42
b148:
  %x332 = getelementptr %lo.result, ptr %r38, i32 0, i32 2
  %x333 = load ptr, ptr %x332, align 8
  store ptr %x333, ptr %v40, align 8, !dbg !112
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 54, ptr %r39), !dbg !114
  %x334 = getelementptr %lo.result, ptr %r39, i32 0, i32 0
  %x335 = load i32, ptr %x334, align 4, !dbg !114
  switch i32 %x335, label %b19 [ i32 0, label %b152 i32 1, label %b19 i32 2, label %b153 ], !dbg !114
b149:
  %x336 = call i1 @lo_result_transfer(ptr %out, ptr %r38, ptr %v40), !dbg !42
  br i1 %x336, label %b3, label %b19, !dbg !42
b152:
  %x337 = getelementptr %lo.result, ptr %r39, i32 0, i32 2
  %x338 = load ptr, ptr %x337, align 8
  store ptr %x338, ptr %v41, align 8, !dbg !114
  %x340 = load ptr, ptr %v41, align 8
  %x339 = getelementptr [1 x ptr], ptr %args40, i64 0, i64 0, !dbg !116
  store ptr %x340, ptr %x339, align 8, !dbg !116
  call void @lo_charge_value(ptr %context, ptr %args40, i64 1, i64 55, ptr %r40), !dbg !116
  %x341 = getelementptr %lo.result, ptr %r40, i32 0, i32 0
  %x342 = load i32, ptr %x341, align 4, !dbg !116
  switch i32 %x342, label %b19 [ i32 0, label %b156 i32 1, label %b19 i32 2, label %b157 ], !dbg !116
b153:
  %x343 = call i1 @lo_result_transfer(ptr %out, ptr %r39, ptr %v41), !dbg !42
  br i1 %x343, label %b3, label %b19, !dbg !42
b156:
  %x344 = getelementptr %lo.result, ptr %r40, i32 0, i32 2
  %x345 = load ptr, ptr %x344, align 8
  store ptr %x345, ptr %v42, align 8, !dbg !116
  call void @lo_step(ptr %context, ptr null, i64 0, i64 56, ptr %r41), !dbg !118
  %x346 = getelementptr %lo.result, ptr %r41, i32 0, i32 0
  %x347 = load i32, ptr %x346, align 4, !dbg !118
  switch i32 %x347, label %b19 [ i32 0, label %b160 i32 1, label %b19 i32 2, label %b161 ], !dbg !118
b157:
  %x348 = call i1 @lo_result_transfer(ptr %out, ptr %r40, ptr %v42), !dbg !42
  br i1 %x348, label %b3, label %b19, !dbg !42
b160:
  %x349 = getelementptr %lo.result, ptr %r41, i32 0, i32 2
  %x350 = load ptr, ptr %x349, align 8
  store ptr %x350, ptr %v43, align 8, !dbg !118
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 57, ptr %r42), !dbg !120
  %x351 = getelementptr %lo.result, ptr %r42, i32 0, i32 0
  %x352 = load i32, ptr %x351, align 4, !dbg !120
  switch i32 %x352, label %b19 [ i32 0, label %b164 i32 1, label %b19 i32 2, label %b165 ], !dbg !120
b161:
  %x353 = call i1 @lo_result_transfer(ptr %out, ptr %r41, ptr %v43), !dbg !42
  br i1 %x353, label %b3, label %b19, !dbg !42
b164:
  %x354 = getelementptr %lo.result, ptr %r42, i32 0, i32 2
  %x355 = load ptr, ptr %x354, align 8
  store ptr %x355, ptr %v44, align 8, !dbg !120
  %x357 = load ptr, ptr %v44, align 8
  %x356 = getelementptr [1 x ptr], ptr %args43, i64 0, i64 0, !dbg !122
  store ptr %x357, ptr %x356, align 8, !dbg !122
  call void @lo_charge_value(ptr %context, ptr %args43, i64 1, i64 58, ptr %r43), !dbg !122
  %x358 = getelementptr %lo.result, ptr %r43, i32 0, i32 0
  %x359 = load i32, ptr %x358, align 4, !dbg !122
  switch i32 %x359, label %b19 [ i32 0, label %b168 i32 1, label %b19 i32 2, label %b169 ], !dbg !122
b165:
  %x360 = call i1 @lo_result_transfer(ptr %out, ptr %r42, ptr %v44), !dbg !42
  br i1 %x360, label %b3, label %b19, !dbg !42
b168:
  %x361 = getelementptr %lo.result, ptr %r43, i32 0, i32 2
  %x362 = load ptr, ptr %x361, align 8
  store ptr %x362, ptr %v45, align 8, !dbg !122
  call void @lo_step(ptr %context, ptr null, i64 0, i64 59, ptr %r44), !dbg !124
  %x363 = getelementptr %lo.result, ptr %r44, i32 0, i32 0
  %x364 = load i32, ptr %x363, align 4, !dbg !124
  switch i32 %x364, label %b19 [ i32 0, label %b172 i32 1, label %b19 i32 2, label %b173 ], !dbg !124
b169:
  %x365 = call i1 @lo_result_transfer(ptr %out, ptr %r43, ptr %v45), !dbg !42
  br i1 %x365, label %b3, label %b19, !dbg !42
b172:
  %x366 = getelementptr %lo.result, ptr %r44, i32 0, i32 2
  %x367 = load ptr, ptr %x366, align 8
  store ptr %x367, ptr %v46, align 8, !dbg !124
  call void @lo_step(ptr %context, ptr null, i64 0, i64 60, ptr %r45), !dbg !126
  %x368 = getelementptr %lo.result, ptr %r45, i32 0, i32 0
  %x369 = load i32, ptr %x368, align 4, !dbg !126
  switch i32 %x369, label %b19 [ i32 0, label %b176 i32 1, label %b19 i32 2, label %b177 ], !dbg !126
b173:
  %x370 = call i1 @lo_result_transfer(ptr %out, ptr %r44, ptr %v46), !dbg !42
  br i1 %x370, label %b3, label %b19, !dbg !42
b176:
  %x371 = getelementptr %lo.result, ptr %r45, i32 0, i32 2
  %x372 = load ptr, ptr %x371, align 8
  store ptr %x372, ptr %v47, align 8, !dbg !126
  call void @lo_op_Record_2Enew(ptr %context, ptr null, i64 0, i64 61, ptr %r46), !dbg !128
  %x373 = getelementptr %lo.result, ptr %r46, i32 0, i32 0
  %x374 = load i32, ptr %x373, align 4, !dbg !128
  switch i32 %x374, label %b19 [ i32 0, label %b180 i32 1, label %b19 i32 2, label %b181 ], !dbg !128
b177:
  %x375 = call i1 @lo_result_transfer(ptr %out, ptr %r45, ptr %v47), !dbg !42
  br i1 %x375, label %b3, label %b19, !dbg !42
b180:
  %x376 = getelementptr %lo.result, ptr %r46, i32 0, i32 2
  %x377 = load ptr, ptr %x376, align 8
  store ptr %x377, ptr %v48, align 8, !dbg !128
  %x379 = load ptr, ptr %v48, align 8
  %x378 = getelementptr [1 x ptr], ptr %args47, i64 0, i64 0, !dbg !130
  store ptr %x379, ptr %x378, align 8, !dbg !130
  call void @lo_charge_value(ptr %context, ptr %args47, i64 1, i64 62, ptr %r47), !dbg !130
  %x380 = getelementptr %lo.result, ptr %r47, i32 0, i32 0
  %x381 = load i32, ptr %x380, align 4, !dbg !130
  switch i32 %x381, label %b19 [ i32 0, label %b184 i32 1, label %b19 i32 2, label %b185 ], !dbg !130
b181:
  %x382 = call i1 @lo_result_transfer(ptr %out, ptr %r46, ptr %v48), !dbg !42
  br i1 %x382, label %b3, label %b19, !dbg !42
b184:
  %x383 = getelementptr %lo.result, ptr %r47, i32 0, i32 2
  %x384 = load ptr, ptr %x383, align 8
  store ptr %x384, ptr %v49, align 8, !dbg !130
  %x386 = load ptr, ptr %v48, align 8
  %x385 = getelementptr [1 x ptr], ptr %args48, i64 0, i64 0, !dbg !132
  store ptr %x386, ptr %x385, align 8, !dbg !132
  call void @lo_convert_record_view(ptr %context, ptr %args48, i64 1, i64 63, ptr %r48), !dbg !132
  %x387 = getelementptr %lo.result, ptr %r48, i32 0, i32 0
  %x388 = load i32, ptr %x387, align 4, !dbg !132
  switch i32 %x388, label %b19 [ i32 0, label %b188 i32 1, label %b19 i32 2, label %b189 ], !dbg !132
b185:
  %x389 = call i1 @lo_result_transfer(ptr %out, ptr %r47, ptr %v49), !dbg !42
  br i1 %x389, label %b3, label %b19, !dbg !42
b188:
  %x390 = getelementptr %lo.result, ptr %r48, i32 0, i32 2
  %x391 = load ptr, ptr %x390, align 8
  store ptr %x391, ptr %v50, align 8, !dbg !132
  %x393 = load ptr, ptr %v50, align 8
  %x392 = getelementptr [1 x ptr], ptr %args49, i64 0, i64 0, !dbg !134
  store ptr %x393, ptr %x392, align 8, !dbg !134
  call void @lo_charge_value(ptr %context, ptr %args49, i64 1, i64 64, ptr %r49), !dbg !134
  %x394 = getelementptr %lo.result, ptr %r49, i32 0, i32 0
  %x395 = load i32, ptr %x394, align 4, !dbg !134
  switch i32 %x395, label %b19 [ i32 0, label %b192 i32 1, label %b19 i32 2, label %b193 ], !dbg !134
b189:
  %x396 = call i1 @lo_result_transfer(ptr %out, ptr %r48, ptr %v50), !dbg !42
  br i1 %x396, label %b3, label %b19, !dbg !42
b192:
  %x397 = getelementptr %lo.result, ptr %r49, i32 0, i32 2
  %x398 = load ptr, ptr %x397, align 8
  store ptr %x398, ptr %v51, align 8, !dbg !134
  %x400 = load ptr, ptr %v41, align 8
  %x399 = getelementptr [3 x ptr], ptr %args50, i64 0, i64 0, !dbg !136
  store ptr %x400, ptr %x399, align 8, !dbg !136
  %x402 = load ptr, ptr %v44, align 8
  %x401 = getelementptr [3 x ptr], ptr %args50, i64 0, i64 1, !dbg !136
  store ptr %x402, ptr %x401, align 8, !dbg !136
  %x404 = load ptr, ptr %v50, align 8
  %x403 = getelementptr [3 x ptr], ptr %args50, i64 0, i64 2, !dbg !136
  store ptr %x404, ptr %x403, align 8, !dbg !136
  call void @lo_op_Error_2Enew(ptr %context, ptr %args50, i64 3, i64 65, ptr %r50), !dbg !136
  %x405 = getelementptr %lo.result, ptr %r50, i32 0, i32 0
  %x406 = load i32, ptr %x405, align 4, !dbg !136
  switch i32 %x406, label %b19 [ i32 0, label %b196 i32 1, label %b19 i32 2, label %b197 ], !dbg !136
b193:
  %x407 = call i1 @lo_result_transfer(ptr %out, ptr %r49, ptr %v51), !dbg !42
  br i1 %x407, label %b3, label %b19, !dbg !42
b196:
  %x408 = getelementptr %lo.result, ptr %r50, i32 0, i32 2
  %x409 = load ptr, ptr %x408, align 8
  store ptr %x409, ptr %v52, align 8, !dbg !136
  %x411 = load ptr, ptr %v52, align 8
  %x410 = getelementptr [1 x ptr], ptr %args51, i64 0, i64 0, !dbg !138
  store ptr %x411, ptr %x410, align 8, !dbg !138
  call void @lo_charge_value(ptr %context, ptr %args51, i64 1, i64 66, ptr %r51), !dbg !138
  %x412 = getelementptr %lo.result, ptr %r51, i32 0, i32 0
  %x413 = load i32, ptr %x412, align 4, !dbg !138
  switch i32 %x413, label %b19 [ i32 0, label %b200 i32 1, label %b19 i32 2, label %b201 ], !dbg !138
b197:
  %x414 = call i1 @lo_result_transfer(ptr %out, ptr %r50, ptr %v52), !dbg !42
  br i1 %x414, label %b3, label %b19, !dbg !42
b200:
  %x415 = getelementptr %lo.result, ptr %r51, i32 0, i32 2
  %x416 = load ptr, ptr %x415, align 8
  store ptr %x416, ptr %v53, align 8, !dbg !138
  %x418 = load ptr, ptr %v52, align 8
  %x417 = getelementptr [1 x ptr], ptr %args52, i64 0, i64 0, !dbg !140
  store ptr %x418, ptr %x417, align 8, !dbg !140
  call void @lo_cause(ptr %context, ptr %args52, i64 1, i64 67, ptr %r52), !dbg !140
  %x419 = getelementptr %lo.result, ptr %r52, i32 0, i32 0
  %x420 = load i32, ptr %x419, align 4, !dbg !140
  switch i32 %x420, label %b19 [ i32 0, label %b204 i32 1, label %b204 i32 2, label %b204 ], !dbg !140
b201:
  %x421 = call i1 @lo_result_transfer(ptr %out, ptr %r51, ptr %v53), !dbg !42
  br i1 %x421, label %b3, label %b19, !dbg !42
b204:
  %x422 = call i1 @lo_result_transfer(ptr %out, ptr %r52, ptr %v54), !dbg !42
  br i1 %x422, label %b3, label %b19, !dbg !42
b207:
  %x423 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x424 = load ptr, ptr %x423, align 8
  call void @lo_value_retain(ptr %x424), !dbg !42
  store ptr %x424, ptr %v55, align 8, !dbg !42
  %x426 = load ptr, ptr %v55, align 8
  %x425 = getelementptr [1 x ptr], ptr %args53, i64 0, i64 0, !dbg !42
  store ptr %x426, ptr %x425, align 8, !dbg !42
  call void @lo_flow_error(ptr %context, i64 1, ptr %args53, i64 1, i64 %callsite, ptr %r53), !dbg !42
  %x427 = getelementptr %lo.result, ptr %r53, i32 0, i32 0
  %x428 = load i32, ptr %x427, align 4, !dbg !42
  switch i32 %x428, label %b14 [ i32 0, label %b14 i32 1, label %b208 i32 2, label %b209 ], !dbg !42
b208:
  %x429 = getelementptr %lo.result, ptr %r53, i32 0, i32 2
  %x430 = load ptr, ptr %x429, align 8
  store ptr %x430, ptr %v56, align 8, !dbg !42
  %x432 = load ptr, ptr %v56, align 8
  %x431 = getelementptr [1 x ptr], ptr %args54, i64 0, i64 0, !dbg !42
  store ptr %x432, ptr %x431, align 8, !dbg !42
  call void @lo_flow_0(ptr %context, ptr %args54, i64 1, i64 %callsite, ptr %r54), !dbg !42
  %x433 = getelementptr %lo.result, ptr %r54, i32 0, i32 0
  %x434 = load i32, ptr %x433, align 4, !dbg !42
  switch i32 %x434, label %b14 [ i32 0, label %b212 i32 1, label %b14 i32 2, label %b215 ], !dbg !42
b209:
  %x435 = call i1 @lo_result_transfer(ptr %out, ptr %r53, ptr %v56), !dbg !42
  br i1 %x435, label %b2, label %b14, !dbg !42
b212:
  %x436 = call i1 @lo_result_transfer(ptr %out, ptr %r54, ptr %v57), !dbg !42
  br i1 %x436, label %b2, label %b14, !dbg !42
b215:
  %x437 = call i1 @lo_result_transfer(ptr %out, ptr %r54, ptr %v57), !dbg !42
  br i1 %x437, label %b2, label %b14, !dbg !42
}

attributes #0 = { noinline "fp-contract"="off" "frame-pointer"="all" }
attributes #1 = { noinline optnone "fp-contract"="off" "frame-pointer"="all" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3}
!0 = distinct !DICompileUnit(language: DW_LANG_C, file: !1, producer: "Lo lo-native-1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)
!1 = !DIFile(filename: "3419148395.lo", directory: "/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestSemanticNativeErrorPrecedencenative-runtime2395153811/002")
!2 = !{i32 2, !"Dwarf Version", i32 4}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !DISubroutineType(types: !5)
!5 = !{null}
!6 = distinct !DISubprogram(name: "<top>", linkageName: "lo_entry", scope: !1, file: !1, line: 1, type: !4, scopeLine: 1, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!8 = !DILocation(line: 1, column: 1, scope: !7)
!9 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!10 = !DILocation(line: 1, column: 1, scope: !9)
!11 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!12 = !DILocation(line: 2, column: 164, scope: !11)
!13 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!14 = !DILocation(line: 2, column: 171, scope: !13)
!15 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!16 = !DILocation(line: 2, column: 171, scope: !15)
!17 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!18 = !DILocation(line: 2, column: 171, scope: !17)
!19 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!20 = !DILocation(line: 2, column: 164, scope: !19)
!21 = distinct !DISubprogram(name: "Handle", linkageName: "lo_flow_0", scope: !1, file: !1, line: 1, type: !4, scopeLine: 1, spFlags: DISPFlagDefinition, unit: !0)
!22 = !DILexicalBlockFile(scope: !21, file: !1, discriminator: 0)
!23 = !DILocation(line: 1, column: 1, scope: !22)
!24 = !DILexicalBlockFile(scope: !21, file: !1, discriminator: 0)
!25 = !DILocation(line: 1, column: 1, scope: !24)
!26 = !DILexicalBlockFile(scope: !21, file: !1, discriminator: 0)
!27 = !DILocation(line: 1, column: 1, scope: !26)
!28 = !DILexicalBlockFile(scope: !21, file: !1, discriminator: 0)
!29 = !DILocation(line: 1, column: 13, scope: !28)
!30 = !DILexicalBlockFile(scope: !21, file: !1, discriminator: 0)
!31 = !DILocation(line: 1, column: 38, scope: !30)
!32 = !DILexicalBlockFile(scope: !21, file: !1, discriminator: 0)
!33 = !DILocation(line: 1, column: 45, scope: !32)
!34 = !DILexicalBlockFile(scope: !21, file: !1, discriminator: 0)
!35 = !DILocation(line: 1, column: 45, scope: !34)
!36 = !DILexicalBlockFile(scope: !21, file: !1, discriminator: 0)
!37 = !DILocation(line: 1, column: 45, scope: !36)
!38 = !DILexicalBlockFile(scope: !21, file: !1, discriminator: 0)
!39 = !DILocation(line: 1, column: 38, scope: !38)
!40 = distinct !DISubprogram(name: "Main", linkageName: "lo_flow_1", scope: !1, file: !1, line: 2, type: !4, scopeLine: 2, spFlags: DISPFlagDefinition, unit: !0)
!41 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!42 = !DILocation(line: 2, column: 1, scope: !41)
!43 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!44 = !DILocation(line: 2, column: 1, scope: !43)
!45 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!46 = !DILocation(line: 2, column: 1, scope: !45)
!47 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!48 = !DILocation(line: 2, column: 39, scope: !47)
!49 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!50 = !DILocation(line: 2, column: 45, scope: !49)
!51 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!52 = !DILocation(line: 2, column: 45, scope: !51)
!53 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!54 = !DILocation(line: 2, column: 55, scope: !53)
!55 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!56 = !DILocation(line: 2, column: 69, scope: !55)
!57 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!58 = !DILocation(line: 2, column: 69, scope: !57)
!59 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!60 = !DILocation(line: 2, column: 69, scope: !59)
!61 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!62 = !DILocation(line: 2, column: 55, scope: !61)
!63 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!64 = !DILocation(line: 2, column: 55, scope: !63)
!65 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!66 = !DILocation(line: 2, column: 45, scope: !65)
!67 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!68 = !DILocation(line: 2, column: 45, scope: !67)
!69 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!70 = !DILocation(line: 2, column: 45, scope: !69)
!71 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!72 = !DILocation(line: 2, column: 45, scope: !71)
!73 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!74 = !DILocation(line: 2, column: 45, scope: !73)
!75 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!76 = !DILocation(line: 2, column: 45, scope: !75)
!77 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!78 = !DILocation(line: 2, column: 79, scope: !77)
!79 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!80 = !DILocation(line: 2, column: 85, scope: !79)
!81 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!82 = !DILocation(line: 2, column: 85, scope: !81)
!83 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!84 = !DILocation(line: 2, column: 95, scope: !83)
!85 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!86 = !DILocation(line: 2, column: 109, scope: !85)
!87 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!88 = !DILocation(line: 2, column: 109, scope: !87)
!89 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!90 = !DILocation(line: 2, column: 109, scope: !89)
!91 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!92 = !DILocation(line: 2, column: 95, scope: !91)
!93 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!94 = !DILocation(line: 2, column: 95, scope: !93)
!95 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!96 = !DILocation(line: 2, column: 85, scope: !95)
!97 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!98 = !DILocation(line: 2, column: 85, scope: !97)
!99 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!100 = !DILocation(line: 2, column: 85, scope: !99)
!101 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!102 = !DILocation(line: 2, column: 85, scope: !101)
!103 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!104 = !DILocation(line: 2, column: 85, scope: !103)
!105 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!106 = !DILocation(line: 2, column: 85, scope: !105)
!107 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!108 = !DILocation(line: 2, column: 119, scope: !107)
!109 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!110 = !DILocation(line: 2, column: 126, scope: !109)
!111 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!112 = !DILocation(line: 2, column: 136, scope: !111)
!113 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!114 = !DILocation(line: 2, column: 136, scope: !113)
!115 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!116 = !DILocation(line: 2, column: 136, scope: !115)
!117 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!118 = !DILocation(line: 2, column: 145, scope: !117)
!119 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!120 = !DILocation(line: 2, column: 145, scope: !119)
!121 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!122 = !DILocation(line: 2, column: 145, scope: !121)
!123 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!124 = !DILocation(line: 2, column: 148, scope: !123)
!125 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!126 = !DILocation(line: 2, column: 148, scope: !125)
!127 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!128 = !DILocation(line: 2, column: 148, scope: !127)
!129 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!130 = !DILocation(line: 2, column: 148, scope: !129)
!131 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!132 = !DILocation(line: 2, column: 148, scope: !131)
!133 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!134 = !DILocation(line: 2, column: 148, scope: !133)
!135 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!136 = !DILocation(line: 2, column: 126, scope: !135)
!137 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!138 = !DILocation(line: 2, column: 126, scope: !137)
!139 = !DILexicalBlockFile(scope: !40, file: !1, discriminator: 0)
!140 = !DILocation(line: 2, column: 119, scope: !139)

declare void @lo_semantic_read(ptr,ptr,i64,i64,ptr)
declare void @lo_semantic_commit(ptr,ptr,i64,i64,ptr)
