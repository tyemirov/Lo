extern int mount(const char*,const char*,const char*,unsigned long,const void*);
extern int open(const char*,int,...); extern int dup2(int,int); extern long write(int,const void*,unsigned long);
extern int printf(const char*,...); extern int fflush(void*); extern int reboot(int);
int main(void) {
 int mounted=mount("devtmpfs","/dev","devtmpfs",0,0);
 int console=open("/dev/console",2); if(console>=0) {dup2(console,1);dup2(console,2);}
 int port=open("/dev/vport0p1",1); int kernel=open("/dev/kmsg",1);
 const char notice[]="<2>LO_TRANSPORT_SMOKE_KERNEL_DIAGNOSTIC\n";
 const char data[]="LO_TRANSPORT_SMOKE_EXPORT:exact-bytes\n";
 int status=mounted!=0||port<0||kernel<0;
 if(!status && write(kernel,notice,sizeof(notice)-1)!=(long)sizeof(notice)-1)status=2;
 if(!status && write(port,data,sizeof(data)-1)!=(long)sizeof(data)-1)status=3;
 printf("LO_TRANSPORT_SMOKE_RESULT:%d\n",status);fflush(0);reboot(0x4321fedc);return 80;
}
