"""Seal campaign11 inputs once, after prior campaigns finish; never start validation jobs."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys

root = Path(__file__).resolve().parents[2]
base = root / '_scratch/i011-20261020'
spec = importlib.util.spec_from_file_location('lo_campaign11_seal_contract', base / 'campaign-contract-11.py')
contract = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = contract
spec.loader.exec_module(contract)
parser = argparse.ArgumentParser()
parser.add_argument('--review', action='append', type=Path, required=True)
args = parser.parse_args()
plan = contract.plan11()
contract.predecessor()
prior_campaign = contract.predecessor9()
destination = base / 'campaign-inputs-11.json'
if destination.exists():
    raise SystemExit('Campaign inputs are already sealed')
audit = contract.module('lo_campaign11_nonperformance_seal', 'final-evidence-audit-11.py')
nonperformance = audit.audit_nonperformance()
if nonperformance != prior_campaign['nonperformance_summary'] or nonperformance != contract.load(base / 'preflight-nonperformance-11.json'):
    raise SystemExit('Nonperformance evidence identity differs from prior campaign/restoration preflight')
reviews = {str(contract.local(path).relative_to(root)): contract.receipt(path) for path in args.review}
for name in plan['required_reviews']:
    reviews[name] = contract.receipt(root / name)
for review in contract.load(base / 'final-validation-status-8.json')['reviews']:
    reviews[review['path']] = contract.receipt(root / review['path'])
predecessor_names = list(contract.PREDECESSOR) + list(contract.PRIOR_CAMPAIGN)
predecessor_names.extend(str((root / name).relative_to(base)) for name in contract.load(base / 'admission-completion-review-9.json')['reviewed_sha256'])
prior_sealed = contract.load(base / 'campaign-inputs-9.json')
for group in ('reused_records', 'predecessor_records', 'orchestration', 'reviews'):
    predecessor_names.extend(str((root / record['path']).relative_to(base)) for record in prior_sealed[group])
predecessor_names.extend(str((root / name).relative_to(base)) for name in contract.load(base / 'final-validation-status-8.json')['orchestration_inputs'])
for pattern in ('*.stdout', '*.stderr', '*/report.json', '*/partial.json'):
    predecessor_names.extend(str(path.relative_to(base)) for path in sorted((base / 'final-performance-5').glob(pattern)))
sealed = {'campaign': 11, 'source_sha256': contract.SOURCE,
          'authorization': contract.receipt(root / plan['authorization']),
          'context_records': [contract.receipt(root / name) for name in plan['context_records']],
          'reused_records': [contract.receipt(base / name) for name in contract.REUSED],
          'predecessor_records': [contract.receipt(base / name) for name in sorted(set(predecessor_names))],
          'orchestration': [contract.receipt(base / name) for name in contract.ORCHESTRATION],
          'reviews': list(reviews.values()), 'nonperformance_summary': nonperformance}
with destination.open('x') as output:
    output.write(json.dumps(sealed, indent=2, allow_nan=False) + '\n')
print(json.dumps({'sealed': contract.receipt(destination), 'status': 'nonperformance_admitted_for_reuse; performance_not_started'}))
