"""Reuse sealed freeze7 nonperformance evidence; run at most two complete attempts."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
base = root / '_scratch/i011-20261020'
spec = importlib.util.spec_from_file_location('lo_campaign9_driver_contract', base / 'campaign-contract-9.py')
contract = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = contract
spec.loader.exec_module(contract)
plan = contract.plan9()
sealed = contract.verify_bindings()
audit = contract.module('lo_campaign9_driver_audit', 'final-evidence-audit-9.py')
if audit.audit_nonperformance() != sealed['nonperformance_summary']:
    raise SystemExit('Sealed nonperformance evidence identity audit differs; separate review is necessary')
quiet_module = contract.module('lo_campaign9_monitor', 'quiet-host-9.py')
status_path = base / 'final-validation-status-9.json'
if status_path.exists():
    raise SystemExit('Campaign status path must be fresh')
for attempt in plan['attempts']:
    directory = root / attempt['performance_directory']
    paths = [directory, root / attempt['trace'], root / attempt['summary'],
             (root / attempt['summary']).with_suffix('.writing'),
             base / f'performance-attempt-{attempt["id"]}.stdout', base / f'performance-attempt-{attempt["id"]}.stderr',
             base / f'freeze-verify-9-attempt-{attempt["id"]}-before.log', base / f'freeze-verify-9-attempt-{attempt["id"]}-after.log']
    if any(path.exists() for path in paths):
        raise SystemExit('Campaign output paths must be fresh; no overwrite or lane reuse')
state = {'campaign': 9, 'complete': False, 'passed': False, 'selected_attempt': None, 'attempts': [],
         'running': [], 'sealed_inputs': contract.receipt(base / 'campaign-inputs-9.json'), 'error': None}
started = time.monotonic()
env = dict(os.environ, CI='1')
env.pop('LO_TEST_BACKEND', None)


def record() -> None:
    state['elapsed_seconds'] = time.monotonic() - started
    status_path.write_text(json.dumps(state, indent=2) + '\n')


def verify_freeze(attempt: int, phase: str) -> None:
    with (base / f'freeze-verify-9-attempt-{attempt}-{phase}.log').open('xb') as output:
        subprocess.run([sys.executable, '-B', str(base / 'freeze-inputs-7.py'), 'verify'], stdin=subprocess.DEVNULL,
                       stdout=output, cwd=root, env=env, check=True)


record()
try:
    for definition in plan['attempts']:
        identifier = definition['id']
        if identifier == 10:
            previous = state['attempts'][-1]
            if previous['disposition'] != 'cpu-load-invalidated':
                raise ValueError('A second attempt is permitted only after CPU-load invalidation')
        contract.verify_bindings()
        verify_freeze(identifier, 'before')
        monitor = quiet_module.Monitor(os.getpid(), base / 'quiet-host-plan-9.json',
                                       root / definition['trace'], root / definition['summary'], identifier)
        performance_status = 1
        entry = {'id': identifier, 'performance_status': None, 'quiet_summary': None, 'disposition': 'pending'}
        state['attempts'].append(entry)
        state['running'] = [f'admission-{identifier}']
        record()
        try:
            print('START quiet admission ' + str(identifier), flush=True)
            monitor.admit()
            state['running'] = [f'performance-{identifier}']
            record()
            print('START complete eight-lane attempt ' + str(identifier), flush=True)
            with (base / f'performance-attempt-{identifier}.stdout').open('xb') as stdout, (base / f'performance-attempt-{identifier}.stderr').open('xb') as stderr:
                performance_status = subprocess.run([sys.executable, '-B', str(base / 'final-performance-6.py'),
                                                      '--attempt', str(identifier)], stdin=subprocess.DEVNULL,
                                                     stdout=stdout, stderr=stderr, cwd=root, env=env).returncode
        finally:
            quiet = monitor.finish(performance_status)
            entry['performance_status'] = performance_status
            entry['quiet_summary'] = contract.receipt(root / definition['summary'])
            state['running'] = []
            record()
        # This check is outside measurement. A changed input never opens a retry.
        verify_freeze(identifier, 'after')
        contract.verify_bindings()
        outcome_path = root / definition['performance_directory'] / 'runner-outcome.json'
        outcome = contract.load(outcome_path)
        entry['runner_outcome'] = contract.receipt(outcome_path)
        if performance_status == 0 and quiet['passed'] is True and outcome['failure_kind'] == 'passed':
            contract.validate_quiet(root / definition['summary'], plan)
            entry['disposition'] = 'passed'
            state['selected_attempt'] = identifier
            state['passed'] = True
            record()
            break
        if contract.retry_allowed(quiet, outcome):
            contract.validate_quiet(root / definition['summary'], plan, cpu_rejection=True)
            entry['disposition'] = 'cpu-load-invalidated'
            print('REJECT whole attempt ' + str(identifier) + ' for CPU load', flush=True)
            record()
            if identifier == 9:
                continue
            raise ValueError('Both predeclared complete attempts are CPU-load-invalidated; campaign exhausted')
        entry['disposition'] = 'failed-no-retry'
        record()
        raise ValueError('Failed/inconclusive gate or observation/provenance failure; separate review is necessary')
    if not state['passed']:
        raise ValueError('No complete accepted performance attempt')
except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
    state['error'] = str(error)
finally:
    state['complete'] = True
    state['running'] = []
    record()
if not state['passed'] or state['error'] is not None:
    raise SystemExit('Campaign qualification incomplete: ' + str(state['error']))
print('All campaign qualification commands passed', flush=True)
