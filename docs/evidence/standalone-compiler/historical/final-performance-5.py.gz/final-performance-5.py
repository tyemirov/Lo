"""Run one complete serial performance attempt under the live quiet-host receipt."""
from pathlib import Path
import json
import os
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
base = root / '_scratch/i011-20261020/final-performance-5'
quiet = root / '_scratch/i011-20261020/quiet-host-summary-8.json'


def permitted() -> None:
    record = json.loads(quiet.read_text())
    if (record.get('attempt') != 8 or record.get('admitted') is not True or
        record.get('invalid_reason') is not None or record.get('complete') is not False or
        record.get('phase') != 'performance'):
        raise ValueError('quiet host invalidated this complete attempt; no next lane or merge is permitted')


permitted()
base.mkdir()
reports = {target: [] for target in ('darwin', 'linux')}
for lane in ('execution', 'process', 'http', 'build'):
    for target in ('darwin', 'linux'):
        permitted()
        work = base / (target + '-' + lane)
        command = ['make', '-s', 'benchmark-standalone' if target == 'darwin' else 'benchmark-native-linux',
                   'NATIVE_BENCH_WORK=' + str(work), 'NATIVE_BENCH_LANE=' + lane,
                   'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                   'NATIVE_BENCH_COMPILER=bin/distributions/lo-darwin-arm64-software/bin/lo',
                   'SEMANTIC_COMPILER=bin/distributions/lo-darwin-arm64-software/bin/lo', 'LINUX_ACCELERATOR=hvf']
        print('START ' + target + ' ' + lane, flush=True)
        with (base / (target + '-' + lane + '.stdout')).open('xb') as stdout, (base / (target + '-' + lane + '.stderr')).open('xb') as stderr:
            status = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                    cwd=root, env=dict(os.environ, CI='1')).returncode
        # Never terminate the current lane because of noise. Its records remain
        # intact, but invalidation forbids every following lane and strict merge.
        permitted()
        report = work / 'report.json'
        if not report.is_file():
            raise SystemExit(f'{target}:{lane} no report; status {status}')
        result = json.loads(report.read_text())
        print(json.dumps({'target': target, 'lane': lane, 'status': status,
                          'measurement_complete': result.get('measurement_complete'),
                          'error': result.get('measurement_error'), 'gate_failures': result.get('gate_failures'),
                          'callback_speedup': result.get('callback_speedup'),
                          'callback_ci': result.get('callback_bootstrap_95_percent')}), flush=True)
        if status or not result.get('measurement_complete') or not result.get('gates_passed'):
            raise SystemExit(f'{target}:{lane} failed qualification')
        reports[target].append(report)
for target, paths in reports.items():
    permitted()
    command = [sys.executable, '-B', 'tools/nativebench/merge.py', '--output', str(base / (target + '-merged.json'))]
    for path in paths:
        command.extend(['--report', str(path)])
    subprocess.run(command, stdin=subprocess.DEVNULL, cwd=root, check=True)
    permitted()
print('Both complete target performance contracts passed.', flush=True)
