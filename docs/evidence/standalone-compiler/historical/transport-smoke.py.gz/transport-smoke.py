from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys
root=Path.cwd().resolve();work=root/'_scratch/i011-20261020/transport-smoke';work.mkdir()
preparation=root/'_scratch/native-runtime'
sys.path.insert(0,str(root/'tools/lodistribution'))
from prepare import verified
tools=json.loads((preparation/'tools.json').read_text())['tools']
source=work/'probe.c'
source.write_text('''extern int mount(const char*,const char*,const char*,unsigned long,const void*);
extern int open(const char*,int,...); extern int dup2(int,int); extern long write(int,const void*,unsigned long);
extern int printf(const char*,...); extern int fflush(void*); extern int reboot(int);
int main(void) {
 int mounted=mount("devtmpfs","/dev","devtmpfs",0,0);
 int console=open("/dev/console",2); if(console>=0) {dup2(console,1);dup2(console,2);}
 int port=open("/dev/vport0p1",1); int kernel=open("/dev/kmsg",1);
 const char notice[]="<2>LO_TRANSPORT_SMOKE_KERNEL_DIAGNOSTIC\\n";
 const char data[]="LO_TRANSPORT_SMOKE_EXPORT:exact-bytes\\n";
 int status=mounted!=0||port<0||kernel<0;
 if(!status && write(kernel,notice,sizeof(notice)-1)!=(long)sizeof(notice)-1)status=2;
 if(!status && write(port,data,sizeof(data)-1)!=(long)sizeof(data)-1)status=3;
 printf("LO_TRANSPORT_SMOKE_RESULT:%d\\n",status);fflush(0);reboot(0x4321fedc);return 80;
}
''')
env={'CI':'1','PATH':'','HOME':str(work),'TMPDIR':str(work),'DYLD_LIBRARY_PATH':str(preparation/'emulation/lib')}
sysroot=preparation/'linux-sysroot';obj=work/'probe.o';binary=work/'init'
commands=[
 [str(verified(tools['clang'])),'--target=aarch64-unknown-linux-gnu','-O2','-c',str(source),'-o',str(obj)],
 [str(verified(tools['ld.lld'])),'-m','aarch64elf','-dynamic-linker','/lib/ld-linux-aarch64.so.1',
  str(sysroot/'usr/lib/aarch64-linux-gnu/crt1.o'),str(sysroot/'usr/lib/aarch64-linux-gnu/crti.o'),str(obj),
  str(sysroot/'lib/aarch64-linux-gnu/libc.so.6'),str(sysroot/'usr/lib/aarch64-linux-gnu/libc_nonshared.a'),
  str(sysroot/'usr/lib/aarch64-linux-gnu/crtn.o'),'-o',str(binary)]]
for command in commands: subprocess.run(command,cwd=root,env=env,stdin=subprocess.DEVNULL,check=True)
guest=work/'root';(guest/'dev').mkdir(parents=True);os.link(binary,guest/'init')
shutil.copytree(sysroot/'lib',guest/'lib',copy_function=os.link)
archive=work/'root.cpio'
subprocess.run(['/usr/bin/tar','--format=newc','-cf',str(archive),'-C',str(guest),'.'],cwd=root,env=env,stdin=subprocess.DEVNULL,check=True)
export=work/'export.log';serial=work/'serial.log';errors=work/'qemu.stderr'
command=[str(preparation/'emulation/qemu-system-aarch64'),'-machine','virt','-accel','tcg','-cpu','cortex-a72',
 '-m','256','-smp','2','-display','none','-monitor','none','-serial','stdio','-no-reboot','-nodefaults','-nic','none',
 '-device','virtio-serial-pci,id=lo-transport','-chardev',f'file,id=lo-export,path={export}',
 '-device','virtserialport,bus=lo-transport.0,nr=1,chardev=lo-export,name=lo.export',
 '-kernel',str(preparation/'vmlinuz-virt'),'-initrd',str(archive),'-append','console=ttyAMA0 rdinit=/init panic=-1 loglevel=3']
with serial.open('wb') as stdout,errors.open('wb') as stderr:
 result=subprocess.run(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=90,check=False)
expected=b'LO_TRANSPORT_SMOKE_EXPORT:exact-bytes\n'
passed=result.returncode==0 and export.read_bytes()==expected and b'LO_TRANSPORT_SMOKE_KERNEL_DIAGNOSTIC' in serial.read_bytes() and b'LO_TRANSPORT_SMOKE_RESULT:0' in serial.read_bytes()
report={'passed':passed,'qemu_status':result.returncode,'command':command,'export':export.read_text(),'serial':serial.read_text(),
 'kernel_sha256':hashlib.sha256((preparation/'vmlinuz-virt').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
(work/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
raise SystemExit(0 if passed else 1)
