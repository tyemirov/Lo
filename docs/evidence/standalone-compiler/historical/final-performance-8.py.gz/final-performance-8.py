"""Run every lane for one predeclared campaign11 attempt; never reuse old lanes."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
task = root / '_scratch/i011-20261020'
spec = importlib.util.spec_from_file_location('lo_campaign11_runner_contract', task / 'campaign-contract-11.py')
contract = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = contract
spec.loader.exec_module(contract)
sys.path.insert(0, str(root / 'tools/nativebench'))
import merge
import identity
parser = argparse.ArgumentParser()
parser.add_argument('--attempt', type=int, choices=(11, 12), required=True)
args = parser.parse_args()
plan = contract.plan11()
definition = next(item for item in plan['attempts'] if item['id'] == args.attempt)
base = contract.local(root / definition['performance_directory'])
quiet = contract.local(root / definition['summary'])
base.mkdir()
outcome = {'campaign': 11, 'attempt': args.attempt, 'complete': False, 'failure_kind': None, 'lanes': []}


class StopAttempt(ValueError):
    pass


def permitted() -> None:
    record = contract.load(quiet)
    if (record.get('attempt') != args.attempt or record.get('admitted') is not True or record.get('complete') is not False):
        outcome['failure_kind'] = 'observation'
        raise StopAttempt('live quiet receipt is missing or inconsistent')
    if record.get('invalid_reason'):
        outcome['failure_kind'] = 'cpu-load' if record['invalid_reason'] == contract.CPU_INVALID else 'observation'
        raise StopAttempt('quiet environment invalidated this complete attempt')


try:
    permitted()
    reports = {target: [] for target in ('darwin', 'linux')}
    for lane in ('execution', 'process', 'http', 'build'):
        for target in ('darwin', 'linux'):
            permitted()
            work = base / (target + '-' + lane)
            command = ['make', '-s', 'benchmark-standalone' if target == 'darwin' else 'benchmark-native-linux',
                       'NATIVE_BENCH_WORK=' + str(work), 'NATIVE_BENCH_LANE=' + lane,
                       'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                       'NATIVE_BENCH_COMPILER=bin/distributions/lo-darwin-arm64-software/bin/lo',
                       'SEMANTIC_COMPILER=bin/distributions/lo-darwin-arm64-software/bin/lo', 'LINUX_ACCELERATOR=hvf']
            print('START ' + target + ' ' + lane, flush=True)
            with (base / (target + '-' + lane + '.stdout')).open('xb') as stdout, (base / (target + '-' + lane + '.stderr')).open('xb') as stderr:
                status = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                        cwd=root, env=dict(os.environ, CI='1')).returncode
            # Admit the just-completed whole lane before classifying a retry.
            # A CPU violation cannot excuse malformed/provenance-invalid results.
            result, report_receipt = merge.admit(work / 'report.json')
            identity.verify_source_identity(root, result['merge_identity'])
            package = root / 'bin/distributions' / f'lo-{target}-arm64-software'
            admitted_package, _ = identity.package_provenance(root, package / 'bin/lo', package / 'toolchain.json', target + '/arm64')
            if result['merge_identity']['package'] != admitted_package:
                raise ValueError('lane package identity differs from freeze7')
            if result['merge_identity']['source']['semantic_source_sha256'] != contract.SOURCE:
                raise ValueError('lane source identity differs from freeze7')
            if status != (0 if result.get('gates_passed') is True else 1):
                raise ValueError('lane command status differs from complete measurement gate result')
            outcome['lanes'].append({'target': target, 'lane': lane, 'status': status, 'report': report_receipt})
            permitted()
            if status or result.get('gates_passed') is not True:
                outcome['failure_kind'] = 'benchmark-gate'
                raise StopAttempt('valid-environment failed or inconclusive gate; no retry permitted')
            reports[target].append(work / 'report.json')
    for target, paths in reports.items():
        permitted()
        command = [sys.executable, '-B', 'tools/nativebench/merge.py', '--output', str(base / (target + '-merged.json'))]
        for path in paths:
            command.extend(['--report', str(path)])
        subprocess.run(command, stdin=subprocess.DEVNULL, cwd=root, env=dict(os.environ, CI='1'), check=True)
        permitted()
    outcome['failure_kind'] = 'passed'
    print('Both complete target performance contracts passed.', flush=True)
except StopAttempt as error:
    outcome['error'] = str(error)
except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
    outcome['failure_kind'] = 'measurement-or-provenance'
    outcome['error'] = str(error)
finally:
    outcome['complete'] = True
    with (base / 'runner-outcome.json').open('x') as output:
        output.write(json.dumps(outcome, indent=2) + '\n')
raise SystemExit(0 if outcome['failure_kind'] == 'passed' else 1)
