"""Record an observed admission timeout without claiming performance acceptance."""
from pathlib import Path
import datetime
import hashlib
import json
import sys

root = Path.cwd().resolve()
base = root / '_scratch/i011-20261020'
assert sys.argv[1:] == ['--observed-exit', '1']
status = json.loads((base / 'final-validation-status-9.json').read_text())
quiet = json.loads((base / 'quiet-host-summary-9.json').read_text())
assert status['complete'] is True and status['passed'] is False
assert status['selected_attempt'] is None and status['running'] == []
assert [a['id'] for a in status['attempts']] == [9]
assert quiet['complete'] is True and quiet['passed'] is False and quiet['admitted'] is False
assert quiet['admission_evidence'] is None
assert quiet['invalid_reason'].startswith('quiet admission timed out after 3600 seconds')
assert status['error'] == quiet['invalid_reason']
assert not (base / 'final-performance-6').exists()
assert not (base / 'performance-attempt-9.stdout').exists()
assert not (base / 'quiet-host-summary-10.json').exists()
trace = base / 'quiet-host-trace-9.jsonl'
assert hashlib.sha256(trace.read_bytes()).hexdigest() == quiet['trace_sha256']
rows = [json.loads(line) for line in trace.read_text().splitlines()]
observations = [r for r in rows if 'processes' in r]
errors = [r for r in rows if 'error' in r]
assert len(observations) == quiet['samples']
assert len(errors) == 1 and errors[0]['error'] == quiet['invalid_reason']
assert all(r['phase'] == 'admission' for r in observations)
current = longest = violations = 0
for row in observations:
    violations += int(row['violation'])
    current = current + 1 if not row['violation'] and not row['offending_identity_present'] else 0
    longest = max(current, longest)
start = datetime.datetime.fromisoformat(quiet['started_timestamp_utc'])
end = datetime.datetime.fromisoformat(quiet['completion_timestamp_utc'])
monotonic_duration = quiet['completion_monotonic_seconds'] - quiet['started_monotonic_seconds']
utc_duration = (end - start).total_seconds()
assert min(monotonic_duration, utc_duration) >= 3600

def receipt(name):
    path = base / name
    return {'path': str(path.relative_to(root)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

result = {
    'issue': 'I011', 'campaign': 9, 'attempt': 9,
    'status': 'admission_timeout_no_performance_measurement',
    'observed_driver_exit': 1, 'performance_qualification_complete': False,
    'timing_lanes_started': 0, 'selected_attempt': None, 'retry_permitted_by_campaign': False,
    'reason': quiet['invalid_reason'],
    'started_utc': quiet['started_timestamp_utc'], 'completed_utc': quiet['completion_timestamp_utc'],
    'duration_seconds': {'monotonic': monotonic_duration, 'utc': utc_duration},
    'observations': {'samples': len(observations), 'cpu_limit_violations': violations,
                     'longest_consecutive_quiet_samples': longest, 'required_quiet_samples': 61,
                     'required_quiet_span_seconds': 300},
    'source_sha256': '30456a563ea64716d16e3b0d954338fae144fdde5b66a13f570c31c6bbf501e2',
    'evidence': {name: receipt(name) for name in (
        'final-validation-status-9.json', 'quiet-host-summary-9.json', 'quiet-host-trace-9.jsonl',
        'quiet-host-plan-9.json', 'campaign-inputs-9.json', 'final-validation-9.log', 'final-validation-9.stderr')},
    'scope': 'This records failure to obtain the declared environment. It does not measure compiler performance or invalidate the completed nonperformance checks.',
    'required_remaining': ['A valid complete eight-lane performance campaign on both targets',
                           'Strict target merges and complete evidence audit',
                           'Independent full qualification completion review']
}
for name, value in [('final-driver-exit-9.json', {'session': 42719, 'observed_exit_code': 1,
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'campaign_complete': True, 'campaign_passed': False, 'selected_attempt': None,
    'reason': quiet['invalid_reason']}), ('admission-outcome-9.json', result)]:
    with (base / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'timing_lanes_started', 'duration_seconds', 'observations')}))
