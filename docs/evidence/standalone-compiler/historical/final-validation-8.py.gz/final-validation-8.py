"""Qualify freeze7 inputs, then make one complete quiet-host performance attempt."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
base = root / '_scratch/i011-20261020'
parser = argparse.ArgumentParser()
parser.add_argument('--runtime', type=Path, required=True)
parser.add_argument('--review', type=Path, action='append', required=True,
                    help='repository-local source/orchestration review receipts approved before this attempt')
arguments = parser.parse_args()
runtime = arguments.runtime.resolve()
if not runtime.is_relative_to(root) or not (runtime / 'build-receipt.json').is_file():
    raise SystemExit('Required runtime input is absent or outside Lo: ' + str(runtime))
reviews = []
for path in arguments.review:
    path = path.resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise SystemExit('Required review receipt is absent or outside Lo: ' + str(path))
    reviews.append({'path': str(path.relative_to(root)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
fresh = ['final-validation-status-8.json', 'final-offline-7', 'final-offline-7.log', 'final-offline-7.stderr',
         'final-ci.stdout', 'final-ci.stderr', 'final-corpus-7', 'final-linux-corpus-7.log', 'final-linux-corpus-7.stderr',
         'final-component-tools-7.log', 'final-component-tools-7.stderr', 'final-semantic-report.json',
         'final-performance-5', 'final-performance-5.stdout', 'final-performance-5.stderr',
         'quiet-host-trace-8.jsonl', 'quiet-host-summary-8.json', 'quiet-host-summary-8.writing',
         'freeze-verify-8-start.log', 'freeze-verify-8-performance.log', 'freeze-verify-8-complete.log']
for name in fresh:
    if (base / name).exists():
        raise SystemExit('Output must be fresh; preserve and retire the existing record first: ' + name)
env = dict(os.environ, CI='1')
env.pop('LO_TEST_BACKEND', None)
ci_env = dict(env, LO_TEST_COMPILER=str(root / 'bin/distributions/lo-darwin-arm64-metal/bin/lo'))
component_env = dict(env, LO_TEST_RUNTIME_DISTRIBUTION=str(runtime))
statuses, active = {}, {}
started = time.monotonic()
plan = base / 'quiet-host-plan-8.json'
plan_digest = hashlib.sha256(plan.read_bytes()).hexdigest()
orchestration = {str((base / name).relative_to(root)): hashlib.sha256((base / name).read_bytes()).hexdigest()
                 for name in ('final-validation-8.py', 'quiet-host.py', 'quiet-host-plan-8.json',
                              'final-performance-5.py', 'fixtures/final-evidence-audit-8.py', 'prepare-final-preservation-8.py')}


def record():
    (base / 'final-validation-status-8.json').write_text(json.dumps({
        'statuses': statuses, 'running': list(active), 'elapsed_seconds': round(time.monotonic() - started, 3),
        'source_freeze': str((base / 'frozen-inputs-7.json').relative_to(root)),
        'quiet_plan': {'path': str(plan.relative_to(root)), 'sha256': plan_digest},
        'reviews': reviews, 'orchestration_inputs': orchestration,
    }, indent=2) + '\n')


def verify_freeze(stage):
    with (base / ('freeze-verify-8-' + stage + '.log')).open('xb') as output:
        subprocess.run([sys.executable, '-B', str(base / 'freeze-inputs-7.py'), 'verify'],
                       stdout=output, stdin=subprocess.DEVNULL, cwd=root, env=env, check=True)


verify_freeze('start')
record()
print('START complete offline matrix before CI and corpus jobs', flush=True)
with (base / 'final-offline-7.log').open('xb') as stdout, (base / 'final-offline-7.stderr').open('xb') as stderr:
    offline = subprocess.run(['make', '-s', 'test-compiler-distributions',
                              'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                              'COMPILER_DISTRIBUTION_ACCEPTANCE=_scratch/i011-20261020/final-offline-7'],
                             stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, cwd=root, env=env)
statuses['offline'] = offline.returncode
record()
print('DONE offline ' + str(offline.returncode), flush=True)
if offline.returncode:
    raise SystemExit('Offline matrix failed; CI and corpus jobs not started')
jobs = [
    ('ci', ['make', '-s', 'ci', 'LLVM_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json',
            'SEMANTIC_COMPILER=bin/distributions/lo-darwin-arm64-metal/bin/lo',
            'SEMANTIC_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json',
            'NATIVE_RUNTIME_STATE=_scratch/native-runtime', 'TEST_ARGS=-json -count=1'],
     ci_env, 'final-ci.stdout', 'final-ci.stderr'),
    ('linux-corpus', ['make', '-s', 'test-native-linux', 'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                      'NATIVE_QUALIFICATION_OUTPUT=_scratch/i011-20261020/final-corpus-7', 'LINUX_ACCELERATOR=hvf'],
     env, 'final-linux-corpus-7.log', 'final-linux-corpus-7.stderr'),
    ('component-tools', ['make', '-s', 'test-compiler-distribution-tools', 'test-native-runtime-tools',
                         'NATIVE_RUNTIME_OUTPUT=' + str(runtime)],
     component_env, 'final-component-tools-7.log', 'final-component-tools-7.stderr'),
]
for name, command, environment, output, error in jobs:
    stdout, stderr = (base / output).open('xb'), (base / error).open('xb')
    active[name] = (subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                    cwd=root, env=environment), stdout, stderr)
    print('START ' + name, flush=True)
record()
while active:
    for name, (process, stdout, stderr) in list(active.items()):
        code = process.poll()
        if code is not None:
            stdout.close(); stderr.close()
            statuses[name] = code
            del active[name]
            print('DONE ' + name + ' ' + str(code), flush=True)
            record()
    if active:
        time.sleep(1)
if any(statuses.values()):
    raise SystemExit('Required nonperformance validation failed; quiet admission not started')
subprocess.run([sys.executable, '-B', str(base / 'extract-ci-corpus-7.py')],
               stdin=subprocess.DEVNULL, cwd=root, env=env, check=True)
subprocess.run([sys.executable, '-B', 'tools/semanticcoverage/report.py',
                '--interpreter', str(base / 'final-corpus-7/darwin/semantic-interpreter.jsonl'),
                '--llvm', 'darwin/arm64=' + str(base / 'final-corpus-7/darwin/semantic-llvm-darwin-arm64.jsonl'),
                '--llvm', 'linux/arm64=' + str(base / 'final-corpus-7/linux/semantic-linux-arm64.jsonl'),
                '--output', str(base / 'final-semantic-report.json')],
               stdin=subprocess.DEVNULL, cwd=root, env=env, check=True)
verify_freeze('performance')
module_spec = importlib.util.spec_from_file_location('lo_quiet_host', base / 'quiet-host.py')
quiet_module = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(quiet_module)
monitor = quiet_module.Monitor(os.getpid(), plan, base / 'quiet-host-trace-8.jsonl', base / 'quiet-host-summary-8.json')
performance_status = 1
try:
    print('START predeclared quiet-host admission', flush=True)
    monitor.admit()
    print('START one complete eight-lane performance attempt', flush=True)
    with (base / 'final-performance-5.stdout').open('xb') as stdout, (base / 'final-performance-5.stderr').open('xb') as stderr:
        performance_status = subprocess.run([sys.executable, '-B', str(base / 'final-performance-5.py')],
                                            stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                            cwd=root, env=env).returncode
finally:
    environment = monitor.finish(performance_status)
    statuses['performance'] = performance_status
    record()
if performance_status or not environment['passed']:
    raise SystemExit('Complete performance attempt failed or quiet-host evidence is invalid')
verify_freeze('complete')
print('All final qualification commands passed', flush=True)
