"""Read campaign11 receipts for original freeze7 without running commands; emit JSON only after every gate passes.

Run from Lo with python3 -B. This audit does not replace the independent completion
review. It never starts tests, compilers, guests, benchmarks, or child processes.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
import importlib.util
import json
import math
from pathlib import Path
import sys
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '_scratch/i011-20261020'
sys.path.insert(0, str(ROOT / 'tools/nativebench'))
import merge as performance_merge
import identity as performance_identity


def require(condition: bool, subject: str) -> None:
    if not condition:
        raise ValueError(subject)


def local(path: Path) -> Path:
    resolved = path.resolve()
    require(resolved.is_relative_to(ROOT), f'path outside Lo: {path}')
    return resolved


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with local(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(local(path).read_text())
    require(isinstance(value, dict), f'expected JSON object: {path}')
    return value


def receipt(path: Path) -> dict[str, str]:
    return {'path': str(local(path).relative_to(ROOT)), 'sha256': sha(path)}


def success(result: dict[str, Any], subject: str) -> None:
    require(type(result.get('status')) is int and result['status'] == 0,
            f'{subject}: command did not exit zero')
    require(result.get('stderr') == '', f'{subject}: unexpected stderr')


def corpus(path: Path, expected: dict[str, str], semantic: Any) -> dict[str, Any]:
    events = semantic.read_events(local(path), expected)
    require(not any(value == 'fail' for value in events.statuses.values()), f'failed corpus case: {path}')
    counts = {key: sum(value == key for value in events.statuses.values()) for key in ('pass', 'fail', 'skip')}
    require(counts['pass'] > 0, f'empty corpus: {path}')
    return {'log': receipt(path), 'identity': events.identity, 'counts': counts,
            'statuses': events.statuses}



spec = importlib.util.spec_from_file_location('lo_campaign11_contract', BASE / 'campaign-contract-11.py')
campaign = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = campaign
spec.loader.exec_module(campaign)

def audit_nonperformance() -> dict[str, Any]:
    frozen = load(BASE / 'frozen-inputs-7.json')
    for group in ('sources', 'measurement_sources', 'packages'):
        require(isinstance(frozen.get(group), dict) and bool(frozen[group]), f'empty freeze group: {group}')
        for name, expected_digest in frozen[group].items():
            require(sha(ROOT / name) == expected_digest, f'frozen input changed: {name}')
    source_hash = frozen['semantic_source_sha256']
    require(source_hash == campaign.SOURCE, 'freeze7 source differs from predeclared quiet plan')
    specification = importlib.util.spec_from_file_location('lo_final_semantic_report', ROOT / 'tools/semanticcoverage/report.py')
    require(specification is not None and specification.loader is not None, 'semantic reporter unavailable')
    semantic = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = semantic
    specification.loader.exec_module(semantic)
    sources, current_hash = semantic.source_identity()
    require(current_hash == source_hash and sources == frozen['sources'], 'semantic source freeze differs')
    report_path = BASE / 'final-semantic-report.json'
    report = load(report_path)
    require(report.get('execution_status') == report.get('qualification_status') == 'passed',
            'semantic report is incomplete')
    require(report.get('missing_targets') == [] and report.get('qualification_gaps') == [],
            'semantic targets or required obligations are absent')
    require(report.get('source_sha256') == sources, 'semantic report source map differs')
    matrix_path = ROOT / 'testdata/semantic-migration/matrix.json'
    matrix = load(matrix_path)
    matrix_hash = sha(matrix_path)
    require(report.get('matrix_sha256') == matrix_hash, 'semantic matrix identity differs')
    paths = {
        'interpreter': BASE / 'final-corpus-7/darwin/semantic-interpreter.jsonl',
        'llvm:darwin/arm64': BASE / 'final-corpus-7/darwin/semantic-llvm-darwin-arm64.jsonl',
        'llvm:linux/arm64': BASE / 'final-corpus-7/linux/semantic-linux-arm64.jsonl',
    }
    lanes = {}
    for lane, path in paths.items():
        backend = 'interpreter' if lane == 'interpreter' else 'llvm'
        expected = {'source_sha256': source_hash, 'matrix_sha256': matrix_hash, 'backend': backend}
        expected['target'] = 'darwin/arm64' if backend == 'interpreter' else lane.split(':', 1)[1]
        lanes[lane] = corpus(path, expected, semantic)
        require(report['log_sha256'][lane] == sha(path), f'semantic log digest differs: {lane}')
        require(report['execution_identity'][lane] == lanes[lane]['identity'], f'semantic lane identity differs: {lane}')
    refs = semantic.references(matrix)
    expected_tests = set(refs)
    observed_tests = [item['test'] for item in report['references']]
    require(len(observed_tests) == len(expected_tests) and set(observed_tests) == expected_tests,
            'semantic reference inventory differs')
    for ref in expected_tests:
        for lane, details in lanes.items():
            required = [ref] if lane == 'interpreter' else matrix['native_tests'][ref]
            require(bool(required) and all(details['statuses'].get(test) == 'pass' for test in required),
                    f'required semantic obligation did not pass: {lane}:{ref}')
    removed_paths = ('internal/codegen', 'internal/runtimebundle', 'tools/runtimebundle',
                     'tools/nativefixture', 'tools/nativecache', 'tools/nativefixture/nativecache')
    for name in removed_paths:
        require(not (ROOT / name).exists() and not (ROOT / name).is_symlink(),
                f'retired Go-generation path remains: {name}')
    retirement_tests = ('TestNativeRejectsBackendSelection', 'TestNativeRemovedSourceDiagnostics')
    retirement = {'absent_paths': list(removed_paths), 'public_tests': {}}
    for name in retirement_tests:
        retirement['public_tests'][name] = {}
        for lane, details in lanes.items():
            require(details['statuses'].get(name) == 'pass',
                    f'retirement public test did not pass: {lane}:{name}')
            retirement['public_tests'][name][lane] = [test for test, state in details['statuses'].items()
                                                    if state == 'pass' and (test == name or test.startswith(name + '/'))]
    allocation_preservation = {}
    for name in ('TestCollectionArgumentResults', 'TestLLVMCollectionArgumentLifetime'):
        allocation_preservation[name] = {}
        for lane, details in lanes.items():
            expected_status = 'skip' if name.startswith('TestLLVM') and lane == 'interpreter' else 'pass'
            actual_status = details['statuses'].get(name)
            require(actual_status == expected_status,
                    f'callback preservation result differs: {lane}:{name}:{actual_status}')
            allocation_preservation[name][lane] = actual_status
    ml_refs = ('TestAutodiffAnalyticalAndFiniteDifferences', 'TestMetalComputeTraining',
               'TestMetalTrainingGradients', 'TestSemanticMigrationCheckpointResume',
               'TestSemanticNativeMetalCheckpointResume')
    ml = {name: {lane: ([name] if lane == 'interpreter' else matrix['native_tests'][name])
                 for lane in lanes} for name in ml_refs}
    ml_observed = {lane: [name for name, state in details['statuses'].items()
                          if state == 'pass' and any(term in name.lower() for term in ('autodiff', 'training', 'xor', 'checkpoint'))]
                   for lane, details in lanes.items()}
    ci_stdout, ci_stderr = BASE / 'final-ci.stdout', BASE / 'final-ci.stderr'
    require(ci_stdout.is_file() and ci_stderr.is_file() and ci_stdout.stat().st_size > 0, 'final CI logs missing')
    # Reconcile extracted Darwin logs with the original CI stream, preserving event order.
    ci_events = []
    for line in ci_stdout.read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict):
            require(event.get('Action') != 'fail', 'final CI contains a failed package or test')
            if event.get('Package') == semantic.PACKAGE:
                ci_events.append(event)
    extracted = []
    for lane in ('interpreter', 'llvm:darwin/arm64'):
        extracted.extend(json.loads(line) for line in paths[lane].read_text().splitlines())
    require(ci_events == extracted, 'Darwin corpus extraction differs from final CI integration events')
    regression_names = {
        'B001': ('TestFlowFoldNestedCancellationProgress', 'TestLLVMNestedFoldCancellationProgress'),
        'B002': ('TestLLVMMetalBroadcastStandalone',),
        'B003': ('TestAdapterProcessUnavailableInServerCallbacks', 'TestAdapterServerFailureContext',
                 'TestAdapterServerStartupFailureContext', 'TestLLVMServerCallbackIndependentCleanup'),
    }
    ci_passes = {event.get('Test') for event in ci_events if event.get('Action') == 'pass' and event.get('Test')}
    regression_evidence = {}
    for issue, names in regression_names.items():
        for name in names:
            require(name in ci_passes, f'final CI regression did not pass: {issue}:{name}')
        regression_evidence[issue] = {name: sorted(test for test in ci_passes
                                                if test == name or test.startswith(name + '/')) for name in names}
    transport_smoke_path = BASE / 'transport-smoke/report.json'
    transport_smoke = load(transport_smoke_path)
    require(transport_smoke.get('passed') is True and transport_smoke.get('qemu_status') == 0,
            'B004 pinned-QEMU smoke did not pass')
    require(transport_smoke.get('export') == 'LO_TRANSPORT_SMOKE_EXPORT:exact-bytes\n' and
            'LO_TRANSPORT_SMOKE_KERNEL_DIAGNOSTIC' in transport_smoke.get('serial', '') and
            'LO_TRANSPORT_SMOKE_EXPORT:' not in transport_smoke.get('serial', ''),
            'B004 smoke does not separate export from kernel diagnostics')
    transport_real_path = BASE / 'transport-real-checks.json'
    transport_real = load(transport_real_path)
    require(transport_real.get('distribution_status') == 0 and
            transport_real.get('artifact_digest_matches') is True and
            transport_real.get('batch_artifact_bytes_match') is True and
            transport_real.get('serial_protocol_absent') is True and
            transport_real.get('strict_receiver_recheck') == 'passed', 'B004 real transport checks differ')
    require({item['id'] for item in transport_real['results']} == {'interpreter', 'artifact'} and
            all(item['status'] == 0 and item['result']['result'] == {'type': 'Int', 'value': '10'}
                for item in transport_real['results']), 'B004 real interpreter/artifact results differ')
    regression_evidence['B004'] = {
        'focused_scope': 'Historical public injected-dependency checks and pinned-QEMU transport checks; not a full corpus.',
        'smoke': receipt(transport_smoke_path), 'real_checks': receipt(transport_real_path),
        'focused_logs': [receipt(BASE / name) for name in
                         ('fixtures/transport/red.log', 'fixtures/transport/green.log',
                          'linux/transport/red.log', 'linux/transport/strict-final-green.log')],
        'final_corpus_status': 'Current source-bound corpora admitted separately by this audit.',
    }
    linux = load(BASE / 'final-corpus-7/linux/report.json')
    require(linux['target'] == 'linux/arm64' and linux['cases'] and all(case['status'] == 0 for case in linux['cases']),
            'Linux guest corpus command failed')
    require(local(ROOT / linux['events']) == local(paths['llvm:linux/arm64']), 'Linux event path differs')
    packages = {}
    for name in ('lo-darwin-arm64-software', 'lo-linux-arm64-software', 'lo-darwin-arm64-metal'):
        package = ROOT / 'bin/distributions' / name
        package_receipt_path = package.with_suffix('.receipt.json')
        package_receipt = load(package_receipt_path)
        require(package_receipt['toolchain_sha256'] == sha(package / 'toolchain.json'), f'package manifest differs: {name}')
        require(package_receipt['inventory_sha256'] == sha(package / 'inventory.json'), f'package inventory differs: {name}')
        require(package_receipt['archive_sha256'] == sha(ROOT / package_receipt['archive']), f'package archive differs: {name}')
        packages[name] = {'receipt': receipt(package_receipt_path), 'values': package_receipt,
                          'compiler_sha256': sha(package / 'bin/lo')}
    for lane, package_name in (
        ('interpreter', 'lo-darwin-arm64-metal'),
        ('llvm:darwin/arm64', 'lo-darwin-arm64-metal'),
        ('llvm:linux/arm64', 'lo-linux-arm64-software'),
    ):
        execution = lanes[lane]['identity']
        selected = packages[package_name]
        package = ROOT / 'bin/distributions' / package_name
        require(local(ROOT / execution['compiler']) == local(package / 'bin/lo'),
                f'corpus selected compiler path differs: {lane}')
        require(execution['compiler_sha256'] == selected['compiler_sha256'],
                f'corpus selected compiler digest differs: {lane}')
        if lane != 'interpreter':
            manifest_path = package / 'toolchain.json'
            manifest = load(manifest_path)
            require(local(ROOT / execution['toolchain']) == local(manifest_path),
                    f'corpus selected manifest path differs: {lane}')
            require(execution['toolchain_sha256'] == selected['values']['toolchain_sha256'],
                    f'corpus selected manifest digest differs: {lane}')
            runtime = manifest['targets'][execution['target']]['runtime']
            require(execution['runtime_sha256'] == runtime['sha256'] == sha(package / runtime['path']),
                    f'corpus selected runtime digest differs: {lane}')
    require(linux['compiler_sha256'] == packages['lo-linux-arm64-software']['compiler_sha256'], 'Linux corpus compiler differs')
    require(linux['manifest_sha256'] == packages['lo-linux-arm64-software']['values']['toolchain_sha256'], 'Linux corpus manifest differs')
    offline_path = BASE / 'final-offline-7/validation.json'
    offline = load(offline_path)
    require(offline.get('status') == 'passed', 'offline matrix incomplete')
    success(offline['guard'], 'Darwin isolation guard')
    require(offline['guard']['stdout'] == 'filesystem, network, and descendant restrictions verified\n',
            'offline isolation guard facts differ')
    expected_rejections = {'manifest-missing', 'manifest-corrupt', 'compiler-missing', 'compiler-corrupt',
                           'linker-corrupt', 'runtime-corrupt', 'platform-corrupt', 'kernel-corrupt', 'linux-host-library'}
    rejected = offline['rejections']
    require(len(rejected) == 9 and {item['case'] for item in rejected} == expected_rejections,
            'offline requires exactly nine negative cases')
    for item in rejected:
        require(item.get('status') == 2 and item.get('stdout') == '' and
                item.get('prior_output_preserved') is True and item.get('staging_empty') is True,
                f'offline negative case contract differs: {item.get("case")}')
        diagnostics = json.loads(item['stderr'])['diagnostics']
        require(len(diagnostics) == 1 and diagnostics[0]['code'] == 'build.toolchain',
                f'offline negative diagnostic differs: {item["case"]}')
    negative_summary = [{'case': item['case'], 'status': item['status'],
                         'prior_output_preserved': item['prior_output_preserved'],
                         'staging_empty': item['staging_empty'], 'diagnostic': 'build.toolchain'} for item in rejected]

    expected_matrix = {(host, target) for host in ('darwin/arm64', 'linux/arm64') for target in ('darwin/arm64', 'linux/arm64')}
    actual_matrix = [(item['host'], item['target']) for item in offline['matrix']]
    require(len(actual_matrix) == 4 and set(actual_matrix) == expected_matrix, 'offline host-target matrix differs')
    expected_core = {'large': '123456789012345678901234567891', 'text': 'λ雪', 'count': '3', 'tensor': '6', 'error': 'Math.DivideByZero'}
    for item in [*offline['matrix'], offline['metal'], offline['relocation']]:
        success(item['compile'], 'offline compile')
        success(item['execute'], 'separate artifact execution')
        fields = json.loads(item['execute']['stdout'])['result']['value']['value']
        require({name: value['value'] for name, value in fields.items()} == expected_core, 'representative artifact result differs')
    for short, name in (('darwin', 'lo-darwin-arm64-software'), ('linux', 'lo-linux-arm64-software'), ('metal', 'lo-darwin-arm64-metal')):
        actual = offline['packages'][short]
        for key, value in packages[name]['values'].items():
            require(actual.get(key) == value, f'offline package identity differs: {short}:{key}')
        require(actual['frontend_sha256'] == packages[name]['compiler_sha256'], f'offline compiler differs: {short}')
    require(len(offline['training']) == 2 and {entry['host'] for entry in offline['training']} == {'darwin/arm64', 'linux/arm64'}, 'offline XOR hosts missing')
    xor_values = {}
    for item in offline['training']:
        success(item['compile'], 'offline XOR compile')
        success(item['execute'], 'offline XOR execution')
        fields = json.loads(item['execute']['stdout'])['result']['value']['value']
        require(fields['steps']['value'] == '500' and float(fields['loss']['value']) < 1e-10 < float(fields['initial_loss']['value']), 'offline XOR loss or steps differ')
        predictions = [float(value) for value in fields['predictions']['value']['values']]
        require(len(predictions) == 4 and all(abs(value - expected) <= 1e-4 for value, expected in zip(predictions, (0, 1, 1, 0))), 'offline XOR predictions differ')
        xor_values[item['host']] = {'steps': fields['steps']['value'], 'initial_loss': fields['initial_loss']['value'],
                                    'loss': fields['loss']['value'], 'predictions': fields['predictions']['value']['values']}
    for details in lanes.values():
        del details['statuses']
    return {'semantic_source_sha256': source_hash, 'freeze': receipt(BASE / 'frozen-inputs-7.json'),
            'ci': {'stdout': receipt(ci_stdout), 'stderr': receipt(ci_stderr)}, 'semantic_report': receipt(report_path),
            'corpora': lanes, 'ml_required_references': ml, 'ml_observed_cases': ml_observed,
            'go_generation_retirement': retirement, 'callback_allocation_preservation': allocation_preservation,
            'defect_regressions': regression_evidence, 'packages': packages,
            'offline': {'receipt': receipt(offline_path), 'matrix': offline['matrix'], 'training': offline['training'],
                        'guard': offline['guard'], 'negative_cases': negative_summary, 'xor_values': xor_values,
                        'separate_metal_and_relocation': True,
                        'cancellation_scope': 'Separate public CI build test; not an offline matrix cell.'}}


def audit() -> dict[str, Any]:
    sealed = campaign.verify_bindings()
    nonperformance = audit_nonperformance()
    require(nonperformance == sealed['nonperformance_summary'], 'sealed nonperformance identity audit differs')
    status_path = BASE / 'final-validation-status-11.json'
    status = load(status_path)
    require(status.get('campaign') == 11 and status.get('complete') is True and status.get('passed') is True and
            status.get('phase') == 'terminal' and status.get('terminal_reason') is None and status.get('running') == [] and status.get('error') is None and status.get('selected_attempt') in (11, 12), 'campaign did not complete successfully')
    require(status.get('sealed_inputs') == receipt(BASE / 'campaign-inputs-11.json'), 'campaign sealed-input receipt differs')
    require('All campaign qualification commands passed' in (BASE / 'final-validation-11.log').read_text(), 'campaign success marker absent')
    exit_receipt = load(BASE / 'final-driver-exit-11.json')
    require(exit_receipt.get('observed_exit_code') == 0 and exit_receipt.get('campaign_complete') is True and
            exit_receipt.get('campaign_passed') is True and exit_receipt.get('selected_attempt') == status['selected_attempt'],
            'root-observed successful driver exit is absent or inconsistent')
    plan = campaign.plan11()
    frozen = load(BASE / 'frozen-inputs-7.json')
    selected_id = status['selected_attempt']
    expected_ids = [11] if selected_id == 11 else [11, 12]
    require([attempt['id'] for attempt in status['attempts']] == expected_ids, 'campaign attempt order differs')
    for item in status['attempts']:
        definition = next(value for value in plan['attempts'] if value['id'] == item['id'])
        require(item['measurement_started'] is True and type(item['measurement_status']) is int and item['phase'] == 'terminal' and item['admission_status'] == 'passed', 'attempt does not prove an admitted measurement process')
        rejected = item['id'] != selected_id
        require(item['disposition'] == ('cpu-load-invalidated' if rejected else 'passed'), 'campaign retry reason differs')
        environment = campaign.validate_quiet(ROOT / definition['summary'], plan, cpu_rejection=rejected)
        require(environment['summary'] == item['quiet_summary'] and environment['attempt'] == item['id'], 'attempt quiet receipt differs')
        outcome = campaign.validate_runner(definition, item['runner_outcome'])
        if rejected:
            require(campaign.retry_allowed(load(ROOT / definition['summary']), outcome), 'second attempt is not eligible')
        else:
            require(outcome['failure_kind'] == 'passed', 'selected runner did not pass')
        if not rejected:
            require(item['measurement_started'] is True and item['measurement_status'] == 0 and item['phase'] == 'terminal' and item['admission_status'] == 'passed', 'selected performance command failed')
        for phase in ('before', 'after'):
            verification_path = BASE / f'freeze-verify-11-attempt-{item["id"]}-{phase}.log'
            verification = load(verification_path)
            require(verification.get('action') == 'verify' and verification.get('source_sha256') == campaign.SOURCE and
                    verification.get('source_files') == len(frozen['sources']) and verification.get('package_files') == len(frozen['packages']),
                    'campaign freeze check differs')
    selected = next(value for value in plan['attempts'] if value['id'] == selected_id)
    performance = {}
    for short, target in (('darwin', 'darwin/arm64'), ('linux', 'linux/arm64')):
        directory = local(ROOT / selected['performance_directory'])
        input_paths = [directory / f'{short}-{lane}/report.json' for lane in ('execution', 'process', 'http', 'build')]
        calculated = performance_merge.merge(input_paths)
        merged_path = directory / f'{short}-merged.json'
        stored = load(merged_path)
        require(stored == calculated, f'stored strict merge differs from recomputed whole lanes: {short}')
        require(calculated['qualification_complete'] is True and calculated['gates_passed'] is True, f'performance gates incomplete: {short}')
        identity = calculated['merge_identity']
        require(identity['target'] == target and identity['source']['semantic_source_sha256'] == nonperformance['semantic_source_sha256'], f'performance target/source differs: {short}')
        package = ROOT / 'bin/distributions' / f'lo-{short}-arm64-software'
        admitted, _ = performance_identity.package_provenance(ROOT, package / 'bin/lo', package / 'toolchain.json', target)
        require(identity['package'] == admitted, f'performance package differs: {short}')
        performance_identity.verify_source_identity(ROOT, identity)
        build = calculated['build']
        performance[target] = {'report': receipt(merged_path), 'lanes': [receipt(path) for path in input_paths],
            'callback_speedup': calculated['callback_speedup'], 'callback_bootstrap_95_percent': calculated['callback_bootstrap_95_percent'],
            'max_build_seconds': max(item['elapsed_ns'] for item in build) / 1e9,
            'max_build_rss_bytes': max(item['peak_process_tree_rss_bytes'] for item in build),
            'max_artifact_bytes': max(item['artifact_bytes'] for item in build),
            'max_diagnostic_bytes': max(item['diagnostic_bytes'] for item in build),
            'merge_identity': identity}
    return {'issue': 'I011', 'campaign': 11, 'selected_attempt': selected_id, 'source_candidate': 7,
            'audit_status': 'all_required_evidence_complete', 'campaign_status': receipt(status_path),
            'campaign_log': receipt(BASE / 'final-validation-11.log'), 'driver_exit': receipt(BASE / 'final-driver-exit-11.json'),
            'sealed_inputs': receipt(BASE / 'campaign-inputs-11.json'), 'plan': receipt(BASE / 'quiet-host-plan-11.json'),
            'original_attempt8_rejection': campaign.predecessor(), 'prior_campaign9_timeout': campaign.predecessor9(),
            'authorization': sealed['authorization'], 'restoration_context': sealed['context_records'], 'reused_nonperformance': nonperformance,
            'quiet_environment': campaign.validate_quiet(ROOT / selected['summary'], plan),
            'performance': performance, 'limits': ['Final independent completion review remains root-owned.',
            'Physical Metal execution and performance remain unmeasured.',
            'No performance lane from an invalidated attempt is accepted.']}


if __name__ == '__main__':
    try:
        result = audit()
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        print(f'Campaign11 evidence audit rejected: {error}', file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps(result, indent=2, allow_nan=False))
