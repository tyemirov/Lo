from pathlib import Path
import json, os, subprocess, sys, time
root=Path.cwd().resolve(); base=root/'_scratch/i011-20261020'
env=dict(os.environ);env.pop('LO_TEST_BACKEND',None)
ci_env=dict(env,LO_TEST_COMPILER=str(root/'bin/distributions/lo-darwin-arm64-metal/bin/lo'))
component_env=dict(env,LO_TEST_RUNTIME_DISTRIBUTION=str(root/'_scratch/i011-20261020/optimization/distribution-server-context-metal'))
jobs=[
 ('ci',['make','-s','ci','LLVM_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json','SEMANTIC_COMPILER=bin/distributions/lo-darwin-arm64-metal/bin/lo','SEMANTIC_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json','NATIVE_RUNTIME_STATE=_scratch/native-runtime','TEST_ARGS=-json -count=1'],ci_env,'final-ci.stdout','final-ci.stderr'),
 ('linux-corpus',['make','-s','test-native-linux','COMPILER_DISTRIBUTION_OUTPUT=bin/distributions','NATIVE_QUALIFICATION_OUTPUT=_scratch/i011-20261020/final-corpus-5','LINUX_ACCELERATOR=hvf'],env,'final-linux-corpus-5.log','final-linux-corpus-5.stderr'),
 ('component-tools',['make','-s','test-compiler-distribution-tools','test-native-runtime-tools','NATIVE_RUNTIME_OUTPUT=_scratch/i011-20261020/optimization/distribution-server-context-metal'],component_env,'final-component-tools-5.log','final-component-tools-5.stderr')]

active={}; statuses={};started=time.monotonic()
def record():
 (base/'final-validation-status-5.json').write_text(json.dumps({'statuses':statuses,'running':list(active),'elapsed_seconds':round(time.monotonic()-started,3)},indent=2)+'\n')
for name,command,environment,output,error in jobs:
 stdout=(base/output).open('wb');stderr=(base/error).open('wb')
 active[name]=(subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,cwd=root,env=environment),stdout,stderr)
 print('START '+name,flush=True)
record()
while active:
 for name,(process,stdout,stderr) in list(active.items()):
  code=process.poll()
  if code is not None:
   stdout.close();stderr.close();statuses[name]=code;del active[name];print('DONE '+name+' '+str(code),flush=True);record()
 if active:time.sleep(1)
if any(statuses.values()):raise SystemExit('Required validation failed; performance not started')
print('START complete offline matrix after all other validation jobs ended',flush=True)
with (base/'final-offline-5.log').open('wb') as stdout,(base/'final-offline-5.stderr').open('wb') as stderr:
 result=subprocess.run(['make','-s','test-compiler-distributions','COMPILER_DISTRIBUTION_OUTPUT=bin/distributions','COMPILER_DISTRIBUTION_ACCEPTANCE=_scratch/i011-20261020/final-offline-5'],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,cwd=root,env=env)
statuses['offline']=result.returncode;record()
print('DONE offline '+str(result.returncode),flush=True)
if result.returncode:raise SystemExit('Offline matrix failed; performance not started')
with (base/'freeze-verify-5.log').open('wb') as output:
 subprocess.run([sys.executable,'-B',str(base/'freeze-inputs.py'),'verify'],stdout=output,stdin=subprocess.DEVNULL,cwd=root,check=True)
subprocess.run([sys.executable,'-B',str(base/'extract-ci-corpus.py')],stdin=subprocess.DEVNULL,cwd=root,check=True)
command=[sys.executable,'-B','tools/semanticcoverage/report.py','--interpreter',str(base/'final-corpus-5/darwin/semantic-interpreter.jsonl'),'--llvm','darwin/arm64='+str(base/'final-corpus-5/darwin/semantic-llvm-darwin-arm64.jsonl'),'--llvm','linux/arm64='+str(base/'final-corpus-5/linux/semantic-linux-arm64.jsonl'),'--output',str(base/'final-semantic-report.json')]
subprocess.run(command,stdin=subprocess.DEVNULL,cwd=root,check=True)
print('START full performance matrix after all other jobs ended',flush=True)
subprocess.run([sys.executable,'-B',str(base/'final-performance-2.py')],stdin=subprocess.DEVNULL,cwd=root,check=True)
print('All final qualification commands passed',flush=True)
