from pathlib import Path
import argparse
import json
import os
import subprocess
import sys
import time

root = Path.cwd().resolve()
base = root / '_scratch/i011-20261020'
parser = argparse.ArgumentParser()
parser.add_argument('--runtime', type=Path, required=True)
arguments = parser.parse_args()
runtime = arguments.runtime.resolve()
if not runtime.is_relative_to(root) or not (runtime / 'build-receipt.json').is_file():
    raise SystemExit('Required runtime input is absent or outside Lo: ' + str(runtime))
env = dict(os.environ, CI='1')
env.pop('LO_TEST_BACKEND', None)
ci_env = dict(env, LO_TEST_COMPILER=str(root / 'bin/distributions/lo-darwin-arm64-metal/bin/lo'))
component_env = dict(env, LO_TEST_RUNTIME_DISTRIBUTION=str(runtime))
statuses = {}
active = {}
started = time.monotonic()


def record():
    (base / 'final-validation-status-7.json').write_text(json.dumps({
        'statuses': statuses, 'running': list(active),
        'elapsed_seconds': round(time.monotonic() - started, 3),
    }, indent=2) + '\n')


def verify_freeze(stage):
    with (base / ('freeze-verify-7-' + stage + '.log')).open('wb') as output:
        subprocess.run([sys.executable, '-B', str(base / 'freeze-inputs-7.py'), 'verify'],
                       stdout=output, stdin=subprocess.DEVNULL, cwd=root, env=env, check=True)


verify_freeze('start')
record()
print('START all eight serial performance lanes before other qualification jobs', flush=True)
performance = subprocess.run([sys.executable, '-B', str(base / 'final-performance-4.py')],
                             stdin=subprocess.DEVNULL, cwd=root, env=env)
statuses['performance'] = performance.returncode
record()
print('DONE performance ' + str(performance.returncode), flush=True)
if performance.returncode:
    raise SystemExit('Performance qualification failed; remaining qualification not started')
verify_freeze('performance')

print('START complete offline matrix before CI and corpus jobs', flush=True)
with (base / 'final-offline-7.log').open('wb') as stdout, (base / 'final-offline-7.stderr').open('wb') as stderr:
    offline = subprocess.run([
        'make', '-s', 'test-compiler-distributions',
        'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
        'COMPILER_DISTRIBUTION_ACCEPTANCE=_scratch/i011-20261020/final-offline-7',
    ], stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, cwd=root, env=env)
statuses['offline'] = offline.returncode
record()
print('DONE offline ' + str(offline.returncode), flush=True)
if offline.returncode:
    raise SystemExit('Offline matrix failed; CI and corpus jobs not started')

jobs = [
    ('ci', ['make', '-s', 'ci',
            'LLVM_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json',
            'SEMANTIC_COMPILER=bin/distributions/lo-darwin-arm64-metal/bin/lo',
            'SEMANTIC_TOOLCHAIN=bin/distributions/lo-darwin-arm64-metal/toolchain.json',
            'NATIVE_RUNTIME_STATE=_scratch/native-runtime', 'TEST_ARGS=-json -count=1'],
     ci_env, 'final-ci.stdout', 'final-ci.stderr'),
    ('linux-corpus', ['make', '-s', 'test-native-linux',
                      'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
                      'NATIVE_QUALIFICATION_OUTPUT=_scratch/i011-20261020/final-corpus-7',
                      'LINUX_ACCELERATOR=hvf'],
     env, 'final-linux-corpus-7.log', 'final-linux-corpus-7.stderr'),
    ('component-tools', ['make', '-s', 'test-compiler-distribution-tools',
                         'test-native-runtime-tools', 'NATIVE_RUNTIME_OUTPUT=' + str(runtime)],
     component_env, 'final-component-tools-7.log', 'final-component-tools-7.stderr'),
]
for name, command, environment, output, error in jobs:
    stdout = (base / output).open('wb')
    stderr = (base / error).open('wb')
    active[name] = (subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout,
                                    stderr=stderr, cwd=root, env=environment), stdout, stderr)
    print('START ' + name, flush=True)
record()
while active:
    for name, (process, stdout, stderr) in list(active.items()):
        status = process.poll()
        if status is not None:
            stdout.close()
            stderr.close()
            statuses[name] = status
            del active[name]
            print('DONE ' + name + ' ' + str(status), flush=True)
            record()
    if active:
        time.sleep(1)
if any(statuses.values()):
    raise SystemExit('Required validation failed')
verify_freeze('complete')
subprocess.run([sys.executable, '-B', str(base / 'extract-ci-corpus-7.py')],
               stdin=subprocess.DEVNULL, cwd=root, env=env, check=True)
subprocess.run([
    sys.executable, '-B', 'tools/semanticcoverage/report.py',
    '--interpreter', str(base / 'final-corpus-7/darwin/semantic-interpreter.jsonl'),
    '--llvm', 'darwin/arm64=' + str(base / 'final-corpus-7/darwin/semantic-llvm-darwin-arm64.jsonl'),
    '--llvm', 'linux/arm64=' + str(base / 'final-corpus-7/linux/semantic-linux-arm64.jsonl'),
    '--output', str(base / 'final-semantic-report.json'),
], stdin=subprocess.DEVNULL, cwd=root, env=env, check=True)
print('All final qualification commands passed', flush=True)
