# I011 execution plan

Task: Qualify the standalone compiler on both targets and remove Go generation.
Related defect: B001 records the nested-fold cancellation correction and its final validation.

Owned temporary directory: `_scratch/i011-20261020/`.
The directory contains the verified STE reference, test logs, and agent evidence.
Agent evidence uses the `harness`, `fixtures`, `linux`, and `optimization` subdirectories.
Reusable inputs remain in `_scratch/native-runtime/` and `_scratch/compiler-distribution/`.

- [x] Read the repository instructions and I011 dependencies.
- [x] Obtain the architect review before implementation.
- [x] Verify the official STE reference.
- [x] Bind semantic evidence to the installed compiler, runtime, and target.
- [x] Replace generated Go fixtures with native runtime fixtures.
- [x] Execute the complete applicable corpus on both targets.
- [ ] Measure the performance and build resource contracts.
- [x] Remove Go generation after the initial full corpus and corrected fixture checks.
- [x] Rebuild the distributions and repeat offline acceptance.
- [ ] Run final CI and obtain an independent architect review.
- [ ] Update the durable plan and I011 status.
- [ ] Preserve evidence and remove this plan and its temporary directory.

The primary agent owns integration, long commands, documentation, and issue status.
The optimization worker owns each assigned runtime change and its characterization tests.
The Linux worker owns guest measurement tools and benchmark identity inputs.
The fixture worker owns benchmark merge validation and assigned documentation.
Workers use `mpr-worker`, `gpt-6.1-sol`, `medium`.
The architect uses `mpr-architect`, `gpt-6-astra`, `high`.
The host does not expose separate model telemetry.

The initial interpreter, Darwin native, and Linux native runs recorded 1,022, 1,188, and 1,173 passing cases.
Compiler selection and shared-directory fixture corrections passed with the same compiler and runtime inputs.
The architect approved Go retirement on this evidence, with final qualification still required.
Go generation, its helper tools, and the embedded runtime source bundle are removed.
Metal uses direct kernel assets with a producer receipt that identifies their source.
All original semantic references have native coverage mappings.
The architect approved removal of two obsolete coverage gaps from the matrix.
Native ABI fixtures now cover the injected device contracts.
Linux guest execution replaces the earlier cross-build-only limitation.
Strict reports still require passing references and exact source identities on both targets.
The I005 disclosed limits remain unchanged.
Linux qualification uses QEMU HVF or TCG without a network interface.
Physical Metal execution is not required and will not be claimed.

The fixed-slot metadata parser preserves 55 admission results and exact source-span diagnostics.
The latest map process probe passes the 10 percent gate with a 1.04 median ratio.
A size-based optimization policy keeps large function builds below the 180-second limit in diagnostic probes.
The complete Darwin execution probe failed startup and callback performance gates.
Its timing method charged two clock reads per native invocation.
The corrected timer uses calibrated batches with complete session setup and cleanup.
Ten deterministic driver tests pass for this timing contract.
Strict whole-lane merging requires identical package, source, environment, and measurement inputs.
The merge and identity tools have 33 and 11 passing tests.

Profiling identified repeated thread checks in admitted runtime operations.
New boundary tests passed before removal of duplicate internal checks.
The optimized runtime is in `_scratch/i011-20261020/thread-runtime/`.
The device HTTP lifetime fixture compared counts from different connection phases.
The correction checks exact counts in each phase and preserves final cleanup checks.
Both runtimes pass the corrected fixture.
The broader preservation run passes in 21 seconds.
The benchmark review requires canonical timer values and actual batch duration records.
Those corrections pass 102 focused tests after 24 expected failures.
Package and tool identity checks pass 21 focused tests and eight wrapper tests.
The obsolete package candidate was removed after preservation of its JSON receipts and artifact identities.

The final allocation changes pass preservation checks in 26 seconds.
The startup probe has a 0.880 native-to-interpreter ratio.
The map probe has a 2.180 speed improvement with a confidence interval above two.
Both probes use the corrected timer and pass their selected gates.
They remain diagnostic results, not complete acceptance evidence.
Final package preparation writes to `bin/distributions/`.
These packages must remain available after task cleanup.
All three final packages are prepared.
The 22 distribution tool tests and 20 native runtime tool tests pass.
The independent review found no remaining P1 or P2 defect in the latest changes.
The final Linux corpus passed under QEMU HVF in 284 seconds.
It recorded 1,274 passing cases, with no failed or skipped cases.
Both full execution lanes passed their performance gates.
The callback speed improvement is 2.033 on Darwin and 2.553 on Linux.
Both confidence intervals are above two.
The Darwin process lane stopped qualification at an inconclusive record case.
Its median ratio is 1.075, with a confidence interval from 1.007 to 1.169.
The upper bound exceeds the 1.1 limit.
All other process cases passed.
The profile attributes 82 percent of program work to admission and destruction.
The record program contains 6,082 coordinate objects and 18,246 owned coordinate-key strings.
The architect approved compact coordinate storage with unchanged validation and lossless output.
The optimization worker owns the representation, direct consumers, and public characterization tests.
The worker must preserve duplicate keys, extra members, exact diagnostics, receipts, and validation order.
The first source freeze ended for this change.
All first-candidate results remain historical evidence.
The packages and all required qualification runs must be repeated after the change.
Final CI will retain full interpreter and Darwin native JSON logs for semantic evidence.
The source and package inputs must stay unchanged during final qualification.

Preserve the first source and package identities before the next package build.
Resolve the inconclusive process gate before another acceptance attempt.
Finish all performance lanes without concurrent Lo builds or tests.
Merge only complete lanes with identical inputs.
Run the offline matrix and final CI.
Combine the final CI corpus logs with the completed Linux corpus log.
Preserve durable evidence before issue closure and task cleanup.

The compact coordinate change passed host preservation in 73 seconds and Linux preservation in 250 seconds.
The architect found no remaining P1 or P2 defect in the representation or compiler fixtures.
The matrix now requires all four coordinate test groups.
The fixed 20-pair record probe passed with a ratio below one and an upper confidence bound below 1.1.
This probe uses the development compiler and remains diagnostic evidence.
The first package candidate was retired after preservation of its identities and receipts.
The second final package build uses the reviewed coordinate runtime.
Final CI uses the installed Metal compiler with its matching manifest.
Custom-manifest tests select and identify their development compiler fixtures explicitly.

The second Linux corpus passed 1,401 cases with no failures or skips.
Final CI found one stale emission-limit fixture in the native build package.
The fixture assumed 18 LLVM bytes per NUL, but the current encoding uses eight bytes.
The corrected input stays below the lowering limit and exceeds the unchanged 64 MiB emission limit.
The focused test passed and preserved the existing output after the expected failure.
The second package candidate and CI results remain historical evidence.
The third package build includes this fixture correction.
Final qualification must use the third source identity.

The third Linux corpus passed, but the third candidate did not pass all qualification gates.
Offline Metal compilation failed because its system-library input omitted `memset_pattern16`.
B002 records this defect and the public broadcast build regression.
The regression reproduced the linker failure before the library description changed.
The architect confirmed that this export is the only missing runtime dependency between the two system-library descriptions.
Full native CI also found incorrect HTTP callback context and duplicate failure reports.
B003 records those semantic defects and the required preservation checks.
The optimization worker owns the B003 runtime correction and public tests.
The failed CI process tree was stopped after its diagnostic was preserved.
The third source freeze ended for these corrections.
All third-candidate results remain historical evidence.
The fourth source freeze must follow both corrections and their focused checks.

Both corrections passed their focused regressions and independent source review.
The fourth source freeze identifies the final packages in `bin/distributions/`.
Its semantic source digest is `8faf0dde4e57f9e74cf0bd159abacf9dd6a2638cf6cb9ebcfc763ac694ca9f83`.
The fourth Linux corpus passed 1,408 cases with no failures or skips.
All 42 distribution and runtime tool tests passed.
Final CI remains active.

The fourth offline attempt rejected a corrupted Linux XOR artifact transfer.
A kernel watchdog message interrupted the artifact bytes on the shared console.
The compiler reported success, but the receiver correctly rejected the transfer.
The failed log and independent diagnosis are preserved as historical evidence.
The architect approved one complete retry with unchanged source and packages after other jobs finish.
The retry uses `final-offline-5/` and retains all original limits.
The task process prevents idle system sleep while validation runs.
Any repeated corruption requires a separate guest data channel before another attempt.
The completion driver starts performance only after the full offline retry and strict semantic report pass.

The fourth candidate's CI run reached its 30-minute native-package timeout during continued successful execution.
No individual test failed before the timeout.
The active `TestLLVMMetalPrimitives/sqrt` case had just started.
The architect approved a 120-minute package budget, consistent with Linux qualification.
The Make targets and semantic runner now use that budget.
The compiler, runtime, per-build limits, and performance gates did not change.
The fourth candidate remains historical evidence.

The fifth packages are prepared and their source review passed.
The semantic source digest is `b30ddf2ddc67ec7a2d78e33df80b6f2a2106806136d4fbb84b03a40ad5602efa`.
`final-validation-5.py` runs all required checks with this source and these packages.
It waits for CI, the Linux corpus, and component checks before the full offline matrix.
It runs strict semantic checks and all performance lanes only after those commands pass.
The separate task process prevents idle system sleep during this work.

The fifth CI run passed, including 2,618 native cases without failures or skips.
Its interpreter run passed 1,737 cases, with 152 native-only cases excluded from that lane.
The fifth Linux corpus and all 42 component checks also passed.
The full offline matrix then rejected another artifact record interrupted by a kernel watchdog message.
B004 owns this repeated guest transport defect.
The architect requires separate virtio export channels in both guest harnesses.
The kernel console must retain its diagnostics, and all export checks must remain strict.
The pinned-QEMU smoke test passed with exact export bytes and a separate injected kernel diagnostic.
The Linux worker owns the distribution harness and its tests.
The fixture worker owns the qualification batch harness and its tests.
The primary agent owns real guest checks, the new source freeze, and final qualification.
Compiler packages can remain unchanged only after their complete identity verification.
The fifth source freeze ended for this harness correction.
The fifth results remain historical evidence and do not qualify the corrected harness.

The sixth source freeze is `316a045aa3db09c485251c0d57094c1928fe6bbe27fbb2cd9ba422655285ef17`.
All 339 package-file digests match the fifth freeze.
B004 focused checks and the real guest checks passed.
Independent source and validation-order review found no remaining blocker.
The new driver runs the full offline matrix first, then all other required qualification stages.
Final completion review remains pending.

The sixth offline matrix passed before the other validation jobs started.
All four software combinations and the separate Metal package passed compilation and artifact execution.
Both compiler hosts passed 500-step XOR training.
Relocation and nine input-rejection cases passed with prior output preservation.
Cancellation remains a separate CI build check.
All 56 distribution and runtime tool checks passed.
The sixth Linux corpus passed all 1,408 cases in 332 seconds without failures or skips.
Darwin CI passed all 2,618 native cases without failures or skips.
The strict semantic report passed all 394 required references across the three lanes.
The source and package freeze checks passed.
The Darwin execution lane finished all measurements, but its callback gate was inconclusive.
The speed improvement was 1.992, with a confidence interval from 1.976 to 2.008.
The lower bound must be at least two.
All individual execution cases passed their elapsed-time gates.
The driver stopped before the other seven performance lanes.
Candidate6 remains incomplete evidence.
The optimization worker owns callback profiling and a proposed correction.
The architect reviews the cause, proposed change, and next validation order before implementation.

The architect approved profiling and a bounded callback optimization.
Per-iteration argument storage is the first proposed allocation to examine.
No runtime cause is confirmed before profiling.
The change must preserve handle release points, cancellation charges, early-error cleanup, and nested callback isolation.
Focused checks must pass on both targets before new packages and a new source freeze.
All eight performance lanes will then run serially before final CI.
Successful performance still requires fresh CI, full semantic checks, offline acceptance, and independent completion review.

Profiling measured allocator work in all six callback cases.
The architect approved two separate runtime changes with preservation checks between them.
The first change reuses callback argument capacity within one invocation and clears handles at their original release point.
The second skips allocation scanning only when all immutable storage flags are false.
The worker owns `collections.rs`, `tensor.rs`, and the new public characterization fixtures.
The sixth source freeze ends for these reviewed changes.
The candidate6 records are archived, including successful CI, semantic, offline, and component checks and the inconclusive performance result.
