; Lo native lowering; ABI lo-native-1; LLVM 21
source_filename = "/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo"
target triple = "aarch64-apple-darwin"

%lo.result = type { i32, i32, ptr }

@lo_program_metadata = constant [51930 x i8] c"{\22abi\22:\22lo-native-1\22,\22artifact\22:{\22source_sha256\22:\227bb586f839807ed249b1e54659460af125d674cf5823acd89aefe561daa1f2fb\22,\22source\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22compiler\22:\22lo-native-llvm-v1\22,\22toolchain\22:\22LLVM 21.1.8\22,\22target\22:\22darwin/arm64\22,\22device_backend\22:\22software\22},\22derivatives\22:[],\22flows\22:[{\22identity\22:\222:0\22,\22id\22:0,\22name\22:\22Main\22,\22parameters\22:[],\22output\22:0,\22handler\22:null,\22location\22:0}],\22has_result\22:true,\22locations\22:[{\22id\22:0,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:231,\22line\22:1,\22column\22:232},\22action\22:\22flow\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:1,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:245,\22line\22:1,\22column\22:246},\22action\22:\22body\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:2,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:245,\22line\22:1,\22column\22:246},\22action\22:\22scope_enter\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:3,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:232,\22line\22:1,\22column\22:233},\22end\22:{\22offset\22:245,\22line\22:1,\22column\22:246},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:4,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:239,\22line\22:1,\22column\22:240},\22end\22:{\22offset\22:245,\22line\22:1,\22column\22:246},\22action\22:\22expression_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:5,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:239,\22line\22:1,\22column\22:240},\22end\22:{\22offset\22:245,\22line\22:1,\22column\22:246},\22action\22:\22flow_call\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:6,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:239,\22line\22:1,\22column\22:240},\22end\22:{\22offset\22:245,\22line\22:1,\22column\22:246},\22action\22:\22convert_success\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:7,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:239,\22line\22:1,\22column\22:240},\22end\22:{\22offset\22:245,\22line\22:1,\22column\22:246},\22action\22:\22convert_failure\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:8,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:239,\22line\22:1,\22column\22:240},\22end\22:{\22offset\22:245,\22line\22:1,\22column\22:246},\22action\22:\22charge_value\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:9,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:232,\22line\22:1,\22column\22:233},\22end\22:{\22offset\22:245,\22line\22:1,\22column\22:246},\22action\22:\22cause\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22\5Cu003ctop\5Cu003e\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:10,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:231,\22line\22:1,\22column\22:232},\22action\22:\22body\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:11,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:231,\22line\22:1,\22column\22:232},\22action\22:\22flow_enter\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:12,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:0,\22line\22:1,\22column\22:1},\22end\22:{\22offset\22:231,\22line\22:1,\22column\22:232},\22action\22:\22scope_enter\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:13,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:28,\22line\22:1,\22column\22:29},\22end\22:{\22offset\22:75,\22line\22:1,\22column\22:76},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:14,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22end\22:{\22offset\22:75,\22line\22:1,\22column\22:76},\22action\22:\22expression_step\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:15,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22end\22:{\22offset\22:75,\22line\22:1,\22column\22:76},\22action\22:\22expression_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:16,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:41,\22line\22:1,\22column\22:42},\22end\22:{\22offset\22:62,\22line\22:1,\22column\22:63},\22action\22:\22expression_step\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:17,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:50,\22line\22:1,\22column\22:51},\22end\22:{\22offset\22:53,\22line\22:1,\22column\22:54},\22action\22:\22expression_step\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:18,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:50,\22line\22:1,\22column\22:51},\22end\22:{\22offset\22:53,\22line\22:1,\22column\22:54},\22action\22:\22literal\22,\22type\22:4,\22text\22:\221.0\22,\22float_bits\22:\223ff0000000000000\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:19,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:50,\22line\22:1,\22column\22:51},\22end\22:{\22offset\22:53,\22line\22:1,\22column\22:54},\22action\22:\22charge_value\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:20,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:54,\22line\22:1,\22column\22:55},\22end\22:{\22offset\22:57,\22line\22:1,\22column\22:58},\22action\22:\22expression_step\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:21,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:54,\22line\22:1,\22column\22:55},\22end\22:{\22offset\22:57,\22line\22:1,\22column\22:58},\22action\22:\22literal\22,\22type\22:4,\22text\22:\222.0\22,\22float_bits\22:\224000000000000000\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:22,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:54,\22line\22:1,\22column\22:55},\22end\22:{\22offset\22:57,\22line\22:1,\22column\22:58},\22action\22:\22charge_value\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:23,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:58,\22line\22:1,\22column\22:59},\22end\22:{\22offset\22:61,\22line\22:1,\22column\22:62},\22action\22:\22expression_step\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:24,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:58,\22line\22:1,\22column\22:59},\22end\22:{\22offset\22:61,\22line\22:1,\22column\22:62},\22action\22:\22literal\22,\22type\22:4,\22text\22:\223.0\22,\22float_bits\22:\224008000000000000\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:25,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:58,\22line\22:1,\22column\22:59},\22end\22:{\22offset\22:61,\22line\22:1,\22column\22:62},\22action\22:\22charge_value\22,\22type\22:4,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:26,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:41,\22line\22:1,\22column\22:42},\22end\22:{\22offset\22:62,\22line\22:1,\22column\22:63},\22action\22:\22operation\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22List.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:4,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:4,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:4,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:27,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:41,\22line\22:1,\22column\22:42},\22end\22:{\22offset\22:62,\22line\22:1,\22column\22:63},\22action\22:\22charge_value\22,\22type\22:3,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:28,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:63,\22line\22:1,\22column\22:64},\22end\22:{\22offset\22:74,\22line\22:1,\22column\22:75},\22action\22:\22expression_step\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:29,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:72,\22line\22:1,\22column\22:73},\22end\22:{\22offset\22:73,\22line\22:1,\22column\22:74},\22action\22:\22expression_step\22,\22type\22:6,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:30,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:72,\22line\22:1,\22column\22:73},\22end\22:{\22offset\22:73,\22line\22:1,\22column\22:74},\22action\22:\22literal\22,\22type\22:6,\22text\22:\223\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:31,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:72,\22line\22:1,\22column\22:73},\22end\22:{\22offset\22:73,\22line\22:1,\22column\22:74},\22action\22:\22charge_value\22,\22type\22:6,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:32,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:63,\22line\22:1,\22column\22:64},\22end\22:{\22offset\22:74,\22line\22:1,\22column\22:75},\22action\22:\22operation\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22List.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:6,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:33,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:63,\22line\22:1,\22column\22:64},\22end\22:{\22offset\22:74,\22line\22:1,\22column\22:75},\22action\22:\22charge_value\22,\22type\22:5,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:34,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22end\22:{\22offset\22:75,\22line\22:1,\22column\22:76},\22action\22:\22operation\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22Tensor.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:3,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:5,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:35,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22end\22:{\22offset\22:75,\22line\22:1,\22column\22:76},\22action\22:\22convert_success\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:36,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22end\22:{\22offset\22:75,\22line\22:1,\22column\22:76},\22action\22:\22convert_failure\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:37,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22end\22:{\22offset\22:75,\22line\22:1,\22column\22:76},\22action\22:\22charge_value\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:38,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22end\22:{\22offset\22:75,\22line\22:1,\22column\22:76},\22action\22:\22convert_propagate\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:39,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:30,\22line\22:1,\22column\22:31},\22end\22:{\22offset\22:75,\22line\22:1,\22column\22:76},\22action\22:\22charge_value\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:40,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:76,\22line\22:1,\22column\22:77},\22end\22:{\22offset\22:115,\22line\22:1,\22column\22:116},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:41,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:78,\22line\22:1,\22column\22:79},\22end\22:{\22offset\22:115,\22line\22:1,\22column\22:116},\22action\22:\22expression_step\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:42,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:78,\22line\22:1,\22column\22:79},\22end\22:{\22offset\22:115,\22line\22:1,\22column\22:116},\22action\22:\22expression_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:43,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:88,\22line\22:1,\22column\22:89},\22end\22:{\22offset\22:89,\22line\22:1,\22column\22:90},\22action\22:\22expression_step\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:44,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:88,\22line\22:1,\22column\22:89},\22end\22:{\22offset\22:89,\22line\22:1,\22column\22:90},\22action\22:\22reference\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:45,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:88,\22line\22:1,\22column\22:89},\22end\22:{\22offset\22:89,\22line\22:1,\22column\22:90},\22action\22:\22charge_value\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:46,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:90,\22line\22:1,\22column\22:91},\22end\22:{\22offset\22:114,\22line\22:1,\22column\22:115},\22action\22:\22expression_step\22,\22type\22:7,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:47,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:90,\22line\22:1,\22column\22:91},\22end\22:{\22offset\22:114,\22line\22:1,\22column\22:115},\22action\22:\22expression_step\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:48,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:101,\22line\22:1,\22column\22:102},\22end\22:{\22offset\22:113,\22line\22:1,\22column\22:114},\22action\22:\22expression_step\22,\22type\22:9,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:49,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:101,\22line\22:1,\22column\22:102},\22end\22:{\22offset\22:113,\22line\22:1,\22column\22:114},\22action\22:\22literal\22,\22type\22:9,\22text\22:\22cuda-sim:0\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:50,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:101,\22line\22:1,\22column\22:102},\22end\22:{\22offset\22:113,\22line\22:1,\22column\22:114},\22action\22:\22charge_value\22,\22type\22:9,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:51,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:90,\22line\22:1,\22column\22:91},\22end\22:{\22offset\22:114,\22line\22:1,\22column\22:115},\22action\22:\22operation\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22Device.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:9,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:52,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:90,\22line\22:1,\22column\22:91},\22end\22:{\22offset\22:114,\22line\22:1,\22column\22:115},\22action\22:\22convert_success\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:53,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:90,\22line\22:1,\22column\22:91},\22end\22:{\22offset\22:114,\22line\22:1,\22column\22:115},\22action\22:\22convert_failure\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:54,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:90,\22line\22:1,\22column\22:91},\22end\22:{\22offset\22:114,\22line\22:1,\22column\22:115},\22action\22:\22charge_value\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:55,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:90,\22line\22:1,\22column\22:91},\22end\22:{\22offset\22:114,\22line\22:1,\22column\22:115},\22action\22:\22convert_propagate\22,\22type\22:7,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:56,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:90,\22line\22:1,\22column\22:91},\22end\22:{\22offset\22:114,\22line\22:1,\22column\22:115},\22action\22:\22charge_value\22,\22type\22:7,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:57,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:78,\22line\22:1,\22column\22:79},\22end\22:{\22offset\22:115,\22line\22:1,\22column\22:116},\22action\22:\22operation\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22Tensor.to\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:2,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:7,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:58,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:78,\22line\22:1,\22column\22:79},\22end\22:{\22offset\22:115,\22line\22:1,\22column\22:116},\22action\22:\22convert_success\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:59,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:78,\22line\22:1,\22column\22:79},\22end\22:{\22offset\22:115,\22line\22:1,\22column\22:116},\22action\22:\22convert_failure\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:60,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:78,\22line\22:1,\22column\22:79},\22end\22:{\22offset\22:115,\22line\22:1,\22column\22:116},\22action\22:\22charge_value\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:61,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:78,\22line\22:1,\22column\22:79},\22end\22:{\22offset\22:115,\22line\22:1,\22column\22:116},\22action\22:\22convert_propagate\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:62,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:78,\22line\22:1,\22column\22:79},\22end\22:{\22offset\22:115,\22line\22:1,\22column\22:116},\22action\22:\22charge_value\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:63,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:116,\22line\22:1,\22column\22:117},\22end\22:{\22offset\22:148,\22line\22:1,\22column\22:149},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:64,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:118,\22line\22:1,\22column\22:119},\22end\22:{\22offset\22:148,\22line\22:1,\22column\22:149},\22action\22:\22expression_step\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:65,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:118,\22line\22:1,\22column\22:119},\22end\22:{\22offset\22:148,\22line\22:1,\22column\22:149},\22action\22:\22expression_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:66,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:128,\22line\22:1,\22column\22:129},\22end\22:{\22offset\22:129,\22line\22:1,\22column\22:130},\22action\22:\22expression_step\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:67,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:128,\22line\22:1,\22column\22:129},\22end\22:{\22offset\22:129,\22line\22:1,\22column\22:130},\22action\22:\22reference\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:68,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:128,\22line\22:1,\22column\22:129},\22end\22:{\22offset\22:129,\22line\22:1,\22column\22:130},\22action\22:\22charge_value\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:69,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:130,\22line\22:1,\22column\22:131},\22end\22:{\22offset\22:147,\22line\22:1,\22column\22:148},\22action\22:\22expression_step\22,\22type\22:7,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:70,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:130,\22line\22:1,\22column\22:131},\22end\22:{\22offset\22:147,\22line\22:1,\22column\22:148},\22action\22:\22expression_step\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:71,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:141,\22line\22:1,\22column\22:142},\22end\22:{\22offset\22:146,\22line\22:1,\22column\22:147},\22action\22:\22expression_step\22,\22type\22:9,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:72,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:141,\22line\22:1,\22column\22:142},\22end\22:{\22offset\22:146,\22line\22:1,\22column\22:147},\22action\22:\22literal\22,\22type\22:9,\22text\22:\22cpu\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:73,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:141,\22line\22:1,\22column\22:142},\22end\22:{\22offset\22:146,\22line\22:1,\22column\22:147},\22action\22:\22charge_value\22,\22type\22:9,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:74,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:130,\22line\22:1,\22column\22:131},\22end\22:{\22offset\22:147,\22line\22:1,\22column\22:148},\22action\22:\22operation\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22Device.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:9,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:75,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:130,\22line\22:1,\22column\22:131},\22end\22:{\22offset\22:147,\22line\22:1,\22column\22:148},\22action\22:\22convert_success\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:76,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:130,\22line\22:1,\22column\22:131},\22end\22:{\22offset\22:147,\22line\22:1,\22column\22:148},\22action\22:\22convert_failure\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:77,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:130,\22line\22:1,\22column\22:131},\22end\22:{\22offset\22:147,\22line\22:1,\22column\22:148},\22action\22:\22charge_value\22,\22type\22:8,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:78,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:130,\22line\22:1,\22column\22:131},\22end\22:{\22offset\22:147,\22line\22:1,\22column\22:148},\22action\22:\22convert_propagate\22,\22type\22:7,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:79,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:130,\22line\22:1,\22column\22:131},\22end\22:{\22offset\22:147,\22line\22:1,\22column\22:148},\22action\22:\22charge_value\22,\22type\22:7,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:80,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:118,\22line\22:1,\22column\22:119},\22end\22:{\22offset\22:148,\22line\22:1,\22column\22:149},\22action\22:\22operation\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22Tensor.to\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:2,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:7,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:81,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:118,\22line\22:1,\22column\22:119},\22end\22:{\22offset\22:148,\22line\22:1,\22column\22:149},\22action\22:\22convert_success\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:82,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:118,\22line\22:1,\22column\22:119},\22end\22:{\22offset\22:148,\22line\22:1,\22column\22:149},\22action\22:\22convert_failure\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:83,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:118,\22line\22:1,\22column\22:119},\22end\22:{\22offset\22:148,\22line\22:1,\22column\22:149},\22action\22:\22charge_value\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:84,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:118,\22line\22:1,\22column\22:119},\22end\22:{\22offset\22:148,\22line\22:1,\22column\22:149},\22action\22:\22convert_propagate\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:85,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:118,\22line\22:1,\22column\22:119},\22end\22:{\22offset\22:148,\22line\22:1,\22column\22:149},\22action\22:\22charge_value\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:86,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:149,\22line\22:1,\22column\22:150},\22end\22:{\22offset\22:209,\22line\22:1,\22column\22:210},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:87,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:154,\22line\22:1,\22column\22:155},\22end\22:{\22offset\22:209,\22line\22:1,\22column\22:210},\22action\22:\22expression_step\22,\22type\22:10,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:88,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:169,\22line\22:1,\22column\22:170},\22end\22:{\22offset\22:191,\22line\22:1,\22column\22:192},\22action\22:\22expression_step\22,\22type\22:11,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:89,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:183,\22line\22:1,\22column\22:184},\22end\22:{\22offset\22:190,\22line\22:1,\22column\22:191},\22action\22:\22expression_step\22,\22type\22:9,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:90,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:183,\22line\22:1,\22column\22:184},\22end\22:{\22offset\22:190,\22line\22:1,\22column\22:191},\22action\22:\22literal\22,\22type\22:9,\22text\22:\22later\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:91,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:183,\22line\22:1,\22column\22:184},\22end\22:{\22offset\22:190,\22line\22:1,\22column\22:191},\22action\22:\22charge_value\22,\22type\22:9,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:92,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:169,\22line\22:1,\22column\22:170},\22end\22:{\22offset\22:191,\22line\22:1,\22column\22:192},\22action\22:\22operation\22,\22type\22:11,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22File.Path.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:9,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:93,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:169,\22line\22:1,\22column\22:170},\22end\22:{\22offset\22:191,\22line\22:1,\22column\22:192},\22action\22:\22charge_value\22,\22type\22:11,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:94,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:192,\22line\22:1,\22column\22:193},\22end\22:{\22offset\22:208,\22line\22:1,\22column\22:209},\22action\22:\22expression_step\22,\22type\22:12,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:95,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:202,\22line\22:1,\22column\22:203},\22end\22:{\22offset\22:207,\22line\22:1,\22column\22:208},\22action\22:\22expression_step\22,\22type\22:9,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:96,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:202,\22line\22:1,\22column\22:203},\22end\22:{\22offset\22:207,\22line\22:1,\22column\22:208},\22action\22:\22literal\22,\22type\22:9,\22text\22:\22ran\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:97,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:202,\22line\22:1,\22column\22:203},\22end\22:{\22offset\22:207,\22line\22:1,\22column\22:208},\22action\22:\22charge_value\22,\22type\22:9,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:98,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:192,\22line\22:1,\22column\22:193},\22end\22:{\22offset\22:208,\22line\22:1,\22column\22:209},\22action\22:\22operation\22,\22type\22:12,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22Bytes.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:9,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:99,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:192,\22line\22:1,\22column\22:193},\22end\22:{\22offset\22:208,\22line\22:1,\22column\22:209},\22action\22:\22charge_value\22,\22type\22:12,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:100,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:154,\22line\22:1,\22column\22:155},\22end\22:{\22offset\22:209,\22line\22:1,\22column\22:210},\22action\22:\22operation\22,\22type\22:10,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22File.Write.new\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[{\22kind\22:\22value\22,\22type\22:11,\22flow\22:0},{\22kind\22:\22value\22,\22type\22:12,\22flow\22:0}],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:101,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:154,\22line\22:1,\22column\22:155},\22end\22:{\22offset\22:209,\22line\22:1,\22column\22:210},\22action\22:\22charge_value\22,\22type\22:10,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:102,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:210,\22line\22:1,\22column\22:211},\22end\22:{\22offset\22:221,\22line\22:1,\22column\22:222},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:103,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:210,\22line\22:1,\22column\22:211},\22end\22:{\22offset\22:221,\22line\22:1,\22column\22:222},\22action\22:\22expression_step\22,\22type\22:10,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:104,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:210,\22line\22:1,\22column\22:211},\22end\22:{\22offset\22:221,\22line\22:1,\22column\22:222},\22action\22:\22reference\22,\22type\22:10,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:105,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:210,\22line\22:1,\22column\22:211},\22end\22:{\22offset\22:221,\22line\22:1,\22column\22:222},\22action\22:\22charge_value\22,\22type\22:10,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:106,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:210,\22line\22:1,\22column\22:211},\22end\22:{\22offset\22:221,\22line\22:1,\22column\22:222},\22action\22:\22commit\22,\22type\22:13,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:107,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:222,\22line\22:1,\22column\22:223},\22end\22:{\22offset\22:230,\22line\22:1,\22column\22:231},\22action\22:\22statement_step\22,\22type\22:1,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:108,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:229,\22line\22:1,\22column\22:230},\22end\22:{\22offset\22:230,\22line\22:1,\22column\22:231},\22action\22:\22expression_step\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:109,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:229,\22line\22:1,\22column\22:230},\22end\22:{\22offset\22:230,\22line\22:1,\22column\22:231},\22action\22:\22expression_step\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:110,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:229,\22line\22:1,\22column\22:230},\22end\22:{\22offset\22:230,\22line\22:1,\22column\22:231},\22action\22:\22reference\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:111,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:229,\22line\22:1,\22column\22:230},\22end\22:{\22offset\22:230,\22line\22:1,\22column\22:231},\22action\22:\22charge_value\22,\22type\22:2,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:112,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:229,\22line\22:1,\22column\22:230},\22end\22:{\22offset\22:230,\22line\22:1,\22column\22:231},\22action\22:\22convert_success\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:113,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:229,\22line\22:1,\22column\22:230},\22end\22:{\22offset\22:230,\22line\22:1,\22column\22:231},\22action\22:\22charge_value\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0},{\22id\22:114,\22file\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22start\22:{\22offset\22:222,\22line\22:1,\22column\22:223},\22end\22:{\22offset\22:230,\22line\22:1,\22column\22:231},\22action\22:\22cause\22,\22type\22:0,\22text\22:\22\22,\22float_bits\22:\22\22,\22field\22:\22\22,\22flow\22:0,\22operation\22:\22\22,\22labels\22:[],\22owner\22:\22Main\22,\22arguments\22:[],\22derivative_plan\22:0,\22derivative_node\22:0,\22derivative_frame\22:0}],\22source\22:{\22path\22:\22/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002/1674860807.lo\22,\22sha256\22:\227bb586f839807ed249b1e54659460af125d674cf5823acd89aefe561daa1f2fb\22},\22types\22:[{\22id\22:0,\22name\22:\22Tensor\5Cu003cFP32\5Cu003e!\22,\22kind\22:\22Fallible\22},{\22id\22:1,\22name\22:\22Null\22,\22kind\22:\22Null\22},{\22id\22:2,\22name\22:\22Tensor\5Cu003cFP32\5Cu003e\22,\22kind\22:\22Tensor\5Cu003cFP32\5Cu003e\22},{\22id\22:3,\22name\22:\22List\5Cu003cFloat\5Cu003e\22,\22kind\22:\22List\22},{\22id\22:4,\22name\22:\22Float\22,\22kind\22:\22Float\22},{\22id\22:5,\22name\22:\22List\5Cu003cInt\5Cu003e\22,\22kind\22:\22List\22},{\22id\22:6,\22name\22:\22Int\22,\22kind\22:\22Int\22},{\22id\22:7,\22name\22:\22Device\22,\22kind\22:\22Device\22},{\22id\22:8,\22name\22:\22Device!\22,\22kind\22:\22Fallible\22},{\22id\22:9,\22name\22:\22String\22,\22kind\22:\22String\22},{\22id\22:10,\22name\22:\22File.Write\22,\22kind\22:\22File.Write\22},{\22id\22:11,\22name\22:\22File.Path\22,\22kind\22:\22File.Path\22},{\22id\22:12,\22name\22:\22Bytes\22,\22kind\22:\22Bytes\22},{\22id\22:13,\22name\22:\22File.WriteReceipt\22,\22kind\22:\22File.WriteReceipt\22}]}", align 1
@lo_program_metadata_size = constant i64 51930
@lo_program_flow_count = constant i64 1
@lo_program_flows = constant [1 x ptr] [ptr @lo_flow_0]

declare void @lo_cause(ptr, ptr, i64, i64, ptr)
declare void @lo_charge_value(ptr, ptr, i64, i64, ptr)
declare void @lo_commit(ptr, ptr, i64, i64, ptr)
declare void @lo_convert_failure(ptr, ptr, i64, i64, ptr)
declare void @lo_convert_propagate(ptr, ptr, i64, i64, ptr)
declare void @lo_convert_success(ptr, ptr, i64, i64, ptr)
declare void @lo_flow_enter(ptr, ptr, i64, i64, ptr)
declare void @lo_flow_error(ptr, i64, ptr, i64, i64, ptr)
declare void @lo_invalid_status(ptr, ptr, i64, i64, ptr)
declare void @lo_literal(ptr, ptr, i64, i64, ptr)
declare void @lo_op_Bytes_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_op_Device_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_op_File_2EPath_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_op_File_2EWrite_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_op_List_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_op_Tensor_2Enew(ptr, ptr, i64, i64, ptr)
declare void @lo_op_Tensor_2Eto(ptr, ptr, i64, i64, ptr)
declare void @lo_scope_enter(ptr, ptr, i64, i64, ptr)
declare void @lo_step(ptr, ptr, i64, i64, ptr)
declare void @lo_value_retain(ptr)
declare void @lo_value_release(ptr)
declare void @lo_scope_leave(ptr, ptr, i64)
declare void @lo_flow_leave(ptr)
declare i32 @lo_boolean_value(ptr)

declare void @lo_derivative_leave(ptr)

define internal void @lo_result_copy_value(ptr %out, ptr %result) #0 {
entry:
  %old_pointer = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %old = load ptr, ptr %old_pointer, align 8
  %value_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 2
  %value = load ptr, ptr %value_pointer, align 8
  call void @lo_value_retain(ptr %value)
  call void @lo_value_release(ptr %old)
  %copy = load %lo.result, ptr %result, align 8
  store %lo.result %copy, ptr %out, align 8
  ret void
}
define internal void @lo_result_copy_host(ptr %out, ptr %result) #0 {
entry:
  %old_pointer = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %old = load ptr, ptr %old_pointer, align 8
  call void @lo_value_release(ptr %old)
  %code_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 1
  %code = load i32, ptr %code_pointer, align 4
  %copy = insertvalue %lo.result { i32 2, i32 0, ptr null }, i32 %code, 1
  store %lo.result %copy, ptr %out, align 8
  ret void
}
define internal i1 @lo_result_transfer(ptr %out, ptr %result, ptr %owned) #0 {
entry:
  %status_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 0
  %status = load i32, ptr %status_pointer, align 4
  switch i32 %status, label %unknown [ i32 0, label %payload i32 1, label %payload i32 2, label %host ]
payload:
  %value_pointer = getelementptr %lo.result, ptr %result, i32 0, i32 2
  %value = load ptr, ptr %value_pointer, align 8
  store ptr %value, ptr %owned, align 8
  call void @lo_result_copy_value(ptr %out, ptr %result)
  ret i1 true
host:
  call void @lo_result_copy_host(ptr %out, ptr %result)
  ret i1 true
unknown:
  ret i1 false
}


define void @lo_entry(ptr %context, ptr %arguments, i64 %argc, i64 %callsite, ptr %out) #0 !dbg !6 {
entry:
  %v1 = alloca ptr, align 8
  store ptr null, ptr %v1, align 8
  %v2 = alloca ptr, align 8
  store ptr null, ptr %v2, align 8
  %v3 = alloca ptr, align 8
  store ptr null, ptr %v3, align 8
  %v4 = alloca ptr, align 8
  store ptr null, ptr %v4, align 8
  %v5 = alloca ptr, align 8
  store ptr null, ptr %v5, align 8
  %v6 = alloca ptr, align 8
  store ptr null, ptr %v6, align 8
  %v7 = alloca ptr, align 8
  store ptr null, ptr %v7, align 8
  %v8 = alloca ptr, align 8
  store ptr null, ptr %v8, align 8
  %v9 = alloca ptr, align 8
  store ptr null, ptr %v9, align 8
  %v10 = alloca ptr, align 8
  store ptr null, ptr %v10, align 8
  %v11 = alloca ptr, align 8
  store ptr null, ptr %v11, align 8
  %r1 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r1, align 8
  %r2 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r2, align 8
  %r3 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r3, align 8
  %r4 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r4, align 8
  %r5 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r5, align 8
  %r6 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r6, align 8
  %r7 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r7, align 8
  %r8 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r8, align 8
  %r9 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r9, align 8
  %r10 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r10, align 8
  %args7 = alloca [1 x ptr], align 8
  %args8 = alloca [1 x ptr], align 8
  %args9 = alloca [1 x ptr], align 8
  %args10 = alloca [1 x ptr], align 8
  store %lo.result zeroinitializer, ptr %out, align 8
  br label %b0
b0:
  %x1 = icmp eq i64 %argc, 0, !dbg !8
  br i1 %x1, label %b4, label %b5, !dbg !8
b1:
  %x2 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x2), !dbg !8
  store ptr null, ptr %v1, align 8, !dbg !8
  %x3 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x3), !dbg !8
  store ptr null, ptr %v2, align 8, !dbg !8
  %x4 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x4), !dbg !8
  store ptr null, ptr %v3, align 8, !dbg !8
  %x5 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x5), !dbg !8
  store ptr null, ptr %v4, align 8, !dbg !8
  %x6 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x6), !dbg !8
  store ptr null, ptr %v5, align 8, !dbg !8
  %x7 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x7), !dbg !8
  store ptr null, ptr %v6, align 8, !dbg !8
  %x8 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x8), !dbg !8
  store ptr null, ptr %v7, align 8, !dbg !8
  %x9 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x9), !dbg !8
  store ptr null, ptr %v8, align 8, !dbg !8
  %x10 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x10), !dbg !8
  store ptr null, ptr %v9, align 8, !dbg !8
  %x11 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x11), !dbg !8
  store ptr null, ptr %v10, align 8, !dbg !8
  %x12 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x12), !dbg !8
  store ptr null, ptr %v11, align 8, !dbg !8
  ret void, !dbg !8
b2:
  br label %b1, !dbg !8
b3:
  %x13 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x14 = load ptr, ptr %x13, align 8
  call void @lo_scope_leave(ptr %context, ptr %x14, i64 1), !dbg !8
  %x15 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x15), !dbg !8
  store ptr null, ptr %v1, align 8, !dbg !8
  %x16 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x16), !dbg !8
  store ptr null, ptr %v2, align 8, !dbg !8
  %x17 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x17), !dbg !8
  store ptr null, ptr %v3, align 8, !dbg !8
  %x18 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x18), !dbg !8
  store ptr null, ptr %v4, align 8, !dbg !8
  %x19 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x19), !dbg !8
  store ptr null, ptr %v5, align 8, !dbg !8
  %x20 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x20), !dbg !8
  store ptr null, ptr %v6, align 8, !dbg !8
  %x21 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x21), !dbg !8
  store ptr null, ptr %v7, align 8, !dbg !8
  %x22 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x22), !dbg !8
  store ptr null, ptr %v8, align 8, !dbg !8
  %x23 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x23), !dbg !8
  store ptr null, ptr %v9, align 8, !dbg !8
  %x24 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x24), !dbg !8
  store ptr null, ptr %v10, align 8, !dbg !8
  %x25 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x25), !dbg !8
  store ptr null, ptr %v11, align 8, !dbg !8
  br label %b1, !dbg !8
b4:
  call void @lo_scope_enter(ptr %context, ptr null, i64 0, i64 2, ptr %r2), !dbg !10
  %x26 = getelementptr %lo.result, ptr %r2, i32 0, i32 0
  %x27 = load i32, ptr %x26, align 4, !dbg !10
  switch i32 %x27, label %b5 [ i32 0, label %b6 i32 1, label %b5 i32 2, label %b7 ], !dbg !10
b5:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 1, ptr %r1), !dbg !8
  call void @lo_result_copy_host(ptr %out, ptr %r1), !dbg !8
  br label %b1, !dbg !8
b6:
  %x28 = getelementptr %lo.result, ptr %r2, i32 0, i32 2
  %x29 = load ptr, ptr %x28, align 8
  store ptr %x29, ptr %v2, align 8, !dbg !10
  call void @lo_step(ptr %context, ptr null, i64 0, i64 3, ptr %r3), !dbg !12
  %x30 = getelementptr %lo.result, ptr %r3, i32 0, i32 0
  %x31 = load i32, ptr %x30, align 4, !dbg !12
  switch i32 %x31, label %b14 [ i32 0, label %b10 i32 1, label %b14 i32 2, label %b11 ], !dbg !12
b7:
  %x32 = call i1 @lo_result_transfer(ptr %out, ptr %r2, ptr %v2), !dbg !8
  br i1 %x32, label %b1, label %b5, !dbg !8
b10:
  %x33 = getelementptr %lo.result, ptr %r3, i32 0, i32 2
  %x34 = load ptr, ptr %x33, align 8
  store ptr %x34, ptr %v3, align 8, !dbg !12
  call void @lo_step(ptr %context, ptr null, i64 0, i64 4, ptr %r5), !dbg !14
  %x35 = getelementptr %lo.result, ptr %r5, i32 0, i32 0
  %x36 = load i32, ptr %x35, align 4, !dbg !14
  switch i32 %x36, label %b14 [ i32 0, label %b15 i32 1, label %b14 i32 2, label %b16 ], !dbg !14
b11:
  %x37 = call i1 @lo_result_transfer(ptr %out, ptr %r3, ptr %v3), !dbg !8
  br i1 %x37, label %b3, label %b14, !dbg !8
b14:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 1, ptr %r4), !dbg !8
  call void @lo_result_copy_host(ptr %out, ptr %r4), !dbg !8
  br label %b3, !dbg !8
b15:
  %x38 = getelementptr %lo.result, ptr %r5, i32 0, i32 2
  %x39 = load ptr, ptr %x38, align 8
  store ptr %x39, ptr %v5, align 8, !dbg !14
  call void @lo_flow_0(ptr %context, ptr null, i64 0, i64 5, ptr %r6), !dbg !16
  %x40 = getelementptr %lo.result, ptr %r6, i32 0, i32 0
  %x41 = load i32, ptr %x40, align 4, !dbg !16
  switch i32 %x41, label %b14 [ i32 0, label %b19 i32 1, label %b20 i32 2, label %b22 ], !dbg !16
b16:
  %x42 = call i1 @lo_result_transfer(ptr %out, ptr %r5, ptr %v5), !dbg !8
  br i1 %x42, label %b3, label %b14, !dbg !8
b19:
  %x43 = getelementptr %lo.result, ptr %r6, i32 0, i32 2
  %x44 = load ptr, ptr %x43, align 8
  store ptr %x44, ptr %v6, align 8, !dbg !16
  %x46 = load ptr, ptr %v6, align 8
  %x45 = getelementptr [1 x ptr], ptr %args7, i64 0, i64 0, !dbg !18
  store ptr %x46, ptr %x45, align 8, !dbg !18
  call void @lo_convert_success(ptr %context, ptr %args7, i64 1, i64 6, ptr %r7), !dbg !18
  %x47 = getelementptr %lo.result, ptr %r7, i32 0, i32 0
  %x48 = load i32, ptr %x47, align 4, !dbg !18
  switch i32 %x48, label %b14 [ i32 0, label %b25 i32 1, label %b14 i32 2, label %b26 ], !dbg !18
b20:
  %x49 = getelementptr %lo.result, ptr %r6, i32 0, i32 2
  %x50 = load ptr, ptr %x49, align 8
  store ptr %x50, ptr %v6, align 8, !dbg !16
  %x52 = load ptr, ptr %v6, align 8
  %x51 = getelementptr [1 x ptr], ptr %args8, i64 0, i64 0, !dbg !20
  store ptr %x52, ptr %x51, align 8, !dbg !20
  call void @lo_convert_failure(ptr %context, ptr %args8, i64 1, i64 7, ptr %r8), !dbg !20
  %x53 = getelementptr %lo.result, ptr %r8, i32 0, i32 0
  %x54 = load i32, ptr %x53, align 4, !dbg !20
  switch i32 %x54, label %b14 [ i32 0, label %b29 i32 1, label %b14 i32 2, label %b30 ], !dbg !20
b21:
  %phi9 = phi ptr [ %phi_edge_9_0, %b25 ], [ %phi_edge_9_1, %b29 ], !dbg !16
  call void @lo_value_retain(ptr %phi9), !dbg !16
  store ptr %phi9, ptr %v9, align 8, !dbg !16
  %x56 = load ptr, ptr %v9, align 8
  %x55 = getelementptr [1 x ptr], ptr %args9, i64 0, i64 0, !dbg !22
  store ptr %x56, ptr %x55, align 8, !dbg !22
  call void @lo_charge_value(ptr %context, ptr %args9, i64 1, i64 8, ptr %r9), !dbg !22
  %x57 = getelementptr %lo.result, ptr %r9, i32 0, i32 0
  %x58 = load i32, ptr %x57, align 4, !dbg !22
  switch i32 %x58, label %b14 [ i32 0, label %b33 i32 1, label %b14 i32 2, label %b34 ], !dbg !22
b22:
  %x59 = call i1 @lo_result_transfer(ptr %out, ptr %r6, ptr %v6), !dbg !8
  br i1 %x59, label %b3, label %b14, !dbg !8
b25:
  %x60 = getelementptr %lo.result, ptr %r7, i32 0, i32 2
  %x61 = load ptr, ptr %x60, align 8
  store ptr %x61, ptr %v7, align 8, !dbg !18
  %phi_edge_9_0 = load ptr, ptr %v7, align 8
  br label %b21, !dbg !8
b26:
  %x62 = call i1 @lo_result_transfer(ptr %out, ptr %r7, ptr %v7), !dbg !8
  br i1 %x62, label %b3, label %b14, !dbg !8
b29:
  %x63 = getelementptr %lo.result, ptr %r8, i32 0, i32 2
  %x64 = load ptr, ptr %x63, align 8
  store ptr %x64, ptr %v8, align 8, !dbg !20
  %phi_edge_9_1 = load ptr, ptr %v8, align 8
  br label %b21, !dbg !8
b30:
  %x65 = call i1 @lo_result_transfer(ptr %out, ptr %r8, ptr %v8), !dbg !8
  br i1 %x65, label %b3, label %b14, !dbg !8
b33:
  %x66 = getelementptr %lo.result, ptr %r9, i32 0, i32 2
  %x67 = load ptr, ptr %x66, align 8
  store ptr %x67, ptr %v10, align 8, !dbg !22
  %x69 = load ptr, ptr %v9, align 8
  %x68 = getelementptr [1 x ptr], ptr %args10, i64 0, i64 0, !dbg !24
  store ptr %x69, ptr %x68, align 8, !dbg !24
  call void @lo_cause(ptr %context, ptr %args10, i64 1, i64 9, ptr %r10), !dbg !24
  %x70 = getelementptr %lo.result, ptr %r10, i32 0, i32 0
  %x71 = load i32, ptr %x70, align 4, !dbg !24
  switch i32 %x71, label %b14 [ i32 0, label %b37 i32 1, label %b37 i32 2, label %b37 ], !dbg !24
b34:
  %x72 = call i1 @lo_result_transfer(ptr %out, ptr %r9, ptr %v10), !dbg !8
  br i1 %x72, label %b3, label %b14, !dbg !8
b37:
  %x73 = call i1 @lo_result_transfer(ptr %out, ptr %r10, ptr %v11), !dbg !8
  br i1 %x73, label %b3, label %b14, !dbg !8
}

define void @lo_flow_0(ptr %context, ptr %arguments, i64 %argc, i64 %callsite, ptr %out) #0 !dbg !25 {
entry:
  %v1 = alloca ptr, align 8
  store ptr null, ptr %v1, align 8
  %v2 = alloca ptr, align 8
  store ptr null, ptr %v2, align 8
  %v3 = alloca ptr, align 8
  store ptr null, ptr %v3, align 8
  %v4 = alloca ptr, align 8
  store ptr null, ptr %v4, align 8
  %v5 = alloca ptr, align 8
  store ptr null, ptr %v5, align 8
  %v6 = alloca ptr, align 8
  store ptr null, ptr %v6, align 8
  %v7 = alloca ptr, align 8
  store ptr null, ptr %v7, align 8
  %v8 = alloca ptr, align 8
  store ptr null, ptr %v8, align 8
  %v9 = alloca ptr, align 8
  store ptr null, ptr %v9, align 8
  %v10 = alloca ptr, align 8
  store ptr null, ptr %v10, align 8
  %v11 = alloca ptr, align 8
  store ptr null, ptr %v11, align 8
  %v12 = alloca ptr, align 8
  store ptr null, ptr %v12, align 8
  %v13 = alloca ptr, align 8
  store ptr null, ptr %v13, align 8
  %v14 = alloca ptr, align 8
  store ptr null, ptr %v14, align 8
  %v15 = alloca ptr, align 8
  store ptr null, ptr %v15, align 8
  %v16 = alloca ptr, align 8
  store ptr null, ptr %v16, align 8
  %v17 = alloca ptr, align 8
  store ptr null, ptr %v17, align 8
  %v18 = alloca ptr, align 8
  store ptr null, ptr %v18, align 8
  %v19 = alloca ptr, align 8
  store ptr null, ptr %v19, align 8
  %v20 = alloca ptr, align 8
  store ptr null, ptr %v20, align 8
  %v21 = alloca ptr, align 8
  store ptr null, ptr %v21, align 8
  %v22 = alloca ptr, align 8
  store ptr null, ptr %v22, align 8
  %v23 = alloca ptr, align 8
  store ptr null, ptr %v23, align 8
  %v24 = alloca ptr, align 8
  store ptr null, ptr %v24, align 8
  %v25 = alloca ptr, align 8
  store ptr null, ptr %v25, align 8
  %v26 = alloca ptr, align 8
  store ptr null, ptr %v26, align 8
  %v27 = alloca ptr, align 8
  store ptr null, ptr %v27, align 8
  %v28 = alloca ptr, align 8
  store ptr null, ptr %v28, align 8
  %v29 = alloca ptr, align 8
  store ptr null, ptr %v29, align 8
  %v30 = alloca ptr, align 8
  store ptr null, ptr %v30, align 8
  %v31 = alloca ptr, align 8
  store ptr null, ptr %v31, align 8
  %v32 = alloca ptr, align 8
  store ptr null, ptr %v32, align 8
  %v33 = alloca ptr, align 8
  store ptr null, ptr %v33, align 8
  %v34 = alloca ptr, align 8
  store ptr null, ptr %v34, align 8
  %v35 = alloca ptr, align 8
  store ptr null, ptr %v35, align 8
  %v36 = alloca ptr, align 8
  store ptr null, ptr %v36, align 8
  %v37 = alloca ptr, align 8
  store ptr null, ptr %v37, align 8
  %v38 = alloca ptr, align 8
  store ptr null, ptr %v38, align 8
  %v39 = alloca ptr, align 8
  store ptr null, ptr %v39, align 8
  %v40 = alloca ptr, align 8
  store ptr null, ptr %v40, align 8
  %v41 = alloca ptr, align 8
  store ptr null, ptr %v41, align 8
  %v42 = alloca ptr, align 8
  store ptr null, ptr %v42, align 8
  %v43 = alloca ptr, align 8
  store ptr null, ptr %v43, align 8
  %v44 = alloca ptr, align 8
  store ptr null, ptr %v44, align 8
  %v45 = alloca ptr, align 8
  store ptr null, ptr %v45, align 8
  %v46 = alloca ptr, align 8
  store ptr null, ptr %v46, align 8
  %v47 = alloca ptr, align 8
  store ptr null, ptr %v47, align 8
  %v48 = alloca ptr, align 8
  store ptr null, ptr %v48, align 8
  %v49 = alloca ptr, align 8
  store ptr null, ptr %v49, align 8
  %v50 = alloca ptr, align 8
  store ptr null, ptr %v50, align 8
  %v51 = alloca ptr, align 8
  store ptr null, ptr %v51, align 8
  %v52 = alloca ptr, align 8
  store ptr null, ptr %v52, align 8
  %v53 = alloca ptr, align 8
  store ptr null, ptr %v53, align 8
  %v54 = alloca ptr, align 8
  store ptr null, ptr %v54, align 8
  %v55 = alloca ptr, align 8
  store ptr null, ptr %v55, align 8
  %v56 = alloca ptr, align 8
  store ptr null, ptr %v56, align 8
  %v57 = alloca ptr, align 8
  store ptr null, ptr %v57, align 8
  %v58 = alloca ptr, align 8
  store ptr null, ptr %v58, align 8
  %v59 = alloca ptr, align 8
  store ptr null, ptr %v59, align 8
  %v60 = alloca ptr, align 8
  store ptr null, ptr %v60, align 8
  %v61 = alloca ptr, align 8
  store ptr null, ptr %v61, align 8
  %v62 = alloca ptr, align 8
  store ptr null, ptr %v62, align 8
  %v63 = alloca ptr, align 8
  store ptr null, ptr %v63, align 8
  %v64 = alloca ptr, align 8
  store ptr null, ptr %v64, align 8
  %v65 = alloca ptr, align 8
  store ptr null, ptr %v65, align 8
  %v66 = alloca ptr, align 8
  store ptr null, ptr %v66, align 8
  %v67 = alloca ptr, align 8
  store ptr null, ptr %v67, align 8
  %v68 = alloca ptr, align 8
  store ptr null, ptr %v68, align 8
  %v69 = alloca ptr, align 8
  store ptr null, ptr %v69, align 8
  %v70 = alloca ptr, align 8
  store ptr null, ptr %v70, align 8
  %v71 = alloca ptr, align 8
  store ptr null, ptr %v71, align 8
  %v72 = alloca ptr, align 8
  store ptr null, ptr %v72, align 8
  %v73 = alloca ptr, align 8
  store ptr null, ptr %v73, align 8
  %v74 = alloca ptr, align 8
  store ptr null, ptr %v74, align 8
  %v75 = alloca ptr, align 8
  store ptr null, ptr %v75, align 8
  %v76 = alloca ptr, align 8
  store ptr null, ptr %v76, align 8
  %v77 = alloca ptr, align 8
  store ptr null, ptr %v77, align 8
  %v78 = alloca ptr, align 8
  store ptr null, ptr %v78, align 8
  %v79 = alloca ptr, align 8
  store ptr null, ptr %v79, align 8
  %v80 = alloca ptr, align 8
  store ptr null, ptr %v80, align 8
  %v81 = alloca ptr, align 8
  store ptr null, ptr %v81, align 8
  %v82 = alloca ptr, align 8
  store ptr null, ptr %v82, align 8
  %v83 = alloca ptr, align 8
  store ptr null, ptr %v83, align 8
  %v84 = alloca ptr, align 8
  store ptr null, ptr %v84, align 8
  %v85 = alloca ptr, align 8
  store ptr null, ptr %v85, align 8
  %v86 = alloca ptr, align 8
  store ptr null, ptr %v86, align 8
  %v87 = alloca ptr, align 8
  store ptr null, ptr %v87, align 8
  %v88 = alloca ptr, align 8
  store ptr null, ptr %v88, align 8
  %v89 = alloca ptr, align 8
  store ptr null, ptr %v89, align 8
  %v90 = alloca ptr, align 8
  store ptr null, ptr %v90, align 8
  %v91 = alloca ptr, align 8
  store ptr null, ptr %v91, align 8
  %v92 = alloca ptr, align 8
  store ptr null, ptr %v92, align 8
  %v93 = alloca ptr, align 8
  store ptr null, ptr %v93, align 8
  %v94 = alloca ptr, align 8
  store ptr null, ptr %v94, align 8
  %v95 = alloca ptr, align 8
  store ptr null, ptr %v95, align 8
  %v96 = alloca ptr, align 8
  store ptr null, ptr %v96, align 8
  %v97 = alloca ptr, align 8
  store ptr null, ptr %v97, align 8
  %v98 = alloca ptr, align 8
  store ptr null, ptr %v98, align 8
  %v99 = alloca ptr, align 8
  store ptr null, ptr %v99, align 8
  %v100 = alloca ptr, align 8
  store ptr null, ptr %v100, align 8
  %v101 = alloca ptr, align 8
  store ptr null, ptr %v101, align 8
  %v102 = alloca ptr, align 8
  store ptr null, ptr %v102, align 8
  %v103 = alloca ptr, align 8
  store ptr null, ptr %v103, align 8
  %v104 = alloca ptr, align 8
  store ptr null, ptr %v104, align 8
  %v105 = alloca ptr, align 8
  store ptr null, ptr %v105, align 8
  %v106 = alloca ptr, align 8
  store ptr null, ptr %v106, align 8
  %v107 = alloca ptr, align 8
  store ptr null, ptr %v107, align 8
  %v108 = alloca ptr, align 8
  store ptr null, ptr %v108, align 8
  %v109 = alloca ptr, align 8
  store ptr null, ptr %v109, align 8
  %v110 = alloca ptr, align 8
  store ptr null, ptr %v110, align 8
  %v111 = alloca ptr, align 8
  store ptr null, ptr %v111, align 8
  %v112 = alloca ptr, align 8
  store ptr null, ptr %v112, align 8
  %v113 = alloca ptr, align 8
  store ptr null, ptr %v113, align 8
  %v114 = alloca ptr, align 8
  store ptr null, ptr %v114, align 8
  %r1 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r1, align 8
  %r2 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r2, align 8
  %r3 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r3, align 8
  %r4 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r4, align 8
  %r5 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r5, align 8
  %r6 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r6, align 8
  %r7 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r7, align 8
  %r8 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r8, align 8
  %r9 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r9, align 8
  %r10 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r10, align 8
  %r11 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r11, align 8
  %r12 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r12, align 8
  %r13 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r13, align 8
  %r14 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r14, align 8
  %r15 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r15, align 8
  %r16 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r16, align 8
  %r17 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r17, align 8
  %r18 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r18, align 8
  %r19 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r19, align 8
  %r20 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r20, align 8
  %r21 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r21, align 8
  %r22 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r22, align 8
  %r23 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r23, align 8
  %r24 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r24, align 8
  %r25 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r25, align 8
  %r26 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r26, align 8
  %r27 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r27, align 8
  %r28 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r28, align 8
  %r29 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r29, align 8
  %r30 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r30, align 8
  %r31 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r31, align 8
  %r32 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r32, align 8
  %r33 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r33, align 8
  %r34 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r34, align 8
  %r35 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r35, align 8
  %r36 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r36, align 8
  %r37 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r37, align 8
  %r38 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r38, align 8
  %r39 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r39, align 8
  %r40 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r40, align 8
  %r41 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r41, align 8
  %r42 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r42, align 8
  %r43 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r43, align 8
  %r44 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r44, align 8
  %r45 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r45, align 8
  %r46 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r46, align 8
  %r47 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r47, align 8
  %r48 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r48, align 8
  %r49 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r49, align 8
  %r50 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r50, align 8
  %r51 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r51, align 8
  %r52 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r52, align 8
  %r53 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r53, align 8
  %r54 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r54, align 8
  %r55 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r55, align 8
  %r56 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r56, align 8
  %r57 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r57, align 8
  %r58 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r58, align 8
  %r59 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r59, align 8
  %r60 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r60, align 8
  %r61 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r61, align 8
  %r62 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r62, align 8
  %r63 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r63, align 8
  %r64 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r64, align 8
  %r65 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r65, align 8
  %r66 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r66, align 8
  %r67 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r67, align 8
  %r68 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r68, align 8
  %r69 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r69, align 8
  %r70 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r70, align 8
  %r71 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r71, align 8
  %r72 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r72, align 8
  %r73 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r73, align 8
  %r74 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r74, align 8
  %r75 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r75, align 8
  %r76 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r76, align 8
  %r77 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r77, align 8
  %r78 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r78, align 8
  %r79 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r79, align 8
  %r80 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r80, align 8
  %r81 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r81, align 8
  %r82 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r82, align 8
  %r83 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r83, align 8
  %r84 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r84, align 8
  %r85 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r85, align 8
  %r86 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r86, align 8
  %r87 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r87, align 8
  %r88 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r88, align 8
  %r89 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r89, align 8
  %r90 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r90, align 8
  %r91 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r91, align 8
  %r92 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r92, align 8
  %r93 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r93, align 8
  %r94 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r94, align 8
  %r95 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r95, align 8
  %r96 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r96, align 8
  %r97 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r97, align 8
  %r98 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r98, align 8
  %r99 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r99, align 8
  %r100 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r100, align 8
  %r101 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r101, align 8
  %r102 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r102, align 8
  %r103 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r103, align 8
  %r104 = alloca %lo.result, align 8
  store %lo.result zeroinitializer, ptr %r104, align 8
  %args12 = alloca [1 x ptr], align 8
  %args15 = alloca [1 x ptr], align 8
  %args18 = alloca [1 x ptr], align 8
  %args19 = alloca [3 x ptr], align 8
  %args20 = alloca [1 x ptr], align 8
  %args24 = alloca [1 x ptr], align 8
  %args25 = alloca [1 x ptr], align 8
  %args26 = alloca [1 x ptr], align 8
  %args27 = alloca [2 x ptr], align 8
  %args28 = alloca [1 x ptr], align 8
  %args29 = alloca [1 x ptr], align 8
  %args30 = alloca [1 x ptr], align 8
  %args31 = alloca [1 x ptr], align 8
  %args32 = alloca [1 x ptr], align 8
  %args37 = alloca [1 x ptr], align 8
  %args42 = alloca [1 x ptr], align 8
  %args43 = alloca [1 x ptr], align 8
  %args44 = alloca [1 x ptr], align 8
  %args45 = alloca [1 x ptr], align 8
  %args46 = alloca [1 x ptr], align 8
  %args47 = alloca [1 x ptr], align 8
  %args48 = alloca [1 x ptr], align 8
  %args49 = alloca [2 x ptr], align 8
  %args50 = alloca [1 x ptr], align 8
  %args51 = alloca [1 x ptr], align 8
  %args52 = alloca [1 x ptr], align 8
  %args53 = alloca [1 x ptr], align 8
  %args54 = alloca [1 x ptr], align 8
  %args59 = alloca [1 x ptr], align 8
  %args64 = alloca [1 x ptr], align 8
  %args65 = alloca [1 x ptr], align 8
  %args66 = alloca [1 x ptr], align 8
  %args67 = alloca [1 x ptr], align 8
  %args68 = alloca [1 x ptr], align 8
  %args69 = alloca [1 x ptr], align 8
  %args70 = alloca [1 x ptr], align 8
  %args71 = alloca [2 x ptr], align 8
  %args72 = alloca [1 x ptr], align 8
  %args73 = alloca [1 x ptr], align 8
  %args74 = alloca [1 x ptr], align 8
  %args75 = alloca [1 x ptr], align 8
  %args76 = alloca [1 x ptr], align 8
  %args82 = alloca [1 x ptr], align 8
  %args83 = alloca [1 x ptr], align 8
  %args84 = alloca [1 x ptr], align 8
  %args88 = alloca [1 x ptr], align 8
  %args89 = alloca [1 x ptr], align 8
  %args90 = alloca [1 x ptr], align 8
  %args91 = alloca [2 x ptr], align 8
  %args92 = alloca [1 x ptr], align 8
  %args95 = alloca [1 x ptr], align 8
  %args96 = alloca [1 x ptr], align 8
  %args100 = alloca [1 x ptr], align 8
  %args101 = alloca [1 x ptr], align 8
  %args102 = alloca [1 x ptr], align 8
  %args103 = alloca [1 x ptr], align 8
  %args104 = alloca [1 x ptr], align 8
  store %lo.result zeroinitializer, ptr %out, align 8
  br label %b0
b0:
  %x1 = icmp eq i64 %argc, 0, !dbg !27
  br i1 %x1, label %b4, label %b5, !dbg !27
b1:
  %x2 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x2), !dbg !27
  store ptr null, ptr %v1, align 8, !dbg !27
  %x3 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x3), !dbg !27
  store ptr null, ptr %v2, align 8, !dbg !27
  %x4 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x4), !dbg !27
  store ptr null, ptr %v3, align 8, !dbg !27
  %x5 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x5), !dbg !27
  store ptr null, ptr %v4, align 8, !dbg !27
  %x6 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x6), !dbg !27
  store ptr null, ptr %v5, align 8, !dbg !27
  %x7 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x7), !dbg !27
  store ptr null, ptr %v6, align 8, !dbg !27
  %x8 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x8), !dbg !27
  store ptr null, ptr %v7, align 8, !dbg !27
  %x9 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x9), !dbg !27
  store ptr null, ptr %v8, align 8, !dbg !27
  %x10 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x10), !dbg !27
  store ptr null, ptr %v9, align 8, !dbg !27
  %x11 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x11), !dbg !27
  store ptr null, ptr %v10, align 8, !dbg !27
  %x12 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x12), !dbg !27
  store ptr null, ptr %v11, align 8, !dbg !27
  %x13 = load ptr, ptr %v12, align 8
  call void @lo_value_release(ptr %x13), !dbg !27
  store ptr null, ptr %v12, align 8, !dbg !27
  %x14 = load ptr, ptr %v13, align 8
  call void @lo_value_release(ptr %x14), !dbg !27
  store ptr null, ptr %v13, align 8, !dbg !27
  %x15 = load ptr, ptr %v14, align 8
  call void @lo_value_release(ptr %x15), !dbg !27
  store ptr null, ptr %v14, align 8, !dbg !27
  %x16 = load ptr, ptr %v15, align 8
  call void @lo_value_release(ptr %x16), !dbg !27
  store ptr null, ptr %v15, align 8, !dbg !27
  %x17 = load ptr, ptr %v16, align 8
  call void @lo_value_release(ptr %x17), !dbg !27
  store ptr null, ptr %v16, align 8, !dbg !27
  %x18 = load ptr, ptr %v17, align 8
  call void @lo_value_release(ptr %x18), !dbg !27
  store ptr null, ptr %v17, align 8, !dbg !27
  %x19 = load ptr, ptr %v18, align 8
  call void @lo_value_release(ptr %x19), !dbg !27
  store ptr null, ptr %v18, align 8, !dbg !27
  %x20 = load ptr, ptr %v19, align 8
  call void @lo_value_release(ptr %x20), !dbg !27
  store ptr null, ptr %v19, align 8, !dbg !27
  %x21 = load ptr, ptr %v20, align 8
  call void @lo_value_release(ptr %x21), !dbg !27
  store ptr null, ptr %v20, align 8, !dbg !27
  %x22 = load ptr, ptr %v21, align 8
  call void @lo_value_release(ptr %x22), !dbg !27
  store ptr null, ptr %v21, align 8, !dbg !27
  %x23 = load ptr, ptr %v22, align 8
  call void @lo_value_release(ptr %x23), !dbg !27
  store ptr null, ptr %v22, align 8, !dbg !27
  %x24 = load ptr, ptr %v23, align 8
  call void @lo_value_release(ptr %x24), !dbg !27
  store ptr null, ptr %v23, align 8, !dbg !27
  %x25 = load ptr, ptr %v24, align 8
  call void @lo_value_release(ptr %x25), !dbg !27
  store ptr null, ptr %v24, align 8, !dbg !27
  %x26 = load ptr, ptr %v25, align 8
  call void @lo_value_release(ptr %x26), !dbg !27
  store ptr null, ptr %v25, align 8, !dbg !27
  %x27 = load ptr, ptr %v26, align 8
  call void @lo_value_release(ptr %x27), !dbg !27
  store ptr null, ptr %v26, align 8, !dbg !27
  %x28 = load ptr, ptr %v27, align 8
  call void @lo_value_release(ptr %x28), !dbg !27
  store ptr null, ptr %v27, align 8, !dbg !27
  %x29 = load ptr, ptr %v28, align 8
  call void @lo_value_release(ptr %x29), !dbg !27
  store ptr null, ptr %v28, align 8, !dbg !27
  %x30 = load ptr, ptr %v29, align 8
  call void @lo_value_release(ptr %x30), !dbg !27
  store ptr null, ptr %v29, align 8, !dbg !27
  %x31 = load ptr, ptr %v30, align 8
  call void @lo_value_release(ptr %x31), !dbg !27
  store ptr null, ptr %v30, align 8, !dbg !27
  %x32 = load ptr, ptr %v31, align 8
  call void @lo_value_release(ptr %x32), !dbg !27
  store ptr null, ptr %v31, align 8, !dbg !27
  %x33 = load ptr, ptr %v32, align 8
  call void @lo_value_release(ptr %x33), !dbg !27
  store ptr null, ptr %v32, align 8, !dbg !27
  %x34 = load ptr, ptr %v33, align 8
  call void @lo_value_release(ptr %x34), !dbg !27
  store ptr null, ptr %v33, align 8, !dbg !27
  %x35 = load ptr, ptr %v34, align 8
  call void @lo_value_release(ptr %x35), !dbg !27
  store ptr null, ptr %v34, align 8, !dbg !27
  %x36 = load ptr, ptr %v35, align 8
  call void @lo_value_release(ptr %x36), !dbg !27
  store ptr null, ptr %v35, align 8, !dbg !27
  %x37 = load ptr, ptr %v36, align 8
  call void @lo_value_release(ptr %x37), !dbg !27
  store ptr null, ptr %v36, align 8, !dbg !27
  %x38 = load ptr, ptr %v37, align 8
  call void @lo_value_release(ptr %x38), !dbg !27
  store ptr null, ptr %v37, align 8, !dbg !27
  %x39 = load ptr, ptr %v38, align 8
  call void @lo_value_release(ptr %x39), !dbg !27
  store ptr null, ptr %v38, align 8, !dbg !27
  %x40 = load ptr, ptr %v39, align 8
  call void @lo_value_release(ptr %x40), !dbg !27
  store ptr null, ptr %v39, align 8, !dbg !27
  %x41 = load ptr, ptr %v40, align 8
  call void @lo_value_release(ptr %x41), !dbg !27
  store ptr null, ptr %v40, align 8, !dbg !27
  %x42 = load ptr, ptr %v41, align 8
  call void @lo_value_release(ptr %x42), !dbg !27
  store ptr null, ptr %v41, align 8, !dbg !27
  %x43 = load ptr, ptr %v42, align 8
  call void @lo_value_release(ptr %x43), !dbg !27
  store ptr null, ptr %v42, align 8, !dbg !27
  %x44 = load ptr, ptr %v43, align 8
  call void @lo_value_release(ptr %x44), !dbg !27
  store ptr null, ptr %v43, align 8, !dbg !27
  %x45 = load ptr, ptr %v44, align 8
  call void @lo_value_release(ptr %x45), !dbg !27
  store ptr null, ptr %v44, align 8, !dbg !27
  %x46 = load ptr, ptr %v45, align 8
  call void @lo_value_release(ptr %x46), !dbg !27
  store ptr null, ptr %v45, align 8, !dbg !27
  %x47 = load ptr, ptr %v46, align 8
  call void @lo_value_release(ptr %x47), !dbg !27
  store ptr null, ptr %v46, align 8, !dbg !27
  %x48 = load ptr, ptr %v47, align 8
  call void @lo_value_release(ptr %x48), !dbg !27
  store ptr null, ptr %v47, align 8, !dbg !27
  %x49 = load ptr, ptr %v48, align 8
  call void @lo_value_release(ptr %x49), !dbg !27
  store ptr null, ptr %v48, align 8, !dbg !27
  %x50 = load ptr, ptr %v49, align 8
  call void @lo_value_release(ptr %x50), !dbg !27
  store ptr null, ptr %v49, align 8, !dbg !27
  %x51 = load ptr, ptr %v50, align 8
  call void @lo_value_release(ptr %x51), !dbg !27
  store ptr null, ptr %v50, align 8, !dbg !27
  %x52 = load ptr, ptr %v51, align 8
  call void @lo_value_release(ptr %x52), !dbg !27
  store ptr null, ptr %v51, align 8, !dbg !27
  %x53 = load ptr, ptr %v52, align 8
  call void @lo_value_release(ptr %x53), !dbg !27
  store ptr null, ptr %v52, align 8, !dbg !27
  %x54 = load ptr, ptr %v53, align 8
  call void @lo_value_release(ptr %x54), !dbg !27
  store ptr null, ptr %v53, align 8, !dbg !27
  %x55 = load ptr, ptr %v54, align 8
  call void @lo_value_release(ptr %x55), !dbg !27
  store ptr null, ptr %v54, align 8, !dbg !27
  %x56 = load ptr, ptr %v55, align 8
  call void @lo_value_release(ptr %x56), !dbg !27
  store ptr null, ptr %v55, align 8, !dbg !27
  %x57 = load ptr, ptr %v56, align 8
  call void @lo_value_release(ptr %x57), !dbg !27
  store ptr null, ptr %v56, align 8, !dbg !27
  %x58 = load ptr, ptr %v57, align 8
  call void @lo_value_release(ptr %x58), !dbg !27
  store ptr null, ptr %v57, align 8, !dbg !27
  %x59 = load ptr, ptr %v58, align 8
  call void @lo_value_release(ptr %x59), !dbg !27
  store ptr null, ptr %v58, align 8, !dbg !27
  %x60 = load ptr, ptr %v59, align 8
  call void @lo_value_release(ptr %x60), !dbg !27
  store ptr null, ptr %v59, align 8, !dbg !27
  %x61 = load ptr, ptr %v60, align 8
  call void @lo_value_release(ptr %x61), !dbg !27
  store ptr null, ptr %v60, align 8, !dbg !27
  %x62 = load ptr, ptr %v61, align 8
  call void @lo_value_release(ptr %x62), !dbg !27
  store ptr null, ptr %v61, align 8, !dbg !27
  %x63 = load ptr, ptr %v62, align 8
  call void @lo_value_release(ptr %x63), !dbg !27
  store ptr null, ptr %v62, align 8, !dbg !27
  %x64 = load ptr, ptr %v63, align 8
  call void @lo_value_release(ptr %x64), !dbg !27
  store ptr null, ptr %v63, align 8, !dbg !27
  %x65 = load ptr, ptr %v64, align 8
  call void @lo_value_release(ptr %x65), !dbg !27
  store ptr null, ptr %v64, align 8, !dbg !27
  %x66 = load ptr, ptr %v65, align 8
  call void @lo_value_release(ptr %x66), !dbg !27
  store ptr null, ptr %v65, align 8, !dbg !27
  %x67 = load ptr, ptr %v66, align 8
  call void @lo_value_release(ptr %x67), !dbg !27
  store ptr null, ptr %v66, align 8, !dbg !27
  %x68 = load ptr, ptr %v67, align 8
  call void @lo_value_release(ptr %x68), !dbg !27
  store ptr null, ptr %v67, align 8, !dbg !27
  %x69 = load ptr, ptr %v68, align 8
  call void @lo_value_release(ptr %x69), !dbg !27
  store ptr null, ptr %v68, align 8, !dbg !27
  %x70 = load ptr, ptr %v69, align 8
  call void @lo_value_release(ptr %x70), !dbg !27
  store ptr null, ptr %v69, align 8, !dbg !27
  %x71 = load ptr, ptr %v70, align 8
  call void @lo_value_release(ptr %x71), !dbg !27
  store ptr null, ptr %v70, align 8, !dbg !27
  %x72 = load ptr, ptr %v71, align 8
  call void @lo_value_release(ptr %x72), !dbg !27
  store ptr null, ptr %v71, align 8, !dbg !27
  %x73 = load ptr, ptr %v72, align 8
  call void @lo_value_release(ptr %x73), !dbg !27
  store ptr null, ptr %v72, align 8, !dbg !27
  %x74 = load ptr, ptr %v73, align 8
  call void @lo_value_release(ptr %x74), !dbg !27
  store ptr null, ptr %v73, align 8, !dbg !27
  %x75 = load ptr, ptr %v74, align 8
  call void @lo_value_release(ptr %x75), !dbg !27
  store ptr null, ptr %v74, align 8, !dbg !27
  %x76 = load ptr, ptr %v75, align 8
  call void @lo_value_release(ptr %x76), !dbg !27
  store ptr null, ptr %v75, align 8, !dbg !27
  %x77 = load ptr, ptr %v76, align 8
  call void @lo_value_release(ptr %x77), !dbg !27
  store ptr null, ptr %v76, align 8, !dbg !27
  %x78 = load ptr, ptr %v77, align 8
  call void @lo_value_release(ptr %x78), !dbg !27
  store ptr null, ptr %v77, align 8, !dbg !27
  %x79 = load ptr, ptr %v78, align 8
  call void @lo_value_release(ptr %x79), !dbg !27
  store ptr null, ptr %v78, align 8, !dbg !27
  %x80 = load ptr, ptr %v79, align 8
  call void @lo_value_release(ptr %x80), !dbg !27
  store ptr null, ptr %v79, align 8, !dbg !27
  %x81 = load ptr, ptr %v80, align 8
  call void @lo_value_release(ptr %x81), !dbg !27
  store ptr null, ptr %v80, align 8, !dbg !27
  %x82 = load ptr, ptr %v81, align 8
  call void @lo_value_release(ptr %x82), !dbg !27
  store ptr null, ptr %v81, align 8, !dbg !27
  %x83 = load ptr, ptr %v82, align 8
  call void @lo_value_release(ptr %x83), !dbg !27
  store ptr null, ptr %v82, align 8, !dbg !27
  %x84 = load ptr, ptr %v83, align 8
  call void @lo_value_release(ptr %x84), !dbg !27
  store ptr null, ptr %v83, align 8, !dbg !27
  %x85 = load ptr, ptr %v84, align 8
  call void @lo_value_release(ptr %x85), !dbg !27
  store ptr null, ptr %v84, align 8, !dbg !27
  %x86 = load ptr, ptr %v85, align 8
  call void @lo_value_release(ptr %x86), !dbg !27
  store ptr null, ptr %v85, align 8, !dbg !27
  %x87 = load ptr, ptr %v86, align 8
  call void @lo_value_release(ptr %x87), !dbg !27
  store ptr null, ptr %v86, align 8, !dbg !27
  %x88 = load ptr, ptr %v87, align 8
  call void @lo_value_release(ptr %x88), !dbg !27
  store ptr null, ptr %v87, align 8, !dbg !27
  %x89 = load ptr, ptr %v88, align 8
  call void @lo_value_release(ptr %x89), !dbg !27
  store ptr null, ptr %v88, align 8, !dbg !27
  %x90 = load ptr, ptr %v89, align 8
  call void @lo_value_release(ptr %x90), !dbg !27
  store ptr null, ptr %v89, align 8, !dbg !27
  %x91 = load ptr, ptr %v90, align 8
  call void @lo_value_release(ptr %x91), !dbg !27
  store ptr null, ptr %v90, align 8, !dbg !27
  %x92 = load ptr, ptr %v91, align 8
  call void @lo_value_release(ptr %x92), !dbg !27
  store ptr null, ptr %v91, align 8, !dbg !27
  %x93 = load ptr, ptr %v92, align 8
  call void @lo_value_release(ptr %x93), !dbg !27
  store ptr null, ptr %v92, align 8, !dbg !27
  %x94 = load ptr, ptr %v93, align 8
  call void @lo_value_release(ptr %x94), !dbg !27
  store ptr null, ptr %v93, align 8, !dbg !27
  %x95 = load ptr, ptr %v94, align 8
  call void @lo_value_release(ptr %x95), !dbg !27
  store ptr null, ptr %v94, align 8, !dbg !27
  %x96 = load ptr, ptr %v95, align 8
  call void @lo_value_release(ptr %x96), !dbg !27
  store ptr null, ptr %v95, align 8, !dbg !27
  %x97 = load ptr, ptr %v96, align 8
  call void @lo_value_release(ptr %x97), !dbg !27
  store ptr null, ptr %v96, align 8, !dbg !27
  %x98 = load ptr, ptr %v97, align 8
  call void @lo_value_release(ptr %x98), !dbg !27
  store ptr null, ptr %v97, align 8, !dbg !27
  %x99 = load ptr, ptr %v98, align 8
  call void @lo_value_release(ptr %x99), !dbg !27
  store ptr null, ptr %v98, align 8, !dbg !27
  %x100 = load ptr, ptr %v99, align 8
  call void @lo_value_release(ptr %x100), !dbg !27
  store ptr null, ptr %v99, align 8, !dbg !27
  %x101 = load ptr, ptr %v100, align 8
  call void @lo_value_release(ptr %x101), !dbg !27
  store ptr null, ptr %v100, align 8, !dbg !27
  %x102 = load ptr, ptr %v101, align 8
  call void @lo_value_release(ptr %x102), !dbg !27
  store ptr null, ptr %v101, align 8, !dbg !27
  %x103 = load ptr, ptr %v102, align 8
  call void @lo_value_release(ptr %x103), !dbg !27
  store ptr null, ptr %v102, align 8, !dbg !27
  %x104 = load ptr, ptr %v103, align 8
  call void @lo_value_release(ptr %x104), !dbg !27
  store ptr null, ptr %v103, align 8, !dbg !27
  %x105 = load ptr, ptr %v104, align 8
  call void @lo_value_release(ptr %x105), !dbg !27
  store ptr null, ptr %v104, align 8, !dbg !27
  %x106 = load ptr, ptr %v105, align 8
  call void @lo_value_release(ptr %x106), !dbg !27
  store ptr null, ptr %v105, align 8, !dbg !27
  %x107 = load ptr, ptr %v106, align 8
  call void @lo_value_release(ptr %x107), !dbg !27
  store ptr null, ptr %v106, align 8, !dbg !27
  %x108 = load ptr, ptr %v107, align 8
  call void @lo_value_release(ptr %x108), !dbg !27
  store ptr null, ptr %v107, align 8, !dbg !27
  %x109 = load ptr, ptr %v108, align 8
  call void @lo_value_release(ptr %x109), !dbg !27
  store ptr null, ptr %v108, align 8, !dbg !27
  %x110 = load ptr, ptr %v109, align 8
  call void @lo_value_release(ptr %x110), !dbg !27
  store ptr null, ptr %v109, align 8, !dbg !27
  %x111 = load ptr, ptr %v110, align 8
  call void @lo_value_release(ptr %x111), !dbg !27
  store ptr null, ptr %v110, align 8, !dbg !27
  %x112 = load ptr, ptr %v111, align 8
  call void @lo_value_release(ptr %x112), !dbg !27
  store ptr null, ptr %v111, align 8, !dbg !27
  %x113 = load ptr, ptr %v112, align 8
  call void @lo_value_release(ptr %x113), !dbg !27
  store ptr null, ptr %v112, align 8, !dbg !27
  %x114 = load ptr, ptr %v113, align 8
  call void @lo_value_release(ptr %x114), !dbg !27
  store ptr null, ptr %v113, align 8, !dbg !27
  %x115 = load ptr, ptr %v114, align 8
  call void @lo_value_release(ptr %x115), !dbg !27
  store ptr null, ptr %v114, align 8, !dbg !27
  ret void, !dbg !27
b2:
  call void @lo_flow_leave(ptr %context), !dbg !27
  br label %b1, !dbg !27
b3:
  %x116 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x117 = load ptr, ptr %x116, align 8
  call void @lo_scope_leave(ptr %context, ptr %x117, i64 10), !dbg !27
  %x118 = load ptr, ptr %v1, align 8
  call void @lo_value_release(ptr %x118), !dbg !27
  store ptr null, ptr %v1, align 8, !dbg !27
  %x119 = load ptr, ptr %v2, align 8
  call void @lo_value_release(ptr %x119), !dbg !27
  store ptr null, ptr %v2, align 8, !dbg !27
  %x120 = load ptr, ptr %v3, align 8
  call void @lo_value_release(ptr %x120), !dbg !27
  store ptr null, ptr %v3, align 8, !dbg !27
  %x121 = load ptr, ptr %v4, align 8
  call void @lo_value_release(ptr %x121), !dbg !27
  store ptr null, ptr %v4, align 8, !dbg !27
  %x122 = load ptr, ptr %v5, align 8
  call void @lo_value_release(ptr %x122), !dbg !27
  store ptr null, ptr %v5, align 8, !dbg !27
  %x123 = load ptr, ptr %v6, align 8
  call void @lo_value_release(ptr %x123), !dbg !27
  store ptr null, ptr %v6, align 8, !dbg !27
  %x124 = load ptr, ptr %v7, align 8
  call void @lo_value_release(ptr %x124), !dbg !27
  store ptr null, ptr %v7, align 8, !dbg !27
  %x125 = load ptr, ptr %v8, align 8
  call void @lo_value_release(ptr %x125), !dbg !27
  store ptr null, ptr %v8, align 8, !dbg !27
  %x126 = load ptr, ptr %v9, align 8
  call void @lo_value_release(ptr %x126), !dbg !27
  store ptr null, ptr %v9, align 8, !dbg !27
  %x127 = load ptr, ptr %v10, align 8
  call void @lo_value_release(ptr %x127), !dbg !27
  store ptr null, ptr %v10, align 8, !dbg !27
  %x128 = load ptr, ptr %v11, align 8
  call void @lo_value_release(ptr %x128), !dbg !27
  store ptr null, ptr %v11, align 8, !dbg !27
  %x129 = load ptr, ptr %v12, align 8
  call void @lo_value_release(ptr %x129), !dbg !27
  store ptr null, ptr %v12, align 8, !dbg !27
  %x130 = load ptr, ptr %v13, align 8
  call void @lo_value_release(ptr %x130), !dbg !27
  store ptr null, ptr %v13, align 8, !dbg !27
  %x131 = load ptr, ptr %v14, align 8
  call void @lo_value_release(ptr %x131), !dbg !27
  store ptr null, ptr %v14, align 8, !dbg !27
  %x132 = load ptr, ptr %v15, align 8
  call void @lo_value_release(ptr %x132), !dbg !27
  store ptr null, ptr %v15, align 8, !dbg !27
  %x133 = load ptr, ptr %v16, align 8
  call void @lo_value_release(ptr %x133), !dbg !27
  store ptr null, ptr %v16, align 8, !dbg !27
  %x134 = load ptr, ptr %v17, align 8
  call void @lo_value_release(ptr %x134), !dbg !27
  store ptr null, ptr %v17, align 8, !dbg !27
  %x135 = load ptr, ptr %v18, align 8
  call void @lo_value_release(ptr %x135), !dbg !27
  store ptr null, ptr %v18, align 8, !dbg !27
  %x136 = load ptr, ptr %v19, align 8
  call void @lo_value_release(ptr %x136), !dbg !27
  store ptr null, ptr %v19, align 8, !dbg !27
  %x137 = load ptr, ptr %v20, align 8
  call void @lo_value_release(ptr %x137), !dbg !27
  store ptr null, ptr %v20, align 8, !dbg !27
  %x138 = load ptr, ptr %v21, align 8
  call void @lo_value_release(ptr %x138), !dbg !27
  store ptr null, ptr %v21, align 8, !dbg !27
  %x139 = load ptr, ptr %v22, align 8
  call void @lo_value_release(ptr %x139), !dbg !27
  store ptr null, ptr %v22, align 8, !dbg !27
  %x140 = load ptr, ptr %v23, align 8
  call void @lo_value_release(ptr %x140), !dbg !27
  store ptr null, ptr %v23, align 8, !dbg !27
  %x141 = load ptr, ptr %v24, align 8
  call void @lo_value_release(ptr %x141), !dbg !27
  store ptr null, ptr %v24, align 8, !dbg !27
  %x142 = load ptr, ptr %v25, align 8
  call void @lo_value_release(ptr %x142), !dbg !27
  store ptr null, ptr %v25, align 8, !dbg !27
  %x143 = load ptr, ptr %v26, align 8
  call void @lo_value_release(ptr %x143), !dbg !27
  store ptr null, ptr %v26, align 8, !dbg !27
  %x144 = load ptr, ptr %v27, align 8
  call void @lo_value_release(ptr %x144), !dbg !27
  store ptr null, ptr %v27, align 8, !dbg !27
  %x145 = load ptr, ptr %v28, align 8
  call void @lo_value_release(ptr %x145), !dbg !27
  store ptr null, ptr %v28, align 8, !dbg !27
  %x146 = load ptr, ptr %v29, align 8
  call void @lo_value_release(ptr %x146), !dbg !27
  store ptr null, ptr %v29, align 8, !dbg !27
  %x147 = load ptr, ptr %v30, align 8
  call void @lo_value_release(ptr %x147), !dbg !27
  store ptr null, ptr %v30, align 8, !dbg !27
  %x148 = load ptr, ptr %v31, align 8
  call void @lo_value_release(ptr %x148), !dbg !27
  store ptr null, ptr %v31, align 8, !dbg !27
  %x149 = load ptr, ptr %v32, align 8
  call void @lo_value_release(ptr %x149), !dbg !27
  store ptr null, ptr %v32, align 8, !dbg !27
  %x150 = load ptr, ptr %v33, align 8
  call void @lo_value_release(ptr %x150), !dbg !27
  store ptr null, ptr %v33, align 8, !dbg !27
  %x151 = load ptr, ptr %v34, align 8
  call void @lo_value_release(ptr %x151), !dbg !27
  store ptr null, ptr %v34, align 8, !dbg !27
  %x152 = load ptr, ptr %v35, align 8
  call void @lo_value_release(ptr %x152), !dbg !27
  store ptr null, ptr %v35, align 8, !dbg !27
  %x153 = load ptr, ptr %v36, align 8
  call void @lo_value_release(ptr %x153), !dbg !27
  store ptr null, ptr %v36, align 8, !dbg !27
  %x154 = load ptr, ptr %v37, align 8
  call void @lo_value_release(ptr %x154), !dbg !27
  store ptr null, ptr %v37, align 8, !dbg !27
  %x155 = load ptr, ptr %v38, align 8
  call void @lo_value_release(ptr %x155), !dbg !27
  store ptr null, ptr %v38, align 8, !dbg !27
  %x156 = load ptr, ptr %v39, align 8
  call void @lo_value_release(ptr %x156), !dbg !27
  store ptr null, ptr %v39, align 8, !dbg !27
  %x157 = load ptr, ptr %v40, align 8
  call void @lo_value_release(ptr %x157), !dbg !27
  store ptr null, ptr %v40, align 8, !dbg !27
  %x158 = load ptr, ptr %v41, align 8
  call void @lo_value_release(ptr %x158), !dbg !27
  store ptr null, ptr %v41, align 8, !dbg !27
  %x159 = load ptr, ptr %v42, align 8
  call void @lo_value_release(ptr %x159), !dbg !27
  store ptr null, ptr %v42, align 8, !dbg !27
  %x160 = load ptr, ptr %v43, align 8
  call void @lo_value_release(ptr %x160), !dbg !27
  store ptr null, ptr %v43, align 8, !dbg !27
  %x161 = load ptr, ptr %v44, align 8
  call void @lo_value_release(ptr %x161), !dbg !27
  store ptr null, ptr %v44, align 8, !dbg !27
  %x162 = load ptr, ptr %v45, align 8
  call void @lo_value_release(ptr %x162), !dbg !27
  store ptr null, ptr %v45, align 8, !dbg !27
  %x163 = load ptr, ptr %v46, align 8
  call void @lo_value_release(ptr %x163), !dbg !27
  store ptr null, ptr %v46, align 8, !dbg !27
  %x164 = load ptr, ptr %v47, align 8
  call void @lo_value_release(ptr %x164), !dbg !27
  store ptr null, ptr %v47, align 8, !dbg !27
  %x165 = load ptr, ptr %v48, align 8
  call void @lo_value_release(ptr %x165), !dbg !27
  store ptr null, ptr %v48, align 8, !dbg !27
  %x166 = load ptr, ptr %v49, align 8
  call void @lo_value_release(ptr %x166), !dbg !27
  store ptr null, ptr %v49, align 8, !dbg !27
  %x167 = load ptr, ptr %v50, align 8
  call void @lo_value_release(ptr %x167), !dbg !27
  store ptr null, ptr %v50, align 8, !dbg !27
  %x168 = load ptr, ptr %v51, align 8
  call void @lo_value_release(ptr %x168), !dbg !27
  store ptr null, ptr %v51, align 8, !dbg !27
  %x169 = load ptr, ptr %v52, align 8
  call void @lo_value_release(ptr %x169), !dbg !27
  store ptr null, ptr %v52, align 8, !dbg !27
  %x170 = load ptr, ptr %v53, align 8
  call void @lo_value_release(ptr %x170), !dbg !27
  store ptr null, ptr %v53, align 8, !dbg !27
  %x171 = load ptr, ptr %v54, align 8
  call void @lo_value_release(ptr %x171), !dbg !27
  store ptr null, ptr %v54, align 8, !dbg !27
  %x172 = load ptr, ptr %v55, align 8
  call void @lo_value_release(ptr %x172), !dbg !27
  store ptr null, ptr %v55, align 8, !dbg !27
  %x173 = load ptr, ptr %v56, align 8
  call void @lo_value_release(ptr %x173), !dbg !27
  store ptr null, ptr %v56, align 8, !dbg !27
  %x174 = load ptr, ptr %v57, align 8
  call void @lo_value_release(ptr %x174), !dbg !27
  store ptr null, ptr %v57, align 8, !dbg !27
  %x175 = load ptr, ptr %v58, align 8
  call void @lo_value_release(ptr %x175), !dbg !27
  store ptr null, ptr %v58, align 8, !dbg !27
  %x176 = load ptr, ptr %v59, align 8
  call void @lo_value_release(ptr %x176), !dbg !27
  store ptr null, ptr %v59, align 8, !dbg !27
  %x177 = load ptr, ptr %v60, align 8
  call void @lo_value_release(ptr %x177), !dbg !27
  store ptr null, ptr %v60, align 8, !dbg !27
  %x178 = load ptr, ptr %v61, align 8
  call void @lo_value_release(ptr %x178), !dbg !27
  store ptr null, ptr %v61, align 8, !dbg !27
  %x179 = load ptr, ptr %v62, align 8
  call void @lo_value_release(ptr %x179), !dbg !27
  store ptr null, ptr %v62, align 8, !dbg !27
  %x180 = load ptr, ptr %v63, align 8
  call void @lo_value_release(ptr %x180), !dbg !27
  store ptr null, ptr %v63, align 8, !dbg !27
  %x181 = load ptr, ptr %v64, align 8
  call void @lo_value_release(ptr %x181), !dbg !27
  store ptr null, ptr %v64, align 8, !dbg !27
  %x182 = load ptr, ptr %v65, align 8
  call void @lo_value_release(ptr %x182), !dbg !27
  store ptr null, ptr %v65, align 8, !dbg !27
  %x183 = load ptr, ptr %v66, align 8
  call void @lo_value_release(ptr %x183), !dbg !27
  store ptr null, ptr %v66, align 8, !dbg !27
  %x184 = load ptr, ptr %v67, align 8
  call void @lo_value_release(ptr %x184), !dbg !27
  store ptr null, ptr %v67, align 8, !dbg !27
  %x185 = load ptr, ptr %v68, align 8
  call void @lo_value_release(ptr %x185), !dbg !27
  store ptr null, ptr %v68, align 8, !dbg !27
  %x186 = load ptr, ptr %v69, align 8
  call void @lo_value_release(ptr %x186), !dbg !27
  store ptr null, ptr %v69, align 8, !dbg !27
  %x187 = load ptr, ptr %v70, align 8
  call void @lo_value_release(ptr %x187), !dbg !27
  store ptr null, ptr %v70, align 8, !dbg !27
  %x188 = load ptr, ptr %v71, align 8
  call void @lo_value_release(ptr %x188), !dbg !27
  store ptr null, ptr %v71, align 8, !dbg !27
  %x189 = load ptr, ptr %v72, align 8
  call void @lo_value_release(ptr %x189), !dbg !27
  store ptr null, ptr %v72, align 8, !dbg !27
  %x190 = load ptr, ptr %v73, align 8
  call void @lo_value_release(ptr %x190), !dbg !27
  store ptr null, ptr %v73, align 8, !dbg !27
  %x191 = load ptr, ptr %v74, align 8
  call void @lo_value_release(ptr %x191), !dbg !27
  store ptr null, ptr %v74, align 8, !dbg !27
  %x192 = load ptr, ptr %v75, align 8
  call void @lo_value_release(ptr %x192), !dbg !27
  store ptr null, ptr %v75, align 8, !dbg !27
  %x193 = load ptr, ptr %v76, align 8
  call void @lo_value_release(ptr %x193), !dbg !27
  store ptr null, ptr %v76, align 8, !dbg !27
  %x194 = load ptr, ptr %v77, align 8
  call void @lo_value_release(ptr %x194), !dbg !27
  store ptr null, ptr %v77, align 8, !dbg !27
  %x195 = load ptr, ptr %v78, align 8
  call void @lo_value_release(ptr %x195), !dbg !27
  store ptr null, ptr %v78, align 8, !dbg !27
  %x196 = load ptr, ptr %v79, align 8
  call void @lo_value_release(ptr %x196), !dbg !27
  store ptr null, ptr %v79, align 8, !dbg !27
  %x197 = load ptr, ptr %v80, align 8
  call void @lo_value_release(ptr %x197), !dbg !27
  store ptr null, ptr %v80, align 8, !dbg !27
  %x198 = load ptr, ptr %v81, align 8
  call void @lo_value_release(ptr %x198), !dbg !27
  store ptr null, ptr %v81, align 8, !dbg !27
  %x199 = load ptr, ptr %v82, align 8
  call void @lo_value_release(ptr %x199), !dbg !27
  store ptr null, ptr %v82, align 8, !dbg !27
  %x200 = load ptr, ptr %v83, align 8
  call void @lo_value_release(ptr %x200), !dbg !27
  store ptr null, ptr %v83, align 8, !dbg !27
  %x201 = load ptr, ptr %v84, align 8
  call void @lo_value_release(ptr %x201), !dbg !27
  store ptr null, ptr %v84, align 8, !dbg !27
  %x202 = load ptr, ptr %v85, align 8
  call void @lo_value_release(ptr %x202), !dbg !27
  store ptr null, ptr %v85, align 8, !dbg !27
  %x203 = load ptr, ptr %v86, align 8
  call void @lo_value_release(ptr %x203), !dbg !27
  store ptr null, ptr %v86, align 8, !dbg !27
  %x204 = load ptr, ptr %v87, align 8
  call void @lo_value_release(ptr %x204), !dbg !27
  store ptr null, ptr %v87, align 8, !dbg !27
  %x205 = load ptr, ptr %v88, align 8
  call void @lo_value_release(ptr %x205), !dbg !27
  store ptr null, ptr %v88, align 8, !dbg !27
  %x206 = load ptr, ptr %v89, align 8
  call void @lo_value_release(ptr %x206), !dbg !27
  store ptr null, ptr %v89, align 8, !dbg !27
  %x207 = load ptr, ptr %v90, align 8
  call void @lo_value_release(ptr %x207), !dbg !27
  store ptr null, ptr %v90, align 8, !dbg !27
  %x208 = load ptr, ptr %v91, align 8
  call void @lo_value_release(ptr %x208), !dbg !27
  store ptr null, ptr %v91, align 8, !dbg !27
  %x209 = load ptr, ptr %v92, align 8
  call void @lo_value_release(ptr %x209), !dbg !27
  store ptr null, ptr %v92, align 8, !dbg !27
  %x210 = load ptr, ptr %v93, align 8
  call void @lo_value_release(ptr %x210), !dbg !27
  store ptr null, ptr %v93, align 8, !dbg !27
  %x211 = load ptr, ptr %v94, align 8
  call void @lo_value_release(ptr %x211), !dbg !27
  store ptr null, ptr %v94, align 8, !dbg !27
  %x212 = load ptr, ptr %v95, align 8
  call void @lo_value_release(ptr %x212), !dbg !27
  store ptr null, ptr %v95, align 8, !dbg !27
  %x213 = load ptr, ptr %v96, align 8
  call void @lo_value_release(ptr %x213), !dbg !27
  store ptr null, ptr %v96, align 8, !dbg !27
  %x214 = load ptr, ptr %v97, align 8
  call void @lo_value_release(ptr %x214), !dbg !27
  store ptr null, ptr %v97, align 8, !dbg !27
  %x215 = load ptr, ptr %v98, align 8
  call void @lo_value_release(ptr %x215), !dbg !27
  store ptr null, ptr %v98, align 8, !dbg !27
  %x216 = load ptr, ptr %v99, align 8
  call void @lo_value_release(ptr %x216), !dbg !27
  store ptr null, ptr %v99, align 8, !dbg !27
  %x217 = load ptr, ptr %v100, align 8
  call void @lo_value_release(ptr %x217), !dbg !27
  store ptr null, ptr %v100, align 8, !dbg !27
  %x218 = load ptr, ptr %v101, align 8
  call void @lo_value_release(ptr %x218), !dbg !27
  store ptr null, ptr %v101, align 8, !dbg !27
  %x219 = load ptr, ptr %v102, align 8
  call void @lo_value_release(ptr %x219), !dbg !27
  store ptr null, ptr %v102, align 8, !dbg !27
  %x220 = load ptr, ptr %v103, align 8
  call void @lo_value_release(ptr %x220), !dbg !27
  store ptr null, ptr %v103, align 8, !dbg !27
  %x221 = load ptr, ptr %v104, align 8
  call void @lo_value_release(ptr %x221), !dbg !27
  store ptr null, ptr %v104, align 8, !dbg !27
  %x222 = load ptr, ptr %v105, align 8
  call void @lo_value_release(ptr %x222), !dbg !27
  store ptr null, ptr %v105, align 8, !dbg !27
  %x223 = load ptr, ptr %v106, align 8
  call void @lo_value_release(ptr %x223), !dbg !27
  store ptr null, ptr %v106, align 8, !dbg !27
  %x224 = load ptr, ptr %v107, align 8
  call void @lo_value_release(ptr %x224), !dbg !27
  store ptr null, ptr %v107, align 8, !dbg !27
  %x225 = load ptr, ptr %v108, align 8
  call void @lo_value_release(ptr %x225), !dbg !27
  store ptr null, ptr %v108, align 8, !dbg !27
  %x226 = load ptr, ptr %v109, align 8
  call void @lo_value_release(ptr %x226), !dbg !27
  store ptr null, ptr %v109, align 8, !dbg !27
  %x227 = load ptr, ptr %v110, align 8
  call void @lo_value_release(ptr %x227), !dbg !27
  store ptr null, ptr %v110, align 8, !dbg !27
  %x228 = load ptr, ptr %v111, align 8
  call void @lo_value_release(ptr %x228), !dbg !27
  store ptr null, ptr %v111, align 8, !dbg !27
  %x229 = load ptr, ptr %v112, align 8
  call void @lo_value_release(ptr %x229), !dbg !27
  store ptr null, ptr %v112, align 8, !dbg !27
  %x230 = load ptr, ptr %v113, align 8
  call void @lo_value_release(ptr %x230), !dbg !27
  store ptr null, ptr %v113, align 8, !dbg !27
  %x231 = load ptr, ptr %v114, align 8
  call void @lo_value_release(ptr %x231), !dbg !27
  store ptr null, ptr %v114, align 8, !dbg !27
  %x232 = getelementptr %lo.result, ptr %out, i32 0, i32 0
  %x233 = load i32, ptr %x232, align 4, !dbg !27
  switch i32 %x233, label %b14 [ i32 0, label %b2 i32 1, label %b417 i32 2, label %b2 ], !dbg !27
b4:
  call void @lo_flow_enter(ptr %context, ptr null, i64 0, i64 %callsite, ptr %r2), !dbg !29
  %x234 = getelementptr %lo.result, ptr %r2, i32 0, i32 0
  %x235 = load i32, ptr %x234, align 4, !dbg !29
  switch i32 %x235, label %b5 [ i32 0, label %b6 i32 1, label %b5 i32 2, label %b7 ], !dbg !29
b5:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 10, ptr %r1), !dbg !27
  call void @lo_result_copy_host(ptr %out, ptr %r1), !dbg !27
  br label %b1, !dbg !27
b6:
  %x236 = getelementptr %lo.result, ptr %r2, i32 0, i32 2
  %x237 = load ptr, ptr %x236, align 8
  store ptr %x237, ptr %v2, align 8, !dbg !29
  call void @lo_scope_enter(ptr %context, ptr null, i64 0, i64 12, ptr %r3), !dbg !31
  %x238 = getelementptr %lo.result, ptr %r3, i32 0, i32 0
  %x239 = load i32, ptr %x238, align 4, !dbg !31
  switch i32 %x239, label %b14 [ i32 0, label %b10 i32 1, label %b14 i32 2, label %b11 ], !dbg !31
b7:
  %x240 = call i1 @lo_result_transfer(ptr %out, ptr %r2, ptr %v2), !dbg !27
  br i1 %x240, label %b1, label %b5, !dbg !27
b10:
  %x241 = getelementptr %lo.result, ptr %r3, i32 0, i32 2
  %x242 = load ptr, ptr %x241, align 8
  store ptr %x242, ptr %v3, align 8, !dbg !31
  call void @lo_step(ptr %context, ptr null, i64 0, i64 13, ptr %r5), !dbg !33
  %x243 = getelementptr %lo.result, ptr %r5, i32 0, i32 0
  %x244 = load i32, ptr %x243, align 4, !dbg !33
  switch i32 %x244, label %b19 [ i32 0, label %b15 i32 1, label %b19 i32 2, label %b16 ], !dbg !33
b11:
  %x245 = call i1 @lo_result_transfer(ptr %out, ptr %r3, ptr %v3), !dbg !27
  br i1 %x245, label %b2, label %b14, !dbg !27
b14:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 10, ptr %r4), !dbg !27
  call void @lo_result_copy_host(ptr %out, ptr %r4), !dbg !27
  br label %b2, !dbg !27
b15:
  %x246 = getelementptr %lo.result, ptr %r5, i32 0, i32 2
  %x247 = load ptr, ptr %x246, align 8
  store ptr %x247, ptr %v5, align 8, !dbg !33
  call void @lo_step(ptr %context, ptr null, i64 0, i64 14, ptr %r7), !dbg !35
  %x248 = getelementptr %lo.result, ptr %r7, i32 0, i32 0
  %x249 = load i32, ptr %x248, align 4, !dbg !35
  switch i32 %x249, label %b19 [ i32 0, label %b20 i32 1, label %b19 i32 2, label %b21 ], !dbg !35
b16:
  %x250 = call i1 @lo_result_transfer(ptr %out, ptr %r5, ptr %v5), !dbg !27
  br i1 %x250, label %b3, label %b19, !dbg !27
b19:
  call void @lo_invalid_status(ptr %context, ptr null, i64 0, i64 10, ptr %r6), !dbg !27
  call void @lo_result_copy_host(ptr %out, ptr %r6), !dbg !27
  br label %b3, !dbg !27
b20:
  %x251 = getelementptr %lo.result, ptr %r7, i32 0, i32 2
  %x252 = load ptr, ptr %x251, align 8
  store ptr %x252, ptr %v7, align 8, !dbg !35
  call void @lo_step(ptr %context, ptr null, i64 0, i64 15, ptr %r8), !dbg !37
  %x253 = getelementptr %lo.result, ptr %r8, i32 0, i32 0
  %x254 = load i32, ptr %x253, align 4, !dbg !37
  switch i32 %x254, label %b19 [ i32 0, label %b24 i32 1, label %b19 i32 2, label %b25 ], !dbg !37
b21:
  %x255 = call i1 @lo_result_transfer(ptr %out, ptr %r7, ptr %v7), !dbg !27
  br i1 %x255, label %b3, label %b19, !dbg !27
b24:
  %x256 = getelementptr %lo.result, ptr %r8, i32 0, i32 2
  %x257 = load ptr, ptr %x256, align 8
  store ptr %x257, ptr %v8, align 8, !dbg !37
  call void @lo_step(ptr %context, ptr null, i64 0, i64 16, ptr %r9), !dbg !39
  %x258 = getelementptr %lo.result, ptr %r9, i32 0, i32 0
  %x259 = load i32, ptr %x258, align 4, !dbg !39
  switch i32 %x259, label %b19 [ i32 0, label %b28 i32 1, label %b19 i32 2, label %b29 ], !dbg !39
b25:
  %x260 = call i1 @lo_result_transfer(ptr %out, ptr %r8, ptr %v8), !dbg !27
  br i1 %x260, label %b3, label %b19, !dbg !27
b28:
  %x261 = getelementptr %lo.result, ptr %r9, i32 0, i32 2
  %x262 = load ptr, ptr %x261, align 8
  store ptr %x262, ptr %v9, align 8, !dbg !39
  call void @lo_step(ptr %context, ptr null, i64 0, i64 17, ptr %r10), !dbg !41
  %x263 = getelementptr %lo.result, ptr %r10, i32 0, i32 0
  %x264 = load i32, ptr %x263, align 4, !dbg !41
  switch i32 %x264, label %b19 [ i32 0, label %b32 i32 1, label %b19 i32 2, label %b33 ], !dbg !41
b29:
  %x265 = call i1 @lo_result_transfer(ptr %out, ptr %r9, ptr %v9), !dbg !27
  br i1 %x265, label %b3, label %b19, !dbg !27
b32:
  %x266 = getelementptr %lo.result, ptr %r10, i32 0, i32 2
  %x267 = load ptr, ptr %x266, align 8
  store ptr %x267, ptr %v10, align 8, !dbg !41
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 18, ptr %r11), !dbg !43
  %x268 = getelementptr %lo.result, ptr %r11, i32 0, i32 0
  %x269 = load i32, ptr %x268, align 4, !dbg !43
  switch i32 %x269, label %b19 [ i32 0, label %b36 i32 1, label %b19 i32 2, label %b37 ], !dbg !43
b33:
  %x270 = call i1 @lo_result_transfer(ptr %out, ptr %r10, ptr %v10), !dbg !27
  br i1 %x270, label %b3, label %b19, !dbg !27
b36:
  %x271 = getelementptr %lo.result, ptr %r11, i32 0, i32 2
  %x272 = load ptr, ptr %x271, align 8
  store ptr %x272, ptr %v11, align 8, !dbg !43
  %x274 = load ptr, ptr %v11, align 8
  %x273 = getelementptr [1 x ptr], ptr %args12, i64 0, i64 0, !dbg !45
  store ptr %x274, ptr %x273, align 8, !dbg !45
  call void @lo_charge_value(ptr %context, ptr %args12, i64 1, i64 19, ptr %r12), !dbg !45
  %x275 = getelementptr %lo.result, ptr %r12, i32 0, i32 0
  %x276 = load i32, ptr %x275, align 4, !dbg !45
  switch i32 %x276, label %b19 [ i32 0, label %b40 i32 1, label %b19 i32 2, label %b41 ], !dbg !45
b37:
  %x277 = call i1 @lo_result_transfer(ptr %out, ptr %r11, ptr %v11), !dbg !27
  br i1 %x277, label %b3, label %b19, !dbg !27
b40:
  %x278 = getelementptr %lo.result, ptr %r12, i32 0, i32 2
  %x279 = load ptr, ptr %x278, align 8
  store ptr %x279, ptr %v12, align 8, !dbg !45
  call void @lo_step(ptr %context, ptr null, i64 0, i64 20, ptr %r13), !dbg !47
  %x280 = getelementptr %lo.result, ptr %r13, i32 0, i32 0
  %x281 = load i32, ptr %x280, align 4, !dbg !47
  switch i32 %x281, label %b19 [ i32 0, label %b44 i32 1, label %b19 i32 2, label %b45 ], !dbg !47
b41:
  %x282 = call i1 @lo_result_transfer(ptr %out, ptr %r12, ptr %v12), !dbg !27
  br i1 %x282, label %b3, label %b19, !dbg !27
b44:
  %x283 = getelementptr %lo.result, ptr %r13, i32 0, i32 2
  %x284 = load ptr, ptr %x283, align 8
  store ptr %x284, ptr %v13, align 8, !dbg !47
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 21, ptr %r14), !dbg !49
  %x285 = getelementptr %lo.result, ptr %r14, i32 0, i32 0
  %x286 = load i32, ptr %x285, align 4, !dbg !49
  switch i32 %x286, label %b19 [ i32 0, label %b48 i32 1, label %b19 i32 2, label %b49 ], !dbg !49
b45:
  %x287 = call i1 @lo_result_transfer(ptr %out, ptr %r13, ptr %v13), !dbg !27
  br i1 %x287, label %b3, label %b19, !dbg !27
b48:
  %x288 = getelementptr %lo.result, ptr %r14, i32 0, i32 2
  %x289 = load ptr, ptr %x288, align 8
  store ptr %x289, ptr %v14, align 8, !dbg !49
  %x291 = load ptr, ptr %v14, align 8
  %x290 = getelementptr [1 x ptr], ptr %args15, i64 0, i64 0, !dbg !51
  store ptr %x291, ptr %x290, align 8, !dbg !51
  call void @lo_charge_value(ptr %context, ptr %args15, i64 1, i64 22, ptr %r15), !dbg !51
  %x292 = getelementptr %lo.result, ptr %r15, i32 0, i32 0
  %x293 = load i32, ptr %x292, align 4, !dbg !51
  switch i32 %x293, label %b19 [ i32 0, label %b52 i32 1, label %b19 i32 2, label %b53 ], !dbg !51
b49:
  %x294 = call i1 @lo_result_transfer(ptr %out, ptr %r14, ptr %v14), !dbg !27
  br i1 %x294, label %b3, label %b19, !dbg !27
b52:
  %x295 = getelementptr %lo.result, ptr %r15, i32 0, i32 2
  %x296 = load ptr, ptr %x295, align 8
  store ptr %x296, ptr %v15, align 8, !dbg !51
  call void @lo_step(ptr %context, ptr null, i64 0, i64 23, ptr %r16), !dbg !53
  %x297 = getelementptr %lo.result, ptr %r16, i32 0, i32 0
  %x298 = load i32, ptr %x297, align 4, !dbg !53
  switch i32 %x298, label %b19 [ i32 0, label %b56 i32 1, label %b19 i32 2, label %b57 ], !dbg !53
b53:
  %x299 = call i1 @lo_result_transfer(ptr %out, ptr %r15, ptr %v15), !dbg !27
  br i1 %x299, label %b3, label %b19, !dbg !27
b56:
  %x300 = getelementptr %lo.result, ptr %r16, i32 0, i32 2
  %x301 = load ptr, ptr %x300, align 8
  store ptr %x301, ptr %v16, align 8, !dbg !53
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 24, ptr %r17), !dbg !55
  %x302 = getelementptr %lo.result, ptr %r17, i32 0, i32 0
  %x303 = load i32, ptr %x302, align 4, !dbg !55
  switch i32 %x303, label %b19 [ i32 0, label %b60 i32 1, label %b19 i32 2, label %b61 ], !dbg !55
b57:
  %x304 = call i1 @lo_result_transfer(ptr %out, ptr %r16, ptr %v16), !dbg !27
  br i1 %x304, label %b3, label %b19, !dbg !27
b60:
  %x305 = getelementptr %lo.result, ptr %r17, i32 0, i32 2
  %x306 = load ptr, ptr %x305, align 8
  store ptr %x306, ptr %v17, align 8, !dbg !55
  %x308 = load ptr, ptr %v17, align 8
  %x307 = getelementptr [1 x ptr], ptr %args18, i64 0, i64 0, !dbg !57
  store ptr %x308, ptr %x307, align 8, !dbg !57
  call void @lo_charge_value(ptr %context, ptr %args18, i64 1, i64 25, ptr %r18), !dbg !57
  %x309 = getelementptr %lo.result, ptr %r18, i32 0, i32 0
  %x310 = load i32, ptr %x309, align 4, !dbg !57
  switch i32 %x310, label %b19 [ i32 0, label %b64 i32 1, label %b19 i32 2, label %b65 ], !dbg !57
b61:
  %x311 = call i1 @lo_result_transfer(ptr %out, ptr %r17, ptr %v17), !dbg !27
  br i1 %x311, label %b3, label %b19, !dbg !27
b64:
  %x312 = getelementptr %lo.result, ptr %r18, i32 0, i32 2
  %x313 = load ptr, ptr %x312, align 8
  store ptr %x313, ptr %v18, align 8, !dbg !57
  %x315 = load ptr, ptr %v11, align 8
  %x314 = getelementptr [3 x ptr], ptr %args19, i64 0, i64 0, !dbg !59
  store ptr %x315, ptr %x314, align 8, !dbg !59
  %x317 = load ptr, ptr %v14, align 8
  %x316 = getelementptr [3 x ptr], ptr %args19, i64 0, i64 1, !dbg !59
  store ptr %x317, ptr %x316, align 8, !dbg !59
  %x319 = load ptr, ptr %v17, align 8
  %x318 = getelementptr [3 x ptr], ptr %args19, i64 0, i64 2, !dbg !59
  store ptr %x319, ptr %x318, align 8, !dbg !59
  call void @lo_op_List_2Enew(ptr %context, ptr %args19, i64 3, i64 26, ptr %r19), !dbg !59
  %x320 = getelementptr %lo.result, ptr %r19, i32 0, i32 0
  %x321 = load i32, ptr %x320, align 4, !dbg !59
  switch i32 %x321, label %b19 [ i32 0, label %b68 i32 1, label %b19 i32 2, label %b69 ], !dbg !59
b65:
  %x322 = call i1 @lo_result_transfer(ptr %out, ptr %r18, ptr %v18), !dbg !27
  br i1 %x322, label %b3, label %b19, !dbg !27
b68:
  %x323 = getelementptr %lo.result, ptr %r19, i32 0, i32 2
  %x324 = load ptr, ptr %x323, align 8
  store ptr %x324, ptr %v19, align 8, !dbg !59
  %x326 = load ptr, ptr %v19, align 8
  %x325 = getelementptr [1 x ptr], ptr %args20, i64 0, i64 0, !dbg !61
  store ptr %x326, ptr %x325, align 8, !dbg !61
  call void @lo_charge_value(ptr %context, ptr %args20, i64 1, i64 27, ptr %r20), !dbg !61
  %x327 = getelementptr %lo.result, ptr %r20, i32 0, i32 0
  %x328 = load i32, ptr %x327, align 4, !dbg !61
  switch i32 %x328, label %b19 [ i32 0, label %b72 i32 1, label %b19 i32 2, label %b73 ], !dbg !61
b69:
  %x329 = call i1 @lo_result_transfer(ptr %out, ptr %r19, ptr %v19), !dbg !27
  br i1 %x329, label %b3, label %b19, !dbg !27
b72:
  %x330 = getelementptr %lo.result, ptr %r20, i32 0, i32 2
  %x331 = load ptr, ptr %x330, align 8
  store ptr %x331, ptr %v20, align 8, !dbg !61
  call void @lo_step(ptr %context, ptr null, i64 0, i64 28, ptr %r21), !dbg !63
  %x332 = getelementptr %lo.result, ptr %r21, i32 0, i32 0
  %x333 = load i32, ptr %x332, align 4, !dbg !63
  switch i32 %x333, label %b19 [ i32 0, label %b76 i32 1, label %b19 i32 2, label %b77 ], !dbg !63
b73:
  %x334 = call i1 @lo_result_transfer(ptr %out, ptr %r20, ptr %v20), !dbg !27
  br i1 %x334, label %b3, label %b19, !dbg !27
b76:
  %x335 = getelementptr %lo.result, ptr %r21, i32 0, i32 2
  %x336 = load ptr, ptr %x335, align 8
  store ptr %x336, ptr %v21, align 8, !dbg !63
  call void @lo_step(ptr %context, ptr null, i64 0, i64 29, ptr %r22), !dbg !65
  %x337 = getelementptr %lo.result, ptr %r22, i32 0, i32 0
  %x338 = load i32, ptr %x337, align 4, !dbg !65
  switch i32 %x338, label %b19 [ i32 0, label %b80 i32 1, label %b19 i32 2, label %b81 ], !dbg !65
b77:
  %x339 = call i1 @lo_result_transfer(ptr %out, ptr %r21, ptr %v21), !dbg !27
  br i1 %x339, label %b3, label %b19, !dbg !27
b80:
  %x340 = getelementptr %lo.result, ptr %r22, i32 0, i32 2
  %x341 = load ptr, ptr %x340, align 8
  store ptr %x341, ptr %v22, align 8, !dbg !65
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 30, ptr %r23), !dbg !67
  %x342 = getelementptr %lo.result, ptr %r23, i32 0, i32 0
  %x343 = load i32, ptr %x342, align 4, !dbg !67
  switch i32 %x343, label %b19 [ i32 0, label %b84 i32 1, label %b19 i32 2, label %b85 ], !dbg !67
b81:
  %x344 = call i1 @lo_result_transfer(ptr %out, ptr %r22, ptr %v22), !dbg !27
  br i1 %x344, label %b3, label %b19, !dbg !27
b84:
  %x345 = getelementptr %lo.result, ptr %r23, i32 0, i32 2
  %x346 = load ptr, ptr %x345, align 8
  store ptr %x346, ptr %v23, align 8, !dbg !67
  %x348 = load ptr, ptr %v23, align 8
  %x347 = getelementptr [1 x ptr], ptr %args24, i64 0, i64 0, !dbg !69
  store ptr %x348, ptr %x347, align 8, !dbg !69
  call void @lo_charge_value(ptr %context, ptr %args24, i64 1, i64 31, ptr %r24), !dbg !69
  %x349 = getelementptr %lo.result, ptr %r24, i32 0, i32 0
  %x350 = load i32, ptr %x349, align 4, !dbg !69
  switch i32 %x350, label %b19 [ i32 0, label %b88 i32 1, label %b19 i32 2, label %b89 ], !dbg !69
b85:
  %x351 = call i1 @lo_result_transfer(ptr %out, ptr %r23, ptr %v23), !dbg !27
  br i1 %x351, label %b3, label %b19, !dbg !27
b88:
  %x352 = getelementptr %lo.result, ptr %r24, i32 0, i32 2
  %x353 = load ptr, ptr %x352, align 8
  store ptr %x353, ptr %v24, align 8, !dbg !69
  %x355 = load ptr, ptr %v23, align 8
  %x354 = getelementptr [1 x ptr], ptr %args25, i64 0, i64 0, !dbg !71
  store ptr %x355, ptr %x354, align 8, !dbg !71
  call void @lo_op_List_2Enew(ptr %context, ptr %args25, i64 1, i64 32, ptr %r25), !dbg !71
  %x356 = getelementptr %lo.result, ptr %r25, i32 0, i32 0
  %x357 = load i32, ptr %x356, align 4, !dbg !71
  switch i32 %x357, label %b19 [ i32 0, label %b92 i32 1, label %b19 i32 2, label %b93 ], !dbg !71
b89:
  %x358 = call i1 @lo_result_transfer(ptr %out, ptr %r24, ptr %v24), !dbg !27
  br i1 %x358, label %b3, label %b19, !dbg !27
b92:
  %x359 = getelementptr %lo.result, ptr %r25, i32 0, i32 2
  %x360 = load ptr, ptr %x359, align 8
  store ptr %x360, ptr %v25, align 8, !dbg !71
  %x362 = load ptr, ptr %v25, align 8
  %x361 = getelementptr [1 x ptr], ptr %args26, i64 0, i64 0, !dbg !73
  store ptr %x362, ptr %x361, align 8, !dbg !73
  call void @lo_charge_value(ptr %context, ptr %args26, i64 1, i64 33, ptr %r26), !dbg !73
  %x363 = getelementptr %lo.result, ptr %r26, i32 0, i32 0
  %x364 = load i32, ptr %x363, align 4, !dbg !73
  switch i32 %x364, label %b19 [ i32 0, label %b96 i32 1, label %b19 i32 2, label %b97 ], !dbg !73
b93:
  %x365 = call i1 @lo_result_transfer(ptr %out, ptr %r25, ptr %v25), !dbg !27
  br i1 %x365, label %b3, label %b19, !dbg !27
b96:
  %x366 = getelementptr %lo.result, ptr %r26, i32 0, i32 2
  %x367 = load ptr, ptr %x366, align 8
  store ptr %x367, ptr %v26, align 8, !dbg !73
  %x369 = load ptr, ptr %v19, align 8
  %x368 = getelementptr [2 x ptr], ptr %args27, i64 0, i64 0, !dbg !75
  store ptr %x369, ptr %x368, align 8, !dbg !75
  %x371 = load ptr, ptr %v25, align 8
  %x370 = getelementptr [2 x ptr], ptr %args27, i64 0, i64 1, !dbg !75
  store ptr %x371, ptr %x370, align 8, !dbg !75
  call void @lo_op_Tensor_2Enew(ptr %context, ptr %args27, i64 2, i64 34, ptr %r27), !dbg !75
  %x372 = getelementptr %lo.result, ptr %r27, i32 0, i32 0
  %x373 = load i32, ptr %x372, align 4, !dbg !75
  switch i32 %x373, label %b19 [ i32 0, label %b100 i32 1, label %b101 i32 2, label %b103 ], !dbg !75
b97:
  %x374 = call i1 @lo_result_transfer(ptr %out, ptr %r26, ptr %v26), !dbg !27
  br i1 %x374, label %b3, label %b19, !dbg !27
b100:
  %x375 = getelementptr %lo.result, ptr %r27, i32 0, i32 2
  %x376 = load ptr, ptr %x375, align 8
  store ptr %x376, ptr %v27, align 8, !dbg !75
  %x378 = load ptr, ptr %v27, align 8
  %x377 = getelementptr [1 x ptr], ptr %args28, i64 0, i64 0, !dbg !77
  store ptr %x378, ptr %x377, align 8, !dbg !77
  call void @lo_convert_success(ptr %context, ptr %args28, i64 1, i64 35, ptr %r28), !dbg !77
  %x379 = getelementptr %lo.result, ptr %r28, i32 0, i32 0
  %x380 = load i32, ptr %x379, align 4, !dbg !77
  switch i32 %x380, label %b19 [ i32 0, label %b106 i32 1, label %b19 i32 2, label %b107 ], !dbg !77
b101:
  %x381 = getelementptr %lo.result, ptr %r27, i32 0, i32 2
  %x382 = load ptr, ptr %x381, align 8
  store ptr %x382, ptr %v27, align 8, !dbg !75
  %x384 = load ptr, ptr %v27, align 8
  %x383 = getelementptr [1 x ptr], ptr %args29, i64 0, i64 0, !dbg !79
  store ptr %x384, ptr %x383, align 8, !dbg !79
  call void @lo_convert_failure(ptr %context, ptr %args29, i64 1, i64 36, ptr %r29), !dbg !79
  %x385 = getelementptr %lo.result, ptr %r29, i32 0, i32 0
  %x386 = load i32, ptr %x385, align 4, !dbg !79
  switch i32 %x386, label %b19 [ i32 0, label %b110 i32 1, label %b19 i32 2, label %b111 ], !dbg !79
b102:
  %phi30 = phi ptr [ %phi_edge_30_0, %b106 ], [ %phi_edge_30_1, %b110 ], !dbg !75
  call void @lo_value_retain(ptr %phi30), !dbg !75
  store ptr %phi30, ptr %v30, align 8, !dbg !75
  %x388 = load ptr, ptr %v30, align 8
  %x387 = getelementptr [1 x ptr], ptr %args30, i64 0, i64 0, !dbg !81
  store ptr %x388, ptr %x387, align 8, !dbg !81
  call void @lo_charge_value(ptr %context, ptr %args30, i64 1, i64 37, ptr %r30), !dbg !81
  %x389 = getelementptr %lo.result, ptr %r30, i32 0, i32 0
  %x390 = load i32, ptr %x389, align 4, !dbg !81
  switch i32 %x390, label %b19 [ i32 0, label %b114 i32 1, label %b19 i32 2, label %b115 ], !dbg !81
b103:
  %x391 = call i1 @lo_result_transfer(ptr %out, ptr %r27, ptr %v27), !dbg !27
  br i1 %x391, label %b3, label %b19, !dbg !27
b106:
  %x392 = getelementptr %lo.result, ptr %r28, i32 0, i32 2
  %x393 = load ptr, ptr %x392, align 8
  store ptr %x393, ptr %v28, align 8, !dbg !77
  %phi_edge_30_0 = load ptr, ptr %v28, align 8
  br label %b102, !dbg !27
b107:
  %x394 = call i1 @lo_result_transfer(ptr %out, ptr %r28, ptr %v28), !dbg !27
  br i1 %x394, label %b3, label %b19, !dbg !27
b110:
  %x395 = getelementptr %lo.result, ptr %r29, i32 0, i32 2
  %x396 = load ptr, ptr %x395, align 8
  store ptr %x396, ptr %v29, align 8, !dbg !79
  %phi_edge_30_1 = load ptr, ptr %v29, align 8
  br label %b102, !dbg !27
b111:
  %x397 = call i1 @lo_result_transfer(ptr %out, ptr %r29, ptr %v29), !dbg !27
  br i1 %x397, label %b3, label %b19, !dbg !27
b114:
  %x398 = getelementptr %lo.result, ptr %r30, i32 0, i32 2
  %x399 = load ptr, ptr %x398, align 8
  store ptr %x399, ptr %v31, align 8, !dbg !81
  %x401 = load ptr, ptr %v30, align 8
  %x400 = getelementptr [1 x ptr], ptr %args31, i64 0, i64 0, !dbg !83
  store ptr %x401, ptr %x400, align 8, !dbg !83
  call void @lo_convert_propagate(ptr %context, ptr %args31, i64 1, i64 38, ptr %r31), !dbg !83
  %x402 = getelementptr %lo.result, ptr %r31, i32 0, i32 0
  %x403 = load i32, ptr %x402, align 4, !dbg !83
  switch i32 %x403, label %b19 [ i32 0, label %b118 i32 1, label %b119 i32 2, label %b119 ], !dbg !83
b115:
  %x404 = call i1 @lo_result_transfer(ptr %out, ptr %r30, ptr %v31), !dbg !27
  br i1 %x404, label %b3, label %b19, !dbg !27
b118:
  %x405 = getelementptr %lo.result, ptr %r31, i32 0, i32 2
  %x406 = load ptr, ptr %x405, align 8
  store ptr %x406, ptr %v32, align 8, !dbg !83
  %x408 = load ptr, ptr %v32, align 8
  %x407 = getelementptr [1 x ptr], ptr %args32, i64 0, i64 0, !dbg !85
  store ptr %x408, ptr %x407, align 8, !dbg !85
  call void @lo_charge_value(ptr %context, ptr %args32, i64 1, i64 39, ptr %r32), !dbg !85
  %x409 = getelementptr %lo.result, ptr %r32, i32 0, i32 0
  %x410 = load i32, ptr %x409, align 4, !dbg !85
  switch i32 %x410, label %b19 [ i32 0, label %b122 i32 1, label %b19 i32 2, label %b123 ], !dbg !85
b119:
  %x411 = call i1 @lo_result_transfer(ptr %out, ptr %r31, ptr %v32), !dbg !27
  br i1 %x411, label %b3, label %b19, !dbg !27
b122:
  %x412 = getelementptr %lo.result, ptr %r32, i32 0, i32 2
  %x413 = load ptr, ptr %x412, align 8
  store ptr %x413, ptr %v33, align 8, !dbg !85
  call void @lo_step(ptr %context, ptr null, i64 0, i64 40, ptr %r33), !dbg !87
  %x414 = getelementptr %lo.result, ptr %r33, i32 0, i32 0
  %x415 = load i32, ptr %x414, align 4, !dbg !87
  switch i32 %x415, label %b19 [ i32 0, label %b126 i32 1, label %b19 i32 2, label %b127 ], !dbg !87
b123:
  %x416 = call i1 @lo_result_transfer(ptr %out, ptr %r32, ptr %v33), !dbg !27
  br i1 %x416, label %b3, label %b19, !dbg !27
b126:
  %x417 = getelementptr %lo.result, ptr %r33, i32 0, i32 2
  %x418 = load ptr, ptr %x417, align 8
  store ptr %x418, ptr %v34, align 8, !dbg !87
  call void @lo_step(ptr %context, ptr null, i64 0, i64 41, ptr %r34), !dbg !89
  %x419 = getelementptr %lo.result, ptr %r34, i32 0, i32 0
  %x420 = load i32, ptr %x419, align 4, !dbg !89
  switch i32 %x420, label %b19 [ i32 0, label %b130 i32 1, label %b19 i32 2, label %b131 ], !dbg !89
b127:
  %x421 = call i1 @lo_result_transfer(ptr %out, ptr %r33, ptr %v34), !dbg !27
  br i1 %x421, label %b3, label %b19, !dbg !27
b130:
  %x422 = getelementptr %lo.result, ptr %r34, i32 0, i32 2
  %x423 = load ptr, ptr %x422, align 8
  store ptr %x423, ptr %v35, align 8, !dbg !89
  call void @lo_step(ptr %context, ptr null, i64 0, i64 42, ptr %r35), !dbg !91
  %x424 = getelementptr %lo.result, ptr %r35, i32 0, i32 0
  %x425 = load i32, ptr %x424, align 4, !dbg !91
  switch i32 %x425, label %b19 [ i32 0, label %b134 i32 1, label %b19 i32 2, label %b135 ], !dbg !91
b131:
  %x426 = call i1 @lo_result_transfer(ptr %out, ptr %r34, ptr %v35), !dbg !27
  br i1 %x426, label %b3, label %b19, !dbg !27
b134:
  %x427 = getelementptr %lo.result, ptr %r35, i32 0, i32 2
  %x428 = load ptr, ptr %x427, align 8
  store ptr %x428, ptr %v36, align 8, !dbg !91
  call void @lo_step(ptr %context, ptr null, i64 0, i64 43, ptr %r36), !dbg !93
  %x429 = getelementptr %lo.result, ptr %r36, i32 0, i32 0
  %x430 = load i32, ptr %x429, align 4, !dbg !93
  switch i32 %x430, label %b19 [ i32 0, label %b138 i32 1, label %b19 i32 2, label %b139 ], !dbg !93
b135:
  %x431 = call i1 @lo_result_transfer(ptr %out, ptr %r35, ptr %v36), !dbg !27
  br i1 %x431, label %b3, label %b19, !dbg !27
b138:
  %x432 = getelementptr %lo.result, ptr %r36, i32 0, i32 2
  %x433 = load ptr, ptr %x432, align 8
  store ptr %x433, ptr %v37, align 8, !dbg !93
  %x434 = load ptr, ptr %v32, align 8
  call void @lo_value_retain(ptr %x434), !dbg !95
  store ptr %x434, ptr %v38, align 8, !dbg !95
  %x436 = load ptr, ptr %v38, align 8
  %x435 = getelementptr [1 x ptr], ptr %args37, i64 0, i64 0, !dbg !97
  store ptr %x436, ptr %x435, align 8, !dbg !97
  call void @lo_charge_value(ptr %context, ptr %args37, i64 1, i64 45, ptr %r37), !dbg !97
  %x437 = getelementptr %lo.result, ptr %r37, i32 0, i32 0
  %x438 = load i32, ptr %x437, align 4, !dbg !97
  switch i32 %x438, label %b19 [ i32 0, label %b142 i32 1, label %b19 i32 2, label %b143 ], !dbg !97
b139:
  %x439 = call i1 @lo_result_transfer(ptr %out, ptr %r36, ptr %v37), !dbg !27
  br i1 %x439, label %b3, label %b19, !dbg !27
b142:
  %x440 = getelementptr %lo.result, ptr %r37, i32 0, i32 2
  %x441 = load ptr, ptr %x440, align 8
  store ptr %x441, ptr %v39, align 8, !dbg !97
  call void @lo_step(ptr %context, ptr null, i64 0, i64 46, ptr %r38), !dbg !99
  %x442 = getelementptr %lo.result, ptr %r38, i32 0, i32 0
  %x443 = load i32, ptr %x442, align 4, !dbg !99
  switch i32 %x443, label %b19 [ i32 0, label %b146 i32 1, label %b19 i32 2, label %b147 ], !dbg !99
b143:
  %x444 = call i1 @lo_result_transfer(ptr %out, ptr %r37, ptr %v39), !dbg !27
  br i1 %x444, label %b3, label %b19, !dbg !27
b146:
  %x445 = getelementptr %lo.result, ptr %r38, i32 0, i32 2
  %x446 = load ptr, ptr %x445, align 8
  store ptr %x446, ptr %v40, align 8, !dbg !99
  call void @lo_step(ptr %context, ptr null, i64 0, i64 47, ptr %r39), !dbg !101
  %x447 = getelementptr %lo.result, ptr %r39, i32 0, i32 0
  %x448 = load i32, ptr %x447, align 4, !dbg !101
  switch i32 %x448, label %b19 [ i32 0, label %b150 i32 1, label %b19 i32 2, label %b151 ], !dbg !101
b147:
  %x449 = call i1 @lo_result_transfer(ptr %out, ptr %r38, ptr %v40), !dbg !27
  br i1 %x449, label %b3, label %b19, !dbg !27
b150:
  %x450 = getelementptr %lo.result, ptr %r39, i32 0, i32 2
  %x451 = load ptr, ptr %x450, align 8
  store ptr %x451, ptr %v41, align 8, !dbg !101
  call void @lo_step(ptr %context, ptr null, i64 0, i64 48, ptr %r40), !dbg !103
  %x452 = getelementptr %lo.result, ptr %r40, i32 0, i32 0
  %x453 = load i32, ptr %x452, align 4, !dbg !103
  switch i32 %x453, label %b19 [ i32 0, label %b154 i32 1, label %b19 i32 2, label %b155 ], !dbg !103
b151:
  %x454 = call i1 @lo_result_transfer(ptr %out, ptr %r39, ptr %v41), !dbg !27
  br i1 %x454, label %b3, label %b19, !dbg !27
b154:
  %x455 = getelementptr %lo.result, ptr %r40, i32 0, i32 2
  %x456 = load ptr, ptr %x455, align 8
  store ptr %x456, ptr %v42, align 8, !dbg !103
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 49, ptr %r41), !dbg !105
  %x457 = getelementptr %lo.result, ptr %r41, i32 0, i32 0
  %x458 = load i32, ptr %x457, align 4, !dbg !105
  switch i32 %x458, label %b19 [ i32 0, label %b158 i32 1, label %b19 i32 2, label %b159 ], !dbg !105
b155:
  %x459 = call i1 @lo_result_transfer(ptr %out, ptr %r40, ptr %v42), !dbg !27
  br i1 %x459, label %b3, label %b19, !dbg !27
b158:
  %x460 = getelementptr %lo.result, ptr %r41, i32 0, i32 2
  %x461 = load ptr, ptr %x460, align 8
  store ptr %x461, ptr %v43, align 8, !dbg !105
  %x463 = load ptr, ptr %v43, align 8
  %x462 = getelementptr [1 x ptr], ptr %args42, i64 0, i64 0, !dbg !107
  store ptr %x463, ptr %x462, align 8, !dbg !107
  call void @lo_charge_value(ptr %context, ptr %args42, i64 1, i64 50, ptr %r42), !dbg !107
  %x464 = getelementptr %lo.result, ptr %r42, i32 0, i32 0
  %x465 = load i32, ptr %x464, align 4, !dbg !107
  switch i32 %x465, label %b19 [ i32 0, label %b162 i32 1, label %b19 i32 2, label %b163 ], !dbg !107
b159:
  %x466 = call i1 @lo_result_transfer(ptr %out, ptr %r41, ptr %v43), !dbg !27
  br i1 %x466, label %b3, label %b19, !dbg !27
b162:
  %x467 = getelementptr %lo.result, ptr %r42, i32 0, i32 2
  %x468 = load ptr, ptr %x467, align 8
  store ptr %x468, ptr %v44, align 8, !dbg !107
  %x470 = load ptr, ptr %v43, align 8
  %x469 = getelementptr [1 x ptr], ptr %args43, i64 0, i64 0, !dbg !109
  store ptr %x470, ptr %x469, align 8, !dbg !109
  call void @lo_op_Device_2Enew(ptr %context, ptr %args43, i64 1, i64 51, ptr %r43), !dbg !109
  %x471 = getelementptr %lo.result, ptr %r43, i32 0, i32 0
  %x472 = load i32, ptr %x471, align 4, !dbg !109
  switch i32 %x472, label %b19 [ i32 0, label %b166 i32 1, label %b167 i32 2, label %b169 ], !dbg !109
b163:
  %x473 = call i1 @lo_result_transfer(ptr %out, ptr %r42, ptr %v44), !dbg !27
  br i1 %x473, label %b3, label %b19, !dbg !27
b166:
  %x474 = getelementptr %lo.result, ptr %r43, i32 0, i32 2
  %x475 = load ptr, ptr %x474, align 8
  store ptr %x475, ptr %v45, align 8, !dbg !109
  %x477 = load ptr, ptr %v45, align 8
  %x476 = getelementptr [1 x ptr], ptr %args44, i64 0, i64 0, !dbg !111
  store ptr %x477, ptr %x476, align 8, !dbg !111
  call void @lo_convert_success(ptr %context, ptr %args44, i64 1, i64 52, ptr %r44), !dbg !111
  %x478 = getelementptr %lo.result, ptr %r44, i32 0, i32 0
  %x479 = load i32, ptr %x478, align 4, !dbg !111
  switch i32 %x479, label %b19 [ i32 0, label %b172 i32 1, label %b19 i32 2, label %b173 ], !dbg !111
b167:
  %x480 = getelementptr %lo.result, ptr %r43, i32 0, i32 2
  %x481 = load ptr, ptr %x480, align 8
  store ptr %x481, ptr %v45, align 8, !dbg !109
  %x483 = load ptr, ptr %v45, align 8
  %x482 = getelementptr [1 x ptr], ptr %args45, i64 0, i64 0, !dbg !113
  store ptr %x483, ptr %x482, align 8, !dbg !113
  call void @lo_convert_failure(ptr %context, ptr %args45, i64 1, i64 53, ptr %r45), !dbg !113
  %x484 = getelementptr %lo.result, ptr %r45, i32 0, i32 0
  %x485 = load i32, ptr %x484, align 4, !dbg !113
  switch i32 %x485, label %b19 [ i32 0, label %b176 i32 1, label %b19 i32 2, label %b177 ], !dbg !113
b168:
  %phi48 = phi ptr [ %phi_edge_48_0, %b172 ], [ %phi_edge_48_1, %b176 ], !dbg !109
  call void @lo_value_retain(ptr %phi48), !dbg !109
  store ptr %phi48, ptr %v48, align 8, !dbg !109
  %x487 = load ptr, ptr %v48, align 8
  %x486 = getelementptr [1 x ptr], ptr %args46, i64 0, i64 0, !dbg !115
  store ptr %x487, ptr %x486, align 8, !dbg !115
  call void @lo_charge_value(ptr %context, ptr %args46, i64 1, i64 54, ptr %r46), !dbg !115
  %x488 = getelementptr %lo.result, ptr %r46, i32 0, i32 0
  %x489 = load i32, ptr %x488, align 4, !dbg !115
  switch i32 %x489, label %b19 [ i32 0, label %b180 i32 1, label %b19 i32 2, label %b181 ], !dbg !115
b169:
  %x490 = call i1 @lo_result_transfer(ptr %out, ptr %r43, ptr %v45), !dbg !27
  br i1 %x490, label %b3, label %b19, !dbg !27
b172:
  %x491 = getelementptr %lo.result, ptr %r44, i32 0, i32 2
  %x492 = load ptr, ptr %x491, align 8
  store ptr %x492, ptr %v46, align 8, !dbg !111
  %phi_edge_48_0 = load ptr, ptr %v46, align 8
  br label %b168, !dbg !27
b173:
  %x493 = call i1 @lo_result_transfer(ptr %out, ptr %r44, ptr %v46), !dbg !27
  br i1 %x493, label %b3, label %b19, !dbg !27
b176:
  %x494 = getelementptr %lo.result, ptr %r45, i32 0, i32 2
  %x495 = load ptr, ptr %x494, align 8
  store ptr %x495, ptr %v47, align 8, !dbg !113
  %phi_edge_48_1 = load ptr, ptr %v47, align 8
  br label %b168, !dbg !27
b177:
  %x496 = call i1 @lo_result_transfer(ptr %out, ptr %r45, ptr %v47), !dbg !27
  br i1 %x496, label %b3, label %b19, !dbg !27
b180:
  %x497 = getelementptr %lo.result, ptr %r46, i32 0, i32 2
  %x498 = load ptr, ptr %x497, align 8
  store ptr %x498, ptr %v49, align 8, !dbg !115
  %x500 = load ptr, ptr %v48, align 8
  %x499 = getelementptr [1 x ptr], ptr %args47, i64 0, i64 0, !dbg !117
  store ptr %x500, ptr %x499, align 8, !dbg !117
  call void @lo_convert_propagate(ptr %context, ptr %args47, i64 1, i64 55, ptr %r47), !dbg !117
  %x501 = getelementptr %lo.result, ptr %r47, i32 0, i32 0
  %x502 = load i32, ptr %x501, align 4, !dbg !117
  switch i32 %x502, label %b19 [ i32 0, label %b184 i32 1, label %b185 i32 2, label %b185 ], !dbg !117
b181:
  %x503 = call i1 @lo_result_transfer(ptr %out, ptr %r46, ptr %v49), !dbg !27
  br i1 %x503, label %b3, label %b19, !dbg !27
b184:
  %x504 = getelementptr %lo.result, ptr %r47, i32 0, i32 2
  %x505 = load ptr, ptr %x504, align 8
  store ptr %x505, ptr %v50, align 8, !dbg !117
  %x507 = load ptr, ptr %v50, align 8
  %x506 = getelementptr [1 x ptr], ptr %args48, i64 0, i64 0, !dbg !119
  store ptr %x507, ptr %x506, align 8, !dbg !119
  call void @lo_charge_value(ptr %context, ptr %args48, i64 1, i64 56, ptr %r48), !dbg !119
  %x508 = getelementptr %lo.result, ptr %r48, i32 0, i32 0
  %x509 = load i32, ptr %x508, align 4, !dbg !119
  switch i32 %x509, label %b19 [ i32 0, label %b188 i32 1, label %b19 i32 2, label %b189 ], !dbg !119
b185:
  %x510 = call i1 @lo_result_transfer(ptr %out, ptr %r47, ptr %v50), !dbg !27
  br i1 %x510, label %b3, label %b19, !dbg !27
b188:
  %x511 = getelementptr %lo.result, ptr %r48, i32 0, i32 2
  %x512 = load ptr, ptr %x511, align 8
  store ptr %x512, ptr %v51, align 8, !dbg !119
  %x514 = load ptr, ptr %v38, align 8
  %x513 = getelementptr [2 x ptr], ptr %args49, i64 0, i64 0, !dbg !121
  store ptr %x514, ptr %x513, align 8, !dbg !121
  %x516 = load ptr, ptr %v50, align 8
  %x515 = getelementptr [2 x ptr], ptr %args49, i64 0, i64 1, !dbg !121
  store ptr %x516, ptr %x515, align 8, !dbg !121
  call void @lo_op_Tensor_2Eto(ptr %context, ptr %args49, i64 2, i64 57, ptr %r49), !dbg !121
  %x517 = getelementptr %lo.result, ptr %r49, i32 0, i32 0
  %x518 = load i32, ptr %x517, align 4, !dbg !121
  switch i32 %x518, label %b19 [ i32 0, label %b192 i32 1, label %b193 i32 2, label %b195 ], !dbg !121
b189:
  %x519 = call i1 @lo_result_transfer(ptr %out, ptr %r48, ptr %v51), !dbg !27
  br i1 %x519, label %b3, label %b19, !dbg !27
b192:
  %x520 = getelementptr %lo.result, ptr %r49, i32 0, i32 2
  %x521 = load ptr, ptr %x520, align 8
  store ptr %x521, ptr %v52, align 8, !dbg !121
  %x523 = load ptr, ptr %v52, align 8
  %x522 = getelementptr [1 x ptr], ptr %args50, i64 0, i64 0, !dbg !123
  store ptr %x523, ptr %x522, align 8, !dbg !123
  call void @lo_convert_success(ptr %context, ptr %args50, i64 1, i64 58, ptr %r50), !dbg !123
  %x524 = getelementptr %lo.result, ptr %r50, i32 0, i32 0
  %x525 = load i32, ptr %x524, align 4, !dbg !123
  switch i32 %x525, label %b19 [ i32 0, label %b198 i32 1, label %b19 i32 2, label %b199 ], !dbg !123
b193:
  %x526 = getelementptr %lo.result, ptr %r49, i32 0, i32 2
  %x527 = load ptr, ptr %x526, align 8
  store ptr %x527, ptr %v52, align 8, !dbg !121
  %x529 = load ptr, ptr %v52, align 8
  %x528 = getelementptr [1 x ptr], ptr %args51, i64 0, i64 0, !dbg !125
  store ptr %x529, ptr %x528, align 8, !dbg !125
  call void @lo_convert_failure(ptr %context, ptr %args51, i64 1, i64 59, ptr %r51), !dbg !125
  %x530 = getelementptr %lo.result, ptr %r51, i32 0, i32 0
  %x531 = load i32, ptr %x530, align 4, !dbg !125
  switch i32 %x531, label %b19 [ i32 0, label %b202 i32 1, label %b19 i32 2, label %b203 ], !dbg !125
b194:
  %phi55 = phi ptr [ %phi_edge_55_0, %b198 ], [ %phi_edge_55_1, %b202 ], !dbg !121
  call void @lo_value_retain(ptr %phi55), !dbg !121
  store ptr %phi55, ptr %v55, align 8, !dbg !121
  %x533 = load ptr, ptr %v55, align 8
  %x532 = getelementptr [1 x ptr], ptr %args52, i64 0, i64 0, !dbg !127
  store ptr %x533, ptr %x532, align 8, !dbg !127
  call void @lo_charge_value(ptr %context, ptr %args52, i64 1, i64 60, ptr %r52), !dbg !127
  %x534 = getelementptr %lo.result, ptr %r52, i32 0, i32 0
  %x535 = load i32, ptr %x534, align 4, !dbg !127
  switch i32 %x535, label %b19 [ i32 0, label %b206 i32 1, label %b19 i32 2, label %b207 ], !dbg !127
b195:
  %x536 = call i1 @lo_result_transfer(ptr %out, ptr %r49, ptr %v52), !dbg !27
  br i1 %x536, label %b3, label %b19, !dbg !27
b198:
  %x537 = getelementptr %lo.result, ptr %r50, i32 0, i32 2
  %x538 = load ptr, ptr %x537, align 8
  store ptr %x538, ptr %v53, align 8, !dbg !123
  %phi_edge_55_0 = load ptr, ptr %v53, align 8
  br label %b194, !dbg !27
b199:
  %x539 = call i1 @lo_result_transfer(ptr %out, ptr %r50, ptr %v53), !dbg !27
  br i1 %x539, label %b3, label %b19, !dbg !27
b202:
  %x540 = getelementptr %lo.result, ptr %r51, i32 0, i32 2
  %x541 = load ptr, ptr %x540, align 8
  store ptr %x541, ptr %v54, align 8, !dbg !125
  %phi_edge_55_1 = load ptr, ptr %v54, align 8
  br label %b194, !dbg !27
b203:
  %x542 = call i1 @lo_result_transfer(ptr %out, ptr %r51, ptr %v54), !dbg !27
  br i1 %x542, label %b3, label %b19, !dbg !27
b206:
  %x543 = getelementptr %lo.result, ptr %r52, i32 0, i32 2
  %x544 = load ptr, ptr %x543, align 8
  store ptr %x544, ptr %v56, align 8, !dbg !127
  %x546 = load ptr, ptr %v55, align 8
  %x545 = getelementptr [1 x ptr], ptr %args53, i64 0, i64 0, !dbg !129
  store ptr %x546, ptr %x545, align 8, !dbg !129
  call void @lo_convert_propagate(ptr %context, ptr %args53, i64 1, i64 61, ptr %r53), !dbg !129
  %x547 = getelementptr %lo.result, ptr %r53, i32 0, i32 0
  %x548 = load i32, ptr %x547, align 4, !dbg !129
  switch i32 %x548, label %b19 [ i32 0, label %b210 i32 1, label %b211 i32 2, label %b211 ], !dbg !129
b207:
  %x549 = call i1 @lo_result_transfer(ptr %out, ptr %r52, ptr %v56), !dbg !27
  br i1 %x549, label %b3, label %b19, !dbg !27
b210:
  %x550 = getelementptr %lo.result, ptr %r53, i32 0, i32 2
  %x551 = load ptr, ptr %x550, align 8
  store ptr %x551, ptr %v57, align 8, !dbg !129
  %x553 = load ptr, ptr %v57, align 8
  %x552 = getelementptr [1 x ptr], ptr %args54, i64 0, i64 0, !dbg !131
  store ptr %x553, ptr %x552, align 8, !dbg !131
  call void @lo_charge_value(ptr %context, ptr %args54, i64 1, i64 62, ptr %r54), !dbg !131
  %x554 = getelementptr %lo.result, ptr %r54, i32 0, i32 0
  %x555 = load i32, ptr %x554, align 4, !dbg !131
  switch i32 %x555, label %b19 [ i32 0, label %b214 i32 1, label %b19 i32 2, label %b215 ], !dbg !131
b211:
  %x556 = call i1 @lo_result_transfer(ptr %out, ptr %r53, ptr %v57), !dbg !27
  br i1 %x556, label %b3, label %b19, !dbg !27
b214:
  %x557 = getelementptr %lo.result, ptr %r54, i32 0, i32 2
  %x558 = load ptr, ptr %x557, align 8
  store ptr %x558, ptr %v58, align 8, !dbg !131
  call void @lo_step(ptr %context, ptr null, i64 0, i64 63, ptr %r55), !dbg !133
  %x559 = getelementptr %lo.result, ptr %r55, i32 0, i32 0
  %x560 = load i32, ptr %x559, align 4, !dbg !133
  switch i32 %x560, label %b19 [ i32 0, label %b218 i32 1, label %b19 i32 2, label %b219 ], !dbg !133
b215:
  %x561 = call i1 @lo_result_transfer(ptr %out, ptr %r54, ptr %v58), !dbg !27
  br i1 %x561, label %b3, label %b19, !dbg !27
b218:
  %x562 = getelementptr %lo.result, ptr %r55, i32 0, i32 2
  %x563 = load ptr, ptr %x562, align 8
  store ptr %x563, ptr %v59, align 8, !dbg !133
  call void @lo_step(ptr %context, ptr null, i64 0, i64 64, ptr %r56), !dbg !135
  %x564 = getelementptr %lo.result, ptr %r56, i32 0, i32 0
  %x565 = load i32, ptr %x564, align 4, !dbg !135
  switch i32 %x565, label %b19 [ i32 0, label %b222 i32 1, label %b19 i32 2, label %b223 ], !dbg !135
b219:
  %x566 = call i1 @lo_result_transfer(ptr %out, ptr %r55, ptr %v59), !dbg !27
  br i1 %x566, label %b3, label %b19, !dbg !27
b222:
  %x567 = getelementptr %lo.result, ptr %r56, i32 0, i32 2
  %x568 = load ptr, ptr %x567, align 8
  store ptr %x568, ptr %v60, align 8, !dbg !135
  call void @lo_step(ptr %context, ptr null, i64 0, i64 65, ptr %r57), !dbg !137
  %x569 = getelementptr %lo.result, ptr %r57, i32 0, i32 0
  %x570 = load i32, ptr %x569, align 4, !dbg !137
  switch i32 %x570, label %b19 [ i32 0, label %b226 i32 1, label %b19 i32 2, label %b227 ], !dbg !137
b223:
  %x571 = call i1 @lo_result_transfer(ptr %out, ptr %r56, ptr %v60), !dbg !27
  br i1 %x571, label %b3, label %b19, !dbg !27
b226:
  %x572 = getelementptr %lo.result, ptr %r57, i32 0, i32 2
  %x573 = load ptr, ptr %x572, align 8
  store ptr %x573, ptr %v61, align 8, !dbg !137
  call void @lo_step(ptr %context, ptr null, i64 0, i64 66, ptr %r58), !dbg !139
  %x574 = getelementptr %lo.result, ptr %r58, i32 0, i32 0
  %x575 = load i32, ptr %x574, align 4, !dbg !139
  switch i32 %x575, label %b19 [ i32 0, label %b230 i32 1, label %b19 i32 2, label %b231 ], !dbg !139
b227:
  %x576 = call i1 @lo_result_transfer(ptr %out, ptr %r57, ptr %v61), !dbg !27
  br i1 %x576, label %b3, label %b19, !dbg !27
b230:
  %x577 = getelementptr %lo.result, ptr %r58, i32 0, i32 2
  %x578 = load ptr, ptr %x577, align 8
  store ptr %x578, ptr %v62, align 8, !dbg !139
  %x579 = load ptr, ptr %v57, align 8
  call void @lo_value_retain(ptr %x579), !dbg !141
  store ptr %x579, ptr %v63, align 8, !dbg !141
  %x581 = load ptr, ptr %v63, align 8
  %x580 = getelementptr [1 x ptr], ptr %args59, i64 0, i64 0, !dbg !143
  store ptr %x581, ptr %x580, align 8, !dbg !143
  call void @lo_charge_value(ptr %context, ptr %args59, i64 1, i64 68, ptr %r59), !dbg !143
  %x582 = getelementptr %lo.result, ptr %r59, i32 0, i32 0
  %x583 = load i32, ptr %x582, align 4, !dbg !143
  switch i32 %x583, label %b19 [ i32 0, label %b234 i32 1, label %b19 i32 2, label %b235 ], !dbg !143
b231:
  %x584 = call i1 @lo_result_transfer(ptr %out, ptr %r58, ptr %v62), !dbg !27
  br i1 %x584, label %b3, label %b19, !dbg !27
b234:
  %x585 = getelementptr %lo.result, ptr %r59, i32 0, i32 2
  %x586 = load ptr, ptr %x585, align 8
  store ptr %x586, ptr %v64, align 8, !dbg !143
  call void @lo_step(ptr %context, ptr null, i64 0, i64 69, ptr %r60), !dbg !145
  %x587 = getelementptr %lo.result, ptr %r60, i32 0, i32 0
  %x588 = load i32, ptr %x587, align 4, !dbg !145
  switch i32 %x588, label %b19 [ i32 0, label %b238 i32 1, label %b19 i32 2, label %b239 ], !dbg !145
b235:
  %x589 = call i1 @lo_result_transfer(ptr %out, ptr %r59, ptr %v64), !dbg !27
  br i1 %x589, label %b3, label %b19, !dbg !27
b238:
  %x590 = getelementptr %lo.result, ptr %r60, i32 0, i32 2
  %x591 = load ptr, ptr %x590, align 8
  store ptr %x591, ptr %v65, align 8, !dbg !145
  call void @lo_step(ptr %context, ptr null, i64 0, i64 70, ptr %r61), !dbg !147
  %x592 = getelementptr %lo.result, ptr %r61, i32 0, i32 0
  %x593 = load i32, ptr %x592, align 4, !dbg !147
  switch i32 %x593, label %b19 [ i32 0, label %b242 i32 1, label %b19 i32 2, label %b243 ], !dbg !147
b239:
  %x594 = call i1 @lo_result_transfer(ptr %out, ptr %r60, ptr %v65), !dbg !27
  br i1 %x594, label %b3, label %b19, !dbg !27
b242:
  %x595 = getelementptr %lo.result, ptr %r61, i32 0, i32 2
  %x596 = load ptr, ptr %x595, align 8
  store ptr %x596, ptr %v66, align 8, !dbg !147
  call void @lo_step(ptr %context, ptr null, i64 0, i64 71, ptr %r62), !dbg !149
  %x597 = getelementptr %lo.result, ptr %r62, i32 0, i32 0
  %x598 = load i32, ptr %x597, align 4, !dbg !149
  switch i32 %x598, label %b19 [ i32 0, label %b246 i32 1, label %b19 i32 2, label %b247 ], !dbg !149
b243:
  %x599 = call i1 @lo_result_transfer(ptr %out, ptr %r61, ptr %v66), !dbg !27
  br i1 %x599, label %b3, label %b19, !dbg !27
b246:
  %x600 = getelementptr %lo.result, ptr %r62, i32 0, i32 2
  %x601 = load ptr, ptr %x600, align 8
  store ptr %x601, ptr %v67, align 8, !dbg !149
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 72, ptr %r63), !dbg !151
  %x602 = getelementptr %lo.result, ptr %r63, i32 0, i32 0
  %x603 = load i32, ptr %x602, align 4, !dbg !151
  switch i32 %x603, label %b19 [ i32 0, label %b250 i32 1, label %b19 i32 2, label %b251 ], !dbg !151
b247:
  %x604 = call i1 @lo_result_transfer(ptr %out, ptr %r62, ptr %v67), !dbg !27
  br i1 %x604, label %b3, label %b19, !dbg !27
b250:
  %x605 = getelementptr %lo.result, ptr %r63, i32 0, i32 2
  %x606 = load ptr, ptr %x605, align 8
  store ptr %x606, ptr %v68, align 8, !dbg !151
  %x608 = load ptr, ptr %v68, align 8
  %x607 = getelementptr [1 x ptr], ptr %args64, i64 0, i64 0, !dbg !153
  store ptr %x608, ptr %x607, align 8, !dbg !153
  call void @lo_charge_value(ptr %context, ptr %args64, i64 1, i64 73, ptr %r64), !dbg !153
  %x609 = getelementptr %lo.result, ptr %r64, i32 0, i32 0
  %x610 = load i32, ptr %x609, align 4, !dbg !153
  switch i32 %x610, label %b19 [ i32 0, label %b254 i32 1, label %b19 i32 2, label %b255 ], !dbg !153
b251:
  %x611 = call i1 @lo_result_transfer(ptr %out, ptr %r63, ptr %v68), !dbg !27
  br i1 %x611, label %b3, label %b19, !dbg !27
b254:
  %x612 = getelementptr %lo.result, ptr %r64, i32 0, i32 2
  %x613 = load ptr, ptr %x612, align 8
  store ptr %x613, ptr %v69, align 8, !dbg !153
  %x615 = load ptr, ptr %v68, align 8
  %x614 = getelementptr [1 x ptr], ptr %args65, i64 0, i64 0, !dbg !155
  store ptr %x615, ptr %x614, align 8, !dbg !155
  call void @lo_op_Device_2Enew(ptr %context, ptr %args65, i64 1, i64 74, ptr %r65), !dbg !155
  %x616 = getelementptr %lo.result, ptr %r65, i32 0, i32 0
  %x617 = load i32, ptr %x616, align 4, !dbg !155
  switch i32 %x617, label %b19 [ i32 0, label %b258 i32 1, label %b259 i32 2, label %b261 ], !dbg !155
b255:
  %x618 = call i1 @lo_result_transfer(ptr %out, ptr %r64, ptr %v69), !dbg !27
  br i1 %x618, label %b3, label %b19, !dbg !27
b258:
  %x619 = getelementptr %lo.result, ptr %r65, i32 0, i32 2
  %x620 = load ptr, ptr %x619, align 8
  store ptr %x620, ptr %v70, align 8, !dbg !155
  %x622 = load ptr, ptr %v70, align 8
  %x621 = getelementptr [1 x ptr], ptr %args66, i64 0, i64 0, !dbg !157
  store ptr %x622, ptr %x621, align 8, !dbg !157
  call void @lo_convert_success(ptr %context, ptr %args66, i64 1, i64 75, ptr %r66), !dbg !157
  %x623 = getelementptr %lo.result, ptr %r66, i32 0, i32 0
  %x624 = load i32, ptr %x623, align 4, !dbg !157
  switch i32 %x624, label %b19 [ i32 0, label %b264 i32 1, label %b19 i32 2, label %b265 ], !dbg !157
b259:
  %x625 = getelementptr %lo.result, ptr %r65, i32 0, i32 2
  %x626 = load ptr, ptr %x625, align 8
  store ptr %x626, ptr %v70, align 8, !dbg !155
  %x628 = load ptr, ptr %v70, align 8
  %x627 = getelementptr [1 x ptr], ptr %args67, i64 0, i64 0, !dbg !159
  store ptr %x628, ptr %x627, align 8, !dbg !159
  call void @lo_convert_failure(ptr %context, ptr %args67, i64 1, i64 76, ptr %r67), !dbg !159
  %x629 = getelementptr %lo.result, ptr %r67, i32 0, i32 0
  %x630 = load i32, ptr %x629, align 4, !dbg !159
  switch i32 %x630, label %b19 [ i32 0, label %b268 i32 1, label %b19 i32 2, label %b269 ], !dbg !159
b260:
  %phi73 = phi ptr [ %phi_edge_73_0, %b264 ], [ %phi_edge_73_1, %b268 ], !dbg !155
  call void @lo_value_retain(ptr %phi73), !dbg !155
  store ptr %phi73, ptr %v73, align 8, !dbg !155
  %x632 = load ptr, ptr %v73, align 8
  %x631 = getelementptr [1 x ptr], ptr %args68, i64 0, i64 0, !dbg !161
  store ptr %x632, ptr %x631, align 8, !dbg !161
  call void @lo_charge_value(ptr %context, ptr %args68, i64 1, i64 77, ptr %r68), !dbg !161
  %x633 = getelementptr %lo.result, ptr %r68, i32 0, i32 0
  %x634 = load i32, ptr %x633, align 4, !dbg !161
  switch i32 %x634, label %b19 [ i32 0, label %b272 i32 1, label %b19 i32 2, label %b273 ], !dbg !161
b261:
  %x635 = call i1 @lo_result_transfer(ptr %out, ptr %r65, ptr %v70), !dbg !27
  br i1 %x635, label %b3, label %b19, !dbg !27
b264:
  %x636 = getelementptr %lo.result, ptr %r66, i32 0, i32 2
  %x637 = load ptr, ptr %x636, align 8
  store ptr %x637, ptr %v71, align 8, !dbg !157
  %phi_edge_73_0 = load ptr, ptr %v71, align 8
  br label %b260, !dbg !27
b265:
  %x638 = call i1 @lo_result_transfer(ptr %out, ptr %r66, ptr %v71), !dbg !27
  br i1 %x638, label %b3, label %b19, !dbg !27
b268:
  %x639 = getelementptr %lo.result, ptr %r67, i32 0, i32 2
  %x640 = load ptr, ptr %x639, align 8
  store ptr %x640, ptr %v72, align 8, !dbg !159
  %phi_edge_73_1 = load ptr, ptr %v72, align 8
  br label %b260, !dbg !27
b269:
  %x641 = call i1 @lo_result_transfer(ptr %out, ptr %r67, ptr %v72), !dbg !27
  br i1 %x641, label %b3, label %b19, !dbg !27
b272:
  %x642 = getelementptr %lo.result, ptr %r68, i32 0, i32 2
  %x643 = load ptr, ptr %x642, align 8
  store ptr %x643, ptr %v74, align 8, !dbg !161
  %x645 = load ptr, ptr %v73, align 8
  %x644 = getelementptr [1 x ptr], ptr %args69, i64 0, i64 0, !dbg !163
  store ptr %x645, ptr %x644, align 8, !dbg !163
  call void @lo_convert_propagate(ptr %context, ptr %args69, i64 1, i64 78, ptr %r69), !dbg !163
  %x646 = getelementptr %lo.result, ptr %r69, i32 0, i32 0
  %x647 = load i32, ptr %x646, align 4, !dbg !163
  switch i32 %x647, label %b19 [ i32 0, label %b276 i32 1, label %b277 i32 2, label %b277 ], !dbg !163
b273:
  %x648 = call i1 @lo_result_transfer(ptr %out, ptr %r68, ptr %v74), !dbg !27
  br i1 %x648, label %b3, label %b19, !dbg !27
b276:
  %x649 = getelementptr %lo.result, ptr %r69, i32 0, i32 2
  %x650 = load ptr, ptr %x649, align 8
  store ptr %x650, ptr %v75, align 8, !dbg !163
  %x652 = load ptr, ptr %v75, align 8
  %x651 = getelementptr [1 x ptr], ptr %args70, i64 0, i64 0, !dbg !165
  store ptr %x652, ptr %x651, align 8, !dbg !165
  call void @lo_charge_value(ptr %context, ptr %args70, i64 1, i64 79, ptr %r70), !dbg !165
  %x653 = getelementptr %lo.result, ptr %r70, i32 0, i32 0
  %x654 = load i32, ptr %x653, align 4, !dbg !165
  switch i32 %x654, label %b19 [ i32 0, label %b280 i32 1, label %b19 i32 2, label %b281 ], !dbg !165
b277:
  %x655 = call i1 @lo_result_transfer(ptr %out, ptr %r69, ptr %v75), !dbg !27
  br i1 %x655, label %b3, label %b19, !dbg !27
b280:
  %x656 = getelementptr %lo.result, ptr %r70, i32 0, i32 2
  %x657 = load ptr, ptr %x656, align 8
  store ptr %x657, ptr %v76, align 8, !dbg !165
  %x659 = load ptr, ptr %v63, align 8
  %x658 = getelementptr [2 x ptr], ptr %args71, i64 0, i64 0, !dbg !167
  store ptr %x659, ptr %x658, align 8, !dbg !167
  %x661 = load ptr, ptr %v75, align 8
  %x660 = getelementptr [2 x ptr], ptr %args71, i64 0, i64 1, !dbg !167
  store ptr %x661, ptr %x660, align 8, !dbg !167
  call void @lo_op_Tensor_2Eto(ptr %context, ptr %args71, i64 2, i64 80, ptr %r71), !dbg !167
  %x662 = getelementptr %lo.result, ptr %r71, i32 0, i32 0
  %x663 = load i32, ptr %x662, align 4, !dbg !167
  switch i32 %x663, label %b19 [ i32 0, label %b284 i32 1, label %b285 i32 2, label %b287 ], !dbg !167
b281:
  %x664 = call i1 @lo_result_transfer(ptr %out, ptr %r70, ptr %v76), !dbg !27
  br i1 %x664, label %b3, label %b19, !dbg !27
b284:
  %x665 = getelementptr %lo.result, ptr %r71, i32 0, i32 2
  %x666 = load ptr, ptr %x665, align 8
  store ptr %x666, ptr %v77, align 8, !dbg !167
  %x668 = load ptr, ptr %v77, align 8
  %x667 = getelementptr [1 x ptr], ptr %args72, i64 0, i64 0, !dbg !169
  store ptr %x668, ptr %x667, align 8, !dbg !169
  call void @lo_convert_success(ptr %context, ptr %args72, i64 1, i64 81, ptr %r72), !dbg !169
  %x669 = getelementptr %lo.result, ptr %r72, i32 0, i32 0
  %x670 = load i32, ptr %x669, align 4, !dbg !169
  switch i32 %x670, label %b19 [ i32 0, label %b290 i32 1, label %b19 i32 2, label %b291 ], !dbg !169
b285:
  %x671 = getelementptr %lo.result, ptr %r71, i32 0, i32 2
  %x672 = load ptr, ptr %x671, align 8
  store ptr %x672, ptr %v77, align 8, !dbg !167
  %x674 = load ptr, ptr %v77, align 8
  %x673 = getelementptr [1 x ptr], ptr %args73, i64 0, i64 0, !dbg !171
  store ptr %x674, ptr %x673, align 8, !dbg !171
  call void @lo_convert_failure(ptr %context, ptr %args73, i64 1, i64 82, ptr %r73), !dbg !171
  %x675 = getelementptr %lo.result, ptr %r73, i32 0, i32 0
  %x676 = load i32, ptr %x675, align 4, !dbg !171
  switch i32 %x676, label %b19 [ i32 0, label %b294 i32 1, label %b19 i32 2, label %b295 ], !dbg !171
b286:
  %phi80 = phi ptr [ %phi_edge_80_0, %b290 ], [ %phi_edge_80_1, %b294 ], !dbg !167
  call void @lo_value_retain(ptr %phi80), !dbg !167
  store ptr %phi80, ptr %v80, align 8, !dbg !167
  %x678 = load ptr, ptr %v80, align 8
  %x677 = getelementptr [1 x ptr], ptr %args74, i64 0, i64 0, !dbg !173
  store ptr %x678, ptr %x677, align 8, !dbg !173
  call void @lo_charge_value(ptr %context, ptr %args74, i64 1, i64 83, ptr %r74), !dbg !173
  %x679 = getelementptr %lo.result, ptr %r74, i32 0, i32 0
  %x680 = load i32, ptr %x679, align 4, !dbg !173
  switch i32 %x680, label %b19 [ i32 0, label %b298 i32 1, label %b19 i32 2, label %b299 ], !dbg !173
b287:
  %x681 = call i1 @lo_result_transfer(ptr %out, ptr %r71, ptr %v77), !dbg !27
  br i1 %x681, label %b3, label %b19, !dbg !27
b290:
  %x682 = getelementptr %lo.result, ptr %r72, i32 0, i32 2
  %x683 = load ptr, ptr %x682, align 8
  store ptr %x683, ptr %v78, align 8, !dbg !169
  %phi_edge_80_0 = load ptr, ptr %v78, align 8
  br label %b286, !dbg !27
b291:
  %x684 = call i1 @lo_result_transfer(ptr %out, ptr %r72, ptr %v78), !dbg !27
  br i1 %x684, label %b3, label %b19, !dbg !27
b294:
  %x685 = getelementptr %lo.result, ptr %r73, i32 0, i32 2
  %x686 = load ptr, ptr %x685, align 8
  store ptr %x686, ptr %v79, align 8, !dbg !171
  %phi_edge_80_1 = load ptr, ptr %v79, align 8
  br label %b286, !dbg !27
b295:
  %x687 = call i1 @lo_result_transfer(ptr %out, ptr %r73, ptr %v79), !dbg !27
  br i1 %x687, label %b3, label %b19, !dbg !27
b298:
  %x688 = getelementptr %lo.result, ptr %r74, i32 0, i32 2
  %x689 = load ptr, ptr %x688, align 8
  store ptr %x689, ptr %v81, align 8, !dbg !173
  %x691 = load ptr, ptr %v80, align 8
  %x690 = getelementptr [1 x ptr], ptr %args75, i64 0, i64 0, !dbg !175
  store ptr %x691, ptr %x690, align 8, !dbg !175
  call void @lo_convert_propagate(ptr %context, ptr %args75, i64 1, i64 84, ptr %r75), !dbg !175
  %x692 = getelementptr %lo.result, ptr %r75, i32 0, i32 0
  %x693 = load i32, ptr %x692, align 4, !dbg !175
  switch i32 %x693, label %b19 [ i32 0, label %b302 i32 1, label %b303 i32 2, label %b303 ], !dbg !175
b299:
  %x694 = call i1 @lo_result_transfer(ptr %out, ptr %r74, ptr %v81), !dbg !27
  br i1 %x694, label %b3, label %b19, !dbg !27
b302:
  %x695 = getelementptr %lo.result, ptr %r75, i32 0, i32 2
  %x696 = load ptr, ptr %x695, align 8
  store ptr %x696, ptr %v82, align 8, !dbg !175
  %x698 = load ptr, ptr %v82, align 8
  %x697 = getelementptr [1 x ptr], ptr %args76, i64 0, i64 0, !dbg !177
  store ptr %x698, ptr %x697, align 8, !dbg !177
  call void @lo_charge_value(ptr %context, ptr %args76, i64 1, i64 85, ptr %r76), !dbg !177
  %x699 = getelementptr %lo.result, ptr %r76, i32 0, i32 0
  %x700 = load i32, ptr %x699, align 4, !dbg !177
  switch i32 %x700, label %b19 [ i32 0, label %b306 i32 1, label %b19 i32 2, label %b307 ], !dbg !177
b303:
  %x701 = call i1 @lo_result_transfer(ptr %out, ptr %r75, ptr %v82), !dbg !27
  br i1 %x701, label %b3, label %b19, !dbg !27
b306:
  %x702 = getelementptr %lo.result, ptr %r76, i32 0, i32 2
  %x703 = load ptr, ptr %x702, align 8
  store ptr %x703, ptr %v83, align 8, !dbg !177
  call void @lo_step(ptr %context, ptr null, i64 0, i64 86, ptr %r77), !dbg !179
  %x704 = getelementptr %lo.result, ptr %r77, i32 0, i32 0
  %x705 = load i32, ptr %x704, align 4, !dbg !179
  switch i32 %x705, label %b19 [ i32 0, label %b310 i32 1, label %b19 i32 2, label %b311 ], !dbg !179
b307:
  %x706 = call i1 @lo_result_transfer(ptr %out, ptr %r76, ptr %v83), !dbg !27
  br i1 %x706, label %b3, label %b19, !dbg !27
b310:
  %x707 = getelementptr %lo.result, ptr %r77, i32 0, i32 2
  %x708 = load ptr, ptr %x707, align 8
  store ptr %x708, ptr %v84, align 8, !dbg !179
  call void @lo_step(ptr %context, ptr null, i64 0, i64 87, ptr %r78), !dbg !181
  %x709 = getelementptr %lo.result, ptr %r78, i32 0, i32 0
  %x710 = load i32, ptr %x709, align 4, !dbg !181
  switch i32 %x710, label %b19 [ i32 0, label %b314 i32 1, label %b19 i32 2, label %b315 ], !dbg !181
b311:
  %x711 = call i1 @lo_result_transfer(ptr %out, ptr %r77, ptr %v84), !dbg !27
  br i1 %x711, label %b3, label %b19, !dbg !27
b314:
  %x712 = getelementptr %lo.result, ptr %r78, i32 0, i32 2
  %x713 = load ptr, ptr %x712, align 8
  store ptr %x713, ptr %v85, align 8, !dbg !181
  call void @lo_step(ptr %context, ptr null, i64 0, i64 88, ptr %r79), !dbg !183
  %x714 = getelementptr %lo.result, ptr %r79, i32 0, i32 0
  %x715 = load i32, ptr %x714, align 4, !dbg !183
  switch i32 %x715, label %b19 [ i32 0, label %b318 i32 1, label %b19 i32 2, label %b319 ], !dbg !183
b315:
  %x716 = call i1 @lo_result_transfer(ptr %out, ptr %r78, ptr %v85), !dbg !27
  br i1 %x716, label %b3, label %b19, !dbg !27
b318:
  %x717 = getelementptr %lo.result, ptr %r79, i32 0, i32 2
  %x718 = load ptr, ptr %x717, align 8
  store ptr %x718, ptr %v86, align 8, !dbg !183
  call void @lo_step(ptr %context, ptr null, i64 0, i64 89, ptr %r80), !dbg !185
  %x719 = getelementptr %lo.result, ptr %r80, i32 0, i32 0
  %x720 = load i32, ptr %x719, align 4, !dbg !185
  switch i32 %x720, label %b19 [ i32 0, label %b322 i32 1, label %b19 i32 2, label %b323 ], !dbg !185
b319:
  %x721 = call i1 @lo_result_transfer(ptr %out, ptr %r79, ptr %v86), !dbg !27
  br i1 %x721, label %b3, label %b19, !dbg !27
b322:
  %x722 = getelementptr %lo.result, ptr %r80, i32 0, i32 2
  %x723 = load ptr, ptr %x722, align 8
  store ptr %x723, ptr %v87, align 8, !dbg !185
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 90, ptr %r81), !dbg !187
  %x724 = getelementptr %lo.result, ptr %r81, i32 0, i32 0
  %x725 = load i32, ptr %x724, align 4, !dbg !187
  switch i32 %x725, label %b19 [ i32 0, label %b326 i32 1, label %b19 i32 2, label %b327 ], !dbg !187
b323:
  %x726 = call i1 @lo_result_transfer(ptr %out, ptr %r80, ptr %v87), !dbg !27
  br i1 %x726, label %b3, label %b19, !dbg !27
b326:
  %x727 = getelementptr %lo.result, ptr %r81, i32 0, i32 2
  %x728 = load ptr, ptr %x727, align 8
  store ptr %x728, ptr %v88, align 8, !dbg !187
  %x730 = load ptr, ptr %v88, align 8
  %x729 = getelementptr [1 x ptr], ptr %args82, i64 0, i64 0, !dbg !189
  store ptr %x730, ptr %x729, align 8, !dbg !189
  call void @lo_charge_value(ptr %context, ptr %args82, i64 1, i64 91, ptr %r82), !dbg !189
  %x731 = getelementptr %lo.result, ptr %r82, i32 0, i32 0
  %x732 = load i32, ptr %x731, align 4, !dbg !189
  switch i32 %x732, label %b19 [ i32 0, label %b330 i32 1, label %b19 i32 2, label %b331 ], !dbg !189
b327:
  %x733 = call i1 @lo_result_transfer(ptr %out, ptr %r81, ptr %v88), !dbg !27
  br i1 %x733, label %b3, label %b19, !dbg !27
b330:
  %x734 = getelementptr %lo.result, ptr %r82, i32 0, i32 2
  %x735 = load ptr, ptr %x734, align 8
  store ptr %x735, ptr %v89, align 8, !dbg !189
  %x737 = load ptr, ptr %v88, align 8
  %x736 = getelementptr [1 x ptr], ptr %args83, i64 0, i64 0, !dbg !191
  store ptr %x737, ptr %x736, align 8, !dbg !191
  call void @lo_op_File_2EPath_2Enew(ptr %context, ptr %args83, i64 1, i64 92, ptr %r83), !dbg !191
  %x738 = getelementptr %lo.result, ptr %r83, i32 0, i32 0
  %x739 = load i32, ptr %x738, align 4, !dbg !191
  switch i32 %x739, label %b19 [ i32 0, label %b334 i32 1, label %b19 i32 2, label %b335 ], !dbg !191
b331:
  %x740 = call i1 @lo_result_transfer(ptr %out, ptr %r82, ptr %v89), !dbg !27
  br i1 %x740, label %b3, label %b19, !dbg !27
b334:
  %x741 = getelementptr %lo.result, ptr %r83, i32 0, i32 2
  %x742 = load ptr, ptr %x741, align 8
  store ptr %x742, ptr %v90, align 8, !dbg !191
  %x744 = load ptr, ptr %v90, align 8
  %x743 = getelementptr [1 x ptr], ptr %args84, i64 0, i64 0, !dbg !193
  store ptr %x744, ptr %x743, align 8, !dbg !193
  call void @lo_charge_value(ptr %context, ptr %args84, i64 1, i64 93, ptr %r84), !dbg !193
  %x745 = getelementptr %lo.result, ptr %r84, i32 0, i32 0
  %x746 = load i32, ptr %x745, align 4, !dbg !193
  switch i32 %x746, label %b19 [ i32 0, label %b338 i32 1, label %b19 i32 2, label %b339 ], !dbg !193
b335:
  %x747 = call i1 @lo_result_transfer(ptr %out, ptr %r83, ptr %v90), !dbg !27
  br i1 %x747, label %b3, label %b19, !dbg !27
b338:
  %x748 = getelementptr %lo.result, ptr %r84, i32 0, i32 2
  %x749 = load ptr, ptr %x748, align 8
  store ptr %x749, ptr %v91, align 8, !dbg !193
  call void @lo_step(ptr %context, ptr null, i64 0, i64 94, ptr %r85), !dbg !195
  %x750 = getelementptr %lo.result, ptr %r85, i32 0, i32 0
  %x751 = load i32, ptr %x750, align 4, !dbg !195
  switch i32 %x751, label %b19 [ i32 0, label %b342 i32 1, label %b19 i32 2, label %b343 ], !dbg !195
b339:
  %x752 = call i1 @lo_result_transfer(ptr %out, ptr %r84, ptr %v91), !dbg !27
  br i1 %x752, label %b3, label %b19, !dbg !27
b342:
  %x753 = getelementptr %lo.result, ptr %r85, i32 0, i32 2
  %x754 = load ptr, ptr %x753, align 8
  store ptr %x754, ptr %v92, align 8, !dbg !195
  call void @lo_step(ptr %context, ptr null, i64 0, i64 95, ptr %r86), !dbg !197
  %x755 = getelementptr %lo.result, ptr %r86, i32 0, i32 0
  %x756 = load i32, ptr %x755, align 4, !dbg !197
  switch i32 %x756, label %b19 [ i32 0, label %b346 i32 1, label %b19 i32 2, label %b347 ], !dbg !197
b343:
  %x757 = call i1 @lo_result_transfer(ptr %out, ptr %r85, ptr %v92), !dbg !27
  br i1 %x757, label %b3, label %b19, !dbg !27
b346:
  %x758 = getelementptr %lo.result, ptr %r86, i32 0, i32 2
  %x759 = load ptr, ptr %x758, align 8
  store ptr %x759, ptr %v93, align 8, !dbg !197
  call void @lo_literal(ptr %context, ptr null, i64 0, i64 96, ptr %r87), !dbg !199
  %x760 = getelementptr %lo.result, ptr %r87, i32 0, i32 0
  %x761 = load i32, ptr %x760, align 4, !dbg !199
  switch i32 %x761, label %b19 [ i32 0, label %b350 i32 1, label %b19 i32 2, label %b351 ], !dbg !199
b347:
  %x762 = call i1 @lo_result_transfer(ptr %out, ptr %r86, ptr %v93), !dbg !27
  br i1 %x762, label %b3, label %b19, !dbg !27
b350:
  %x763 = getelementptr %lo.result, ptr %r87, i32 0, i32 2
  %x764 = load ptr, ptr %x763, align 8
  store ptr %x764, ptr %v94, align 8, !dbg !199
  %x766 = load ptr, ptr %v94, align 8
  %x765 = getelementptr [1 x ptr], ptr %args88, i64 0, i64 0, !dbg !201
  store ptr %x766, ptr %x765, align 8, !dbg !201
  call void @lo_charge_value(ptr %context, ptr %args88, i64 1, i64 97, ptr %r88), !dbg !201
  %x767 = getelementptr %lo.result, ptr %r88, i32 0, i32 0
  %x768 = load i32, ptr %x767, align 4, !dbg !201
  switch i32 %x768, label %b19 [ i32 0, label %b354 i32 1, label %b19 i32 2, label %b355 ], !dbg !201
b351:
  %x769 = call i1 @lo_result_transfer(ptr %out, ptr %r87, ptr %v94), !dbg !27
  br i1 %x769, label %b3, label %b19, !dbg !27
b354:
  %x770 = getelementptr %lo.result, ptr %r88, i32 0, i32 2
  %x771 = load ptr, ptr %x770, align 8
  store ptr %x771, ptr %v95, align 8, !dbg !201
  %x773 = load ptr, ptr %v94, align 8
  %x772 = getelementptr [1 x ptr], ptr %args89, i64 0, i64 0, !dbg !203
  store ptr %x773, ptr %x772, align 8, !dbg !203
  call void @lo_op_Bytes_2Enew(ptr %context, ptr %args89, i64 1, i64 98, ptr %r89), !dbg !203
  %x774 = getelementptr %lo.result, ptr %r89, i32 0, i32 0
  %x775 = load i32, ptr %x774, align 4, !dbg !203
  switch i32 %x775, label %b19 [ i32 0, label %b358 i32 1, label %b19 i32 2, label %b359 ], !dbg !203
b355:
  %x776 = call i1 @lo_result_transfer(ptr %out, ptr %r88, ptr %v95), !dbg !27
  br i1 %x776, label %b3, label %b19, !dbg !27
b358:
  %x777 = getelementptr %lo.result, ptr %r89, i32 0, i32 2
  %x778 = load ptr, ptr %x777, align 8
  store ptr %x778, ptr %v96, align 8, !dbg !203
  %x780 = load ptr, ptr %v96, align 8
  %x779 = getelementptr [1 x ptr], ptr %args90, i64 0, i64 0, !dbg !205
  store ptr %x780, ptr %x779, align 8, !dbg !205
  call void @lo_charge_value(ptr %context, ptr %args90, i64 1, i64 99, ptr %r90), !dbg !205
  %x781 = getelementptr %lo.result, ptr %r90, i32 0, i32 0
  %x782 = load i32, ptr %x781, align 4, !dbg !205
  switch i32 %x782, label %b19 [ i32 0, label %b362 i32 1, label %b19 i32 2, label %b363 ], !dbg !205
b359:
  %x783 = call i1 @lo_result_transfer(ptr %out, ptr %r89, ptr %v96), !dbg !27
  br i1 %x783, label %b3, label %b19, !dbg !27
b362:
  %x784 = getelementptr %lo.result, ptr %r90, i32 0, i32 2
  %x785 = load ptr, ptr %x784, align 8
  store ptr %x785, ptr %v97, align 8, !dbg !205
  %x787 = load ptr, ptr %v90, align 8
  %x786 = getelementptr [2 x ptr], ptr %args91, i64 0, i64 0, !dbg !207
  store ptr %x787, ptr %x786, align 8, !dbg !207
  %x789 = load ptr, ptr %v96, align 8
  %x788 = getelementptr [2 x ptr], ptr %args91, i64 0, i64 1, !dbg !207
  store ptr %x789, ptr %x788, align 8, !dbg !207
  call void @lo_op_File_2EWrite_2Enew(ptr %context, ptr %args91, i64 2, i64 100, ptr %r91), !dbg !207
  %x790 = getelementptr %lo.result, ptr %r91, i32 0, i32 0
  %x791 = load i32, ptr %x790, align 4, !dbg !207
  switch i32 %x791, label %b19 [ i32 0, label %b366 i32 1, label %b19 i32 2, label %b367 ], !dbg !207
b363:
  %x792 = call i1 @lo_result_transfer(ptr %out, ptr %r90, ptr %v97), !dbg !27
  br i1 %x792, label %b3, label %b19, !dbg !27
b366:
  %x793 = getelementptr %lo.result, ptr %r91, i32 0, i32 2
  %x794 = load ptr, ptr %x793, align 8
  store ptr %x794, ptr %v98, align 8, !dbg !207
  %x796 = load ptr, ptr %v98, align 8
  %x795 = getelementptr [1 x ptr], ptr %args92, i64 0, i64 0, !dbg !209
  store ptr %x796, ptr %x795, align 8, !dbg !209
  call void @lo_charge_value(ptr %context, ptr %args92, i64 1, i64 101, ptr %r92), !dbg !209
  %x797 = getelementptr %lo.result, ptr %r92, i32 0, i32 0
  %x798 = load i32, ptr %x797, align 4, !dbg !209
  switch i32 %x798, label %b19 [ i32 0, label %b370 i32 1, label %b19 i32 2, label %b371 ], !dbg !209
b367:
  %x799 = call i1 @lo_result_transfer(ptr %out, ptr %r91, ptr %v98), !dbg !27
  br i1 %x799, label %b3, label %b19, !dbg !27
b370:
  %x800 = getelementptr %lo.result, ptr %r92, i32 0, i32 2
  %x801 = load ptr, ptr %x800, align 8
  store ptr %x801, ptr %v99, align 8, !dbg !209
  call void @lo_step(ptr %context, ptr null, i64 0, i64 102, ptr %r93), !dbg !211
  %x802 = getelementptr %lo.result, ptr %r93, i32 0, i32 0
  %x803 = load i32, ptr %x802, align 4, !dbg !211
  switch i32 %x803, label %b19 [ i32 0, label %b374 i32 1, label %b19 i32 2, label %b375 ], !dbg !211
b371:
  %x804 = call i1 @lo_result_transfer(ptr %out, ptr %r92, ptr %v99), !dbg !27
  br i1 %x804, label %b3, label %b19, !dbg !27
b374:
  %x805 = getelementptr %lo.result, ptr %r93, i32 0, i32 2
  %x806 = load ptr, ptr %x805, align 8
  store ptr %x806, ptr %v100, align 8, !dbg !211
  call void @lo_step(ptr %context, ptr null, i64 0, i64 103, ptr %r94), !dbg !213
  %x807 = getelementptr %lo.result, ptr %r94, i32 0, i32 0
  %x808 = load i32, ptr %x807, align 4, !dbg !213
  switch i32 %x808, label %b19 [ i32 0, label %b378 i32 1, label %b19 i32 2, label %b379 ], !dbg !213
b375:
  %x809 = call i1 @lo_result_transfer(ptr %out, ptr %r93, ptr %v100), !dbg !27
  br i1 %x809, label %b3, label %b19, !dbg !27
b378:
  %x810 = getelementptr %lo.result, ptr %r94, i32 0, i32 2
  %x811 = load ptr, ptr %x810, align 8
  store ptr %x811, ptr %v101, align 8, !dbg !213
  %x812 = load ptr, ptr %v98, align 8
  call void @lo_value_retain(ptr %x812), !dbg !215
  store ptr %x812, ptr %v102, align 8, !dbg !215
  %x814 = load ptr, ptr %v102, align 8
  %x813 = getelementptr [1 x ptr], ptr %args95, i64 0, i64 0, !dbg !217
  store ptr %x814, ptr %x813, align 8, !dbg !217
  call void @lo_charge_value(ptr %context, ptr %args95, i64 1, i64 105, ptr %r95), !dbg !217
  %x815 = getelementptr %lo.result, ptr %r95, i32 0, i32 0
  %x816 = load i32, ptr %x815, align 4, !dbg !217
  switch i32 %x816, label %b19 [ i32 0, label %b382 i32 1, label %b19 i32 2, label %b383 ], !dbg !217
b379:
  %x817 = call i1 @lo_result_transfer(ptr %out, ptr %r94, ptr %v101), !dbg !27
  br i1 %x817, label %b3, label %b19, !dbg !27
b382:
  %x818 = getelementptr %lo.result, ptr %r95, i32 0, i32 2
  %x819 = load ptr, ptr %x818, align 8
  store ptr %x819, ptr %v103, align 8, !dbg !217
  %x821 = load ptr, ptr %v102, align 8
  %x820 = getelementptr [1 x ptr], ptr %args96, i64 0, i64 0, !dbg !219
  store ptr %x821, ptr %x820, align 8, !dbg !219
  call void @lo_commit(ptr %context, ptr %args96, i64 1, i64 106, ptr %r96), !dbg !219
  %x822 = getelementptr %lo.result, ptr %r96, i32 0, i32 0
  %x823 = load i32, ptr %x822, align 4, !dbg !219
  switch i32 %x823, label %b19 [ i32 0, label %b386 i32 1, label %b387 i32 2, label %b387 ], !dbg !219
b383:
  %x824 = call i1 @lo_result_transfer(ptr %out, ptr %r95, ptr %v103), !dbg !27
  br i1 %x824, label %b3, label %b19, !dbg !27
b386:
  %x825 = getelementptr %lo.result, ptr %r96, i32 0, i32 2
  %x826 = load ptr, ptr %x825, align 8
  store ptr %x826, ptr %v104, align 8, !dbg !219
  call void @lo_step(ptr %context, ptr null, i64 0, i64 107, ptr %r97), !dbg !221
  %x827 = getelementptr %lo.result, ptr %r97, i32 0, i32 0
  %x828 = load i32, ptr %x827, align 4, !dbg !221
  switch i32 %x828, label %b19 [ i32 0, label %b390 i32 1, label %b19 i32 2, label %b391 ], !dbg !221
b387:
  %x829 = call i1 @lo_result_transfer(ptr %out, ptr %r96, ptr %v104), !dbg !27
  br i1 %x829, label %b3, label %b19, !dbg !27
b390:
  %x830 = getelementptr %lo.result, ptr %r97, i32 0, i32 2
  %x831 = load ptr, ptr %x830, align 8
  store ptr %x831, ptr %v105, align 8, !dbg !221
  call void @lo_step(ptr %context, ptr null, i64 0, i64 108, ptr %r98), !dbg !223
  %x832 = getelementptr %lo.result, ptr %r98, i32 0, i32 0
  %x833 = load i32, ptr %x832, align 4, !dbg !223
  switch i32 %x833, label %b19 [ i32 0, label %b394 i32 1, label %b19 i32 2, label %b395 ], !dbg !223
b391:
  %x834 = call i1 @lo_result_transfer(ptr %out, ptr %r97, ptr %v105), !dbg !27
  br i1 %x834, label %b3, label %b19, !dbg !27
b394:
  %x835 = getelementptr %lo.result, ptr %r98, i32 0, i32 2
  %x836 = load ptr, ptr %x835, align 8
  store ptr %x836, ptr %v106, align 8, !dbg !223
  call void @lo_step(ptr %context, ptr null, i64 0, i64 109, ptr %r99), !dbg !225
  %x837 = getelementptr %lo.result, ptr %r99, i32 0, i32 0
  %x838 = load i32, ptr %x837, align 4, !dbg !225
  switch i32 %x838, label %b19 [ i32 0, label %b398 i32 1, label %b19 i32 2, label %b399 ], !dbg !225
b395:
  %x839 = call i1 @lo_result_transfer(ptr %out, ptr %r98, ptr %v106), !dbg !27
  br i1 %x839, label %b3, label %b19, !dbg !27
b398:
  %x840 = getelementptr %lo.result, ptr %r99, i32 0, i32 2
  %x841 = load ptr, ptr %x840, align 8
  store ptr %x841, ptr %v107, align 8, !dbg !225
  %x842 = load ptr, ptr %v82, align 8
  call void @lo_value_retain(ptr %x842), !dbg !227
  store ptr %x842, ptr %v108, align 8, !dbg !227
  %x844 = load ptr, ptr %v108, align 8
  %x843 = getelementptr [1 x ptr], ptr %args100, i64 0, i64 0, !dbg !229
  store ptr %x844, ptr %x843, align 8, !dbg !229
  call void @lo_charge_value(ptr %context, ptr %args100, i64 1, i64 111, ptr %r100), !dbg !229
  %x845 = getelementptr %lo.result, ptr %r100, i32 0, i32 0
  %x846 = load i32, ptr %x845, align 4, !dbg !229
  switch i32 %x846, label %b19 [ i32 0, label %b402 i32 1, label %b19 i32 2, label %b403 ], !dbg !229
b399:
  %x847 = call i1 @lo_result_transfer(ptr %out, ptr %r99, ptr %v107), !dbg !27
  br i1 %x847, label %b3, label %b19, !dbg !27
b402:
  %x848 = getelementptr %lo.result, ptr %r100, i32 0, i32 2
  %x849 = load ptr, ptr %x848, align 8
  store ptr %x849, ptr %v109, align 8, !dbg !229
  %x851 = load ptr, ptr %v108, align 8
  %x850 = getelementptr [1 x ptr], ptr %args101, i64 0, i64 0, !dbg !231
  store ptr %x851, ptr %x850, align 8, !dbg !231
  call void @lo_convert_success(ptr %context, ptr %args101, i64 1, i64 112, ptr %r101), !dbg !231
  %x852 = getelementptr %lo.result, ptr %r101, i32 0, i32 0
  %x853 = load i32, ptr %x852, align 4, !dbg !231
  switch i32 %x853, label %b19 [ i32 0, label %b406 i32 1, label %b19 i32 2, label %b407 ], !dbg !231
b403:
  %x854 = call i1 @lo_result_transfer(ptr %out, ptr %r100, ptr %v109), !dbg !27
  br i1 %x854, label %b3, label %b19, !dbg !27
b406:
  %x855 = getelementptr %lo.result, ptr %r101, i32 0, i32 2
  %x856 = load ptr, ptr %x855, align 8
  store ptr %x856, ptr %v110, align 8, !dbg !231
  %x858 = load ptr, ptr %v110, align 8
  %x857 = getelementptr [1 x ptr], ptr %args102, i64 0, i64 0, !dbg !233
  store ptr %x858, ptr %x857, align 8, !dbg !233
  call void @lo_charge_value(ptr %context, ptr %args102, i64 1, i64 113, ptr %r102), !dbg !233
  %x859 = getelementptr %lo.result, ptr %r102, i32 0, i32 0
  %x860 = load i32, ptr %x859, align 4, !dbg !233
  switch i32 %x860, label %b19 [ i32 0, label %b410 i32 1, label %b19 i32 2, label %b411 ], !dbg !233
b407:
  %x861 = call i1 @lo_result_transfer(ptr %out, ptr %r101, ptr %v110), !dbg !27
  br i1 %x861, label %b3, label %b19, !dbg !27
b410:
  %x862 = getelementptr %lo.result, ptr %r102, i32 0, i32 2
  %x863 = load ptr, ptr %x862, align 8
  store ptr %x863, ptr %v111, align 8, !dbg !233
  %x865 = load ptr, ptr %v110, align 8
  %x864 = getelementptr [1 x ptr], ptr %args103, i64 0, i64 0, !dbg !235
  store ptr %x865, ptr %x864, align 8, !dbg !235
  call void @lo_convert_propagate(ptr %context, ptr %args103, i64 1, i64 114, ptr %r103), !dbg !235
  %x866 = getelementptr %lo.result, ptr %r103, i32 0, i32 0
  %x867 = load i32, ptr %x866, align 4, !dbg !235
  switch i32 %x867, label %b19 [ i32 0, label %b414 i32 1, label %b414 i32 2, label %b414 ], !dbg !235
b411:
  %x868 = call i1 @lo_result_transfer(ptr %out, ptr %r102, ptr %v111), !dbg !27
  br i1 %x868, label %b3, label %b19, !dbg !27
b414:
  %x869 = call i1 @lo_result_transfer(ptr %out, ptr %r103, ptr %v112), !dbg !27
  br i1 %x869, label %b3, label %b19, !dbg !27
b417:
  %x870 = getelementptr %lo.result, ptr %out, i32 0, i32 2
  %x871 = load ptr, ptr %x870, align 8
  call void @lo_value_retain(ptr %x871), !dbg !27
  store ptr %x871, ptr %v113, align 8, !dbg !27
  %x873 = load ptr, ptr %v113, align 8
  %x872 = getelementptr [1 x ptr], ptr %args104, i64 0, i64 0, !dbg !27
  store ptr %x873, ptr %x872, align 8, !dbg !27
  call void @lo_flow_error(ptr %context, i64 0, ptr %args104, i64 1, i64 %callsite, ptr %r104), !dbg !27
  %x874 = getelementptr %lo.result, ptr %r104, i32 0, i32 0
  %x875 = load i32, ptr %x874, align 4, !dbg !27
  switch i32 %x875, label %b14 [ i32 0, label %b14 i32 1, label %b418 i32 2, label %b419 ], !dbg !27
b418:
  %x876 = getelementptr %lo.result, ptr %r104, i32 0, i32 2
  %x877 = load ptr, ptr %x876, align 8
  store ptr %x877, ptr %v114, align 8, !dbg !27
  call void @lo_result_copy_value(ptr %out, ptr %r104), !dbg !27
  br label %b2, !dbg !27
b419:
  %x878 = call i1 @lo_result_transfer(ptr %out, ptr %r104, ptr %v114), !dbg !27
  br i1 %x878, label %b2, label %b14, !dbg !27
}

attributes #0 = { noinline "fp-contract"="off" "frame-pointer"="all" }
attributes #1 = { noinline optnone "fp-contract"="off" "frame-pointer"="all" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3}
!0 = distinct !DICompileUnit(language: DW_LANG_C, file: !1, producer: "Lo lo-native-1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)
!1 = !DIFile(filename: "1674860807.lo", directory: "/Users/tyemirov/Development/Research/Lo/_scratch/build-state/tmp/TestLLVMDeviceResourcesopen-failure2734861830/002")
!2 = !{i32 2, !"Dwarf Version", i32 4}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !DISubroutineType(types: !5)
!5 = !{null}
!6 = distinct !DISubprogram(name: "<top>", linkageName: "lo_entry", scope: !1, file: !1, line: 1, type: !4, scopeLine: 1, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!8 = !DILocation(line: 1, column: 1, scope: !7)
!9 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!10 = !DILocation(line: 1, column: 1, scope: !9)
!11 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!12 = !DILocation(line: 1, column: 233, scope: !11)
!13 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!14 = !DILocation(line: 1, column: 240, scope: !13)
!15 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!16 = !DILocation(line: 1, column: 240, scope: !15)
!17 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!18 = !DILocation(line: 1, column: 240, scope: !17)
!19 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!20 = !DILocation(line: 1, column: 240, scope: !19)
!21 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!22 = !DILocation(line: 1, column: 240, scope: !21)
!23 = !DILexicalBlockFile(scope: !6, file: !1, discriminator: 0)
!24 = !DILocation(line: 1, column: 233, scope: !23)
!25 = distinct !DISubprogram(name: "Main", linkageName: "lo_flow_0", scope: !1, file: !1, line: 1, type: !4, scopeLine: 1, spFlags: DISPFlagDefinition, unit: !0)
!26 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!27 = !DILocation(line: 1, column: 1, scope: !26)
!28 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!29 = !DILocation(line: 1, column: 1, scope: !28)
!30 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!31 = !DILocation(line: 1, column: 1, scope: !30)
!32 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!33 = !DILocation(line: 1, column: 29, scope: !32)
!34 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!35 = !DILocation(line: 1, column: 31, scope: !34)
!36 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!37 = !DILocation(line: 1, column: 31, scope: !36)
!38 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!39 = !DILocation(line: 1, column: 42, scope: !38)
!40 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!41 = !DILocation(line: 1, column: 51, scope: !40)
!42 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!43 = !DILocation(line: 1, column: 51, scope: !42)
!44 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!45 = !DILocation(line: 1, column: 51, scope: !44)
!46 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!47 = !DILocation(line: 1, column: 55, scope: !46)
!48 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!49 = !DILocation(line: 1, column: 55, scope: !48)
!50 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!51 = !DILocation(line: 1, column: 55, scope: !50)
!52 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!53 = !DILocation(line: 1, column: 59, scope: !52)
!54 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!55 = !DILocation(line: 1, column: 59, scope: !54)
!56 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!57 = !DILocation(line: 1, column: 59, scope: !56)
!58 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!59 = !DILocation(line: 1, column: 42, scope: !58)
!60 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!61 = !DILocation(line: 1, column: 42, scope: !60)
!62 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!63 = !DILocation(line: 1, column: 64, scope: !62)
!64 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!65 = !DILocation(line: 1, column: 73, scope: !64)
!66 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!67 = !DILocation(line: 1, column: 73, scope: !66)
!68 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!69 = !DILocation(line: 1, column: 73, scope: !68)
!70 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!71 = !DILocation(line: 1, column: 64, scope: !70)
!72 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!73 = !DILocation(line: 1, column: 64, scope: !72)
!74 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!75 = !DILocation(line: 1, column: 31, scope: !74)
!76 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!77 = !DILocation(line: 1, column: 31, scope: !76)
!78 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!79 = !DILocation(line: 1, column: 31, scope: !78)
!80 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!81 = !DILocation(line: 1, column: 31, scope: !80)
!82 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!83 = !DILocation(line: 1, column: 31, scope: !82)
!84 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!85 = !DILocation(line: 1, column: 31, scope: !84)
!86 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!87 = !DILocation(line: 1, column: 77, scope: !86)
!88 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!89 = !DILocation(line: 1, column: 79, scope: !88)
!90 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!91 = !DILocation(line: 1, column: 79, scope: !90)
!92 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!93 = !DILocation(line: 1, column: 89, scope: !92)
!94 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!95 = !DILocation(line: 1, column: 89, scope: !94)
!96 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!97 = !DILocation(line: 1, column: 89, scope: !96)
!98 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!99 = !DILocation(line: 1, column: 91, scope: !98)
!100 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!101 = !DILocation(line: 1, column: 91, scope: !100)
!102 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!103 = !DILocation(line: 1, column: 102, scope: !102)
!104 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!105 = !DILocation(line: 1, column: 102, scope: !104)
!106 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!107 = !DILocation(line: 1, column: 102, scope: !106)
!108 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!109 = !DILocation(line: 1, column: 91, scope: !108)
!110 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!111 = !DILocation(line: 1, column: 91, scope: !110)
!112 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!113 = !DILocation(line: 1, column: 91, scope: !112)
!114 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!115 = !DILocation(line: 1, column: 91, scope: !114)
!116 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!117 = !DILocation(line: 1, column: 91, scope: !116)
!118 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!119 = !DILocation(line: 1, column: 91, scope: !118)
!120 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!121 = !DILocation(line: 1, column: 79, scope: !120)
!122 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!123 = !DILocation(line: 1, column: 79, scope: !122)
!124 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!125 = !DILocation(line: 1, column: 79, scope: !124)
!126 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!127 = !DILocation(line: 1, column: 79, scope: !126)
!128 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!129 = !DILocation(line: 1, column: 79, scope: !128)
!130 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!131 = !DILocation(line: 1, column: 79, scope: !130)
!132 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!133 = !DILocation(line: 1, column: 117, scope: !132)
!134 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!135 = !DILocation(line: 1, column: 119, scope: !134)
!136 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!137 = !DILocation(line: 1, column: 119, scope: !136)
!138 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!139 = !DILocation(line: 1, column: 129, scope: !138)
!140 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!141 = !DILocation(line: 1, column: 129, scope: !140)
!142 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!143 = !DILocation(line: 1, column: 129, scope: !142)
!144 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!145 = !DILocation(line: 1, column: 131, scope: !144)
!146 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!147 = !DILocation(line: 1, column: 131, scope: !146)
!148 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!149 = !DILocation(line: 1, column: 142, scope: !148)
!150 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!151 = !DILocation(line: 1, column: 142, scope: !150)
!152 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!153 = !DILocation(line: 1, column: 142, scope: !152)
!154 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!155 = !DILocation(line: 1, column: 131, scope: !154)
!156 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!157 = !DILocation(line: 1, column: 131, scope: !156)
!158 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!159 = !DILocation(line: 1, column: 131, scope: !158)
!160 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!161 = !DILocation(line: 1, column: 131, scope: !160)
!162 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!163 = !DILocation(line: 1, column: 131, scope: !162)
!164 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!165 = !DILocation(line: 1, column: 131, scope: !164)
!166 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!167 = !DILocation(line: 1, column: 119, scope: !166)
!168 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!169 = !DILocation(line: 1, column: 119, scope: !168)
!170 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!171 = !DILocation(line: 1, column: 119, scope: !170)
!172 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!173 = !DILocation(line: 1, column: 119, scope: !172)
!174 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!175 = !DILocation(line: 1, column: 119, scope: !174)
!176 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!177 = !DILocation(line: 1, column: 119, scope: !176)
!178 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!179 = !DILocation(line: 1, column: 150, scope: !178)
!180 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!181 = !DILocation(line: 1, column: 155, scope: !180)
!182 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!183 = !DILocation(line: 1, column: 170, scope: !182)
!184 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!185 = !DILocation(line: 1, column: 184, scope: !184)
!186 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!187 = !DILocation(line: 1, column: 184, scope: !186)
!188 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!189 = !DILocation(line: 1, column: 184, scope: !188)
!190 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!191 = !DILocation(line: 1, column: 170, scope: !190)
!192 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!193 = !DILocation(line: 1, column: 170, scope: !192)
!194 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!195 = !DILocation(line: 1, column: 193, scope: !194)
!196 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!197 = !DILocation(line: 1, column: 203, scope: !196)
!198 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!199 = !DILocation(line: 1, column: 203, scope: !198)
!200 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!201 = !DILocation(line: 1, column: 203, scope: !200)
!202 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!203 = !DILocation(line: 1, column: 193, scope: !202)
!204 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!205 = !DILocation(line: 1, column: 193, scope: !204)
!206 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!207 = !DILocation(line: 1, column: 155, scope: !206)
!208 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!209 = !DILocation(line: 1, column: 155, scope: !208)
!210 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!211 = !DILocation(line: 1, column: 211, scope: !210)
!212 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!213 = !DILocation(line: 1, column: 211, scope: !212)
!214 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!215 = !DILocation(line: 1, column: 211, scope: !214)
!216 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!217 = !DILocation(line: 1, column: 211, scope: !216)
!218 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!219 = !DILocation(line: 1, column: 211, scope: !218)
!220 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!221 = !DILocation(line: 1, column: 223, scope: !220)
!222 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!223 = !DILocation(line: 1, column: 230, scope: !222)
!224 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!225 = !DILocation(line: 1, column: 230, scope: !224)
!226 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!227 = !DILocation(line: 1, column: 230, scope: !226)
!228 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!229 = !DILocation(line: 1, column: 230, scope: !228)
!230 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!231 = !DILocation(line: 1, column: 230, scope: !230)
!232 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!233 = !DILocation(line: 1, column: 230, scope: !232)
!234 = !DILexicalBlockFile(scope: !25, file: !1, discriminator: 0)
!235 = !DILocation(line: 1, column: 223, scope: !234)
