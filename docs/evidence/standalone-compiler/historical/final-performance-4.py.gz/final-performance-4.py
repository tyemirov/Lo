from pathlib import Path
import json, subprocess, sys
root=Path.cwd().resolve()
base=root/'_scratch/i011-20261020/final-performance-4'
base.mkdir()
reports={target:[] for target in ('darwin','linux')}
for lane in ('execution','process','http','build'):
 for target in ('darwin','linux'):
  work=base/(target+'-'+lane)
  command=['make','-s','benchmark-standalone' if target=='darwin' else 'benchmark-native-linux',
   'NATIVE_BENCH_WORK='+str(work),'NATIVE_BENCH_LANE='+lane,'COMPILER_DISTRIBUTION_OUTPUT=bin/distributions',
   'NATIVE_BENCH_COMPILER=bin/distributions/lo-darwin-arm64-software/bin/lo',
   'SEMANTIC_COMPILER=bin/distributions/lo-darwin-arm64-software/bin/lo','LINUX_ACCELERATOR=hvf']
  print('START '+target+' '+lane,flush=True)
  with (base/(target+'-'+lane+'.stdout')).open('wb') as stdout,(base/(target+'-'+lane+'.stderr')).open('wb') as stderr:
   status=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr).returncode
  report=work/'report.json'
  if not report.is_file():raise SystemExit(f'{target}:{lane} no report; status {status}')
  result=json.loads(report.read_text())
  print(json.dumps({'target':target,'lane':lane,'status':status,'measurement_complete':result.get('measurement_complete'),'error':result.get('measurement_error'),'gate_failures':result.get('gate_failures'),'callback_speedup':result.get('callback_speedup'),'callback_ci':result.get('callback_bootstrap_95_percent')}),flush=True)
  if status or not result.get('measurement_complete') or not result.get('gates_passed'):
   raise SystemExit(f'{target}:{lane} failed qualification')
  reports[target].append(report)
for target,paths in reports.items():
 command=[sys.executable,'-B','tools/nativebench/merge.py','--output',str(base/(target+'-merged.json'))]
 for path in paths:command.extend(['--report',str(path)])
 subprocess.run(command,stdin=subprocess.DEVNULL,check=True)
print('Both complete target performance contracts passed.',flush=True)
