"""Select completed attempt8 evidence; retain the existing preservation index intact."""
from pathlib import Path
import hashlib
import json
import sys

root = Path(__file__).resolve().parents[2]
base = root / '_scratch/i011-20261020'
audit_path = base / 'final-evidence-audit-8.json'
audit = json.loads(audit_path.read_text())
if audit.get('audit_status') != 'all_required_evidence_complete' or audit.get('attempt') != 8:
    raise SystemExit('Attempt8 final evidence audit has not passed')
quiet = json.loads((base / 'quiet-host-summary-8.json').read_text())
if quiet.get('passed') is not True or quiet.get('complete') is not True:
    raise SystemExit('Quiet-host attempt8 environment receipt has not passed')
initial = sys.argv[1:] == ['--initial']
if sys.argv[1:] not in ([], ['--initial']):
    raise SystemExit('Only --initial is supported')
groups = {
    'Final attempt8 orchestration and quiet-host environment, with original freeze7 identities.': [
        'final-validation-8.py', 'final-performance-5.py', 'quiet-host.py', 'quiet-host-plan-8.json',
        'quiet-host-trace-8.jsonl', 'quiet-host-summary-8.json', 'final-validation-8.log',
        'final-validation-status-8.json', 'final-driver-exit-8.json', 'frozen-inputs-7.json',
        'freeze-verify-8-start.log', 'freeze-verify-8-performance.log', 'freeze-verify-8-complete.log',
        'freeze-record-7.log', 'final-architecture-source-review-7.json',
        'final-architecture-orchestration-review-8.json', 'final-architecture-completion-review.json',
        'final-evidence-audit-8.json', 'fixtures/final-evidence-audit-8.py', 'prepare-final-preservation-8.py',
        'final-package-build-7.log', 'final-performance-5.stdout', 'final-performance-5.stderr',
    ],
    'Final CI and component checks for the original freeze7 source and packages.': [
        'final-ci.stdout', 'final-ci.stderr', 'final-component-tools-7.log', 'final-component-tools-7.stderr',
    ],
    'Complete semantic evidence for the interpreter and both LLVM targets on original freeze7.': [
        'final-semantic-report.json', 'final-corpus-7/darwin/semantic-interpreter.jsonl',
        'final-corpus-7/darwin/semantic-llvm-darwin-arm64.jsonl', 'final-corpus-7/linux/semantic-linux-arm64.jsonl',
        'final-corpus-7/linux/report.json', 'final-linux-corpus-7.log', 'final-linux-corpus-7.stderr',
    ],
    'Final offline matrix with independent artifact execution, both-host XOR, and negative admission cases.': [
        'final-offline-7/validation.json', 'final-offline-7.log', 'final-offline-7.stderr',
    ],
    'Final documentation review and repository checks.': [
        'final-document-review.json', 'final-document-links.json', 'final-repository-checks.json',
        'final-docs-ste.json', 'final-docs-ste-scope.json',
    ],
}
late = {'final-architecture-completion-review.json', 'final-document-review.json', 'final-document-links.json',
        'final-repository-checks.json', 'final-docs-ste.json', 'final-docs-ste-scope.json'}
records = []
for purpose, names in groups.items():
    for name in names:
        if initial and name in late:
            continue
        records.append({'path': str((base / name).relative_to(root)), 'purpose': purpose, 'scope': 'final'})
driver_status = json.loads((base / 'final-validation-status-8.json').read_text())
if not driver_status.get('reviews'):
    raise SystemExit('Driver8 review receipts are absent')
selected = {record['path'] for record in records}
for review in driver_status['reviews']:
    path = (root / review['path']).resolve()
    if not path.is_relative_to(base) or not path.is_file():
        raise SystemExit('Review receipt is absent or outside task: ' + review['path'])
    if hashlib.sha256(path.read_bytes()).hexdigest() != review['sha256']:
        raise SystemExit('Driver8 review receipt digest differs: ' + review['path'])
    if review['path'] not in selected:
        records.append({'path': review['path'], 'purpose': 'Predeclared driver8 review receipt, with the exact digest bound by driver status.',
                        'scope': 'final'})
        selected.add(review['path'])
for target in ('darwin', 'linux'):
    for lane in ('execution', 'process', 'http', 'build'):
        for name in (f'{target}-{lane}/report.json', f'{target}-{lane}.stdout', f'{target}-{lane}.stderr'):
            records.append({'path': str((base / 'final-performance-5' / name).relative_to(root)),
                            'purpose': f'Final attempt8 {target} {lane} whole-lane measurements.', 'scope': 'final'})
    records.append({'path': str((base / 'final-performance-5' / f'{target}-merged.json').relative_to(root)),
                    'purpose': f'Final attempt8 {target} strict whole-lane performance merge.', 'scope': 'final'})
# Existing archives are immutable. Preservation consumes this additional manifest
# and appends records; this selector never rewrites or replaces prior records.
index_path = root / 'docs/evidence/standalone-compiler/preservation-index.json'
index = json.loads(index_path.read_text())
known = {record['source']: record for record in index['records']}
for record in records:
    path = (root / record['path']).resolve()
    if not path.is_relative_to(base) or not path.is_file():
        raise SystemExit('Missing or invalid final evidence: ' + record['path'])
    if record['path'] in known:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != known[record['path']]['sha256']:
            raise SystemExit('Previously preserved evidence changed: ' + record['path'])
destination = base / ('final-evidence-manifest-8-initial.json' if initial else 'final-evidence-manifest-8.json')
with destination.open('x') as output:
    output.write(json.dumps({'issue': 'I011', 'attempt': 8, 'records': records,
                             'prior_preservation_index': {'path': str(index_path.relative_to(root)),
                                 'sha256': hashlib.sha256(index_path.read_bytes()).hexdigest(),
                                 'records_retained': len(index['records'])}}, indent=2) + '\n')
print(json.dumps({'manifest': str(destination.relative_to(root)), 'records': len(records),
                  'prior_records_retained': len(index['records'])}))
