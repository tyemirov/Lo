"""Select complete campaign11 evidence without changing any existing archive."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

root = Path(__file__).resolve().parents[2]
base = root / '_scratch/i011-20261020'
spec = importlib.util.spec_from_file_location('lo_campaign11_preservation_contract', base / 'campaign-contract-11.py')
contract = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = contract
spec.loader.exec_module(contract)
if sys.argv[1:] not in ([], ['--initial']):
    raise SystemExit('Only --initial is supported')
initial = sys.argv[1:] == ['--initial']
audit_path = base / 'final-evidence-audit-11.json'
audit = contract.load(audit_path)
if audit.get('campaign') != 11 or audit.get('audit_status') != 'all_required_evidence_complete':
    raise SystemExit('Campaign11 evidence audit has not passed')
sealed = contract.verify_bindings()
status = contract.load(base / 'final-validation-status-11.json')
if status.get('passed') is not True or status.get('complete') is not True:
    raise SystemExit('Campaign11 did not complete successfully')
records = {}


def add(record: dict, purpose: str, scope: str) -> None:
    path = contract.local(root / record['path'])
    if not path.is_relative_to(base) or not path.is_file() or contract.sha(path) != record['sha256']:
        raise SystemExit('Missing or changed evidence: ' + record['path'])
    # Identity was checked above. A prior seal can repeat current receipts,
    # but its historical classification cannot downgrade final evidence.
    previous = records.get(record['path'])
    if previous is not None and previous['scope'] == 'final':
        return
    records[record['path']] = {'path': record['path'], 'purpose': purpose, 'scope': scope}


for group in ('reused_records', 'orchestration', 'reviews', 'context_records'):
    for record in sealed[group]:
        add(record, 'Final campaign11 bindings and original freeze7 nonperformance evidence.', 'final')
add(sealed['authorization'], 'New explicit human authorization for campaign11.', 'final')
for record in sealed['predecessor_records']:
    add(record, 'Whole prior attempt8/campaign9 history and bindings. No timing lane from these attempts qualifies.', 'historical')
for name in ('campaign-inputs-11.json', 'final-validation-status-11.json', 'final-validation-11.log',
             'final-driver-exit-11.json', 'final-evidence-audit-11.json'):
    add(contract.receipt(base / name), 'Final campaign11 command, audit, and exit receipts.', 'final')
for attempt in status['attempts']:
    identifier = attempt['id']
    definition = next(item for item in contract.plan11()['attempts'] if item['id'] == identifier)
    scope = 'final' if identifier == status['selected_attempt'] else 'historical'
    purpose = 'Complete selected campaign11 timing attempt.' if scope == 'final' else 'Whole CPU-invalidated campaign11 attempt; no timing lane qualifies.'
    for name in (definition['trace'], definition['summary']):
        add(contract.receipt(root / name), purpose, scope)
    for name in (f'performance-attempt-{identifier}.stdout', f'performance-attempt-{identifier}.stderr',
                 f'freeze-verify-11-attempt-{identifier}-before.log', f'freeze-verify-11-attempt-{identifier}-after.log'):
        add(contract.receipt(base / name), purpose, scope)
    directory = root / definition['performance_directory']
    add(contract.receipt(directory / 'runner-outcome.json'), purpose, scope)
    for pattern in ('*.stdout', '*.stderr', '*-merged.json', '*/report.json', '*/partial.json'):
        for path in sorted(directory.glob(pattern)):
            add(contract.receipt(path), purpose, scope)
if not initial:
    for name in ('final-architecture-completion-review-11.json', 'final-document-review-11.json',
                 'final-document-links-11.json', 'final-repository-checks-11.json', 'final-docs-ste-11.json', 'final-docs-ste-scope-11.json'):
        add(contract.receipt(base / name), 'Final producing-agent and independent completion review.', 'final')
index_path = root / 'docs/evidence/standalone-compiler/preservation-index.json'
index = contract.load(index_path)
known = {item['source']: item for item in index['records']}
for name in records:
    if name in known and known[name]['sha256'] != contract.sha(root / name):
        raise SystemExit('Previously preserved evidence changed: ' + name)
destination = base / ('final-evidence-manifest-11-initial.json' if initial else 'final-evidence-manifest-11.json')
with destination.open('x') as output:
    output.write(json.dumps({'issue': 'I011', 'campaign': 11, 'records': list(records.values()),
                             'prior_preservation_index': contract.receipt(index_path),
                             'prior_records_retained': len(index['records'])}, indent=2) + '\n')
print(json.dumps({'manifest': contract.receipt(destination), 'records': len(records), 'prior_records_retained': len(index['records'])}))
