"""Shared read-only campaign11 identity, predecessor, and quiet-trace admission."""
from __future__ import annotations
from datetime import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '_scratch/i011-20261020'
SOURCE = '30456a563ea64716d16e3b0d954338fae144fdde5b66a13f570c31c6bbf501e2'
CPU_INVALID = 'four consecutive noisy-host observations span at least 15 seconds'
ORCHESTRATION = ('final-validation-11.py', 'quiet-host-11.py', 'quiet-host-plan-11.json',
                 'final-performance-8.py', 'final-evidence-audit-11.py', 'prepare-final-preservation-11.py',
                 'seal-performance-campaign-11.py', 'campaign-contract-11.py')
REUSED = ('frozen-inputs-7.json', 'final-ci.stdout', 'final-ci.stderr',
          'final-corpus-7/darwin/semantic-interpreter.jsonl', 'final-corpus-7/darwin/semantic-llvm-darwin-arm64.jsonl',
          'final-corpus-7/linux/semantic-linux-arm64.jsonl', 'final-corpus-7/linux/report.json',
          'final-semantic-report.json', 'final-component-tools-7.log', 'final-component-tools-7.stderr',
          'final-offline-7/validation.json', 'final-offline-7.log', 'final-offline-7.stderr',
          'final-linux-corpus-7.log', 'final-linux-corpus-7.stderr',
          'freeze-verify-8-start.log', 'freeze-verify-8-performance.log', 'freeze-inputs-7.py')
PREDECESSOR = ('final-validation-status-8.json', 'final-driver-exit-8.json', 'final-validation-8.log',
               'quiet-host-plan-8.json', 'quiet-host-summary-8.json', 'quiet-host-trace-8.jsonl',
               'final-performance-5.stdout', 'final-performance-5.stderr')


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def local(path: Path) -> Path:
    value = path.resolve()
    require(value.is_relative_to(ROOT), f'path outside Lo: {path}')
    return value


def load(path: Path) -> dict[str, Any]:
    value = json.loads(local(path).read_text())
    require(isinstance(value, dict), f'expected JSON object: {path}')
    return value


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with local(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


def receipt(path: Path) -> dict[str, str]:
    return {'path': str(local(path).relative_to(ROOT)), 'sha256': sha(path)}


def module(name: str, filename: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, local(BASE / filename))
    require(spec is not None and spec.loader is not None, 'module unavailable: ' + filename)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def plan11() -> dict[str, Any]:
    plan = load(BASE / 'quiet-host-plan-11.json')
    require(plan['campaign'] == 11 and plan['maximum_attempts'] == 2 and plan['source_sha256'] == SOURCE and
            plan['source_freeze'] == '_scratch/i011-20261020/frozen-inputs-7.json', 'campaign/source policy differs')
    require(plan['observation_command'] == ['/bin/ps', '-axo', 'pid=,ppid=,%cpu=,lstart=,comm='] and
            plan['observation_environment'] == {'LC_ALL': 'C'} and plan['sampling_interval_seconds'] == 5 and
            plan['maximum_sampling_gap_seconds'] == 15 and
            plan['violation'] == {'total_unexcluded_cpu_greater_than': 200, 'any_unexcluded_cpu_at_least': 75} and
            plan['admission'] == {'consecutive_valid_samples': 61, 'minimum_span_seconds': 300, 'maximum_wait_seconds': 3600, 'offending_identity_absent': True} and
            plan['during_performance'] == {'consecutive_violations': 4, 'minimum_span_seconds': 15} and
            plan['offending_identity'] == {'pid': 61298, 'start': 'Wed Oct 21 10:40:57 2026'}, 'quiet campaign criteria differ')
    require(plan['attempts'] == [
        {'id': 11, 'performance_directory': '_scratch/i011-20261020/final-performance-8',
         'trace': '_scratch/i011-20261020/quiet-host-trace-11.jsonl', 'summary': '_scratch/i011-20261020/quiet-host-summary-11.json'},
        {'id': 12, 'performance_directory': '_scratch/i011-20261020/final-performance-9',
         'trace': '_scratch/i011-20261020/quiet-host-trace-12.jsonl', 'summary': '_scratch/i011-20261020/quiet-host-summary-12.json'}], 'attempt path inventory differs')
    require(plan['authorization'] == '_scratch/i011-20261020/campaign-authorization-11.json' and
            plan['prior_campaign'] == 9 and plan['required_reviews'] == [
                '_scratch/i011-20261020/quiet-campaign-architecture-11.json',
                '_scratch/i011-20261020/final-architecture-source-review-7.json',
                '_scratch/i011-20261020/final-architecture-orchestration-review-11.json'] and
            plan['context_records'] == [
                '_scratch/i011-20261020/generated-assets-restoration-11.json',
                '_scratch/i011-20261020/preflight-restored-freeze-11.log',
                '_scratch/i011-20261020/preflight-nonperformance-11.json'], 'authorization/review/context policy differs')
    authorization = load(ROOT / plan['authorization'])
    require(authorization.get('campaign') == 11 and authorization.get('prior_campaign') == 9 and
            authorization.get('origin') == 'Direct user request in this conversation' and
            authorization.get('automatic_retry_of_prior_campaign') is False and bool(authorization.get('request')),
            'new explicit campaign authorization is absent')
    return plan


def validate_quiet(summary_path: Path, plan: dict[str, Any], *, cpu_rejection: bool = False) -> dict[str, Any]:
    quiet = load(summary_path)
    require(quiet.get('complete') is True and quiet.get('admitted') is True, 'quiet receipt incomplete')
    if cpu_rejection:
        require(quiet.get('passed') is False and quiet.get('invalid_reason') == CPU_INVALID,
                'attempt is not a CPU-load rejection')
    else:
        require(quiet.get('passed') is True and quiet.get('invalid_reason') is None and quiet.get('benchmark_status') == 0,
                'quiet environment is invalid or benchmark failed')
    plan_path = local(ROOT / quiet['plan'])
    require(load(plan_path) == plan and quiet['plan_sha256'] == sha(plan_path), 'quiet plan identity differs')
    trace_path = local(ROOT / quiet['trace'])
    records = [json.loads(line) for line in trace_path.read_text().splitlines()]
    require(quiet['trace_sha256'] == sha(trace_path), 'quiet trace digest differs')
    errors = [record for record in records if 'error' in record]
    trace = [record for record in records if 'error' not in record]
    require(bool(trace) and len(trace) == quiet['samples'], 'quiet trace inventory differs')
    require((len(errors) == 1 and records[-1] is errors[0] and errors[0]['error'] == CPU_INVALID) if cpu_rejection else not errors,
            'quiet trace contains an observation failure or unexpected error')
    driver_identity = quiet['driver']
    known = {driver_identity['pid']: driver_identity['start']}
    last = None
    last_utc = None
    valid_since = None
    valid_since_utc = None
    valid_count = 0
    violation_since = None
    violation_since_utc = None
    violation_count = 0
    admitted_time = quiet['admission_evidence']['admitted_monotonic_seconds']
    admitted_utc = datetime.fromisoformat(quiet['admission_evidence']['admitted_timestamp_utc']).timestamp()
    monitor_start = quiet['started_monotonic_seconds']
    monitor_start_utc = datetime.fromisoformat(quiet['started_timestamp_utc']).timestamp()
    performance_observations = 0
    admitted = False
    cpu_invalidated = False
    for sample in trace:
        moment = sample['monotonic_seconds']
        observed_utc = datetime.fromisoformat(sample['timestamp_utc'])
        require(observed_utc.tzinfo is not None and observed_utc.utcoffset().total_seconds() == 0, 'quiet observation timestamp is not UTC')
        utc_seconds = observed_utc.timestamp()
        require(type(moment) in (int, float) and math.isfinite(moment) and moment >= monitor_start and utc_seconds >= monitor_start_utc and
                (last is None or 0 <= moment - last <= 15) and
                (last_utc is None or 0 <= utc_seconds - last_utc <= 15), 'quiet monotonic or UTC observation clock reversed or sampling gap exceeds 15 seconds')
        rows = sample['processes']
        require(rows and all(set(row) == {'pid', 'ppid', 'cpu_percent', 'start', 'basename'} for row in rows),
                'quiet process observation fields differ')
        present = {row['pid']: row for row in rows}
        require(len(present) == len(rows) and driver_identity['pid'] in present and
                present[driver_identity['pid']]['start'] == driver_identity['start'], 'quiet driver identity differs')
        known = {pid: start for pid, start in known.items() if pid in present and present[pid]['start'] == start}
        changed = True
        while changed:
            changed = False
            for row in rows:
                require(type(row['pid']) is int and row['pid'] > 0 and type(row['ppid']) is int and row['ppid'] >= 0 and
                        type(row['cpu_percent']) in (int, float) and math.isfinite(row['cpu_percent']) and row['cpu_percent'] >= 0 and
                        bool(row['start']) and bool(row['basename']) and '/' not in row['basename'], 'malformed quiet process fields')
                if row['ppid'] in known and row['pid'] not in known:
                    known[row['pid']] = row['start']
                    changed = True
        require(sample['excluded'] == [{'pid': pid, 'start': start} for pid, start in sorted(known.items())],
                'quiet exclusion exceeds recorded driver descendants')
        other = [row for row in rows if known.get(row['pid']) != row['start']]
        total = sum(row['cpu_percent'] for row in other)
        peak = max((row['cpu_percent'] for row in other), default=0)
        violation = total > 200 or peak >= 75
        offender = plan.get('offending_identity')
        offender_present = bool(offender) and any(row['pid'] == offender['pid'] and row['start'] == offender['start'] for row in rows)
        if offender:
            require(sample.get('offending_identity_present') is offender_present, 'offender identity observation differs')
        require(sample['unexcluded_cpu_total'] == total and sample['unexcluded_cpu_maximum'] == peak and
                sample['violation'] is violation, 'quiet raw CPU facts differ')
        if not admitted:
            require(sample['phase'] == 'admission', 'quiet admission phase differs')
            if violation or offender_present:
                valid_count, valid_since, valid_since_utc = 0, None, None
            else:
                valid_since = moment if valid_since is None else valid_since
                valid_since_utc = utc_seconds if valid_since_utc is None else valid_since_utc
                valid_count += 1
                if moment == admitted_time:
                    require(valid_count >= plan['admission']['consecutive_valid_samples'] and moment - valid_since >= plan['admission']['minimum_span_seconds'] and utc_seconds - valid_since_utc >= plan['admission']['minimum_span_seconds'] and
                            utc_seconds == admitted_utc and quiet['admission_evidence']['consecutive_valid_samples'] == valid_count and
                            quiet['admission_evidence']['span_seconds'] == moment - valid_since and
                            quiet['admission_evidence']['span_utc_seconds'] == utc_seconds - valid_since_utc, 'quiet admission sample envelope differs')
                    admitted = True
        else:
            require(sample['phase'] == 'performance', 'quiet performance phase differs')
            performance_observations += 1
            if violation:
                violation_since = moment if violation_since is None else violation_since
                violation_since_utc = utc_seconds if violation_since_utc is None else violation_since_utc
                violation_count += 1
                if violation_count >= 4 and (moment - violation_since >= 15 or utc_seconds - violation_since_utc >= 15):
                    cpu_invalidated = True
                    require(cpu_rejection and sample is trace[-1], 'quiet host invalidated this attempt')
            else:
                violation_count, violation_since, violation_since_utc = 0, None, None
        last = moment
        last_utc = utc_seconds
    require(admitted, 'quiet trace does not prove admission')
    require(0 <= admitted_time - monitor_start <= 3600 and 0 <= admitted_utc - monitor_start_utc <= 3600,
            'quiet admission exceeds declared monotonic or UTC maximum wait')
    require(performance_observations >= 1, 'quiet trace lacks a performance-phase observation')
    completion_moment = quiet['completion_monotonic_seconds']
    completion_utc = datetime.fromisoformat(quiet['completion_timestamp_utc'])
    require(completion_utc.tzinfo is not None and completion_utc.utcoffset().total_seconds() == 0 and
            type(completion_moment) in (int, float) and math.isfinite(completion_moment) and
            completion_moment >= last and completion_utc.timestamp() >= last_utc,
            'quiet observation-to-completion clock reversed')
    if cpu_rejection:
        require(cpu_invalidated, 'CPU rejection lacks four sustained violating observations')
    else:
        require(not cpu_invalidated and completion_moment - last <= 15 and completion_utc.timestamp() - last_utc <= 15,
                'quiet observation-to-completion gap exceeds 15 seconds')
    return {'summary': receipt(summary_path), 'trace': receipt(trace_path), 'driver': driver_identity,
            'attempt': quiet['attempt'], 'samples': quiet['samples'], 'cpu_rejection': cpu_rejection}



def predecessor() -> dict[str, Any]:
    status = load(BASE / 'final-validation-status-8.json')
    require(status.get('running') == [] and all(status.get('statuses', {}).get(name) == 0
            for name in ('offline', 'ci', 'linux-corpus', 'component-tools')),
            'attempt8 nonperformance evidence incomplete or failed')
    require(type(status['statuses'].get('performance')) is int and status['statuses']['performance'] != 0,
            'attempt8 must finish rejected before campaign11')
    exit_receipt = load(BASE / 'final-driver-exit-8.json')
    require(exit_receipt.get('driver') == '_scratch/i011-20261020/final-validation-8.py' and
            type(exit_receipt.get('observed_exit_status')) is int and exit_receipt['observed_exit_status'] != 0 and
            exit_receipt.get('current_lane_completed') is True and exit_receipt.get('accepted_performance_lanes') == [] and
            exit_receipt.get('nonperformance_statuses') == {'offline': 0, 'ci': 0, 'linux-corpus': 0, 'component-tools': 0} and
            exit_receipt.get('invalid_reason') == CPU_INVALID, 'attempt8 root exit receipt is absent or not rejected')
    require(status.get('source_freeze') == '_scratch/i011-20261020/frozen-inputs-7.json' and
            status.get('quiet_plan') == receipt(BASE / 'quiet-host-plan-8.json'), 'attempt8 binding differs')
    for name, expected in status['orchestration_inputs'].items():
        require(sha(ROOT / name) == expected, 'original attempt8 orchestration changed: ' + name)
    for review in status['reviews']:
        require(review == receipt(ROOT / review['path']), 'original attempt8 review changed')
    plan = load(BASE / 'quiet-host-plan-8.json')
    require(plan['attempt'] == 8 and plan['source_sha256'] == SOURCE, 'attempt8 source identity differs')
    result = validate_quiet(BASE / 'quiet-host-summary-8.json', plan, cpu_rejection=True)
    require(result['attempt'] == 8, 'predecessor attempt identity differs')
    return result


PRIOR_CAMPAIGN = ('campaign-inputs-9.json', 'final-validation-status-9.json', 'final-driver-exit-9.json',
                  'final-validation-9.log', 'final-validation-9.stderr', 'quiet-host-plan-9.json',
                  'quiet-host-summary-9.json', 'quiet-host-trace-9.jsonl',
                  'freeze-verify-9-after-admission-timeout.log', 'post-admission-bindings-9.json',
                  'admission-completion-review-9.json', 'admission-outcome-9.json')


def predecessor9() -> dict[str, Any]:
    """Admit campaign9 as terminal history, never as retry authorization."""
    previous = module('lo_campaign11_predecessor9', 'campaign-contract-9.py')
    sealed = previous.verify_bindings()
    status = load(BASE / 'final-validation-status-9.json')
    summary = load(BASE / 'quiet-host-summary-9.json')
    exit_record = load(BASE / 'final-driver-exit-9.json')
    reason = 'quiet admission timed out after 3600 seconds on monotonic or UTC clock without the offending identity absent and 61 valid samples over 300 seconds'
    require(status.get('campaign') == 9 and status.get('complete') is True and status.get('passed') is False and
            status.get('selected_attempt') is None and status.get('running') == [] and status.get('error') == reason and
            [item.get('id') for item in status['attempts']] == [9], 'prior campaign9 is not the terminal admission timeout')
    require(summary.get('complete') is True and summary.get('admitted') is False and summary.get('passed') is False and
            summary.get('invalid_reason') == reason and summary.get('trace_sha256') == sha(BASE / 'quiet-host-trace-9.jsonl') and
            summary.get('plan_sha256') == sha(BASE / 'quiet-host-plan-9.json'), 'prior campaign9 quiet identity differs')
    require(status['attempts'][0]['quiet_summary'] == receipt(BASE / 'quiet-host-summary-9.json') and
            status['sealed_inputs'] == receipt(BASE / 'campaign-inputs-9.json') and
            exit_record.get('observed_exit_code') == 1 and exit_record.get('campaign_complete') is True and
            exit_record.get('campaign_passed') is False and exit_record.get('reason') == reason,
            'prior campaign9 exit/bindings differ')
    require(not (BASE / 'final-performance-6').exists() and not (BASE / 'final-performance-7').exists(),
            'prior campaign9 unexpectedly contains timing outputs')
    review = load(BASE / 'admission-completion-review-9.json')
    require(review.get('nonperformance_acceptance_remains_valid') is True and review.get('full_I011_closure_approved') is False,
            'prior outcome review disposition differs')
    for name, expected in review['reviewed_sha256'].items():
        require(sha(ROOT / name) == expected, 'prior campaign9 reviewed evidence changed: ' + name)
    return {'status': receipt(BASE / 'final-validation-status-9.json'),
            'summary': receipt(BASE / 'quiet-host-summary-9.json'),
            'exit': receipt(BASE / 'final-driver-exit-9.json'), 'disposition': 'admission_timeout_no_measurement',
            'nonperformance_summary': sealed['nonperformance_summary']}


def verify_bindings() -> dict[str, Any]:
    plan11()
    sealed = load(BASE / 'campaign-inputs-11.json')
    require(sealed.get('campaign') == 11 and sealed.get('source_sha256') == SOURCE, 'sealed campaign identity differs')
    for group in ('reused_records', 'predecessor_records', 'orchestration', 'reviews', 'context_records'):
        require(sealed.get(group), 'empty campaign bindings: ' + group)
        for record in sealed[group]:
            require(record == receipt(ROOT / record['path']), 'sealed input changed: ' + record['path'])
    require({record['path'] for record in sealed['reused_records']} == {str((BASE / name).relative_to(ROOT)) for name in REUSED},
            'sealed reused record inventory differs')
    require({str((BASE / name).relative_to(ROOT)) for name in PREDECESSOR}.issubset({record['path'] for record in sealed['predecessor_records']}),
            'sealed predecessor receipt inventory incomplete')
    require({record['path'] for record in sealed['orchestration']} == {str((BASE / name).relative_to(ROOT)) for name in ORCHESTRATION},
            'sealed orchestration inventory differs')
    require(set(plan11()['required_reviews']).issubset({record['path'] for record in sealed['reviews']}), 'approach/source reviews missing')
    require(sealed.get('authorization') == receipt(ROOT / plan11()['authorization']), 'authorization binding differs')
    authorization = load(ROOT / plan11()['authorization'])
    require(authorization.get('campaign') == 11 and authorization.get('prior_campaign') == 9 and
            authorization.get('automatic_retry_of_prior_campaign') is False and bool(authorization.get('request')),
            'new explicit campaign authorization is absent')
    require({record['path'] for record in sealed['context_records']} == set(plan11()['context_records']), 'context inventory differs')
    require({str((BASE / name).relative_to(ROOT)) for name in PRIOR_CAMPAIGN}.issubset(
            {record['path'] for record in sealed['predecessor_records']}), 'prior campaign9 receipt inventory incomplete')
    predecessor()
    prior = predecessor9()
    require(prior['nonperformance_summary'] == sealed['nonperformance_summary'], 'prior nonperformance reuse identity differs')
    return sealed


def retry_allowed(quiet: dict[str, Any], outcome: dict[str, Any]) -> bool:
    """Only a proven first CPU invalidation can open the second attempt."""
    return (quiet.get('complete') is True and quiet.get('admitted') is True and quiet.get('passed') is False and
            quiet.get('invalid_reason') == CPU_INVALID and outcome.get('complete') is True and
            outcome.get('failure_kind') in ('cpu-load', 'passed') and bool(outcome.get('lanes')))


def validate_runner(definition: dict[str, Any], outcome_record: dict[str, str]) -> dict[str, Any]:
    """Admit every completed whole lane, including those in rejected attempts."""
    sys.path.insert(0, str(ROOT / 'tools/nativebench'))
    import merge
    import identity
    directory = local(ROOT / definition['performance_directory'])
    path = directory / 'runner-outcome.json'
    require(outcome_record == receipt(path), 'runner outcome receipt differs')
    outcome = load(path)
    require(outcome.get('campaign') == 11 and outcome.get('attempt') == definition['id'] and outcome.get('complete') is True,
            'runner outcome incomplete or mismatched')
    expected_order = [(target, lane) for lane in ('execution', 'process', 'http', 'build') for target in ('darwin', 'linux')]
    observed = [(item['target'], item['lane']) for item in outcome['lanes']]
    require(observed == expected_order[:len(observed)] and len(observed) <= 8, 'whole-lane prefix order differs')
    for item in outcome['lanes']:
        report_path = directory / f'{item["target"]}-{item["lane"]}/report.json'
        report, record = merge.admit(report_path)
        require(record == item['report'], 'runner whole-lane receipt differs')
        require(record['lanes'] == [item['lane']], 'runner input contains another lane')
        require(report['merge_identity']['source']['semantic_source_sha256'] == SOURCE, 'runner lane source differs')
        identity.verify_source_identity(ROOT, report['merge_identity'])
        package = ROOT / 'bin/distributions' / f'lo-{item["target"]}-arm64-software'
        package_identity, _ = identity.package_provenance(ROOT, package / 'bin/lo', package / 'toolchain.json', item['target'] + '/arm64')
        require(report['merge_identity']['package'] == package_identity, 'runner package identity differs')
        require(item['status'] == (0 if report.get('gates_passed') is True else 1), 'runner gate/status differs')
    if outcome['failure_kind'] == 'passed':
        require(observed == expected_order and all(item['status'] == 0 for item in outcome['lanes']), 'passed runner lacks eight passing lanes')
    return outcome
