"""Observe the predeclared quiet-host contract without changing any process."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import threading
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
COMMAND = ['/bin/ps', '-axo', 'pid=,ppid=,%cpu=,lstart=,comm=']


def local(path: Path) -> Path:
    value = path.resolve()
    if not value.is_relative_to(ROOT):
        raise ValueError(f'quiet-host path outside Lo: {path}')
    return value


def digest(path: Path) -> str:
    return hashlib.sha256(local(path).read_bytes()).hexdigest()


def observation() -> list[dict[str, Any]]:
    result = subprocess.run(COMMAND, cwd=ROOT, stdin=subprocess.DEVNULL,
                            capture_output=True, text=True, timeout=15, check=False, env=dict(os.environ, CI='1', LC_ALL='C'))
    if result.returncode or result.stderr:
        raise ValueError('process observation command failed')
    rows, identities = [], set()
    for line in result.stdout.splitlines():
        fields = line.split(None, 8)
        if len(fields) != 9:
            raise ValueError('malformed process observation')
        pid, ppid = int(fields[0]), int(fields[1])
        cpu = float(fields[2])
        start = ' '.join(fields[3:8])
        datetime.strptime(start, '%a %b %d %H:%M:%S %Y')
        basename = Path(fields[8]).name
        if pid <= 0 or ppid < 0 or not math.isfinite(cpu) or cpu < 0 or not basename or pid in identities:
            raise ValueError('invalid or duplicate process observation')
        identities.add(pid)
        rows.append({'pid': pid, 'ppid': ppid, 'cpu_percent': cpu, 'start': start, 'basename': basename})
    if not rows:
        raise ValueError('empty process observation')
    return rows


class Monitor:
    """Keep admission and ongoing evidence for one recorded driver identity."""

    def __init__(self, driver_pid: int, plan_path: Path, trace_path: Path, summary_path: Path, attempt: int):
        self.plan_path, self.trace_path, self.summary_path = map(local, (plan_path, trace_path, summary_path))
        self.plan_digest = digest(self.plan_path)
        self.plan = json.loads(self.plan_path.read_text())
        if (self.plan['campaign'] != 11 or self.plan['maximum_attempts'] != 2 or attempt not in (11, 12) or
            self.plan['source_sha256'] != '30456a563ea64716d16e3b0d954338fae144fdde5b66a13f570c31c6bbf501e2' or
            self.plan['source_freeze'] != '_scratch/i011-20261020/frozen-inputs-7.json' or
            self.plan['observation_command'] != COMMAND or self.plan['observation_environment'] != {'LC_ALL': 'C'} or
            self.plan['sampling_interval_seconds'] != 5 or self.plan['maximum_sampling_gap_seconds'] != 15 or
            self.plan['violation'] != {'total_unexcluded_cpu_greater_than': 200, 'any_unexcluded_cpu_at_least': 75} or
            self.plan['admission'] != {'consecutive_valid_samples': 61, 'minimum_span_seconds': 300, 'maximum_wait_seconds': 3600, 'offending_identity_absent': True} or
            self.plan['during_performance'] != {'consecutive_violations': 4, 'minimum_span_seconds': 15}):
            raise ValueError('quiet plan differs from the approved contract')
        if self.trace_path.exists() or self.summary_path.exists() or self.summary_path.with_suffix('.writing').exists():
            raise ValueError('quiet evidence paths must be fresh')
        self.attempt = attempt
        self.started = time.monotonic()
        self.started_utc = datetime.now(timezone.utc)
        self.completion_monotonic: float | None = None
        self.completion_utc: str | None = None
        self.driver_pid = driver_pid
        self.driver_start: str | None = None
        self.owned: dict[int, str] = {}
        self.invalid_reason: str | None = None
        self.admitted = False
        self.complete = False
        self.benchmark_status: int | None = None
        self.samples = 0
        self.last_sample: float | None = None
        self.last_sample_utc: float | None = None
        self.valid_since: float | None = None
        self.valid_since_utc: float | None = None
        self.valid_count = 0
        self.violation_since: float | None = None
        self.violation_since_utc: float | None = None
        self.violation_count = 0
        self.admission_evidence: dict[str, Any] | None = None
        self.trace = self.trace_path.open('x')
        self.stop_event = threading.Event()
        self.condition = threading.Condition()
        self.thread = threading.Thread(target=self._run, name='quiet-host-observer', daemon=True)

    def _summary(self) -> dict[str, Any]:
        return {'campaign': 11, 'attempt': self.attempt, 'plan': str(self.plan_path.relative_to(ROOT)), 'plan_sha256': self.plan_digest,
                'driver': {'pid': self.driver_pid, 'start': self.driver_start},
                'started_monotonic_seconds': self.started, 'started_timestamp_utc': self.started_utc.isoformat(),
                'completion_monotonic_seconds': self.completion_monotonic, 'completion_timestamp_utc': self.completion_utc,
                'trace': str(self.trace_path.relative_to(ROOT)), 'trace_sha256': digest(self.trace_path) if self.complete else None,
                'samples': self.samples, 'admitted': self.admitted, 'admission_evidence': self.admission_evidence,
                'complete': self.complete, 'passed': self.complete and self.admitted and self.invalid_reason is None,
                'invalid_reason': self.invalid_reason, 'benchmark_status': self.benchmark_status,
                'phase': 'complete' if self.complete else 'performance' if self.admitted else 'admission'}

    def _publish(self) -> None:
        temporary = self.summary_path.with_suffix('.writing')
        temporary.write_text(json.dumps(self._summary(), indent=2) + '\n')
        temporary.replace(self.summary_path)

    def _sample(self) -> None:
        if digest(self.plan_path) != self.plan_digest:
            raise ValueError('predeclared quiet plan changed during the attempt')
        rows = observation()
        current = time.monotonic()
        utc_now = datetime.now(timezone.utc)
        utc_seconds = utc_now.timestamp()
        timestamp = utc_now.isoformat()
        if current < self.started or utc_now < self.started_utc:
            raise ValueError('quiet observation clock reversed before monitor start')
        if self.last_sample is not None and (not 0 <= current - self.last_sample <= 15 or
                                             not 0 <= utc_seconds - self.last_sample_utc <= 15):
            raise ValueError('process observation clock reversed or sampling gap exceeds 15 seconds')
        if not self.admitted and (current - self.started > 3600 or (utc_now - self.started_utc).total_seconds() > 3600):
            raise ValueError('quiet admission timed out after 3600 seconds on monotonic or UTC clock without the offending identity absent and 61 valid samples over 300 seconds')
        driver = next((row for row in rows if row['pid'] == self.driver_pid), None)
        if driver is None:
            raise ValueError('recorded driver process is missing')
        if self.driver_start is None:
            self.driver_start = driver['start']
            self.owned[self.driver_pid] = driver['start']
        elif driver['start'] != self.driver_start:
            raise ValueError('recorded driver PID was reused')
        present = {row['pid']: row for row in rows}
        # Track only identities actually observed as descendants. Reparented,
        # still-live descendants retain their recorded PID/start identity.
        self.owned = {pid: start for pid, start in self.owned.items()
                      if pid in present and present[pid]['start'] == start}
        changed = True
        while changed:
            changed = False
            for row in rows:
                if row['ppid'] in self.owned and row['pid'] not in self.owned:
                    self.owned[row['pid']] = row['start']
                    changed = True
        other = [row for row in rows if self.owned.get(row['pid']) != row['start']]
        total = sum(row['cpu_percent'] for row in other)
        peak = max((row['cpu_percent'] for row in other), default=0)
        violation = total > 200 or peak >= 75
        offending = self.plan['offending_identity']
        offender_present = any(row['pid'] == offending['pid'] and row['start'] == offending['start'] for row in rows)
        record = {'timestamp_utc': timestamp, 'monotonic_seconds': current,
                  'phase': 'performance' if self.admitted else 'admission', 'processes': rows,
                  'excluded': [{'pid': pid, 'start': start} for pid, start in sorted(self.owned.items())],
                  'unexcluded_cpu_total': total, 'unexcluded_cpu_maximum': peak, 'violation': violation,
                  'offending_identity_present': offender_present}
        self.trace.write(json.dumps(record) + '\n')
        self.trace.flush()
        self.samples += 1
        self.last_sample = current
        self.last_sample_utc = utc_seconds
        if not self.admitted:
            if violation or offender_present:
                self.valid_count, self.valid_since, self.valid_since_utc = 0, None, None
            else:
                if self.valid_since is None:
                    self.valid_since = current
                    self.valid_since_utc = utc_seconds
                self.valid_count += 1
                if self.valid_count >= 61 and current - self.valid_since >= 300 and utc_seconds - self.valid_since_utc >= 300:
                    self.admitted = True
                    self.admission_evidence = {'consecutive_valid_samples': self.valid_count,
                                               'span_seconds': current - self.valid_since,
                                               'span_utc_seconds': utc_seconds - self.valid_since_utc,
                                               'admitted_timestamp_utc': timestamp,
                                               'admitted_monotonic_seconds': current}
        elif violation:
            if self.violation_since is None:
                self.violation_since = current
                self.violation_since_utc = utc_seconds
            self.violation_count += 1
            if self.violation_count >= 4 and (current - self.violation_since >= 15 or utc_seconds - self.violation_since_utc >= 15):
                raise ValueError('four consecutive noisy-host observations span at least 15 seconds')
        else:
            self.violation_count, self.violation_since, self.violation_since_utc = 0, None, None
        self._publish()

    def _run(self) -> None:
        deadline = time.monotonic()
        try:
            while not self.stop_event.is_set():
                with self.condition:
                    self._sample()
                    self.condition.notify_all()
                deadline += 5
                self.stop_event.wait(max(0, deadline - time.monotonic()))
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
            with self.condition:
                if self.invalid_reason is None:
                    self.invalid_reason = str(error)
                self.trace.write(json.dumps({'timestamp_utc': datetime.now(timezone.utc).isoformat(),
                                             'monotonic_seconds': time.monotonic(), 'error': self.invalid_reason}) + '\n')
                self.trace.flush()
                self._publish()
                self.condition.notify_all()

    def admit(self) -> None:
        self.thread.start()
        with self.condition:
            while not self.admitted and self.invalid_reason is None:
                self.condition.wait()
            if self.invalid_reason:
                raise ValueError(self.invalid_reason)

    def finish(self, benchmark_status: int | None) -> dict[str, Any]:
        self.stop_event.set()
        if self.thread.ident is not None:
            self.thread.join()
        self.completion_monotonic = time.monotonic()
        completed_utc = datetime.now(timezone.utc)
        self.completion_utc = completed_utc.isoformat()
        if self.admitted and self.last_sample is not None and self.invalid_reason is None:
            if (not 0 <= self.completion_monotonic - self.last_sample <= 15 or
                not 0 <= completed_utc.timestamp() - self.last_sample_utc <= 15):
                self.invalid_reason = 'observation-to-completion clock reversed or gap exceeds 15 seconds'
        self.benchmark_status = benchmark_status
        self.trace.close()
        self.complete = True
        self._publish()
        return self._summary()
