"""Audit repository documentation without tests, builds, network access, or mode inspection.

The interim run is preparation only. Run --phase final after the maintained
acceptance README and all final prose exist. Language compliance and factual
acceptance decisions remain with the producing agent and independent reviewer.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / '_scratch/i011-20261020'
FINAL_README = 'docs/evidence/standalone-compiler/README.md'
ISSUE = re.compile(r'[BIFMP](?!000)[0-9]{3}R?\Z')
ENTRY = re.compile(r'^- \[([ x!\-])\] \[([BIFMP][0-9]{3}[Rr]?)\](?: \(P[0-2]\))?(?: \{([^}]*)\})? (.+)$')
SECTIONS = {'BugFixes': 'B', 'Improvements': 'I', 'Maintenance': 'M', 'Features': 'F', 'Planning': 'P'}


def local(path: Path) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(ROOT):
        raise ValueError(f'path outside Lo: {path}')
    return resolved


def digest(path: Path) -> str:
    return hashlib.sha256(local(path).read_bytes()).hexdigest()


def lines_without_fences(text: str) -> list[str]:
    result, fence = [], None
    for line in text.splitlines():
        marker = re.match(r'^\s*(`{3,}|~{3,})', line)
        if marker:
            char = marker.group(1)[0]
            if fence is None:
                fence = char
            elif char == fence:
                fence = None
            result.append('')
        else:
            result.append(line if fence is None else '')
    return result


def anchors(path: Path) -> set[str]:
    found, counts = set(), {}
    for line in lines_without_fences(path.read_text()):
        heading = re.match(r'^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$', line)
        if heading:
            text = re.sub(r'<[^>]+>', '', heading.group(1)).lower()
            slug = re.sub(r'[^\w\- ]', '', text).replace(' ', '-')
            count = counts.get(slug, 0)
            counts[slug] = count + 1
            found.add(slug if count == 0 else f'{slug}-{count}')
    for match in re.finditer(r'(?:id|name)=["\x27]([^"\x27]+)', '\n'.join(lines_without_fences(path.read_text()))):
        found.add(match.group(1))
    return found


def links(documents: list[str]) -> dict:
    findings, checked, fragments = [], 0, 0
    for name in documents:
        path = local(ROOT / name)
        lines = lines_without_fences(path.read_text())
        definitions = {}
        for line in lines:
            match = re.match(r'^\s*\[([^]]+)\]:\s*(<[^>]+>|\S+)', line)
            if match:
                definitions[match.group(1).lower()] = match.group(2).strip('<>')
        targets = []
        for number, line in enumerate(lines, 1):
            for match in re.finditer(r'!?\[[^\]]*\]\(\s*(<[^>]+>|[^\s)]+)(?:\s+[^)]*)?\)', line):
                targets.append((number, match.group(1).strip('<>')))
            for match in re.finditer(r'!?\[([^]]+)\]\[([^]]*)\]', line):
                key = (match.group(2) or match.group(1)).lower()
                if key not in definitions:
                    findings.append({'path': name, 'line': number, 'kind': 'undefined_reference', 'target': key})
                else:
                    targets.append((number, definitions[key]))
        for number, target in targets:
            if re.match(r'^[a-zA-Z][\w+.-]*:', target):
                continue
            part, _, fragment = target.partition('#')
            try:
                resolved = local(path.parent / unquote(part.split('?', 1)[0])) if part else path
            except ValueError:
                findings.append({'path': name, 'line': number, 'kind': 'outside_repository', 'target': target})
                continue
            checked += 1
            if not resolved.exists():
                findings.append({'path': name, 'line': number, 'kind': 'missing_target', 'target': target})
            elif fragment and resolved.is_file() and resolved.suffix == '.md':
                fragments += 1
                if unquote(fragment) not in anchors(resolved):
                    findings.append({'path': name, 'line': number, 'kind': 'missing_fragment', 'target': target})
    return {'local_links_checked': checked, 'fragments_checked': fragments, 'findings': findings}


def issues() -> dict:
    records, findings, section, archived_ids = {}, [], '', set()
    tracker = ROOT / 'ISSUES.md'
    # D001-D003 are existing closed specification records expressed as headings.
    # Current entries use the canonical checkbox, ID, priority, dependencies shape.
    for number, line in enumerate(lines_without_fences(tracker.read_text()), 1):
        heading = re.match(r'^## (.+)$', line)
        if heading:
            section = heading.group(1)
            old = re.match(r'(D[0-9]{3}) - ', section)
            if old:
                archived_ids.add(old.group(1))
        match = ENTRY.match(line)
        if not match:
            if re.match(r'^- \[[ x!\-]\] \[', line):
                findings.append({'issue': 'tracker', 'kind': 'invalid_entry', 'line': number})
            continue
        state, raw, dependencies, title = match.groups()
        identifier = raw.upper()
        if not ISSUE.fullmatch(identifier) or SECTIONS.get(section) != identifier[0]:
            findings.append({'issue': identifier, 'kind': 'invalid_identifier_or_section'})
        if identifier in records:
            findings.append({'issue': identifier, 'kind': 'duplicate_identifier'})
        refs = [value.strip().upper() for value in dependencies.split(',')] if dependencies else []
        if len(refs) != len(set(refs)):
            findings.append({'issue': identifier, 'kind': 'duplicate_dependency'})
        records[identifier] = {'state': state, 'dependencies': refs}
    for identifier, item in records.items():
        for dependency in item['dependencies']:
            if '@' in dependency:
                findings.append({'issue': identifier, 'kind': 'qualified_dependency_requires_explicit_review', 'dependency': dependency})
            elif not ISSUE.fullmatch(dependency) or dependency not in records:
                findings.append({'issue': identifier, 'kind': 'unresolved_dependency', 'dependency': dependency})
    return {'canonical_issue_count': len(records), 'historical_specification_ids': sorted(archived_ids),
            'archive_discovery': 'No separate issue archive exists in the current repository file inventory.',
            'dependency_count': sum(len(item['dependencies']) for item in records.values()), 'findings': findings}


def instructions(documents: list[str]) -> dict:
    findings, historical = [], []
    obsolete = re.compile(r'--codegen|test-native-llvm|internal/(?:codegen|runtimebundle)|tools/runtimebundle|internal/device/metal\.metallib')
    for name in documents:
        text = (ROOT / name).read_text()
        historical_document = 'This document records historical implementation evidence before I011.' in text[:600]
        lines = text.splitlines()
        for number, line in enumerate(lines, 1):
            if re.search(r'ISSUES\.md(?::[0-9]|#[^\s)]+)', line):
                findings.append({'path': name, 'line': number, 'kind': 'issue_reference_by_tracker_location', 'text': line})
            if not obsolete.search(line):
                continue
            context = ' '.join(lines[max(0, number - 4):number + 2])
            if historical_document or re.search(r'\b(historical|removed|obsolete|no longer|retired)\b', context, re.I):
                historical.append({'path': name, 'line': number, 'text': line})
            else:
                findings.append({'path': name, 'line': number, 'kind': 'obsolete_instruction_requires_review', 'text': line})
    return {'findings': findings, 'clearly_historical_or_removed_references': historical,
            'limit': 'Text-pattern review identifies candidate obsolete instructions; the producing agent owns factual and language review.'}


def whitespace() -> dict:
    environment = dict(os.environ, CI='1',
                       TMPDIR=str(ROOT / '_scratch/build-state/tmp'), GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null')
    records = []
    for command in (['git', 'diff', '--check'], ['git', 'diff', '--cached', '--check']):
        result = subprocess.run(command, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                                capture_output=True, text=True, check=False)
        records.append({'command': command, 'status': result.returncode,
                        'diagnostics': result.stdout + result.stderr})
    return {'records': records, 'passed': all(item['status'] == 0 for item in records)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('interim', 'final'), required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    try:
        documents = json.loads((BASE / 'changed-documents.json').read_text())
        if (ROOT / FINAL_README).is_file():
            if FINAL_README not in documents:
                documents.append(FINAL_README)
        elif args.phase == 'final':
            raise ValueError('final acceptance README does not exist')
        output = local(args.output_dir)
        output.mkdir(parents=True, exist_ok=True)
        link_report = links(documents)
        repository_report = {'issues': issues(), 'current_instruction_review': instructions(documents), 'whitespace': whitespace()}
        shared = {'phase': args.phase, 'review_scope': 'Read-only mechanical review; no final acceptance or STE compliance claim.',
                  'documents': {name: digest(ROOT / name) for name in documents}}
        link_report.update(shared)
        repository_report.update(shared)
        (output / 'final-document-links.json').write_text(json.dumps(link_report, indent=2) + '\n')
        (output / 'final-repository-checks.json').write_text(json.dumps(repository_report, indent=2) + '\n')
        failures = len(link_report['findings']) + len(repository_report['issues']['findings']) + len(repository_report['current_instruction_review']['findings'])
        print(json.dumps({'phase': args.phase, 'documents': len(documents), 'findings': failures,
                          'whitespace_passed': repository_report['whitespace']['passed'], 'output': str(output.relative_to(ROOT))}))
        return 0 if failures == 0 and repository_report['whitespace']['passed'] else 1
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f'Document audit rejected: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
