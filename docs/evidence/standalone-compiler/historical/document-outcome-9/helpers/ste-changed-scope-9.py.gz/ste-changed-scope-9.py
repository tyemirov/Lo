"""Map mechanical findings to changed document lines; do not certify language compliance."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd().resolve()
report_path = Path(sys.argv[1]).resolve()
output_path = Path(sys.argv[2]).resolve()
assert report_path.is_relative_to(root) and output_path.is_relative_to(root)
report = json.loads(report_path.read_text())
environment = dict(os.environ, CI='1',
                   TMPDIR=str(root / '_scratch/build-state/tmp'), GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null')
changed, documents = {}, {}
for name in report['files']:
    path = Path(name).resolve()
    assert path.is_relative_to(root)
    relative = str(path.relative_to(root))
    current = path.read_text().splitlines()
    old = subprocess.run(['git', 'show', 'HEAD:' + relative], cwd=root, env=environment,
                         stdin=subprocess.DEVNULL, capture_output=True, text=True)
    if old.returncode not in (0, 128):
        raise SystemExit('Cannot read document baseline: ' + relative)
    selected = set()
    if old.returncode:
        selected.update(range(1, len(current) + 1))
    else:
        for operation, _, _, first, end in difflib.SequenceMatcher(None, old.stdout.splitlines(), current, autojunk=False).get_opcodes():
            if operation in ('insert', 'replace'):
                selected.update(range(first + 1, end + 1))
    changed[str(path)] = selected
    documents[relative] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'changed_lines': sorted(selected)}
findings = [entry for entry in report['findings'] if entry['line'] in changed[str(Path(entry['path']).resolve())]]
result = {'whole_document_findings': len(report['findings']), 'changed_line_findings': findings,
          'documents': documents, 'review_scope': 'Changed prose only. Mechanical checks do not certify dictionary usage, factual accuracy, or full-document compliance.'}
output_path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'documents':len(documents), 'whole_document_findings':len(report['findings']), 'changed_line_findings':len(findings)}))
raise SystemExit(1 if findings else 0)
