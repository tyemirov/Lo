"""Deterministic entry-point state checks; no real children or observations."""
from pathlib import Path
import importlib.util
import json
import shutil
import sys
from types import SimpleNamespace
import unittest

BASE = Path(__file__).resolve().parents[1]
DRIVER = BASE / 'final-validation-11.py'


class DriverStates(unittest.TestCase):
    def scenario(self, name, admissions, outcomes, launch_error=False, binding_error=False):
        spec = importlib.util.spec_from_file_location('campaign11_driver_test_' + name, DRIVER)
        driver = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(driver)
        work = BASE / 'fixtures' / ('campaign11-case-final-' + name)
        self.assertFalse(work.exists(), 'fixture path must be unused')
        work.mkdir()
        driver.root = work
        driver.base = work
        snapshots, launched, finished, verifications = [], [], [], []
        definitions = [{'id': i, 'performance_directory': f'perf{i}', 'trace': f'trace{i}', 'summary': f'summary{i}'} for i in (11, 12)]
        state = {'calls': 0}
        def receipt(path):
            return {'path': str(path.relative_to(work)), 'sha256': 'fixture'}
        def load(path):
            return json.loads(path.read_text())
        def verify():
            state['calls'] += 1
            if binding_error and state['calls'] >= 3:
                raise ValueError('fixture provenance changed')
            return {'nonperformance_summary': {'fixture': True}}
        contract = SimpleNamespace(plan11=lambda: {'attempts': definitions}, verify_bindings=verify, receipt=receipt,
            load=load, validate_quiet=lambda *a, **k: {}, CPU_INVALID='four consecutive noisy-host observations span at least 15 seconds',
            retry_allowed=lambda q,o: q.get('admitted') is True and q.get('invalid_reason') == 'four consecutive noisy-host observations span at least 15 seconds' and o.get('failure_kind') == 'cpu-load' and bool(o.get('lanes')),
            validate_runner=lambda d,r: load(work / d['performance_directory'] / 'runner-outcome.json'))
        class Monitor:
            def __init__(self, pid, plan, trace, summary, identifier):
                self.identifier, self.summary = identifier, summary
            def admit(self):
                value = admissions[self.identifier - 11]
                if value is not None:
                    raise ValueError(value)
            def finish(self, status):
                finished.append(status)
                idx = self.identifier - 11
                value = {'complete': True, 'admitted': admissions[idx] is None, 'passed': admissions[idx] is None and outcomes[idx] == 'passed',
                    'invalid_reason': None if outcomes[idx] != 'cpu-load' else contract.CPU_INVALID, 'benchmark_status': status}
                self.summary.write_text(json.dumps(value))
                return value
        def start(command, **kwargs):
            if launch_error:
                raise OSError('fixture launch refused')
            identifier = int(command[-1]); launched.append(identifier)
            idx = identifier - 11
            directory = work / f'perf{identifier}'; directory.mkdir()
            (directory / 'runner-outcome.json').write_text(json.dumps({'complete': True, 'failure_kind': outcomes[idx], 'lanes': [{'fixture': True}]}))
            return SimpleNamespace(wait=lambda: 0 if outcomes[idx] == 'passed' else 1)
        def freeze(identifier, phase):
            verifications.append((identifier, phase))
        code = driver.main(contract=contract, quiet_module=SimpleNamespace(Monitor=Monitor),
            audit=SimpleNamespace(audit_nonperformance=lambda: {'fixture': True}), process_start=start,
            freeze_verify=freeze, on_record=lambda value: snapshots.append(json.loads(json.dumps(value))))
        return code, load(work / 'final-validation-status-11.json'), snapshots, launched, finished, verifications

    def test_admission_timeout_has_no_measurement_or_retry(self):
        reason = 'quiet admission timed out after 3600 seconds on monotonic or UTC clock without the offending identity absent and 61 valid samples over 300 seconds'
        code, s, snapshots, launched, finished, checks = self.scenario('timeout', [reason], [None])
        self.assertEqual(code, 1); self.assertEqual(launched, []); self.assertEqual(finished, [None])
        self.assertEqual(s['phase'], 'terminal'); self.assertEqual(s['terminal_reason'], reason)
        self.assertEqual(s['attempts'][0]['disposition'], 'admission-timeout')
        self.assertIsNone(s['attempts'][0]['measurement_status']); self.assertFalse(s['attempts'][0]['measurement_started'])
        self.assertEqual(checks, [(11,'before'),(11,'after')])

    def test_observation_failure_has_no_measurement(self):
        code,s,_,launched,finished,_ = self.scenario('observation', ['malformed process observation'], [None])
        self.assertEqual(code,1); self.assertEqual(launched,[]); self.assertEqual(finished,[None])
        self.assertEqual(s['attempts'][0]['disposition'],'admission-failed')

    def test_success_exposes_admission_then_measurement_then_terminal(self):
        code,s,snapshots,launched,finished,_ = self.scenario('success',[None],['passed'])
        self.assertEqual(code,0); self.assertTrue(s['passed']); self.assertEqual(launched,[11]); self.assertEqual(finished,[0])
        self.assertIn('admission',[x['phase'] for x in snapshots]); self.assertIn('measurement',[x['phase'] for x in snapshots])
        self.assertTrue(all(x['attempts'][0]['measurement_status'] is None for x in snapshots if x.get('attempts') and x['phase']=='admission'))
        self.assertEqual(s['attempts'][0]['measurement_status'],0)

    def test_only_completed_cpu_invalid_lane_opens_restart(self):
        code,s,_,launched,_,_ = self.scenario('cpu-retry',[None,None],['cpu-load','passed'])
        self.assertEqual(code,0); self.assertEqual(launched,[11,12]); self.assertEqual(s['selected_attempt'],12)
        self.assertEqual(s['attempts'][0]['disposition'],'cpu-load-invalidated')

    def test_valid_failed_gate_stops(self):
        code,s,_,launched,_,_ = self.scenario('gate',[None],['benchmark-gate'])
        self.assertEqual(code,1); self.assertEqual(launched,[11]); self.assertEqual(len(s['attempts']),1)
        self.assertEqual(s['attempts'][0]['disposition'],'failed-no-retry')

    def test_spawn_failure_does_not_invent_measurement_status(self):
        code,s,_,launched,finished,_ = self.scenario('spawn',[None],[None],launch_error=True)
        self.assertEqual(code,1); self.assertEqual(launched,[]); self.assertEqual(finished,[None])
        self.assertFalse(s['attempts'][0]['measurement_started']); self.assertIsNone(s['attempts'][0]['measurement_status'])

    def test_post_run_provenance_failure_cannot_pass(self):
        code,s,_,launched,_,_ = self.scenario('provenance',[None],['passed'],binding_error=True)
        self.assertEqual(code,1); self.assertFalse(s['passed']); self.assertEqual(launched,[11])
        self.assertIn('provenance changed',s['error'])


    def test_real_retry_contract_rejects_timeout_and_empty_lane_inventory(self):
        spec = importlib.util.spec_from_file_location('campaign11_actual_contract', BASE / 'campaign-contract-11.py')
        contract = importlib.util.module_from_spec(spec); sys.modules[spec.name] = contract; spec.loader.exec_module(contract)
        quiet = {'complete': True, 'admitted': True, 'passed': False, 'invalid_reason': contract.CPU_INVALID}
        outcome = {'complete': True, 'failure_kind': 'cpu-load', 'lanes': []}
        self.assertFalse(contract.retry_allowed(quiet,outcome))
        outcome['lanes'] = [{'fixture': True}]
        self.assertTrue(contract.retry_allowed(quiet,outcome))
        quiet['admitted'] = False
        self.assertFalse(contract.retry_allowed(quiet,outcome))
        quiet['admitted'] = True; quiet['invalid_reason'] = 'sampling gap'
        self.assertFalse(contract.retry_allowed(quiet,outcome))
        quiet['invalid_reason'] = contract.CPU_INVALID; outcome['failure_kind'] = 'measurement-or-provenance'
        self.assertFalse(contract.retry_allowed(quiet,outcome))

    def test_actual_monitor_finish_retains_null_before_measurement(self):
        spec = importlib.util.spec_from_file_location('campaign11_actual_monitor', BASE / 'quiet-host-11.py')
        monitor_module = importlib.util.module_from_spec(spec); spec.loader.exec_module(monitor_module)
        work = BASE / 'fixtures' / 'campaign11-monitor-null-final'
        self.assertFalse(work.exists()); work.mkdir()
        monitor = monitor_module.Monitor(123, BASE / 'quiet-host-plan-11.json', work / 'trace.jsonl', work / 'summary.json',11)
        monitor.invalid_reason = 'fixture admission timeout'
        result = monitor.finish(None)
        self.assertIsNone(result['benchmark_status']); self.assertFalse(result['admitted']); self.assertFalse(result['passed'])
        self.assertEqual(result['invalid_reason'],'fixture admission timeout')


if __name__ == '__main__':
    unittest.main()
