"""Exercise the selector entry point with injected, repository-local receipts."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
from types import SimpleNamespace
from unittest.mock import patch

parser=argparse.ArgumentParser();parser.add_argument('--case',required=True);args=parser.parse_args()
task=Path(__file__).resolve().parents[1]
work=task/'fixtures'/('campaign11-selector-'+args.case)
assert not work.exists(),'fixture path must be fresh'
base=work/'_scratch/i011-20261020';base.mkdir(parents=True)
index=work/'docs/evidence/standalone-compiler/preservation-index.json';index.parent.mkdir(parents=True);index.write_text('{"records": []}')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def receipt(path):return {'path':str(path.relative_to(work)),'sha256':sha(path)}
for name in ['reused.json','orchestration.json','review.json','context.json','auth.json','rejected-report.json','old-seal.json',
             'campaign-inputs-11.json','final-validation-11.log','final-driver-exit-11.json']:
 (base/name).write_text('{}')
(base/'final-evidence-audit-11.json').write_text(json.dumps({'campaign':11,'audit_status':'all_required_evidence_complete'}))
(base/'final-validation-status-11.json').write_text(json.dumps({'campaign':11,'passed':True,'complete':True,'attempts':[],'selected_attempt':11}))
sealed={group:[receipt(base/name)] for group,name in [('reused_records','reused.json'),('orchestration','orchestration.json'),('reviews','review.json'),('context_records','context.json')]}
sealed['authorization']=receipt(base/'auth.json')
sealed['predecessor_records']=[receipt(base/name) for name in ['reused.json','rejected-report.json','old-seal.json']]
contract=SimpleNamespace(load=lambda path:json.loads(path.read_text()),verify_bindings=lambda:sealed,
    local=lambda path:path.resolve(),sha=sha,receipt=receipt)
class Loader:
 def create_module(self,spec):return contract
 def exec_module(self,module):pass
spec=importlib.util.spec_from_loader('campaign11_selector_fixture',Loader())
source=(task/'prepare-final-preservation-11.py').read_text()
with patch('importlib.util.spec_from_file_location',return_value=spec),patch.object(sys,'argv',['selector','--initial']):
 exec(compile(source,'selector','exec'),{'__file__':str(base/'prepare-final-preservation-11.py'),'__name__':'__main__'})
manifest=json.loads((base/'final-evidence-manifest-11-initial.json').read_text())
scopes={item['path']:item['scope'] for item in manifest['records']}
assert scopes[str((base/'reused.json').relative_to(work))]=='final','predecessor must not downgrade final reused nonperformance'
assert scopes[str((base/'rejected-report.json').relative_to(work))]=='historical','rejected performance must remain historical'
assert scopes[str((base/'old-seal.json').relative_to(work))]=='historical','prior seal must remain historical'
print(json.dumps({'status':'passed','final_reused_nonperformance':True,'historical_rejected_performance':True,'historical_prior_seal':True}))
