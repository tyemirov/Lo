"""Read attempt8 receipts for original freeze7 without running commands; emit JSON only after every gate passes.

Run from Lo with python3 -B. This audit does not replace the independent completion
review. It never starts tests, compilers, guests, benchmarks, or child processes.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
import importlib.util
import json
import math
from pathlib import Path
import sys
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / '_scratch/i011-20261020'
sys.path.insert(0, str(ROOT / 'tools/nativebench'))
import merge as performance_merge
import identity as performance_identity


def require(condition: bool, subject: str) -> None:
    if not condition:
        raise ValueError(subject)


def local(path: Path) -> Path:
    resolved = path.resolve()
    require(resolved.is_relative_to(ROOT), f'path outside Lo: {path}')
    return resolved


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with local(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(local(path).read_text())
    require(isinstance(value, dict), f'expected JSON object: {path}')
    return value


def receipt(path: Path) -> dict[str, str]:
    return {'path': str(local(path).relative_to(ROOT)), 'sha256': sha(path)}


def success(result: dict[str, Any], subject: str) -> None:
    require(type(result.get('status')) is int and result['status'] == 0,
            f'{subject}: command did not exit zero')
    require(result.get('stderr') == '', f'{subject}: unexpected stderr')


def corpus(path: Path, expected: dict[str, str], semantic: Any) -> dict[str, Any]:
    events = semantic.read_events(local(path), expected)
    require(not any(value == 'fail' for value in events.statuses.values()), f'failed corpus case: {path}')
    counts = {key: sum(value == key for value in events.statuses.values()) for key in ('pass', 'fail', 'skip')}
    require(counts['pass'] > 0, f'empty corpus: {path}')
    return {'log': receipt(path), 'identity': events.identity, 'counts': counts,
            'statuses': events.statuses}


def audit() -> dict[str, Any]:
    status = load(BASE / 'final-validation-status-8.json')
    require(status.get('statuses') == {'performance': 0, 'ci': 0, 'linux-corpus': 0, 'component-tools': 0, 'offline': 0},
            'final driver command statuses are missing or failed')
    require(status.get('running') == [], 'final driver still has active jobs')
    require(type(status.get('elapsed_seconds')) in (int, float) and status['elapsed_seconds'] > 0,
            'driver lacks elapsed time')
    driver = BASE / 'final-validation-8.log'
    require('All final qualification commands passed' in local(driver).read_text(),
            'final driver success marker is absent')
    quiet_path = BASE / 'quiet-host-summary-8.json'
    quiet = load(quiet_path)
    plan_path = BASE / 'quiet-host-plan-8.json'
    plan = load(plan_path)
    require(plan['attempt'] == 8 and plan['source_sha256'] == '30456a563ea64716d16e3b0d954338fae144fdde5b66a13f570c31c6bbf501e2' and
            plan['source_freeze'] == '_scratch/i011-20261020/frozen-inputs-7.json', 'quiet plan source identity differs')
    require(plan['observation_command'] == ['/bin/ps', '-axo', 'pid=,ppid=,%cpu=,lstart=,comm='] and
            plan['observation_environment'] == {'LC_ALL': 'C'} and
            plan['sampling_interval_seconds'] == 5 and plan['maximum_sampling_gap_seconds'] == 15 and
            plan['admission'] == {'consecutive_valid_samples': 13, 'minimum_span_seconds': 60, 'maximum_wait_seconds': 3600} and
            plan['during_performance'] == {'consecutive_violations': 4, 'minimum_span_seconds': 15} and
            plan['violation'] == {'total_unexcluded_cpu_greater_than': 200, 'any_unexcluded_cpu_at_least': 75},
            'quiet plan criteria differ')
    require(quiet.get('attempt') == 8 and quiet.get('complete') is True and quiet.get('passed') is True and
            quiet.get('admitted') is True and quiet.get('invalid_reason') is None and quiet.get('benchmark_status') == 0,
            'quiet-host environment is incomplete or invalid')
    require(quiet['plan_sha256'] == sha(plan_path) and status['quiet_plan'] == receipt(plan_path), 'quiet plan digest differs')
    require(status.get('source_freeze') == '_scratch/i011-20261020/frozen-inputs-7.json' and status.get('reviews'),
            'driver freeze or approved review receipts missing')
    require(status.get('orchestration_inputs'), 'driver orchestration identity map missing')
    for name, expected_digest in status['orchestration_inputs'].items():
        require(sha(ROOT / name) == expected_digest, f'orchestration input changed: {name}')
    for review in status['reviews']:
        require(review == receipt(ROOT / review['path']), 'driver review receipt changed')
    trace_path = BASE / 'quiet-host-trace-8.jsonl'
    require(quiet['trace'] == str(trace_path.relative_to(ROOT)) and quiet['trace_sha256'] == sha(trace_path),
            'quiet trace digest differs')
    trace = [json.loads(line) for line in trace_path.read_text().splitlines()]
    require(bool(trace) and len(trace) == quiet['samples'] and all('error' not in sample for sample in trace),
            'quiet trace has missing or invalid observations')
    driver_identity = quiet['driver']
    known = {driver_identity['pid']: driver_identity['start']}
    last = None
    last_utc = None
    valid_since = None
    valid_since_utc = None
    valid_count = 0
    violation_since = None
    violation_since_utc = None
    violation_count = 0
    admitted_time = quiet['admission_evidence']['admitted_monotonic_seconds']
    admitted_utc = datetime.fromisoformat(quiet['admission_evidence']['admitted_timestamp_utc']).timestamp()
    monitor_start = quiet['started_monotonic_seconds']
    monitor_start_utc = datetime.fromisoformat(quiet['started_timestamp_utc']).timestamp()
    performance_observations = 0
    admitted = False
    for sample in trace:
        moment = sample['monotonic_seconds']
        observed_utc = datetime.fromisoformat(sample['timestamp_utc'])
        require(observed_utc.tzinfo is not None and observed_utc.utcoffset().total_seconds() == 0, 'quiet observation timestamp is not UTC')
        utc_seconds = observed_utc.timestamp()
        require(type(moment) in (int, float) and math.isfinite(moment) and moment >= monitor_start and utc_seconds >= monitor_start_utc and
                (last is None or 0 <= moment - last <= 15) and
                (last_utc is None or 0 <= utc_seconds - last_utc <= 15), 'quiet monotonic or UTC observation clock reversed or sampling gap exceeds 15 seconds')
        rows = sample['processes']
        require(rows and all(set(row) == {'pid', 'ppid', 'cpu_percent', 'start', 'basename'} for row in rows),
                'quiet process observation fields differ')
        present = {row['pid']: row for row in rows}
        require(len(present) == len(rows) and driver_identity['pid'] in present and
                present[driver_identity['pid']]['start'] == driver_identity['start'], 'quiet driver identity differs')
        known = {pid: start for pid, start in known.items() if pid in present and present[pid]['start'] == start}
        changed = True
        while changed:
            changed = False
            for row in rows:
                require(type(row['pid']) is int and row['pid'] > 0 and type(row['ppid']) is int and row['ppid'] >= 0 and
                        type(row['cpu_percent']) in (int, float) and math.isfinite(row['cpu_percent']) and row['cpu_percent'] >= 0 and
                        bool(row['start']) and bool(row['basename']) and '/' not in row['basename'], 'malformed quiet process fields')
                if row['ppid'] in known and row['pid'] not in known:
                    known[row['pid']] = row['start']
                    changed = True
        require(sample['excluded'] == [{'pid': pid, 'start': start} for pid, start in sorted(known.items())],
                'quiet exclusion exceeds recorded driver descendants')
        other = [row for row in rows if known.get(row['pid']) != row['start']]
        total = sum(row['cpu_percent'] for row in other)
        peak = max((row['cpu_percent'] for row in other), default=0)
        violation = total > 200 or peak >= 75
        require(sample['unexcluded_cpu_total'] == total and sample['unexcluded_cpu_maximum'] == peak and
                sample['violation'] is violation, 'quiet raw CPU facts differ')
        if not admitted:
            require(sample['phase'] == 'admission', 'quiet admission phase differs')
            if violation:
                valid_count, valid_since, valid_since_utc = 0, None, None
            else:
                valid_since = moment if valid_since is None else valid_since
                valid_since_utc = utc_seconds if valid_since_utc is None else valid_since_utc
                valid_count += 1
                if moment == admitted_time:
                    require(valid_count >= 13 and moment - valid_since >= 60 and utc_seconds - valid_since_utc >= 60 and
                            utc_seconds == admitted_utc and quiet['admission_evidence']['consecutive_valid_samples'] == valid_count and
                            quiet['admission_evidence']['span_seconds'] == moment - valid_since and
                            quiet['admission_evidence']['span_utc_seconds'] == utc_seconds - valid_since_utc, 'quiet admission sample envelope differs')
                    admitted = True
        else:
            require(sample['phase'] == 'performance', 'quiet performance phase differs')
            performance_observations += 1
            if violation:
                violation_since = moment if violation_since is None else violation_since
                violation_since_utc = utc_seconds if violation_since_utc is None else violation_since_utc
                violation_count += 1
                require(not (violation_count >= 4 and (moment - violation_since >= 15 or utc_seconds - violation_since_utc >= 15)), 'quiet host invalidated this attempt')
            else:
                violation_count, violation_since, violation_since_utc = 0, None, None
        last = moment
        last_utc = utc_seconds
    require(admitted, 'quiet trace does not prove admission')
    require(0 <= admitted_time - monitor_start <= 3600 and 0 <= admitted_utc - monitor_start_utc <= 3600,
            'quiet admission exceeds declared monotonic or UTC maximum wait')
    require(performance_observations >= 1, 'quiet trace lacks a performance-phase observation')
    completion_moment = quiet['completion_monotonic_seconds']
    completion_utc = datetime.fromisoformat(quiet['completion_timestamp_utc'])
    require(completion_utc.tzinfo is not None and completion_utc.utcoffset().total_seconds() == 0 and
            type(completion_moment) in (int, float) and math.isfinite(completion_moment) and
            0 <= completion_moment - last <= 15 and 0 <= completion_utc.timestamp() - last_utc <= 15,
            'quiet observation-to-completion clock reversed or gap exceeds 15 seconds')
    frozen = load(BASE / 'frozen-inputs-7.json')
    for group in ('sources', 'measurement_sources', 'packages'):
        require(isinstance(frozen.get(group), dict) and bool(frozen[group]), f'empty freeze group: {group}')
        for name, expected_digest in frozen[group].items():
            require(sha(ROOT / name) == expected_digest, f'frozen input changed: {name}')
    source_hash = frozen['semantic_source_sha256']
    require(source_hash == plan['source_sha256'], 'freeze7 source differs from predeclared quiet plan')
    for stage in ('start', 'performance', 'complete'):
        verification = load(BASE / ('freeze-verify-8-' + stage + '.log'))
        require(verification.get('action') == 'verify' and verification.get('source_sha256') == source_hash and
                verification.get('source_files') == len(frozen['sources']) and verification.get('package_files') == len(frozen['packages']),
                'attempt8 freeze verification differs: ' + stage)
    specification = importlib.util.spec_from_file_location('lo_final_semantic_report', ROOT / 'tools/semanticcoverage/report.py')
    require(specification is not None and specification.loader is not None, 'semantic reporter unavailable')
    semantic = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = semantic
    specification.loader.exec_module(semantic)
    sources, current_hash = semantic.source_identity()
    require(current_hash == source_hash and sources == frozen['sources'], 'semantic source freeze differs')
    report_path = BASE / 'final-semantic-report.json'
    report = load(report_path)
    require(report.get('execution_status') == report.get('qualification_status') == 'passed',
            'semantic report is incomplete')
    require(report.get('missing_targets') == [] and report.get('qualification_gaps') == [],
            'semantic targets or required obligations are absent')
    require(report.get('source_sha256') == sources, 'semantic report source map differs')
    matrix_path = ROOT / 'testdata/semantic-migration/matrix.json'
    matrix = load(matrix_path)
    matrix_hash = sha(matrix_path)
    require(report.get('matrix_sha256') == matrix_hash, 'semantic matrix identity differs')
    paths = {
        'interpreter': BASE / 'final-corpus-7/darwin/semantic-interpreter.jsonl',
        'llvm:darwin/arm64': BASE / 'final-corpus-7/darwin/semantic-llvm-darwin-arm64.jsonl',
        'llvm:linux/arm64': BASE / 'final-corpus-7/linux/semantic-linux-arm64.jsonl',
    }
    lanes = {}
    for lane, path in paths.items():
        backend = 'interpreter' if lane == 'interpreter' else 'llvm'
        expected = {'source_sha256': source_hash, 'matrix_sha256': matrix_hash, 'backend': backend}
        expected['target'] = 'darwin/arm64' if backend == 'interpreter' else lane.split(':', 1)[1]
        lanes[lane] = corpus(path, expected, semantic)
        require(report['log_sha256'][lane] == sha(path), f'semantic log digest differs: {lane}')
        require(report['execution_identity'][lane] == lanes[lane]['identity'], f'semantic lane identity differs: {lane}')
    refs = semantic.references(matrix)
    expected_tests = set(refs)
    observed_tests = [item['test'] for item in report['references']]
    require(len(observed_tests) == len(expected_tests) and set(observed_tests) == expected_tests,
            'semantic reference inventory differs')
    for ref in expected_tests:
        for lane, details in lanes.items():
            required = [ref] if lane == 'interpreter' else matrix['native_tests'][ref]
            require(bool(required) and all(details['statuses'].get(test) == 'pass' for test in required),
                    f'required semantic obligation did not pass: {lane}:{ref}')
    removed_paths = ('internal/codegen', 'internal/runtimebundle', 'tools/runtimebundle',
                     'tools/nativefixture', 'tools/nativecache', 'tools/nativefixture/nativecache')
    for name in removed_paths:
        require(not (ROOT / name).exists() and not (ROOT / name).is_symlink(),
                f'retired Go-generation path remains: {name}')
    retirement_tests = ('TestNativeRejectsBackendSelection', 'TestNativeRemovedSourceDiagnostics')
    retirement = {'absent_paths': list(removed_paths), 'public_tests': {}}
    for name in retirement_tests:
        retirement['public_tests'][name] = {}
        for lane, details in lanes.items():
            require(details['statuses'].get(name) == 'pass',
                    f'retirement public test did not pass: {lane}:{name}')
            retirement['public_tests'][name][lane] = [test for test, state in details['statuses'].items()
                                                    if state == 'pass' and (test == name or test.startswith(name + '/'))]
    allocation_preservation = {}
    for name in ('TestCollectionArgumentResults', 'TestLLVMCollectionArgumentLifetime'):
        allocation_preservation[name] = {}
        for lane, details in lanes.items():
            expected_status = 'skip' if name.startswith('TestLLVM') and lane == 'interpreter' else 'pass'
            actual_status = details['statuses'].get(name)
            require(actual_status == expected_status,
                    f'callback preservation result differs: {lane}:{name}:{actual_status}')
            allocation_preservation[name][lane] = actual_status
    ml_refs = ('TestAutodiffAnalyticalAndFiniteDifferences', 'TestMetalComputeTraining',
               'TestMetalTrainingGradients', 'TestSemanticMigrationCheckpointResume',
               'TestSemanticNativeMetalCheckpointResume')
    ml = {name: {lane: ([name] if lane == 'interpreter' else matrix['native_tests'][name])
                 for lane in lanes} for name in ml_refs}
    ml_observed = {lane: [name for name, state in details['statuses'].items()
                          if state == 'pass' and any(term in name.lower() for term in ('autodiff', 'training', 'xor', 'checkpoint'))]
                   for lane, details in lanes.items()}
    ci_stdout, ci_stderr = BASE / 'final-ci.stdout', BASE / 'final-ci.stderr'
    require(ci_stdout.is_file() and ci_stderr.is_file() and ci_stdout.stat().st_size > 0, 'final CI logs missing')
    # Reconcile extracted Darwin logs with the original CI stream, preserving event order.
    ci_events = []
    for line in ci_stdout.read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict):
            require(event.get('Action') != 'fail', 'final CI contains a failed package or test')
            if event.get('Package') == semantic.PACKAGE:
                ci_events.append(event)
    extracted = []
    for lane in ('interpreter', 'llvm:darwin/arm64'):
        extracted.extend(json.loads(line) for line in paths[lane].read_text().splitlines())
    require(ci_events == extracted, 'Darwin corpus extraction differs from final CI integration events')
    regression_names = {
        'B001': ('TestFlowFoldNestedCancellationProgress', 'TestLLVMNestedFoldCancellationProgress'),
        'B002': ('TestLLVMMetalBroadcastStandalone',),
        'B003': ('TestAdapterProcessUnavailableInServerCallbacks', 'TestAdapterServerFailureContext',
                 'TestAdapterServerStartupFailureContext', 'TestLLVMServerCallbackIndependentCleanup'),
    }
    ci_passes = {event.get('Test') for event in ci_events if event.get('Action') == 'pass' and event.get('Test')}
    regression_evidence = {}
    for issue, names in regression_names.items():
        for name in names:
            require(name in ci_passes, f'final CI regression did not pass: {issue}:{name}')
        regression_evidence[issue] = {name: sorted(test for test in ci_passes
                                                if test == name or test.startswith(name + '/')) for name in names}
    transport_smoke_path = BASE / 'transport-smoke/report.json'
    transport_smoke = load(transport_smoke_path)
    require(transport_smoke.get('passed') is True and transport_smoke.get('qemu_status') == 0,
            'B004 pinned-QEMU smoke did not pass')
    require(transport_smoke.get('export') == 'LO_TRANSPORT_SMOKE_EXPORT:exact-bytes\n' and
            'LO_TRANSPORT_SMOKE_KERNEL_DIAGNOSTIC' in transport_smoke.get('serial', '') and
            'LO_TRANSPORT_SMOKE_EXPORT:' not in transport_smoke.get('serial', ''),
            'B004 smoke does not separate export from kernel diagnostics')
    transport_real_path = BASE / 'transport-real-checks.json'
    transport_real = load(transport_real_path)
    require(transport_real.get('distribution_status') == 0 and
            transport_real.get('artifact_digest_matches') is True and
            transport_real.get('batch_artifact_bytes_match') is True and
            transport_real.get('serial_protocol_absent') is True and
            transport_real.get('strict_receiver_recheck') == 'passed', 'B004 real transport checks differ')
    require({item['id'] for item in transport_real['results']} == {'interpreter', 'artifact'} and
            all(item['status'] == 0 and item['result']['result'] == {'type': 'Int', 'value': '10'}
                for item in transport_real['results']), 'B004 real interpreter/artifact results differ')
    regression_evidence['B004'] = {
        'focused_scope': 'Historical public injected-dependency checks and pinned-QEMU transport checks; not a full corpus.',
        'smoke': receipt(transport_smoke_path), 'real_checks': receipt(transport_real_path),
        'focused_logs': [receipt(BASE / name) for name in
                         ('fixtures/transport/red.log', 'fixtures/transport/green.log',
                          'linux/transport/red.log', 'linux/transport/strict-final-green.log')],
        'final_corpus_status': 'Current source-bound corpora admitted separately by this audit.',
    }
    linux = load(BASE / 'final-corpus-7/linux/report.json')
    require(linux['target'] == 'linux/arm64' and linux['cases'] and all(case['status'] == 0 for case in linux['cases']),
            'Linux guest corpus command failed')
    require(local(ROOT / linux['events']) == local(paths['llvm:linux/arm64']), 'Linux event path differs')
    packages = {}
    for name in ('lo-darwin-arm64-software', 'lo-linux-arm64-software', 'lo-darwin-arm64-metal'):
        package = ROOT / 'bin/distributions' / name
        package_receipt_path = package.with_suffix('.receipt.json')
        package_receipt = load(package_receipt_path)
        require(package_receipt['toolchain_sha256'] == sha(package / 'toolchain.json'), f'package manifest differs: {name}')
        require(package_receipt['inventory_sha256'] == sha(package / 'inventory.json'), f'package inventory differs: {name}')
        require(package_receipt['archive_sha256'] == sha(ROOT / package_receipt['archive']), f'package archive differs: {name}')
        packages[name] = {'receipt': receipt(package_receipt_path), 'values': package_receipt,
                          'compiler_sha256': sha(package / 'bin/lo')}
    for lane, package_name in (
        ('interpreter', 'lo-darwin-arm64-metal'),
        ('llvm:darwin/arm64', 'lo-darwin-arm64-metal'),
        ('llvm:linux/arm64', 'lo-linux-arm64-software'),
    ):
        execution = lanes[lane]['identity']
        selected = packages[package_name]
        package = ROOT / 'bin/distributions' / package_name
        require(local(ROOT / execution['compiler']) == local(package / 'bin/lo'),
                f'corpus selected compiler path differs: {lane}')
        require(execution['compiler_sha256'] == selected['compiler_sha256'],
                f'corpus selected compiler digest differs: {lane}')
        if lane != 'interpreter':
            manifest_path = package / 'toolchain.json'
            manifest = load(manifest_path)
            require(local(ROOT / execution['toolchain']) == local(manifest_path),
                    f'corpus selected manifest path differs: {lane}')
            require(execution['toolchain_sha256'] == selected['values']['toolchain_sha256'],
                    f'corpus selected manifest digest differs: {lane}')
            runtime = manifest['targets'][execution['target']]['runtime']
            require(execution['runtime_sha256'] == runtime['sha256'] == sha(package / runtime['path']),
                    f'corpus selected runtime digest differs: {lane}')
    require(linux['compiler_sha256'] == packages['lo-linux-arm64-software']['compiler_sha256'], 'Linux corpus compiler differs')
    require(linux['manifest_sha256'] == packages['lo-linux-arm64-software']['values']['toolchain_sha256'], 'Linux corpus manifest differs')
    offline_path = BASE / 'final-offline-7/validation.json'
    offline = load(offline_path)
    require(offline.get('status') == 'passed', 'offline matrix incomplete')
    success(offline['guard'], 'Darwin isolation guard')
    require(offline['guard']['stdout'] == 'filesystem, network, and descendant restrictions verified\n',
            'offline isolation guard facts differ')
    expected_rejections = {'manifest-missing', 'manifest-corrupt', 'compiler-missing', 'compiler-corrupt',
                           'linker-corrupt', 'runtime-corrupt', 'platform-corrupt', 'kernel-corrupt', 'linux-host-library'}
    rejected = offline['rejections']
    require(len(rejected) == 9 and {item['case'] for item in rejected} == expected_rejections,
            'offline requires exactly nine negative cases')
    for item in rejected:
        require(item.get('status') == 2 and item.get('stdout') == '' and
                item.get('prior_output_preserved') is True and item.get('staging_empty') is True,
                f'offline negative case contract differs: {item.get("case")}')
        diagnostics = json.loads(item['stderr'])['diagnostics']
        require(len(diagnostics) == 1 and diagnostics[0]['code'] == 'build.toolchain',
                f'offline negative diagnostic differs: {item["case"]}')
    negative_summary = [{'case': item['case'], 'status': item['status'],
                         'prior_output_preserved': item['prior_output_preserved'],
                         'staging_empty': item['staging_empty'], 'diagnostic': 'build.toolchain'} for item in rejected]

    expected_matrix = {(host, target) for host in ('darwin/arm64', 'linux/arm64') for target in ('darwin/arm64', 'linux/arm64')}
    actual_matrix = [(item['host'], item['target']) for item in offline['matrix']]
    require(len(actual_matrix) == 4 and set(actual_matrix) == expected_matrix, 'offline host-target matrix differs')
    expected_core = {'large': '123456789012345678901234567891', 'text': 'λ雪', 'count': '3', 'tensor': '6', 'error': 'Math.DivideByZero'}
    for item in [*offline['matrix'], offline['metal'], offline['relocation']]:
        success(item['compile'], 'offline compile')
        success(item['execute'], 'separate artifact execution')
        fields = json.loads(item['execute']['stdout'])['result']['value']['value']
        require({name: value['value'] for name, value in fields.items()} == expected_core, 'representative artifact result differs')
    for short, name in (('darwin', 'lo-darwin-arm64-software'), ('linux', 'lo-linux-arm64-software'), ('metal', 'lo-darwin-arm64-metal')):
        actual = offline['packages'][short]
        for key, value in packages[name]['values'].items():
            require(actual.get(key) == value, f'offline package identity differs: {short}:{key}')
        require(actual['frontend_sha256'] == packages[name]['compiler_sha256'], f'offline compiler differs: {short}')
    require(len(offline['training']) == 2 and {entry['host'] for entry in offline['training']} == {'darwin/arm64', 'linux/arm64'}, 'offline XOR hosts missing')
    xor_values = {}
    for item in offline['training']:
        success(item['compile'], 'offline XOR compile')
        success(item['execute'], 'offline XOR execution')
        fields = json.loads(item['execute']['stdout'])['result']['value']['value']
        require(fields['steps']['value'] == '500' and float(fields['loss']['value']) < 1e-10 < float(fields['initial_loss']['value']), 'offline XOR loss or steps differ')
        predictions = [float(value) for value in fields['predictions']['value']['values']]
        require(len(predictions) == 4 and all(abs(value - expected) <= 1e-4 for value, expected in zip(predictions, (0, 1, 1, 0))), 'offline XOR predictions differ')
        xor_values[item['host']] = {'steps': fields['steps']['value'], 'initial_loss': fields['initial_loss']['value'],
                                    'loss': fields['loss']['value'], 'predictions': fields['predictions']['value']['values']}
    performance = {}
    for short, target in (('darwin', 'darwin/arm64'), ('linux', 'linux/arm64')):
        directory = BASE / 'final-performance-5'
        input_paths = [directory / f'{short}-{lane}/report.json' for lane in ('execution', 'process', 'http', 'build')]
        calculated = performance_merge.merge(input_paths)
        merged_path = directory / f'{short}-merged.json'
        stored = load(merged_path)
        require(stored == calculated, f'stored strict merge differs from recomputed whole lanes: {short}')
        require(calculated['qualification_complete'] is True and calculated['gates_passed'] is True, f'performance gates incomplete: {short}')
        identity = calculated['merge_identity']
        require(identity['target'] == target and identity['source']['semantic_source_sha256'] == source_hash, f'performance target/source differs: {short}')
        package = ROOT / 'bin/distributions' / f'lo-{short}-arm64-software'
        admitted, _ = performance_identity.package_provenance(ROOT, package / 'bin/lo', package / 'toolchain.json', target)
        require(identity['package'] == admitted, f'performance package differs: {short}')
        performance_identity.verify_source_identity(ROOT, identity)
        build = calculated['build']
        performance[target] = {'report': receipt(merged_path), 'lanes': [receipt(path) for path in input_paths],
            'callback_speedup': calculated['callback_speedup'], 'callback_bootstrap_95_percent': calculated['callback_bootstrap_95_percent'],
            'max_build_seconds': max(item['elapsed_ns'] for item in build) / 1e9,
            'max_build_rss_bytes': max(item['peak_process_tree_rss_bytes'] for item in build),
            'max_artifact_bytes': max(item['artifact_bytes'] for item in build),
            'max_diagnostic_bytes': max(item['diagnostic_bytes'] for item in build),
            'merge_identity': identity}
    for details in lanes.values():
        del details['statuses']
    return {'issue': 'I011', 'attempt': 8, 'source_candidate': 7, 'audit_status': 'all_required_evidence_complete',
            'semantic_source_sha256': source_hash, 'freeze': receipt(BASE / 'frozen-inputs-7.json'),
            'driver_status': receipt(BASE / 'final-validation-status-8.json'), 'driver_log': receipt(driver),
            'quiet_environment': {'plan': receipt(plan_path), 'trace': receipt(trace_path), 'summary': receipt(quiet_path),
                                  'driver': driver_identity, 'samples': quiet['samples'], 'passed': True},
            'ci': {'stdout': receipt(ci_stdout), 'stderr': receipt(ci_stderr)},
            'semantic_report': receipt(report_path), 'corpora': lanes, 'ml_required_references': ml,
            'ml_observed_cases': ml_observed, 'go_generation_retirement': retirement,
            'defect_regressions': regression_evidence, 'allocation_preservation_public_tests': allocation_preservation,
            'offline': {'receipt': receipt(offline_path), 'matrix': offline['matrix'], 'training': offline['training'],
                        'separate_metal_and_relocation': True, 'guard': offline['guard'],
                        'negative_cases': negative_summary, 'xor_values': xor_values,
                        'cancellation_scope': 'Separate public CI build test; not an offline matrix cell.'},
            'packages': packages, 'performance': performance,
            'limits': ['This audit does not replace the final independent architect review.',
                       'Physical Metal execution and performance remain unmeasured.',
                       'Module size is an enforced build boundary; reports retain artifact size, not a measured module-size maximum.',
                       'Root must preserve the driver session exit receipt separately.']}


if __name__ == '__main__':
    try:
        result = audit()
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        print(f'Final evidence audit rejected: {error}', file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps(result, indent=2, allow_nan=False))
