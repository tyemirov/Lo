package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/MarcoPoloResearchLab/Lo/internal/adapter"
	"github.com/MarcoPoloResearchLab/Lo/internal/device"
	"github.com/MarcoPoloResearchLab/Lo/internal/diagnostic"
	"github.com/MarcoPoloResearchLab/Lo/internal/execution"
	"github.com/MarcoPoloResearchLab/Lo/internal/types"
	"github.com/MarcoPoloResearchLab/Lo/internal/value"
	"io"
	"os"
	"strconv"
)

const (
	BuildCommand          = "build"
	outputOption          = "--output"
	targetOption          = "--target"
	deviceBackendOption   = "--device-backend"
	ParseCommand          = "parse"
	CheckCommand          = "check"
	InspectCommand        = "inspect"
	RunCommand            = "run"
	ServeCommand          = "serve"
	listenOption          = "--listen"
	httpAllowOption       = "--http-allow"
	processAllowOption    = "--process-allow"
	processLauncherOption = "--process-launcher"
	processReadRootOption = "--process-read-root"
	readRootOption        = "--read-root"
	writeRootOption       = "--write-root"
	listRootOption        = "--list-root"
	removeRootOption      = "--remove-root"
	openFilesRootOption   = "--open-files-root"
	allowDeviceOption     = "--allow-device"
	maxStepsOption        = "--max-steps"
	formatOption          = "--format"
	TextFormat            = "text"
	JsonFormat            = "json"
	ExitSuccess           = 0
	ExitRejected          = 1
	ExitHost              = 2
)

type invocation struct {
	command, path, format string
	output, target        string
	deviceBackend         device.BuildBackend
	readRoots             []string
	writeRoots            []string
	listRoots             []string
	removeRoots           []string
	openFilesRoots        []string
	devices               device.Config
	budget                execution.Budget
	listenPolicy          adapter.ListenPolicy
	httpPolicy            adapter.HTTPPolicy
	processPolicy         adapter.ProcessPolicy
}

func parseArgs(args []string, embedded bool) (invocation, error) {
	inv := invocation{format: TextFormat, budget: execution.DefaultBudget(), devices: device.DefaultConfig(), deviceBackend: device.SoftwareBuild}
	if len(args) == 0 {
		return inv, fmt.Errorf("expected a command: parse, check, inspect, run, or serve")
	}
	inv.command = args[0]
	formatSet := false
	stepsSet := false
	deviceSet := false
	backendSet := false
	var ports []uint16
	var httpGrants []string
	var processGrants, processReadRoots []string
	var processLauncher string
	processLauncherSet := false
	for i := 1; i < len(args); i++ {
		arg := args[i]
		if arg == processAllowOption || arg == processLauncherOption || arg == processReadRootOption {
			if inv.command != RunCommand && inv.command != ServeCommand || i+1 == len(args) {
				return inv, fmt.Errorf("%s requires a value with run or serve", arg)
			}
			i++
			if args[i] == "" {
				return inv, fmt.Errorf("%s requires a nonempty value", arg)
			}
			switch arg {
			case processAllowOption:
				processGrants = append(processGrants, args[i])
			case processLauncherOption:
				if processLauncherSet {
					return inv, fmt.Errorf("duplicate --process-launcher")
				}
				processLauncherSet, processLauncher = true, args[i]
			case processReadRootOption:
				processReadRoots = append(processReadRoots, args[i])
			}
			continue
		}
		if arg == httpAllowOption {
			if inv.command != RunCommand && inv.command != ServeCommand || i+1 == len(args) {
				return inv, fmt.Errorf("--http-allow requires METHOD,ORIGIN,ADDRESS with run or serve")
			}
			i++
			httpGrants = append(httpGrants, args[i])
			continue
		}
		if arg == deviceBackendOption {
			if embedded || inv.command != BuildCommand || backendSet || i+1 == len(args) {
				return inv, fmt.Errorf("--device-backend requires one software or metal value with build")
			}
			i++
			backendSet = true
			var err error
			inv.deviceBackend, err = device.ParseBuildBackend(args[i])
			if err != nil {
				return inv, err
			}
			continue
		}
		if arg == outputOption || arg == targetOption {
			if embedded || inv.command != BuildCommand || i+1 == len(args) {
				return inv, fmt.Errorf("%s requires a value with build", arg)
			}
			i++
			if args[i] == "" {
				return inv, fmt.Errorf("empty %s", arg)
			}
			if arg == outputOption {
				if inv.output != "" {
					return inv, fmt.Errorf("duplicate --output")
				}
				inv.output = args[i]
			} else {
				if inv.target != "" {
					return inv, fmt.Errorf("duplicate --target")
				}
				inv.target = args[i]
			}
			continue
		}

		if arg == allowDeviceOption {
			if deviceSet || i+1 == len(args) || inv.command != RunCommand && inv.command != ServeCommand {
				return inv, fmt.Errorf("--allow-device requires one selector with run or serve")
			}
			i++
			deviceSet = true
			if args[i] == "" || args[i] == device.CPU {
				return inv, fmt.Errorf("--allow-device requires a non-CPU selector")
			}
			var err error
			inv.devices, err = device.NewConfig(args[i], device.DefaultFactory(), nil)
			if err != nil {
				return inv, err
			}
			continue
		}
		if arg == listenOption {
			if inv.command != ServeCommand || i+1 == len(args) {
				return inv, fmt.Errorf("--listen requires a port with serve")
			}
			i++
			port, err := strconv.ParseUint(args[i], 10, 16)
			if err != nil {
				return inv, fmt.Errorf("invalid listen port: %w", err)
			}
			ports = append(ports, uint16(port))
			continue
		}
		if arg == readRootOption || arg == writeRootOption || arg == listRootOption || arg == removeRootOption || arg == openFilesRootOption || arg == maxStepsOption {
			if inv.command != RunCommand && inv.command != ServeCommand || i+1 == len(args) {
				return inv, fmt.Errorf("%s requires a value with run or serve", arg)
			}
			i++
			if arg != maxStepsOption {
				if args[i] == "" {
					return inv, fmt.Errorf("empty adapter root")
				}
				switch arg {
				case readRootOption:
					inv.readRoots = append(inv.readRoots, args[i])
				case writeRootOption:
					inv.writeRoots = append(inv.writeRoots, args[i])
				case listRootOption:
					inv.listRoots = append(inv.listRoots, args[i])
				case removeRootOption:
					inv.removeRoots = append(inv.removeRoots, args[i])
				case openFilesRootOption:
					inv.openFilesRoots = append(inv.openFilesRoots, args[i])
				}
			} else {
				if stepsSet {
					return inv, fmt.Errorf("duplicate --max-steps")
				}
				stepsSet = true
				steps, err := strconv.ParseUint(args[i], 10, 64)
				if err != nil {
					return inv, fmt.Errorf("invalid --max-steps: %w", err)
				}
				inv.budget, err = execution.NewBudget(steps)
				if err != nil {
					return inv, err
				}
			}
			continue
		}
		if arg == formatOption {
			if formatSet || i+1 == len(args) {
				return inv, fmt.Errorf("--format requires one text or json value")
			}
			i++
			inv.format = args[i]
			formatSet = true
			if inv.format != TextFormat && inv.format != JsonFormat {
				return inv, fmt.Errorf("unknown output format %q", inv.format)
			}
			continue
		}
		if len(arg) > 0 && arg[0] == '-' {
			return inv, fmt.Errorf("unknown option %q", arg)
		}
		if inv.path != "" {
			return inv, fmt.Errorf("expected one source path")
		}
		inv.path = arg
	}
	if inv.command != BuildCommand && inv.command != ParseCommand && inv.command != CheckCommand && inv.command != InspectCommand && inv.command != RunCommand && inv.command != ServeCommand {
		return inv, fmt.Errorf("unknown command %q", inv.command)
	}
	if inv.command == BuildCommand && inv.output == "" {
		return inv, fmt.Errorf("build requires --output")
	}
	if !embedded && inv.path == "" {
		return inv, fmt.Errorf("expected one source path")
	}
	if embedded && (inv.path != "" || inv.command != RunCommand && inv.command != ServeCommand) {
		return inv, fmt.Errorf("artifact requires run or serve without a source path")
	}
	var err error
	inv.listenPolicy, err = adapter.NewListenPolicy(ports)
	if err != nil {
		return inv, err
	}
	inv.httpPolicy, err = adapter.NewHTTPPolicy(httpGrants)
	if err != nil {
		return inv, err
	}
	inv.processPolicy, err = adapter.NewProcessPolicy(processGrants, processLauncher, processReadRoots)
	if err != nil {
		return inv, err
	}
	return inv, nil
}

type Options interface {
	Command() string
	Path() string
	Format() string
	Output() string
	Target() string
	DeviceBackend() device.BuildBackend
	options()
}

func (inv invocation) options()                    {}
func (inv invocation) Command() string             { return inv.command }
func (inv invocation) Path() string                { return inv.path }
func (inv invocation) Format() string              { return inv.format }
func ParseCompiler(args []string) (Options, error) { return parseArgs(args, false) }
func Execute(program execution.Program, args []string, stdout, stderr io.Writer) int {
	if adapter.HandleFileProbe(args) {
		return ExitSuccess
	}
	inv, err := parseArgs(args, true)
	if err != nil {
		return Report(stderr, inv.format, diagnostic.New(diagnostic.Invocation, diagnostic.CLI, err.Error(), nil), ExitHost)
	}
	return executeProgram(inv, program, stdout, stderr)
}
func Run(inv Options, program execution.Program, stdout, stderr io.Writer) int {
	return executeProgram(inv.(invocation), program, stdout, stderr)
}
func Main(program execution.Program) { os.Exit(Execute(program, os.Args[1:], os.Stdout, os.Stderr)) }
func ReportRuntime(stderr io.Writer, format string, err error) int {
	var failure execution.Failure
	if errors.As(err, &failure) {
		v := failure.Value()
		d := diagnostic.New(diagnostic.RuntimeUnhandled, diagnostic.Runtime, err.Error(), v.Span())
		if format == JsonFormat {
			type runtimeDiagnostic struct {
				diagnostic.Data
				Error     value.Error                  `json:"error"`
				Flows     []value.Record               `json:"flow_progress,omitempty"`
				Completed execution.ActivationProgress `json:"last_completed_activation,omitempty"`
				Cleanup   []string                     `json:"cleanup_errors,omitempty"`
			}
			payload := runtimeDiagnostic{d.Data(), v, execution.FlowDetails(err), execution.ActivationDetails(err), execution.CleanupDetails(err)}
			if err := json.NewEncoder(stderr).Encode(struct {
				Diagnostics []runtimeDiagnostic `json:"diagnostics"`
			}{[]runtimeDiagnostic{payload}}); err != nil {
				return ExitHost
			}
			return ExitRejected
		}
		if Report(stderr, format, d, ExitRejected) == ExitHost {
			return ExitHost
		}
		for _, frame := range v.Trace() {
			if _, err := fmt.Fprintf(stderr, "  flow %q, operation %q, input %s\n", frame.Field("flow").(value.Text).Text(), frame.Field("operation").(value.Text).Text(), value.TextResult(frame.Field("input"))); err != nil {
				return ExitHost
			}
		}
		return ExitRejected
	}
	code := diagnostic.RuntimeHost
	var host execution.HostError
	if errors.As(err, &host) {
		code = host.Code()
	}
	entries, progress, removal := execution.RemovalDetails(err)
	flows := execution.FlowDetails(err)
	completed := execution.ActivationDetails(err)
	cleanup := execution.CleanupDetails(err)
	httpProgress, progressErr := execution.HTTPProgress(err)
	processProgress := execution.ProcessProgress(err)
	if progressErr != nil {
		return Report(stderr, format, diagnostic.New(diagnostic.RuntimeHost, diagnostic.Runtime, fmt.Sprintf("HTTP progress: %v; original failure: %v", progressErr, err), nil), ExitHost)
	}
	var writeProgress value.Record
	if confirmed, stage, ok := execution.WriteProgress(err); ok {
		stageValue, valueErr := value.NewText(types.String(), stage)
		if valueErr == nil {
			writeProgress, valueErr = value.NewRecord([]value.Field{{Name: "bytes_written", Value: value.Int64(int64(confirmed))}, {Name: "stage", Value: stageValue}})
		}
		if valueErr != nil {
			return Report(stderr, format, diagnostic.New(diagnostic.RuntimeHost, diagnostic.Runtime, fmt.Sprintf("write progress: %v; original failure: %v", valueErr, err), nil), ExitHost)
		}
	}
	if removal || len(flows) > 0 || writeProgress != nil || httpProgress != nil || processProgress != nil || completed != nil || len(cleanup) > 0 {
		data := diagnostic.New(code, diagnostic.Runtime, err.Error(), nil).Data()
		if format == JsonFormat {
			type removalDiagnostic struct {
				diagnostic.Data
				Entries   value.Value                  `json:"removal_entries,omitempty"`
				Progress  value.Record                 `json:"removal_progress,omitempty"`
				Flows     []value.Record               `json:"flow_progress,omitempty"`
				Write     value.Record                 `json:"write_progress,omitempty"`
				HTTP      value.Record                 `json:"http_progress,omitempty"`
				Process   value.Record                 `json:"process_progress,omitempty"`
				Completed execution.ActivationProgress `json:"last_completed_activation,omitempty"`
				Cleanup   []string                     `json:"cleanup_errors,omitempty"`
			}
			var snapshot value.Value
			if entries != nil {
				snapshot = value.Snapshot(entries)
			}
			payload := struct {
				Diagnostics []removalDiagnostic `json:"diagnostics"`
			}{[]removalDiagnostic{{data, snapshot, progress, flows, writeProgress, httpProgress, processProgress, completed, cleanup}}}
			if err := json.NewEncoder(stderr).Encode(payload); err != nil {
				return ExitHost
			}
			return ExitHost
		}
		message := err.Error()
		if removal {
			message += fmt.Sprintf(" (completed %s removals, stage %s)", value.TextResult(progress.Field("completed_count")), value.TextResult(progress.Field("stage")))
		}
		if writeProgress != nil {
			message += fmt.Sprintf(" (wrote %s bytes, stage %s)", value.TextResult(writeProgress.Field("bytes_written")), value.TextResult(writeProgress.Field("stage")))
		}
		if httpProgress != nil {
			message += fmt.Sprintf(" (HTTP stage %s, request written %s, remote outcome %s)", value.TextResult(httpProgress.Field("stage")), value.TextResult(httpProgress.Field("request_written")), value.TextResult(httpProgress.Field("remote_outcome")))
		}
		if processProgress != nil {
			message += " (Process progress " + value.TextResult(processProgress) + ")"
		}
		if completed != nil {
			message += fmt.Sprintf(" (last completed %s at %s:%d: %s)", completed.Operation(), completed.Span().File(), completed.Span().Start().Line, completed.Summary())
		}
		for _, flow := range flows {
			message += fmt.Sprintf(" (Flow.fold completed %s/%s, state %s)", value.TextResult(flow.Field("completed_count")), value.TextResult(flow.Field("total_count")), value.TextResult(flow.Field("state")))
		}
		return Report(stderr, format, diagnostic.New(code, diagnostic.Runtime, message, nil), ExitHost)
	}
	return Report(stderr, format, diagnostic.New(code, diagnostic.Runtime, err.Error(), nil), ExitHost)
}
func Report(stderr io.Writer, format string, d diagnostic.Diagnostic, status int) int {
	var err error
	if format == JsonFormat {
		err = json.NewEncoder(stderr).Encode(struct {
			Diagnostics []diagnostic.Data `json:"diagnostics"`
		}{[]diagnostic.Data{d.Data()}})
	} else {
		_, err = fmt.Fprintln(stderr, d.Error())
	}
	if err != nil {
		return ExitHost
	}
	return status
}

func (inv invocation) Output() string                     { return inv.output }
func (inv invocation) Target() string                     { return inv.target }
func (inv invocation) DeviceBackend() device.BuildBackend { return inv.deviceBackend }
