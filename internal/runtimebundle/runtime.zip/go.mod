module github.com/MarcoPoloResearchLab/Lo

go 1.27.1

require golang.org/x/sys v0.49.0
